// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Plennhar

(() => {
    'use strict';

    const extensionApi = globalThis.browser;
    const HLTV_ORIGIN = 'https://www.hltv.org';
    // Firefox exposes declared MV3 content-script origins through the
    // Permissions API. This lets an update repair a missing persistent grant
    // without duplicating the required origin as an optional AMO permission.
    const HLTV_HOST_PERMISSION = `${HLTV_ORIGIN}/*`;
    const MAX_SOURCE_LIMIT = 50;
    const MAX_HIDDEN_TAGS = 100;
    const MAX_TAG_CHARS = 80;
    const MAX_USER_TAGS = 500;
    const MAX_READ_ENTRIES = 750;
    const MAX_SELF_POST_NUMBERS = 500;
    const MAX_LOCAL_REACTIONS = 10_000;
    const MAX_EXTENDED_MATCH_TEAMS = 50;
    const MAX_TEAM_NAME_CHARS = 100;
    const MAX_USER_NAME_CHARS = 100;
    const MAX_IMPORT_BYTES = 5 * 1024 * 1024;
    const MIN_VALID_TIMESTAMP = 1_262_304_000_000;
    const READ_RETENTION_MS = 120 * 24 * 60 * 60 * 1000;
    const FUTURE_TIMESTAMP_SKEW_MS = 300_000;
    const USER_TAGS_KEY = 'userAnnotationsV1';
    const READ_STATE_KEY = 'readStateV1';
    const LOCAL_REACTIONS_KEY = 'localReactionsV1';
    const PROVISIONAL_LOCAL_UPVOTES_KEY = 'provisionalLocalUpvotesV1';
    const EXTENDED_MATCH_TEAMS_KEY = 'extendedMatchTeamsV1';
    const STATS_OPTIONAL_COLUMNS_KEY = 'statsOptionalColumnsV2';
    const DEBUG_LOG_KEY = 'debugLogV1';
    const MAX_DEBUG_ENTRIES = 500;
    const DEBUG_RETENTION_MS = 7 * 24 * 60 * 60 * 1000;
    const SYNC_PULSE_KEY = 'syncPulseV1';
    const REACTION_LEASE_KEY = 'hltvForumSidebarPlus.localReactionStorageLeaseV1';

    const SOURCES = Object.freeze([
        { id: 'offtopic', label: 'Off-Topic', color: '#e5484d', path: '/forums/offtopic' },
        { id: 'counterstrike', label: 'Counter-Strike', color: '#ffae00', path: '/forums/counterstrike' },
        { id: 'fantasy', label: 'Fantasy', color: '#8e5bd9', path: '/forums/fantasy' },
        { id: 'betting', label: 'Betting', color: '#2ea043', path: '/forums/betting' },
        { id: 'hardware', label: 'Hardware & Tweaks', color: '#9da7b3', path: '/forums/hardware' },
        { id: 'bugs', label: 'Bugs & Suggestions', color: '#3d8bfd', path: '/forums/bugs' },
        { id: 'news', label: 'News', color: '#f778ba', kind: 'news' },
        { id: 'matches', label: 'Matches', color: '#00a6a6', kind: 'matches' },
    ]);
    const DEFAULT_SOURCE_COLORS = Object.freeze(Object.fromEntries(
        SOURCES.map((source) => [source.id, source.color]),
    ));
    const MATCH_PLAYER_METRICS = Object.freeze([
        ['rating', 'Rating'],
        ['kpr', 'KPR'],
        ['dpr', 'DPR'],
        ['kast', 'KAST'],
        ['adr', 'ADR'],
        ['multiKillRating', 'Multi-kill rating'],
        ['roundSwing', 'Round Swing'],
    ]);
    const DEFAULT_MATCH_PLAYER_METRICS = Object.freeze(['rating', 'kpr']);
    const STATS_MATCH_HISTORY_ROW_OPTIONS = Object.freeze([
        100, 200, 300, 400, 500, 'all',
    ]);
    const PERIOD_METRICS = Object.freeze([
        ['rating', 'Rating'],
        ['kpr', 'KPR'],
        ['dpr', 'DPR'],
        ['adr', 'ADR'],
        ['kast', 'KAST'],
        ['net-kpr', 'Net kills per round'],
    ]);
    const STATS_OPTIONAL_COLUMN_IDS = Object.freeze({
        ranking: Object.freeze(['kpr', 'dpr', 'kills-per-map', 'war']),
        matches: Object.freeze(['kpr', 'dpr']),
    });
    const SOURCE_IDS = new Set(SOURCES.map((source) => source.id));
    const FORUM_SOURCES = SOURCES.filter((source) => source.path);
    const FORUM_IDS = new Set(FORUM_SOURCES.map((source) => source.id));
    const FORUM_ID_BY_PATH = new Map(
        FORUM_SOURCES.map((source) => [source.path, source.id]),
    );
    const FEATURE_PAGE_PATH_BY_SETTING = Object.freeze({
        enableCustomThreadFetching: '/',
        enableCustomThreadColors: '/',
        'source-offtopic': '/forums/offtopic',
        'source-counterstrike': '/forums/counterstrike',
        'source-fantasy': '/forums/fantasy',
        'source-betting': '/forums/betting',
        'source-hardware': '/forums/hardware',
        'source-bugs': '/forums/bugs',
        'source-news': '/',
        'source-matches': '/matches',
        layoutWidthPreset: '/',
        largeSidebarText: '/',
        movePostNewTopicToTop: '/',
        enableExtendedMatchFilter: '/matches',
        strictSelectedTeamMatches: '/matches',
        enableThreadPreviews: '/forums',
        enableReadStatus: '/forums',
        showRelativeAges: '/forums',
        replyComposerAfterOriginalPost: '/forums',
        enableUserTags: '/forums',
        hiddenUserTags: '/forums',
        enableLocalUserScores: '/forums',
        enableLocalDownvotes: '/forums',
        changeUpvoteStyle: '/forums',
        enableSignedOutLocalVoting: '/forums',
        enableUsernameBlocking: '/forums',
        enableStickyMatchHeader: '/matches',
        enableMatchPlayerFormOverlays: '/matches',
        enableMatchPrediction: '/matches',
        showFullMapNames: '/stats/players/matches/21167/donk',
        enableStatsColumnChooser: '/stats/players',
        enableStatsMultiSort: '/stats/players',
        enableStatsCsvExport: '/stats/players',
        enablePlayerMatchSparklines: '/stats/players',
        enableStatsTablePeriodComparison: '/stats/players',
        enableTeamPerformanceDifference: '/stats/teams/ftu',
        enablePlayerMapMatrix: '/stats/players',
        enablePlayerConsistencyScore: '/stats/players',
        enablePlayerPagePeriodComparison: '/stats/players',
        enablePlayerComparisonEnhancements: '/stats/players/compare',
    });
    const FEATURE_PAGE_PATHS = new Set(Object.values(FEATURE_PAGE_PATH_BY_SETTING));
    const STATS_FEATURE_PATH_PREFIX = '/stats/';

    const DEFAULTS = Object.freeze({
        selectedSources: ['offtopic', 'counterstrike'],
        sourceLimits: {
            offtopic: 10,
            counterstrike: 10,
            fantasy: 5,
            betting: 5,
            hardware: 5,
            bugs: 5,
            news: 5,
            matches: 5,
        },
        sourceColors: { ...DEFAULT_SOURCE_COLORS },
        enableCustomThreadFetching: true,
        enableCustomThreadColors: true,
        layoutWidthPreset: 'extra',
        largeSidebarText: true,
        movePostNewTopicToTop: true,
        showRelativeAges: true,
        enableExtendedMatchFilter: true,
        strictSelectedTeamMatches: true,
        enableThreadPreviews: true,
        enableOriginalPosterHighlight: true,
        enableReadStatus: true,
        replyComposerAfterOriginalPost: true,
        enableSavedDrafts: true,
        enableUserTags: true,
        hiddenUserTags: [],
        enableLocalUserScores: true,
        enableLocalDownvotes: true,
        changeUpvoteStyle: true,
        enableSignedOutLocalVoting: true,
        enableUsernameBlocking: true,
        enableWinAdjustedRatings: true,
        showFullMapNames: true,
        enableDiagnosticLogging: false,
        enableStickyMatchHeader: true,
        enableMatchPlayerFormOverlays: true,
        enableMatchPrediction: true,
        matchPredictionMode: 'stats',
        enableTeamPerformanceDifference: true,
        matchPlayerPrimaryMetrics: DEFAULT_MATCH_PLAYER_METRICS,
        matchPlayerPrimaryMetric1: 'rating',
        matchPlayerPrimaryMetric2: 'kpr',
        enableStatsColumnChooser: true,
        enableStatsMultiSort: true,
        enableStatsCsvExport: true,
        enablePlayerMatchSparklines: true,
        enableExtendedMatchHistoryLoading: true,
        playerMatchTrendMetric: 'rating',
        statsMatchHistoryRowsV2: 100,
        enablePlayerMapMatrix: true,
        enablePlayerComparisonEnhancements: true,
        enablePlayerConsistencyScore: true,
        enableStatsTablePeriodComparison: true,
        enablePlayerPagePeriodComparison: true,
        previousPeriodMetric: 'rating',
    });

    const SETTINGS_READ_KEYS = Object.freeze([
        'activitySourcesV2',
        'displayedForumsV1',
        'selectedForums',
        'hideMatches',
        'hideNews',
        'removeNewsMatches',
        'forumThreadLimits',
        'activitySourceColorsV1',
        'enableCustomThreadFetching',
        'enableCustomThreadColors',
        'layoutWidthPreset',
        'largeSidebarText',
        'movePostNewTopicToTop',
        'showRelativeAges',
        'enableExtendedMatchFilter',
        'strictSelectedTeamMatches',
        'enableThreadPreviews',
        'enableOriginalPosterHighlight',
        'enableReadStatus',
        'replyComposerAfterOriginalPost',
        'enableSavedDrafts',
        'enableUserTags',
        'hiddenUserTags',
        'enableLocalUserScores',
        'enableLocalDownvotes',
        'changeUpvoteStyle',
        'enableSignedOutLocalVoting',
        'enableUsernameBlocking',
        'showFullMapNames',
        'enableDiagnosticLogging',
        'enableStickyMatchHeader',
        'enableMatchPlayerFormOverlays',
        'enableMatchPrediction',
        'matchPredictionMode',
        'enableTeamPerformanceDifference',
        'matchPlayerPrimaryMetrics',
        'matchPlayerPrimaryMetric1',
        'matchPlayerPrimaryMetric2',
        'enableStatsColumnChooser',
        'enableStatsMultiSort',
        'enableStatsCsvExport',
        'enablePlayerMatchSparklines',
        'enableExtendedMatchHistoryLoading',
        'playerMatchTrendMetric',
        'statsMatchHistoryRowsV2',
        'enablePlayerMapMatrix',
        'enablePlayerComparisonEnhancements',
        'enablePlayerConsistencyScore',
        'enableStatsTablePeriodComparison',
        'enablePlayerPagePeriodComparison',
        'previousPeriodMetric',
        STATS_OPTIONAL_COLUMNS_KEY,
        // Read-only migration inputs. They are never saved or exported again.
        'enableKprEstimate',
        'enableKprMatchHistory',
        'enableStatsAutoFitColumns',
        'enableDerivedStatsColumns',
        'enablePreviousPeriodComparison',
    ]);
    const SETTINGS_EXPORT_READ_KEYS = Object.freeze([
        ...SETTINGS_READ_KEYS,
        EXTENDED_MATCH_TEAMS_KEY,
        'sortOrder',
        'winAdjustedAutoRun',
        'statsColumnLayoutV2',
        'statsMultiSortV2',
    ]);
    const CURRENT_BOOLEAN_SETTING_KEYS = Object.freeze([
        'enableCustomThreadFetching',
        'enableCustomThreadColors',
        'largeSidebarText',
        'movePostNewTopicToTop',
        'showRelativeAges',
        'enableExtendedMatchFilter',
        'strictSelectedTeamMatches',
        'enableThreadPreviews',
        'enableOriginalPosterHighlight',
        'enableReadStatus',
        'replyComposerAfterOriginalPost',
        'enableSavedDrafts',
        'enableUserTags',
        'enableLocalUserScores',
        'enableLocalDownvotes',
        'changeUpvoteStyle',
        'enableSignedOutLocalVoting',
        'enableUsernameBlocking',
        'enableWinAdjustedRatings',
        'showFullMapNames',
        'enableDiagnosticLogging',
        'enableStickyMatchHeader',
        'enableMatchPlayerFormOverlays',
        'enableMatchPrediction',
        'enableTeamPerformanceDifference',
        'enableStatsColumnChooser',
        'enableStatsMultiSort',
        'enableStatsCsvExport',
        'enablePlayerMatchSparklines',
        'enableExtendedMatchHistoryLoading',
        'enablePlayerMapMatrix',
        'enablePlayerComparisonEnhancements',
        'enablePlayerConsistencyScore',
        'enableStatsTablePeriodComparison',
        'enablePlayerPagePeriodComparison',
    ]);
    const USER_DATA_EXPORT_READ_KEYS = Object.freeze([
        USER_TAGS_KEY,
        READ_STATE_KEY,
        LOCAL_REACTIONS_KEY,
        PROVISIONAL_LOCAL_UPVOTES_KEY,
        EXTENDED_MATCH_TEAMS_KEY,
    ]);

    const WIN_ADJUSTED_RATINGS_DESCRIPTION = [
        'The calculation of WAR starts with each player\'s normal HLTV rating, then estimates how much ratings on this page tend to rise or fall with team success. For each one-team player, it turns the team\'s wins, draws, and losses into a team win percentage. It then looks across all usable players on the page and measures the general relationship between team win percentage and player rating. If players on stronger teams tend to have higher ratings, the script treats part of that rating as team-context inflation. Each player\'s rating is then adjusted by removing the amount explained by being on a team above or below the page\'s average team win percentage. Players on stronger-than-average teams are pulled down; players on weaker-than-average teams are lifted. Players with multiple teams are not adjusted and show ?, because the script cannot know how much of their rating came from each team. The result, WAR, is not a perfect measure of individual skill; it is a simple team-win correction meant to make ratings less dependent on how often the player\'s team won.',
        '',
        'Yes, it works with filters.',
        '',
        'Calculation',
        '',
        'Variables',
        '* R_i: HLTV Rating',
        '* W_i: Team win %',
        '* W_avg: Average team win % across teams present on the table',
        '* \u03B2\u0302: Estimated rating change for a 100 percentage-point win-rate difference [\u03B2\u0302 = Cov(W, R) / Var(W)]',
        '',
        'Final formula',
        '* WAR_i = R_i - \u03B2\u0302 * (W_i - W_avg)',
    ].join('\n');
    const SCREENSHOTS = Object.freeze({
        changeUpvoteStyle: [
            {
                file: 'change-upvoted-comments-to-green.png',
                alt: 'An active HLTV upvote button displayed in green.',
            },
        ],
        enableThreadPreviews: [
            {
                file: 'thread-preview.png',
                alt: 'A thread preview opened from a recent-activity title.',
            },
        ],
        enableReadStatus: [
            {
                file: 'thread-read-status.png',
                alt: 'Recent-activity rows with read and unread indicators.',
            },
        ],
        showRelativeAges: [
            {
                file: 'show_relative_post_ages_in_threads_and_previews.png',
                alt: 'A compact relative age displayed beside a forum post timestamp.',
            },
        ],
        movePostNewTopicToTop: [
            {
                file: 'move_post_new_topic_to_the_top_of_the_sidebar.png',
                alt: 'The Post new topic control above the recent-activity sidebar rows.',
            },
        ],
        enableExtendedMatchFilter: [
            {
                file: 'add_more_teams_to_the_match_filter.png',
                alt: 'An expanded HLTV match filter containing more than five selected teams.',
            },
        ],
        replyComposerAfterOriginalPost: [
            {
                file: 'reply-composer-below-original-post.png',
                alt: 'The reply composer placed directly below the original post.',
            },
        ],
        enableLocalUserScores: [
            {
                file: 'local-user-reaction-counter.png',
                alt: 'A local reaction counter displayed beside an HLTV username.',
            },
        ],
        enableLocalDownvotes: [
            {
                file: 'local-downvote-button.png',
                alt: 'A local minus button displayed beside the HLTV upvote button.',
            },
        ],
        enableUserTags: [
            {
                file: 'enable_local_user_tags.png',
                alt: 'A private local tag displayed after an HLTV username.',
            },
        ],
        enableUsernameBlocking: [
            {
                file: 'enable_right-lcikc_username_actions.png',
                alt: 'A right-click username menu with profile and block actions.',
            },
        ],
        enableStickyMatchHeader: [
            {
                file: 'show_a_sticky_match_header_while_scrolling.png',
                alt: 'A compact live match header remaining visible while the match page is scrolled.',
            },
        ],
        enableMatchPlayerFormOverlays: [
            {
                file: 'show_recent-form_statistics_on_match_lineups.png',
                alt: 'Recent Rating and KPR statistics overlaid on match-lineup player cards.',
            },
        ],
        enableMatchPrediction: [
            {
                file: 'show_match_result_predictions.png',
                alt: 'A match prediction showing the predicted winner, win probability, and likely score.',
            },
        ],
        showFullMapNames: [
            {
                file: 'show_full_map_names_on_player_match_history_pages.png',
                alt: 'Full map names displayed in a player match-history table.',
            },
        ],
        enableStatsColumnChooser: [
            {
                file: 'win-adjusted-ratings.png',
                alt: 'A player statistics table with the win-adjusted rating column.',
            },
            {
                file: 'kpr-ranking-table.png',
                alt: 'Estimated KPR ranges in a player ranking table.',
            },
            {
                file: 'kpr-match-history.png',
                alt: 'Actual KPR values in a player match-history table.',
            },
            {
                file: 'enable_stats-table_column_controls.png',
                alt: 'The stats-table Columns menu beside a configurable player match-history table.',
            },
        ],
        enableStatsMultiSort: [
            {
                file: 'enable_multi-column_sorting.png',
                alt: 'A player match-history table sorted by multiple numbered columns.',
            },
        ],
        enablePlayerMatchSparklines: [
            {
                file: 'show_selectable_player_match-history_trends.png',
                alt: 'A selectable Rating trend chart above a player match-history table.',
            },
        ],
        enableStatsTablePeriodComparison: [
            {
                file: 'compare_stats-table_data_with_another_date_period.png',
                alt: 'A stats ranking table with baseline date controls and a rating-delta column.',
            },
        ],
        enableTeamPerformanceDifference: [
            {
                file: 'show_team_overperformance_score.png',
                alt: 'A team FTU table with a sortable Overperformance Score column.',
            },
        ],
        enablePlayerMapMatrix: [
            {
                file: 'add_a_map-by-stat_matrix_to_player_pages.png',
                alt: 'A player Map matrix tab with map-by-stat performance values.',
            },
        ],
        enablePlayerComparisonEnhancements: [
            {
                file: 'enhance_player_comparison_pages.png',
                alt: 'A player comparison page with configurable match-history trend lines.',
            },
            {
                file: 'bug_comparison_page_graph_color.png',
                alt: 'A two-player Rating history graph with a distinct color for each player.',
            },
        ],
        enablePlayerConsistencyScore: [
            {
                file: 'show_a_player_consistency_score.png',
                alt: 'A player consistency score and its explanatory hover popup.',
            },
        ],
        enablePlayerPagePeriodComparison: [
            {
                file: 'compare_player-page_statistics_with_another_date_period.png',
                alt: 'A player statistics page with baseline date comparison controls and deltas.',
            },
        ],
    });

    const popupState = {
        ready: false,
        hiddenTags: [],
        statsOptionalColumns: normaliseStatsOptionalColumns(null),
        editingTagIndex: -1,
        dirty: false,
        externalChangeWhileDirty: false,
        saving: false,
        importing: false,
        exportSequence: 0,
    };

    function makeElement(tagName, className = '', text = '') {
        const element = document.createElement(tagName);
        if (className) element.className = className;
        if (text) element.textContent = text;
        return element;
    }

    function createInfoIcon() {
        const namespace = 'http://www.w3.org/2000/svg';
        const svg = document.createElementNS(namespace, 'svg');
        svg.setAttribute('viewBox', '0 0 16 16');
        svg.setAttribute('aria-hidden', 'true');
        svg.setAttribute('focusable', 'false');

        const circle = document.createElementNS(namespace, 'circle');
        circle.setAttribute('cx', '8');
        circle.setAttribute('cy', '8');
        circle.setAttribute('r', '6.25');
        circle.setAttribute('fill', 'none');
        circle.setAttribute('stroke', 'currentColor');
        circle.setAttribute('stroke-width', '1.5');

        const stem = document.createElementNS(namespace, 'path');
        stem.setAttribute('d', 'M8 7.1v4');
        stem.setAttribute('fill', 'none');
        stem.setAttribute('stroke', 'currentColor');
        stem.setAttribute('stroke-linecap', 'round');
        stem.setAttribute('stroke-width', '1.6');

        const dot = document.createElementNS(namespace, 'circle');
        dot.setAttribute('cx', '8');
        dot.setAttribute('cy', '4.65');
        dot.setAttribute('r', '0.9');
        dot.setAttribute('fill', 'currentColor');

        svg.append(circle, stem, dot);
        return svg;
    }

    function populateScreenshots(help, settingKey) {
        if (help.dataset.screenshotsLoaded === 'true') return;
        const screenshots = SCREENSHOTS[settingKey] || [];
        if (!screenshots.length) return;
        const gallery = makeElement('div', 'setting-screenshots');
        gallery.setAttribute('aria-label', 'Setting screenshots');
        for (const screenshot of screenshots) {
            const path = `assets/screenshots/${screenshot.file}`;
            const url = extensionApi.runtime.getURL(path);
            const link = makeElement('a', 'setting-screenshot-link');
            link.href = url;
            link.target = '_blank';
            link.rel = 'noopener noreferrer';
            link.title = 'Open full-size screenshot in a new tab';

            const image = makeElement('img', 'setting-screenshot');
            image.src = url;
            image.alt = screenshot.alt;
            image.loading = 'lazy';
            image.decoding = 'async';
            link.appendChild(image);
            gallery.appendChild(link);
        }
        help.appendChild(gallery);
        help.dataset.screenshotsLoaded = 'true';
    }

    function featurePageDateRange(now = new Date()) {
        const end = now instanceof Date && Number.isFinite(now.getTime())
            ? now
            : new Date();
        const endYear = end.getFullYear();
        const endMonth = end.getMonth();
        const endDay = end.getDate();
        const targetMonthIndex = endMonth - 3;
        const startYear = endYear + Math.floor(targetMonthIndex / 12);
        const startMonth = ((targetMonthIndex % 12) + 12) % 12;
        const lastStartMonthDay = new Date(startYear, startMonth + 1, 0).getDate();
        const start = new Date(startYear, startMonth, Math.min(endDay, lastStartMonthDay));
        const format = (date) => [
            String(date.getFullYear()).padStart(4, '0'),
            String(date.getMonth() + 1).padStart(2, '0'),
            String(date.getDate()).padStart(2, '0'),
        ].join('-');
        return { startDate: format(start), endDate: format(end) };
    }

    function featurePageUrl(path) {
        if (!FEATURE_PAGE_PATHS.has(path)) return null;
        const url = new URL(path, HLTV_ORIGIN);
        if (url.origin !== HLTV_ORIGIN || url.pathname !== path) return null;
        if (path.startsWith(STATS_FEATURE_PATH_PREFIX)) {
            const range = featurePageDateRange();
            url.searchParams.set('startDate', range.startDate);
            url.searchParams.set('endDate', range.endDate);
        }
        return url;
    }

    function openFeaturePage(settingKey) {
        const path = FEATURE_PAGE_PATH_BY_SETTING[settingKey];
        const url = featurePageUrl(path);
        if (!url) return;
        if (typeof extensionApi?.tabs?.create === 'function') {
            extensionApi.tabs.create({ url: url.href })?.catch?.(() => undefined);
            return;
        }
        globalThis.open?.(url.href, '_blank', 'noopener,noreferrer');
    }

    function createSettingRow({
        settingKey,
        label,
        description,
        primary,
        secondary = [],
        body = [],
        helpBody = [],
        className = '',
    }) {
        const row = makeElement('div', `setting-row ${className}`.trim());
        row.dataset.settingRow = settingKey;
        const line = makeElement('div', 'setting-line');
        const primaryContainer = makeElement('div');
        primaryContainer.appendChild(primary);
        line.appendChild(primaryContainer);
        for (const item of secondary) line.appendChild(item);

        const helpId = `popup-help-${settingKey}`;
        const info = makeElement('button', 'info-button');
        info.type = 'button';
        info.title = 'Show information';
        info.setAttribute('aria-label', `Show information about ${label}`);
        info.setAttribute('aria-controls', helpId);
        info.setAttribute('aria-expanded', 'false');
        info.appendChild(createInfoIcon());
        line.appendChild(info);

        const help = makeElement('div', 'setting-help');
        help.id = helpId;
        help.hidden = true;
        help.appendChild(makeElement('p', '', description));
        help.append(...helpBody);
        if (FEATURE_PAGE_PATH_BY_SETTING[settingKey]) {
            const featurePage = makeElement(
                'button',
                'feature-page-action',
                'Try it on HLTV',
            );
            featurePage.type = 'button';
            featurePage.addEventListener('click', () => openFeaturePage(settingKey));
            help.appendChild(featurePage);
        }
        info.addEventListener('click', () => {
            const opening = help.hidden;
            help.hidden = !opening;
            info.setAttribute('aria-expanded', opening ? 'true' : 'false');
            info.title = opening ? 'Hide information' : 'Show information';
            if (opening) populateScreenshots(help, settingKey);
        });

        row.append(line, ...body, help);
        return row;
    }

    function createCheckboxPrimary(settingKey, label) {
        const control = makeElement('label', 'setting-primary');
        const input = document.createElement('input');
        input.type = 'checkbox';
        input.id = `popup-setting-${settingKey}`;
        input.dataset.settingKey = settingKey;
        control.htmlFor = input.id;
        control.append(input, makeElement('span', '', label));
        return { control, input };
    }

    function createCheckboxRow(settingKey, label, description, options = {}) {
        const { control, input } = createCheckboxPrimary(settingKey, label);
        const secondary = typeof options.secondary === 'function'
            ? options.secondary(input)
            : options.secondary || [];
        return {
            row: createSettingRow({
                settingKey,
                label,
                description,
                primary: control,
                secondary,
                body: options.body || [],
                helpBody: options.helpBody || [],
                className: options.className || '',
            }),
            input,
        };
    }

    function createSelect(settingKey, options, label) {
        const select = document.createElement('select');
        select.id = `popup-setting-${settingKey}`;
        select.dataset.settingSelect = settingKey;
        select.title = label;
        select.setAttribute('aria-label', label);
        for (const [value, text] of options) {
            const option = document.createElement('option');
            option.value = value;
            option.textContent = text;
            select.append(option);
        }
        return select;
    }

    function createMatchPlayerMetricOptions() {
        const group = makeElement('div', 'match-player-metric-options');
        group.dataset.matchPlayerMetricOptions = 'true';
        group.setAttribute('role', 'group');
        group.setAttribute('aria-label', 'Statistics shown on match lineup player cards');
        for (const [value, labelText] of MATCH_PLAYER_METRICS) {
            const label = makeElement('label', 'match-player-metric-option');
            const input = document.createElement('input');
            input.type = 'checkbox';
            input.value = value;
            input.dataset.matchPlayerMetric = value;
            label.append(input, makeElement('span', '', labelText));
            group.appendChild(label);
        }
        group.addEventListener('change', (event) => {
            if (group.querySelector('input[data-match-player-metric]:checked')) return;
            if (event.target instanceof HTMLInputElement) event.target.checked = true;
        });
        return group;
    }

    function matchPlayerMetricsFromUi() {
        return normaliseMatchPlayerMetrics(
            [...document.querySelectorAll(
                '[data-match-player-metric-options] input[data-match-player-metric]:checked',
            )].map((input) => input.value),
        );
    }

    function createFieldset(legendText, className = 'setting-list') {
        const fieldset = document.createElement('fieldset');
        fieldset.appendChild(makeElement('legend', '', legendText));
        const contents = makeElement('div', className);
        fieldset.appendChild(contents);
        return { fieldset, contents };
    }

    function sourceDescription(source) {
        if (source.kind === 'news') {
            return 'Keep native news rows and fetch up to this many additional front-page news entries.';
        }
        if (source.kind === 'matches') {
            return "Keep native match rows and fetch up to this many additional front-page matches without changing HLTV's match filter.";
        }
        return `Keep native ${source.label} rows and fetch up to this many additional older threads.`;
    }

    function buildSourceSettings(container) {
        const customFetching = createCheckboxRow(
            'enableCustomThreadFetching',
            'Fetch additional recent-activity threads',
            'Add more forum, news, and match rows from the sources you select. Turning this off removes extension-added rows while keeping your source choices.',
            { className: 'recent-activity-master' },
        );
        const customColors = createCheckboxRow(
            'enableCustomThreadColors',
            'Use custom recent-activity thread colors',
            'Apply the saved source colors to native and extension-added recent-activity rows and preview accents. Turning this off restores HLTV\'s native row styling without deleting your saved colors.',
            { className: 'recent-activity-master' },
        );
        customFetching.row.style.gridColumn = '1 / -1';
        customColors.row.style.gridColumn = '1 / -1';
        container.append(customFetching.row, customColors.row);

        for (const source of SOURCES) {
            const label = makeElement('label', 'setting-primary');
            label.style.setProperty('--source-color', source.color);
            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.id = `popup-source-${source.id}`;
            checkbox.dataset.sourceId = source.id;
            label.htmlFor = checkbox.id;
            label.append(checkbox, makeElement('span', '', source.label));

            const limit = document.createElement('input');
            limit.type = 'number';
            limit.className = 'source-limit';
            limit.dataset.sourceLimit = source.id;
            limit.min = '1';
            limit.max = String(MAX_SOURCE_LIMIT);
            limit.step = '1';
            limit.title = `Maximum additional ${source.label} entries to fetch`;
            limit.setAttribute('aria-label', limit.title);

            const color = document.createElement('input');
            color.type = 'color';
            color.className = 'source-color';
            color.dataset.sourceColor = source.id;
            color.title = `Change the ${source.label} thread color`;
            color.setAttribute('aria-label', color.title);

            const row = createSettingRow({
                settingKey: `source-${source.id}`,
                label: source.label,
                description: sourceDescription(source),
                primary: label,
                secondary: [limit],
                className: 'source-row',
            });
            row.style.setProperty('--source-color', source.color);
            color.addEventListener('input', () => {
                row.style.setProperty(
                    '--source-color',
                    normaliseSourceColor(color.value, source.color),
                );
            });
            row.prepend(color);
            container.appendChild(row);
        }

        const note = makeElement('div', 'source-color-note');
        note.appendChild(makeElement('span', '', 'Click a color bar to change it.'));
        const reset = makeElement('button', 'source-color-reset', 'Reset colors');
        reset.type = 'button';
        reset.addEventListener('click', () => {
            for (const source of SOURCES) {
                const color = document.querySelector(`[data-source-color="${source.id}"]`);
                if (!color) continue;
                color.value = DEFAULT_SOURCE_COLORS[source.id];
                color.closest('.source-row')?.style.setProperty(
                    '--source-color',
                    color.value,
                );
            }
            if (popupState.ready) popupState.dirty = true;
        });
        note.appendChild(reset);
        const firstSourceRow = container.querySelector('.source-row');
        container.insertBefore(note, firstSourceRow);

        const syncSourceControls = () => {
            const fetchEnabled = customFetching.input.checked;
            const colorsEnabled = customColors.input.checked;
            for (const input of container.querySelectorAll('[data-source-limit]')) {
                input.disabled = !fetchEnabled;
            }
            for (const input of container.querySelectorAll('[data-source-color]')) {
                input.disabled = !colorsEnabled;
            }
            reset.disabled = !colorsEnabled;
            note.style.opacity = colorsEnabled ? '' : '0.55';
        };
        customFetching.input.addEventListener('change', syncSourceControls);
        customColors.input.addEventListener('change', syncSourceControls);
        container.dataset.syncSourceControls = 'true';
        container.syncSourceControls = syncSourceControls;
    }

    function buildLayoutSettings(container) {
        const widthLabel = makeElement('label', 'setting-primary', 'Page and recent-activity width');
        widthLabel.htmlFor = 'popup-setting-layoutWidthPreset';
        const select = document.createElement('select');
        select.id = 'popup-setting-layoutWidthPreset';
        select.dataset.settingSelect = 'layoutWidthPreset';
        for (const [value, label] of [
            ['default', 'HLTV default'],
            ['wide', 'Wide (+120 main / +80 sidebar)'],
            ['extra', 'Extra wide (+240 main / +140 sidebar)'],
        ]) {
            const option = document.createElement('option');
            option.value = value;
            option.textContent = label;
            select.appendChild(option);
        }
        container.appendChild(createSettingRow({
            settingKey: 'layoutWidthPreset',
            label: 'Page and recent-activity width',
            description: 'Desktop only. Widen the main page and recent-activity sidebar using available side space; the layout scales down on narrower windows.',
            primary: widthLabel,
            secondary: [select],
        }));

        const larger = createCheckboxRow(
            'largeSidebarText',
            'Use larger recent-activity thread text',
            'Increase recent-activity title size and row height for easier reading on large displays.',
        );
        container.appendChild(larger.row);

    }

    function buildSidebarSettings(container) {
        const moveTopic = createCheckboxRow(
            'movePostNewTopicToTop',
            'Move Post new topic to the top of the sidebar',
            "Move HLTV's Post new topic control to the top of the forum sidebar while keeping the original control functional.",
        );
        container.appendChild(moveTopic.row);
    }

    function buildMatchSettings(container) {
        const extended = createCheckboxRow(
            'enableExtendedMatchFilter',
            'Add more teams to the match filter',
            "Extend HLTV's native Search team field beyond its five built-in team slots. Extra selections appear in the same Team list, stay local, and work only while HLTV's match filter is enabled.",
        );
        container.appendChild(extended.row);

        const strict = createCheckboxRow(
            'strictSelectedTeamMatches',
            'Only show matches involving selected teams',
            "While HLTV's own match filter is enabled, exclude high-status and other matches unless at least one selected native or additional team is playing. Turning off HLTV's filter restores its normal unfiltered view.",
        );
        container.appendChild(strict.row);

        const note = makeElement(
            'p',
            'group-note',
            'Selected match teams are managed on HLTV pages and are left untouched by this popup.',
        );
        container.appendChild(note);

    }

    function buildMatchPageSettings(container) {
        container.appendChild(createCheckboxRow(
            'enableStickyMatchHeader',
            'Show a sticky match header while scrolling',
            'Keep a compact match summary below HLTV\'s navigation after the normal header scrolls away. Scheduled, TBD, live, and finished matches are supported; live summaries update the series, map, round, and current score.',
        ).row);

        const metricOptions = createMatchPlayerMetricOptions();
        const overlays = createCheckboxRow(
            'enableMatchPlayerFormOverlays',
            'Show recent-form statistics on match lineups',
            'Use Past 3 months values on each player image. Choose any combination of Rating, KPR, DPR, KAST, ADR, multi-kill, and Round Swing below; the same chooser is available from the Lineup stats button on supported match pages.',
            { helpBody: [metricOptions] },
        );
        container.appendChild(overlays.row);

        container.appendChild(createCheckboxRow(
            'enableMatchPrediction',
            'Show match result predictions',
            'Estimate the likely winner before a match using the announced lineup, recent player performance and map matchups, or bookmaker odds shown by HLTV. HLTV stats is the default and includes the detailed calculation breakdown. At most three additional HLTV fetch attempts run per match-page visit. Market-estimated uses only the median of valid de-vigged bookmaker probabilities, never falls back to page statistics, and reports when odds are unavailable. Predictions are estimates, not betting advice.',
        ).row);

    }

    function buildThreadSettings(container) {
        for (const definition of [
            [
                'enableThreadPreviews',
                'Enable thread previews on title hover',
                'Hover a forum title to load its original post, comments, votes, tags, and reply controls without leaving the current page.',
            ],
            [
                'enableReadStatus',
                'Enable thread read status and first-unread tracking',
                'Track read threads locally and add first-unread jump controls to thread pages and previews. Scrolling inside a preview or keeping it open continuously for five seconds marks its loaded comments as read; your own replies are ignored as unread.',
            ],
            [
                'showRelativeAges',
                'Show relative post ages in threads and previews',
                'Show a compact relative age beside post timestamps on full thread pages and inside previews. Hover an age to see the exact local date and time.',
            ],
            [
                'replyComposerAfterOriginalPost',
                'Place the main reply composer above the comments',
                'Move the thread-level reply box directly below the original post on thread pages and inside previews. Threaded reply boxes remain beside their target comments.',
            ],
            [
                'enableOriginalPosterHighlight',
                'Highlight posts by the original poster',
                'Give the thread creator\'s username a blue background with white text on their original post and later replies, both on normal thread pages and in thread previews.',
            ],
            [
                'enableSavedDrafts',
                'Add saved-draft controls to forum composers',
                'Add Save as draft and Restore saved draft controls to new-topic, thread-reply, and preview composers. Turning this off removes those composer controls without deleting saved records; the on-site draft manager remains available.',
            ],
        ]) {
            container.appendChild(createCheckboxRow(...definition).row);
        }
    }

    function normaliseTag(value) {
        return String(value ?? '')
            .replace(/[\r\n]+/g, ' ')
            .trim()
            .slice(0, MAX_TAG_CHARS);
    }

    function normaliseHiddenTags(value) {
        const source = Array.isArray(value)
            ? value
            : typeof value === 'string' ? value.split(/\r?\n/) : [];
        const tags = [];
        const seen = new Set();
        for (const rawTag of source) {
            const tag = normaliseTag(rawTag);
            if (!tag || seen.has(tag)) continue;
            seen.add(tag);
            tags.push(tag);
            if (tags.length >= MAX_HIDDEN_TAGS) break;
        }
        return tags;
    }

    function hiddenTagElements() {
        return {
            editor: document.querySelector('#popup-hidden-tags-editor'),
            list: document.querySelector('#popup-hidden-tags-list'),
            input: document.querySelector('#popup-hidden-tag-input'),
            commit: document.querySelector('#popup-hidden-tag-commit'),
            cancel: document.querySelector('#popup-hidden-tag-cancel'),
        };
    }

    function setStatus(message, isError = false) {
        const status = document.querySelector('#settings-status');
        if (!status) return;
        status.textContent = message;
        status.classList.toggle('error', Boolean(isError));
    }

    function beginHiddenTagEdit(index) {
        const elements = hiddenTagElements();
        if (!elements.input || index < 0 || index >= popupState.hiddenTags.length) return;
        popupState.editingTagIndex = index;
        elements.input.value = popupState.hiddenTags[index];
        elements.commit.textContent = 'Update';
        elements.cancel.hidden = false;
        elements.input.focus();
        elements.input.select();
    }

    function cancelHiddenTagEdit() {
        const elements = hiddenTagElements();
        popupState.editingTagIndex = -1;
        if (elements.input) elements.input.value = '';
        if (elements.commit) elements.commit.textContent = 'Add tag';
        if (elements.cancel) elements.cancel.hidden = true;
    }

    function renderHiddenTags() {
        const { list } = hiddenTagElements();
        if (!list) return;
        list.replaceChildren();
        if (!popupState.hiddenTags.length) {
            list.appendChild(makeElement('span', 'tag-empty', 'No tags are hidden.'));
            return;
        }
        popupState.hiddenTags.forEach((tag, index) => {
            const chip = makeElement('span', 'tag-chip');
            const value = makeElement('span', 'tag-value', tag);
            value.title = tag;

            const edit = makeElement('button', '', 'Edit');
            edit.type = 'button';
            edit.dataset.editTagIndex = String(index);
            edit.addEventListener('click', () => beginHiddenTagEdit(index));

            const remove = makeElement('button', '', '\u00D7');
            remove.type = 'button';
            remove.dataset.removeTagIndex = String(index);
            remove.title = `Remove hidden tag ${tag}`;
            remove.setAttribute('aria-label', remove.title);
            remove.addEventListener('click', () => {
                popupState.hiddenTags.splice(index, 1);
                popupState.dirty = true;
                cancelHiddenTagEdit();
                renderHiddenTags();
                syncHiddenTagControls();
                setStatus('');
            });
            chip.append(value, edit, remove);
            list.appendChild(chip);
        });
    }

    function syncHiddenTagControls() {
        const enabled = Boolean(
            document.querySelector('[data-setting-key="enableUserTags"]')?.checked,
        );
        const { editor, input, commit, cancel } = hiddenTagElements();
        if (editor) editor.dataset.disabled = enabled ? 'false' : 'true';
        if (input) input.disabled = !enabled;
        if (commit) {
            commit.disabled = !enabled
                || (popupState.editingTagIndex < 0
                    && popupState.hiddenTags.length >= MAX_HIDDEN_TAGS);
        }
        if (cancel) cancel.disabled = !enabled;
        for (const button of editor?.querySelectorAll('.tag-chip button') || []) {
            button.disabled = !enabled;
        }
    }

    function commitHiddenTag() {
        const { input } = hiddenTagElements();
        const tag = normaliseTag(input?.value);
        if (!tag) {
            setStatus('Enter a nonempty tag.', true);
            return;
        }
        const editingIndex = popupState.editingTagIndex;
        if (popupState.hiddenTags.some((candidate, index) => (
            candidate === tag && index !== editingIndex
        ))) {
            setStatus('That exact tag is already in the hidden list.', true);
            return;
        }
        if (editingIndex >= 0 && editingIndex < popupState.hiddenTags.length) {
            popupState.hiddenTags[editingIndex] = tag;
        } else {
            if (popupState.hiddenTags.length >= MAX_HIDDEN_TAGS) {
                setStatus(`At most ${MAX_HIDDEN_TAGS} hidden tags are allowed.`, true);
                return;
            }
            popupState.hiddenTags.push(tag);
        }
        popupState.dirty = true;
        cancelHiddenTagEdit();
        renderHiddenTags();
        syncHiddenTagControls();
        setStatus('');
    }

    function buildHiddenTagEditor() {
        const editor = makeElement('div', 'tag-editor');
        editor.id = 'popup-hidden-tags-editor';

        const list = makeElement('div', 'tag-list');
        list.id = 'popup-hidden-tags-list';

        const actions = makeElement('div', 'tag-editor-actions');
        const input = document.createElement('input');
        input.id = 'popup-hidden-tag-input';
        input.type = 'text';
        input.maxLength = MAX_TAG_CHARS;
        input.placeholder = 'Exact tag';
        input.setAttribute('aria-label', 'Hidden tag');
        input.addEventListener('keydown', (event) => {
            if (event.key !== 'Enter') return;
            event.preventDefault();
            commitHiddenTag();
        });

        const commit = makeElement('button', '', 'Add tag');
        commit.id = 'popup-hidden-tag-commit';
        commit.type = 'button';
        commit.addEventListener('click', commitHiddenTag);

        const cancel = makeElement('button', 'tag-cancel', 'Cancel');
        cancel.id = 'popup-hidden-tag-cancel';
        cancel.type = 'button';
        cancel.hidden = true;
        cancel.addEventListener('click', cancelHiddenTagEdit);

        actions.append(input, commit, cancel);
        editor.append(list, actions);
        return editor;
    }

    function buildUserReactionSettings(container) {
        const userTags = createCheckboxRow(
            'enableUserTags',
            'Enable local user tags',
            'Add private tags beside HLTV usernames, including in thread previews. Tags stay in extension storage.',
        );
        userTags.input.addEventListener('change', syncHiddenTagControls);
        container.appendChild(userTags.row);

        const hiddenLabel = makeElement(
            'span',
            'setting-primary',
            'Hide comments from users with these tags',
        );
        const hiddenEditor = buildHiddenTagEditor();
        container.appendChild(createSettingRow({
            settingKey: 'hiddenUserTags',
            label: 'Hide comments from users with these tags',
            description: 'Hide comments by users whose local tag exactly and case-sensitively matches an entry. Multiple words and case-distinct tags are preserved.',
            primary: hiddenLabel,
            body: [hiddenEditor],
        }));

        const reset = makeElement('button', 'secondary-action', 'Reset counts');
        reset.id = 'popup-reset-local-user-scores';
        reset.type = 'button';
        reset.addEventListener('click', () => resetLocalReactionCounts(reset));
        const scores = createCheckboxRow(
            'enableLocalUserScores',
            'Show local user reaction counters',
            'Show the private reaction score kept for each username. Tracking continues while this display is off.',
            { secondary: [reset] },
        );
        container.appendChild(scores.row);

        for (const definition of [
            [
                'enableLocalDownvotes',
                'Show local downvote buttons',
                'Add a private minus button beside thread and comment votes. If the post has your real HLTV upvote, the extension removes that upvote before recording the local -1.',
            ],
            [
                'changeUpvoteStyle',
                'Change upvoted comment +1 buttons to green',
                'Color a real, active HLTV +1 button green so your current HLTV upvotes are easier to spot. Pink is reserved for local +1s saved when HLTV voting is unavailable, such as while signed out. This setting does not recolor or submit those pink local votes.',
            ],
            [
                'enableSignedOutLocalVoting',
                'Allow local voting when HLTV voting is unavailable',
                'When HLTV cannot accept a +1, keep it locally and show it in pink. After signing in, clicking that pink +1 converts it to a real HLTV upvote without counting twice.',
            ],
        ]) {
            container.appendChild(createCheckboxRow(...definition).row);
        }
    }

    function buildUserActionSettings(container) {
        const usernameActions = createCheckboxRow(
            'enableUsernameBlocking',
            'Enable right-click username actions',
            'Right-click a linked HLTV username to open the profile in a new tab or use HLTV\'s Block user or Unblock user action. The extension checks the current profile state first.',
        );
        container.appendChild(usernameActions.row);
    }

    function buildStatsSettings(container) {
        container.appendChild(createCheckboxRow(
            'showFullMapNames',
            'Show full map names on player match history pages',
            'Replace supported HLTV map abbreviations such as d2, mrg, and anb with Dust2, Mirage, and Anubis. Unknown codes remain unchanged.',
        ).row);
        container.appendChild(createCheckboxRow(
            'enableTeamPerformanceDifference',
            'Show team Overperformance Score',
            'Add a sortable OS column to team FTU tables. OS compares actual T-side round-win performance with an expectation dynamically fitted from CT opening-duel strength across the active filtered cohort. Scores are not comparable between different filter cohorts. It can offer a rough signal of IGL or team-system strength, but it does not isolate or prove an IGL\'s individual impact.',
        ).row);
    }

    function buildStatsTableSettings(container) {
        for (const definition of [
            [
                'enableStatsColumnChooser',
                'Enable stats-table column controls',
                'Add a Columns control to player ranking and match-history tables. Every available column starts visible, including WAR, estimated ranking-table KPR, and exact match-history KPR. Selecting WAR reveals its calculation controls; each calculated column has an in-table explanation. Hidden columns and column order are stored separately for each table type.',
            ],
            [
                'enableStatsMultiSort',
                'Enable multi-column sorting',
                'Click a table header to replace the sort; Shift-click adds or changes a secondary sort. The full stable sort order persists across page loads.',
            ],
            [
                'enableStatsCsvExport',
                'Enable CSV export for stats tables',
                'Export currently loaded rows, visible columns, extension columns, displayed column order, and current sort order. Spreadsheet-formula prefixes are escaped.',
            ],
            [
                'enablePlayerMatchSparklines',
                'Show selectable player match-history trends',
                'Plot any numeric statistic available in the loaded match-history table over the latest 100 maps, with locked labeled axes and a five-map rolling line. Point details appear immediately only while hovered or keyboard-focused, then disappear on pointer exit or blur.',
            ],
            [
                'enableExtendedMatchHistoryLoading',
                'Extend player match-history loading beyond 100 maps',
                'Add a Rows to show selector beneath player match-history tables with 100, 200, 300, 400, 500, and ALL choices. Extra pages are fetched from the same filtered player history and the remembered choice is reused. Turning this off cancels loading, removes extension-fetched rows and the selector, and restores HLTV\'s native pager.',
            ],
        ]) {
            container.appendChild(createCheckboxRow(...definition).row);
        }

        const periodMetric = createSelect(
            'previousPeriodMetric',
            PERIOD_METRICS,
            'Date-period comparison statistic',
        );
        periodMetric.classList.add('compact-select');
        container.appendChild(createCheckboxRow(
            'enableStatsTablePeriodComparison',
            'Compare stats tables with another date period',
            'Add a persistent Baseline delta column to player ranking tables. The same feature can be enabled or removed from the table\'s Columns control. Baseline dates are stored in the page URL; specific-event filters disable comparison.',
            { secondary: [periodMetric] },
        ).row);
    }

    function buildPlayerAnalyticsSettings(container) {
        container.appendChild(createCheckboxRow(
            'enablePlayerMapMatrix',
            'Add a map-by-stat matrix to player pages',
            'Add a Map matrix tab to player stats pages. It groups the current filtered match history by map and shows sortable Rating, KPR, DPR, K-D, and maps-played statistics.',
        ).row);

        container.appendChild(createCheckboxRow(
            'enablePlayerComparisonEnhancements',
            'Enhance player comparison pages',
            'Add compact deltas, lead summaries, player-swap and filter-sync links, CSV export, and a full-width trend graph. The graph can show raw matches, a 10-map average, or a trailing daily mean over 1-365 days, plus an optional straight trend line. Hover or focus a point for its matchup, date, map, K-D, and selected value.',
        ).row);

        container.appendChild(createCheckboxRow(
            'enablePlayerConsistencyScore',
            'Show a player consistency score',
            'Measure how much Rating varies across maps under the current player filters. At least 10 rated maps are required. Score = round(100 * max(0, 1 - SD / 1.00)); Rating SD 0 is 100, and Rating SD 1.00 or higher is 0. Scores of 60 or more are Good (green), 40-59 are Mixed, and scores below 40 are Poor (red).',
        ).row);

        container.appendChild(createCheckboxRow(
            'enablePlayerPagePeriodComparison',
            'Compare player pages with another date period',
            'Compare an individual player page\'s current native date range with selectable baseline dates. If no baseline is supplied, the immediately preceding equal-length period is used. This is independent of the ranking-table Baseline delta column.',
        ).row);

    }

    function buildDataSettings(container) {
        container.appendChild(createCheckboxRow(
            'enableDiagnosticLogging',
            'Enable local diagnostic logging',
            'Off by default. Store a capped, redacted seven-day troubleshooting log in extension-private storage. It never records post or reply text, usernames, tags, cookies, credentials, raw HTML, response bodies, full URLs, or numeric profile/thread identifiers, and it never sends anything automatically. Turning this off stops new entries; use Clear to remove existing entries.',
        ).row);

        const actions = makeElement('div', 'export-actions');

        const settingsButton = makeElement(
            'button',
            'secondary-action export-action',
            'Export saved settings',
        );
        settingsButton.id = 'popup-export-settings';
        settingsButton.type = 'button';
        settingsButton.addEventListener('click', () => exportSavedSettings(settingsButton));

        const userDataButton = makeElement(
            'button',
            'secondary-action export-action',
            'Export user data',
        );
        userDataButton.id = 'popup-export-user-data';
        userDataButton.type = 'button';
        userDataButton.addEventListener('click', () => exportUserData(userDataButton));

        const makeImportControl = ({ id, inputId, text, format }) => {
            const button = makeElement(
                'button',
                'secondary-action export-action',
                text,
            );
            button.id = id;
            button.type = 'button';
            const input = document.createElement('input');
            input.id = inputId;
            input.type = 'file';
            input.accept = '.json,application/json';
            input.hidden = true;
            button.addEventListener('click', () => input.click());
            input.addEventListener('change', () => {
                importSelectedFile(input, button, format).catch(() => {
                    setStatus('The selected file could not be imported.', true);
                });
            });
            return { button, input };
        };
        const settingsImport = makeImportControl({
            id: 'popup-import-settings',
            inputId: 'popup-import-settings-input',
            text: 'Import settings',
            format: 'hltv-enhancements-settings',
        });
        const userDataImport = makeImportControl({
            id: 'popup-import-user-data',
            inputId: 'popup-import-user-data-input',
            text: 'Import user data',
            format: 'hltv-enhancements-user-data',
        });

        const debugButton = makeElement(
            'button',
            'secondary-action export-action',
            'Export debug log',
        );
        debugButton.id = 'popup-export-debug-log';
        debugButton.type = 'button';
        debugButton.addEventListener('click', () => exportDebugLog(debugButton));

        const clearDebugButton = makeElement(
            'button',
            'secondary-action export-action',
            'Clear debug log',
        );
        clearDebugButton.id = 'popup-clear-debug-log';
        clearDebugButton.type = 'button';
        clearDebugButton.addEventListener('click', () => clearDebugLog(clearDebugButton));

        actions.append(
            settingsButton,
            userDataButton,
            settingsImport.button,
            userDataImport.button,
            debugButton,
            clearDebugButton,
            settingsImport.input,
            userDataImport.input,
        );
        container.append(
            actions,
            makeElement(
                'p',
                'group-note export-note',
                'Exports are downloaded locally. Imports are validated and never uploaded. User-data files can contain private tags and local reading and reaction history.',
            ),
        );
    }

    function buildSettingsUi() {
        const root = document.querySelector('#settings-content');
        if (!root || root.childElementCount) return;

        const sourceGroup = createFieldset('Forums to display and fetch', 'source-grid');
        buildSourceSettings(sourceGroup.contents);

        const layoutGroup = createFieldset('Page layout');
        buildLayoutSettings(layoutGroup.contents);

        const sidebarGroup = createFieldset('Sidebar & activity');
        buildSidebarSettings(sidebarGroup.contents);

        const matchGroup = createFieldset('Match filtering');
        buildMatchSettings(matchGroup.contents);

        const matchPageGroup = createFieldset('Match pages');
        buildMatchPageSettings(matchPageGroup.contents);

        const threadGroup = createFieldset('Thread pages & previews');
        buildThreadSettings(threadGroup.contents);

        const reactionGroup = createFieldset('User tags & reactions');
        buildUserReactionSettings(reactionGroup.contents);

        const actionGroup = createFieldset('User actions');
        buildUserActionSettings(actionGroup.contents);

        const statsGroup = createFieldset('Stats pages & tables');
        buildStatsSettings(statsGroup.contents);
        buildStatsTableSettings(statsGroup.contents);

        const analyticsGroup = createFieldset('Player analytics');
        buildPlayerAnalyticsSettings(analyticsGroup.contents);

        const dataGroup = createFieldset('Data & diagnostics');
        buildDataSettings(dataGroup.contents);

        root.append(
            sourceGroup.fieldset,
            layoutGroup.fieldset,
            sidebarGroup.fieldset,
            matchGroup.fieldset,
            matchPageGroup.fieldset,
            threadGroup.fieldset,
            reactionGroup.fieldset,
            actionGroup.fieldset,
            statsGroup.fieldset,
            analyticsGroup.fieldset,
            dataGroup.fieldset,
        );
    }

    function toBoolean(value, fallback) {
        if (typeof value === 'boolean') return value;
        if (value === 'true') return true;
        if (value === 'false') return false;
        return fallback;
    }

    function isPlainRecord(value) {
        return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
    }

    function hasOwn(value, key) {
        return isPlainRecord(value) && Object.hasOwn(value, key);
    }

    function clampInteger(value, minimum, maximum, fallback) {
        const parsed = Number.parseInt(String(value), 10);
        return Number.isFinite(parsed)
            ? Math.min(maximum, Math.max(minimum, parsed))
            : fallback;
    }

    function normaliseChoice(value, options, fallback) {
        const allowed = new Set(options.map(([key]) => key));
        return allowed.has(value) ? value : fallback;
    }

    function normaliseMatchPlayerMetrics(value, legacyFirst, legacySecond) {
        const allowed = new Set(MATCH_PLAYER_METRICS.map(([key]) => key));
        const legacy = [
            normaliseChoice(
                legacyFirst,
                MATCH_PLAYER_METRICS,
                DEFAULT_MATCH_PLAYER_METRICS[0],
            ),
            normaliseChoice(
                legacySecond,
                MATCH_PLAYER_METRICS,
                DEFAULT_MATCH_PLAYER_METRICS[1],
            ),
        ];
        const source = Array.isArray(value)
            ? value.slice(0, MATCH_PLAYER_METRICS.length)
            : legacy;
        const selected = [];
        for (const rawKey of source) {
            const key = String(rawKey || '');
            if (allowed.has(key) && !selected.includes(key)) selected.push(key);
        }
        return selected.length ? selected : [...DEFAULT_MATCH_PLAYER_METRICS];
    }

    function legacyMatchPlayerMetricPair(value) {
        const selected = normaliseMatchPlayerMetrics(value);
        return [
            selected[0],
            selected[1] || (selected[0] === 'rating' ? 'kpr' : 'rating'),
        ];
    }

    function normaliseTrendMetric(value) {
        const metric = String(value || '');
        return /^[A-Za-z0-9_.:-]{1,40}$/.test(metric)
            ? metric
            : DEFAULTS.playerMatchTrendMetric;
    }

    function normaliseStatsMatchHistoryRows(value) {
        if (String(value).toLowerCase() === 'all') return 'all';
        const numeric = Number(value);
        return STATS_MATCH_HISTORY_ROW_OPTIONS.includes(numeric) ? numeric : 100;
    }

    function normalisePreviousPeriodMetric(value) {
        const metric = String(value ?? '')
            .replace(/\s+/g, ' ')
            .trim()
            .toLowerCase()
            .replace(/\brating\s*[123](?:\.0)?\b/g, 'rating')
            .replace(/[^a-z0-9%]+/g, '-')
            .replace(/^-+|-+$/g, '')
            .slice(0, 80);
        return metric || DEFAULTS.previousPeriodMetric;
    }

    function normaliseSourceColor(value, fallback) {
        const color = String(value || '').trim();
        return /^#[0-9a-f]{6}$/i.test(color) ? color.toLowerCase() : fallback;
    }

    function normaliseSourceColors(value) {
        const source = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
        return Object.fromEntries(SOURCES.map((activitySource) => [
            activitySource.id,
            normaliseSourceColor(
                source[activitySource.id],
                DEFAULT_SOURCE_COLORS[activitySource.id],
            ),
        ]));
    }

    function forumIdFromStoredValue(value) {
        const text = String(value || '');
        if (FORUM_IDS.has(text)) return text;
        try {
            const url = new URL(text, HLTV_ORIGIN);
            if (url.origin !== HLTV_ORIGIN) return '';
            return FORUM_ID_BY_PATH.get(url.pathname.replace(/\/$/, '')) || '';
        } catch {
            return '';
        }
    }

    function normaliseForumIds(value) {
        if (!Array.isArray(value)) return FORUM_SOURCES.map((source) => source.id);
        const ids = value.map(forumIdFromStoredValue).filter(Boolean);
        return [...new Set(ids)];
    }

    function normaliseActivitySourceIds(value) {
        if (!Array.isArray(value)) return [...DEFAULTS.selectedSources];
        const ids = [];
        for (const item of value) {
            const text = String(item || '');
            const id = SOURCE_IDS.has(text) ? text : forumIdFromStoredValue(text);
            if (id && !ids.includes(id)) ids.push(id);
        }
        return ids;
    }

    function normaliseStoredSettings(stored) {
        const legacyCombined = stored.removeNewsMatches === undefined
            ? null
            : toBoolean(stored.removeNewsMatches, null);
        const hideNews = toBoolean(stored.hideNews, legacyCombined ?? false);
        const hideMatches = toBoolean(stored.hideMatches, legacyCombined ?? false);
        const hasLegacySourceSelection = Array.isArray(stored.displayedForumsV1)
            || Array.isArray(stored.selectedForums)
            || Object.hasOwn(stored, 'hideNews')
            || Object.hasOwn(stored, 'hideMatches')
            || Object.hasOwn(stored, 'removeNewsMatches');
        const legacySelected = Array.isArray(stored.selectedForums)
            ? normaliseForumIds(stored.selectedForums)
            : [];
        const migratedForums = Array.isArray(stored.displayedForumsV1)
            ? normaliseForumIds(stored.displayedForumsV1)
            : legacySelected.length
                ? legacySelected
                : FORUM_SOURCES.map((source) => source.id);
        const selectedSources = Array.isArray(stored.activitySourcesV2)
            ? normaliseActivitySourceIds(stored.activitySourcesV2)
            : !hasLegacySourceSelection
                ? [...DEFAULTS.selectedSources]
                : [
                    ...migratedForums,
                    ...(hideNews ? [] : ['news']),
                    ...(hideMatches ? [] : ['matches']),
                ];
        const sourceLimits = Object.fromEntries(SOURCES.map((source) => [
            source.id,
            clampInteger(
                stored.forumThreadLimits?.[source.id],
                1,
                MAX_SOURCE_LIMIT,
                DEFAULTS.sourceLimits[source.id],
            ),
        ]));
        const localScores = toBoolean(
            stored.enableLocalUserScores,
            DEFAULTS.enableLocalUserScores,
        );
        const preset = ['default', 'wide', 'extra'].includes(stored.layoutWidthPreset)
            ? stored.layoutWidthPreset
            : DEFAULTS.layoutWidthPreset;
        const statsOptionalColumns = normaliseStatsOptionalColumns(
            stored[STATS_OPTIONAL_COLUMNS_KEY],
            stored,
        );
        const enableStatsColumnChooser = toBoolean(
            stored.enableStatsColumnChooser,
            DEFAULTS.enableStatsColumnChooser,
        );
        const matchPlayerPrimaryMetrics = normaliseMatchPlayerMetrics(
            stored.matchPlayerPrimaryMetrics,
            stored.matchPlayerPrimaryMetric1,
            stored.matchPlayerPrimaryMetric2,
        );
        const [
            matchPlayerPrimaryMetric1,
            matchPlayerPrimaryMetric2,
        ] = legacyMatchPlayerMetricPair(matchPlayerPrimaryMetrics);

        return {
            selectedSources,
            sourceLimits,
            sourceColors: normaliseSourceColors(stored.activitySourceColorsV1),
            enableCustomThreadFetching: toBoolean(
                stored.enableCustomThreadFetching,
                DEFAULTS.enableCustomThreadFetching,
            ),
            enableCustomThreadColors: toBoolean(
                stored.enableCustomThreadColors,
                DEFAULTS.enableCustomThreadColors,
            ),
            layoutWidthPreset: preset,
            largeSidebarText: toBoolean(
                stored.largeSidebarText,
                DEFAULTS.largeSidebarText,
            ),
            movePostNewTopicToTop: toBoolean(
                stored.movePostNewTopicToTop,
                DEFAULTS.movePostNewTopicToTop,
            ),
            showRelativeAges: toBoolean(
                stored.showRelativeAges,
                DEFAULTS.showRelativeAges,
            ),
            enableExtendedMatchFilter: toBoolean(
                stored.enableExtendedMatchFilter,
                DEFAULTS.enableExtendedMatchFilter,
            ),
            strictSelectedTeamMatches: toBoolean(
                stored.strictSelectedTeamMatches,
                DEFAULTS.strictSelectedTeamMatches,
            ),
            enableThreadPreviews: toBoolean(
                stored.enableThreadPreviews,
                DEFAULTS.enableThreadPreviews,
            ),
            enableOriginalPosterHighlight: toBoolean(
                stored.enableOriginalPosterHighlight,
                DEFAULTS.enableOriginalPosterHighlight,
            ),
            enableReadStatus: toBoolean(
                stored.enableReadStatus,
                DEFAULTS.enableReadStatus,
            ),
            replyComposerAfterOriginalPost: toBoolean(
                stored.replyComposerAfterOriginalPost,
                DEFAULTS.replyComposerAfterOriginalPost,
            ),
            enableSavedDrafts: toBoolean(
                stored.enableSavedDrafts,
                DEFAULTS.enableSavedDrafts,
            ),
            enableUserTags: toBoolean(
                stored.enableUserTags,
                DEFAULTS.enableUserTags,
            ),
            hiddenUserTags: normaliseHiddenTags(stored.hiddenUserTags),
            enableLocalUserScores: localScores,
            enableLocalDownvotes: stored.enableLocalDownvotes == null
                ? localScores
                : toBoolean(
                    stored.enableLocalDownvotes,
                    DEFAULTS.enableLocalDownvotes,
                ),
            changeUpvoteStyle: toBoolean(
                stored.changeUpvoteStyle,
                DEFAULTS.changeUpvoteStyle,
            ),
            enableSignedOutLocalVoting: toBoolean(
                stored.enableSignedOutLocalVoting,
                DEFAULTS.enableSignedOutLocalVoting,
            ),
            enableUsernameBlocking: toBoolean(
                stored.enableUsernameBlocking,
                DEFAULTS.enableUsernameBlocking,
            ),
            enableWinAdjustedRatings: enableStatsColumnChooser
                && statsOptionalColumns.ranking.includes('war'),
            showFullMapNames: toBoolean(
                stored.showFullMapNames,
                DEFAULTS.showFullMapNames,
            ),
            enableDiagnosticLogging: toBoolean(
                stored.enableDiagnosticLogging,
                DEFAULTS.enableDiagnosticLogging,
            ),
            enableStickyMatchHeader: toBoolean(
                stored.enableStickyMatchHeader,
                DEFAULTS.enableStickyMatchHeader,
            ),
            enableMatchPlayerFormOverlays: toBoolean(
                stored.enableMatchPlayerFormOverlays,
                DEFAULTS.enableMatchPlayerFormOverlays,
            ),
            enableMatchPrediction: toBoolean(
                stored.enableMatchPrediction,
                DEFAULTS.enableMatchPrediction,
            ),
            matchPredictionMode: stored.matchPredictionMode === 'market' ? 'market' : 'stats',
            enableTeamPerformanceDifference: toBoolean(
                stored.enableTeamPerformanceDifference,
                DEFAULTS.enableTeamPerformanceDifference,
            ),
            matchPlayerPrimaryMetrics,
            matchPlayerPrimaryMetric1,
            matchPlayerPrimaryMetric2,
            enableStatsColumnChooser,
            enableStatsMultiSort: toBoolean(
                stored.enableStatsMultiSort,
                DEFAULTS.enableStatsMultiSort,
            ),
            enableStatsCsvExport: toBoolean(
                stored.enableStatsCsvExport,
                DEFAULTS.enableStatsCsvExport,
            ),
            enablePlayerMatchSparklines: toBoolean(
                stored.enablePlayerMatchSparklines,
                DEFAULTS.enablePlayerMatchSparklines,
            ),
            enableExtendedMatchHistoryLoading: toBoolean(
                stored.enableExtendedMatchHistoryLoading,
                DEFAULTS.enableExtendedMatchHistoryLoading,
            ),
            playerMatchTrendMetric: normaliseTrendMetric(stored.playerMatchTrendMetric),
            statsMatchHistoryRowsV2: normaliseStatsMatchHistoryRows(
                stored.statsMatchHistoryRowsV2,
            ),
            enablePlayerMapMatrix: toBoolean(
                stored.enablePlayerMapMatrix,
                DEFAULTS.enablePlayerMapMatrix,
            ),
            enablePlayerComparisonEnhancements: toBoolean(
                stored.enablePlayerComparisonEnhancements,
                DEFAULTS.enablePlayerComparisonEnhancements,
            ),
            enablePlayerConsistencyScore: toBoolean(
                stored.enablePlayerConsistencyScore,
                DEFAULTS.enablePlayerConsistencyScore,
            ),
            enableStatsTablePeriodComparison: stored.enableStatsTablePeriodComparison == null
                ? toBoolean(
                    stored.enablePreviousPeriodComparison,
                    DEFAULTS.enableStatsTablePeriodComparison,
                )
                : toBoolean(
                    stored.enableStatsTablePeriodComparison,
                    DEFAULTS.enableStatsTablePeriodComparison,
                ),
            enablePlayerPagePeriodComparison: stored.enablePlayerPagePeriodComparison == null
                ? toBoolean(
                    stored.enablePreviousPeriodComparison,
                    DEFAULTS.enablePlayerPagePeriodComparison,
                )
                : toBoolean(
                    stored.enablePlayerPagePeriodComparison,
                    DEFAULTS.enablePlayerPagePeriodComparison,
                ),
            previousPeriodMetric: normalisePreviousPeriodMetric(
                stored.previousPeriodMetric,
            ),
            [STATS_OPTIONAL_COLUMNS_KEY]: statsOptionalColumns,
        };
    }

    function cleanExportText(value, maximumLength) {
        return String(value ?? '')
            .replace(/\s+/g, ' ')
            .trim()
            .slice(0, maximumLength);
    }

    function normaliseSortOrder(value) {
        const text = String(value || '');
        if (text === 'comments' || text === 'high') return 'comments';
        if (text === 'created' || text === 'type') return 'created';
        return 'default';
    }

    function normaliseExtendedMatchTeams(value) {
        const source = value?.schema === 1 && Array.isArray(value.teams)
            ? value.teams
            : Array.isArray(value) ? value : [];
        const teams = [];
        const seenIds = new Set();
        let inspected = 0;
        for (const rawTeam of source) {
            inspected += 1;
            if (inspected > MAX_EXTENDED_MATCH_TEAMS * 4) break;
            const id = String(rawTeam?.id ?? '');
            const name = cleanExportText(rawTeam?.name, MAX_TEAM_NAME_CHARS);
            if (!/^\d{1,20}$/.test(id) || !name || seenIds.has(id)) continue;
            seenIds.add(id);
            teams.push({ id, name });
            if (teams.length >= MAX_EXTENDED_MATCH_TEAMS) break;
        }
        return teams;
    }

    function normaliseStatsColumnLayouts(value) {
        const source = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
        const output = {};
        for (const type of ['ranking', 'matches']) {
            const item = source[type] && typeof source[type] === 'object' ? source[type] : {};
            output[type] = {
                order: [...new Set((Array.isArray(item.order) ? item.order : [])
                    .map((entry) => cleanExportText(entry, 40))
                    .filter(Boolean))].slice(0, 40),
                hidden: [...new Set((Array.isArray(item.hidden) ? item.hidden : [])
                    .map((entry) => cleanExportText(entry, 40))
                    .filter(Boolean))].slice(0, 40),
            };
        }
        return output;
    }

    function normaliseStatsMultiSort(value) {
        const source = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
        const output = {};
        for (const type of ['ranking', 'matches']) {
            output[type] = (Array.isArray(source[type]) ? source[type] : [])
                .slice(0, 12)
                .map((entry) => ({
                    id: cleanExportText(entry?.id, 40),
                    direction: entry?.direction === 'asc' ? 'asc' : 'desc',
                }))
                .filter((entry) => entry.id);
        }
        return output;
    }

    function normaliseStatsOptionalColumns(value, legacySettings = {}) {
        const hasExplicitValue = value
            && typeof value === 'object'
            && !Array.isArray(value);
        const hasLegacyChoices = hasOwn(legacySettings, 'enableKprEstimate')
            || hasOwn(legacySettings, 'enableKprMatchHistory')
            || hasOwn(legacySettings, 'enableDerivedStatsColumns');
        const output = {};
        for (const type of ['ranking', 'matches']) {
            const selected = new Set(hasExplicitValue && Array.isArray(value[type])
                ? value[type].map((entry) => String(entry || ''))
                : []);
            if (!hasExplicitValue) {
                if (!hasLegacyChoices) {
                    for (const id of STATS_OPTIONAL_COLUMN_IDS[type]) selected.add(id);
                } else {
                    if (type === 'ranking'
                        && toBoolean(legacySettings.enableKprEstimate, false)) {
                        selected.add('kpr');
                    }
                    const legacyMatchHistoryKpr = hasOwn(
                        legacySettings,
                        'enableKprMatchHistory',
                    )
                        ? legacySettings.enableKprMatchHistory
                        : legacySettings.enableKprEstimate;
                    if (type === 'matches'
                        && toBoolean(legacyMatchHistoryKpr, false)) {
                        selected.add('kpr');
                    }
                    if (toBoolean(legacySettings.enableDerivedStatsColumns, false)) {
                        selected.add('dpr');
                        if (type === 'ranking') selected.add('kills-per-map');
                    }
                }
            }
            if (type === 'ranking') {
                const legacyWarEnabled = toBoolean(
                    legacySettings.enableWinAdjustedRatings,
                    DEFAULTS.enableWinAdjustedRatings,
                );
                if ((!hasExplicitValue && legacyWarEnabled)
                    || (hasExplicitValue && legacySettings.enableWinAdjustedRatings === true)) {
                    selected.add('war');
                }
            }
            output[type] = STATS_OPTIONAL_COLUMN_IDS[type]
                .filter((id) => selected.has(id));
        }
        return output;
    }

    function canonicalSettingsExport(stored) {
        const {
            enableWinAdjustedRatings: _legacyWarPreference,
            ...currentSettings
        } = normaliseStoredSettings(stored);
        return {
            ...currentSettings,
            additionalMatchTeams: normaliseExtendedMatchTeams(
                stored[EXTENDED_MATCH_TEAMS_KEY],
            ),
            sortOrder: normaliseSortOrder(stored.sortOrder),
            winAdjustedAutoRun: toBoolean(stored.winAdjustedAutoRun, false),
            statsColumnLayout: normaliseStatsColumnLayouts(stored.statsColumnLayoutV2),
            statsMultiSort: normaliseStatsMultiSort(stored.statsMultiSortV2),
            [STATS_OPTIONAL_COLUMNS_KEY]: normaliseStatsOptionalColumns(
                stored[STATS_OPTIONAL_COLUMNS_KEY],
                stored,
            ),
        };
    }

    function normaliseUserTagsForExport(value) {
        const source = (value?.schema === 1 || value?.schema === 2)
            && value.users
            && typeof value.users === 'object'
            && !Array.isArray(value.users)
            ? value.users
            : {};
        const users = [];
        let inspected = 0;
        for (const [userId, rawEntry] of Object.entries(source)) {
            inspected += 1;
            if (inspected > MAX_USER_TAGS * 4) break;
            if (!/^\d{1,20}$/.test(userId)
                || !rawEntry
                || typeof rawEntry !== 'object') continue;
            const tag = normaliseTag(rawEntry.tag ?? rawEntry.note);
            if (!tag) continue;
            const rawUpdatedAt = Number(rawEntry.updatedAt);
            const updatedAt = Number.isFinite(rawUpdatedAt)
                && rawUpdatedAt >= 0
                && rawUpdatedAt <= Date.now() + FUTURE_TIMESTAMP_SKEW_MS
                ? rawUpdatedAt
                : 0;
            users.push({
                userId,
                name: cleanExportText(rawEntry.name, MAX_USER_NAME_CHARS),
                tag,
                updatedAt,
            });
        }
        users.sort((first, second) => (
            second.updatedAt - first.updatedAt
            || first.userId.localeCompare(second.userId)
        ));
        return users.slice(0, MAX_USER_TAGS);
    }

    function normaliseSelfPostNumbers(value, threshold) {
        if (!Array.isArray(value)) return [];
        return [...new Set(value
            .map((item) => clampInteger(item, 1, 10_000_000, 0))
            .filter((item) => item > threshold))]
            .sort((first, second) => first - second)
            .slice(-MAX_SELF_POST_NUMBERS);
    }

    function readThreadId(value) {
        const text = String(value || '');
        if (/^\d{1,20}$/.test(text)) return text;
        return text.match(/^\/forums\/threads\/(\d{1,20})(?:\/|$)/i)?.[1] || '';
    }

    function normaliseReadStateForExport(value) {
        const now = Date.now();
        const source = (value?.schema === 1 || value?.schema === 2)
            && value.entries
            && typeof value.entries === 'object'
            && !Array.isArray(value.entries)
            ? value.entries
            : {};
        const entries = [];
        let inspected = 0;
        for (const [rawKey, rawEntry] of Object.entries(source)) {
            inspected += 1;
            if (inspected > MAX_READ_ENTRIES * 4) break;
            const threadId = readThreadId(rawKey);
            const visitedAt = Number(rawEntry?.visitedAt);
            if (!threadId
                || !rawEntry
                || typeof rawEntry !== 'object'
                || !Number.isFinite(visitedAt)
                || visitedAt < now - READ_RETENTION_MS
                || visitedAt > now + FUTURE_TIMESTAMP_SKEW_MS) continue;
            const seenReplyCount = clampInteger(
                rawEntry.seenReplyCount ?? rawEntry.commentsSeen,
                0,
                10_000_000,
                0,
            );
            const maxPostNo = clampInteger(
                rawEntry.maxPostNo ?? rawEntry.commentsSeen,
                0,
                10_000_000,
                0,
            );
            entries.push({
                threadId,
                seenReplyCount,
                maxPostNo,
                selfPostNumbers: normaliseSelfPostNumbers(
                    rawEntry.selfPostNumbers,
                    Math.max(seenReplyCount, maxPostNo),
                ),
                visitedAt,
            });
        }
        entries.sort((first, second) => second.visitedAt - first.visitedAt);
        const deduplicated = [];
        const seenThreadIds = new Set();
        for (const entry of entries) {
            if (seenThreadIds.has(entry.threadId)) continue;
            seenThreadIds.add(entry.threadId);
            deduplicated.push(entry);
            if (deduplicated.length >= MAX_READ_ENTRIES) break;
        }
        return deduplicated;
    }

    function reactionsForExport(normalisedRecord) {
        return [...normalisedRecord.reactions.entries()]
            .filter(([, entry]) => entry.value !== 0)
            .map(([reactionKey, entry]) => ({
                reactionKey,
                authorId: entry.authorId,
                value: entry.value,
                updatedAt: entry.updatedAt,
            }));
    }

    function reactionScoresForExport(reactions) {
        const scores = new Map();
        for (const reaction of reactions) {
            scores.set(
                reaction.authorId,
                (scores.get(reaction.authorId) || 0) + reaction.value,
            );
        }
        return [...scores.entries()]
            .map(([authorId, score]) => ({ authorId, score }))
            .sort((first, second) => first.authorId.localeCompare(second.authorId));
    }

    function provisionalUpvotesForExport(value, normalisedReactions) {
        const source = value?.schema === 1
            && value.upvotes
            && typeof value.upvotes === 'object'
            && !Array.isArray(value.upvotes)
            ? value.upvotes
            : {};
        const upvotes = [];
        let inspected = 0;
        for (const [reactionKey, rawEntry] of Object.entries(source)) {
            inspected += 1;
            if (inspected > MAX_LOCAL_REACTIONS * 4) break;
            const authorId = String(rawEntry?.authorId ?? '');
            const mutationId = String(rawEntry?.reactionMutationId || '');
            const updatedAt = validResetTimestamp(rawEntry?.updatedAt);
            const reaction = normalisedReactions.get(reactionKey);
            if (!/^(?:thread|reply):\d{1,20}$/.test(reactionKey)
                || !/^\d{1,20}$/.test(authorId)
                || !/^[A-Za-z0-9_.:-]{1,80}$/.test(mutationId)
                || !updatedAt
                || reaction?.value !== 1
                || reaction.authorId !== authorId
                || reaction.mutationId !== mutationId) continue;
            upvotes.push({ reactionKey, authorId, updatedAt });
        }
        upvotes.sort((first, second) => second.updatedAt - first.updatedAt);
        return upvotes.slice(0, MAX_LOCAL_REACTIONS);
    }

    function extensionVersion() {
        return String(extensionApi.runtime.getManifest()?.version || 'unknown').slice(0, 64);
    }

    function exportEnvelope(format, data) {
        return {
            format,
            schemaVersion: 1,
            extensionVersion: extensionVersion(),
            exportedAt: new Date().toISOString(),
            ...data,
        };
    }

    function exportFilename(kind) {
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        popupState.exportSequence += 1;
        return `hltv-enhancements-${kind}-${timestamp}-${popupState.exportSequence}.json`;
    }

    function downloadJson(filename, value) {
        if (typeof globalThis.URL?.createObjectURL !== 'function'
            || typeof globalThis.URL?.revokeObjectURL !== 'function') {
            throw new Error('Local downloads are unavailable.');
        }
        const blob = new Blob([`${JSON.stringify(value, null, 2)}\n`], {
            type: 'application/json',
        });
        const objectUrl = globalThis.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = objectUrl;
        link.download = filename;
        link.rel = 'noopener';
        link.hidden = true;
        document.body.appendChild(link);
        try {
            link.click();
        } finally {
            link.remove();
            globalThis.setTimeout(() => globalThis.URL.revokeObjectURL(objectUrl), 0);
        }
    }

    async function runExport(button, statusText, operation) {
        button.disabled = true;
        button.setAttribute('aria-busy', 'true');
        setStatus('Preparing local export…');
        try {
            await operation();
            setStatus(statusText);
        } catch {
            setStatus('The local export could not be created.', true);
        } finally {
            button.disabled = false;
            button.setAttribute('aria-busy', 'false');
        }
    }

    async function exportSavedSettings(button) {
        await runExport(button, 'Saved settings were exported.', async () => {
            const stored = await extensionApi.storage.local.get(
                SETTINGS_EXPORT_READ_KEYS,
            );
            downloadJson(
                exportFilename('settings'),
                exportEnvelope('hltv-enhancements-settings', {
                    settings: canonicalSettingsExport(stored || {}),
                }),
            );
        });
    }

    async function exportUserData(button) {
        await runExport(button, 'User data was exported.', async () => {
            const stored = await extensionApi.storage.local.get(
                USER_DATA_EXPORT_READ_KEYS,
            );
            const normalisedReactionRecord = normaliseReactionRecord(
                stored?.[LOCAL_REACTIONS_KEY],
            );
            const reactions = reactionsForExport(normalisedReactionRecord);
            downloadJson(
                exportFilename('user-data'),
                exportEnvelope('hltv-enhancements-user-data', {
                    data: {
                        userTags: normaliseUserTagsForExport(stored?.[USER_TAGS_KEY]),
                        readState: normaliseReadStateForExport(stored?.[READ_STATE_KEY]),
                        reactions,
                        userReactionScores: reactionScoresForExport(reactions),
                        provisionalLocalUpvotes: provisionalUpvotesForExport(
                            stored?.[PROVISIONAL_LOCAL_UPVOTES_KEY],
                            normalisedReactionRecord.reactions,
                        ),
                        additionalMatchTeams: normaliseExtendedMatchTeams(
                            stored?.[EXTENDED_MATCH_TEAMS_KEY],
                        ),
                    },
                }),
            );
        });
    }

    function normaliseImportedSettings(rawSettings, currentStored) {
        if (!isPlainRecord(rawSettings)) {
            throw new TypeError('The settings payload must be an object.');
        }
        const importableKeys = [
            'selectedSources',
            'sourceLimits',
            'sourceColors',
            'layoutWidthPreset',
            'hiddenUserTags',
            'matchPlayerPrimaryMetrics',
            'matchPlayerPrimaryMetric1',
            'matchPlayerPrimaryMetric2',
            'matchPredictionMode',
            'playerMatchTrendMetric',
            'statsMatchHistoryRowsV2',
            'previousPeriodMetric',
            STATS_OPTIONAL_COLUMNS_KEY,
            'additionalMatchTeams',
            'sortOrder',
            'winAdjustedAutoRun',
            'statsColumnLayout',
            'statsMultiSort',
            'enableKprEstimate',
            'enableKprMatchHistory',
            'enableDerivedStatsColumns',
            'enablePreviousPeriodComparison',
            'enableWinAdjustedRatings',
            ...CURRENT_BOOLEAN_SETTING_KEYS,
        ];
        if (!importableKeys.some((key) => hasOwn(rawSettings, key))) {
            throw new TypeError('The file contains no supported settings.');
        }
        const current = canonicalSettingsExport(currentStored || {});
        const draft = {
            activitySourcesV2: hasOwn(rawSettings, 'selectedSources')
                ? rawSettings.selectedSources
                : current.selectedSources,
            forumThreadLimits: hasOwn(rawSettings, 'sourceLimits')
                ? rawSettings.sourceLimits
                : current.sourceLimits,
            activitySourceColorsV1: hasOwn(rawSettings, 'sourceColors')
                ? rawSettings.sourceColors
                : current.sourceColors,
            layoutWidthPreset: hasOwn(rawSettings, 'layoutWidthPreset')
                ? rawSettings.layoutWidthPreset
                : current.layoutWidthPreset,
            hiddenUserTags: hasOwn(rawSettings, 'hiddenUserTags')
                ? rawSettings.hiddenUserTags
                : current.hiddenUserTags,
            matchPlayerPrimaryMetrics: hasOwn(rawSettings, 'matchPlayerPrimaryMetrics')
                ? rawSettings.matchPlayerPrimaryMetrics
                : hasOwn(rawSettings, 'matchPlayerPrimaryMetric1')
                    || hasOwn(rawSettings, 'matchPlayerPrimaryMetric2')
                    ? null
                    : current.matchPlayerPrimaryMetrics,
            matchPlayerPrimaryMetric1: hasOwn(rawSettings, 'matchPlayerPrimaryMetric1')
                ? rawSettings.matchPlayerPrimaryMetric1
                : current.matchPlayerPrimaryMetric1,
            matchPlayerPrimaryMetric2: hasOwn(rawSettings, 'matchPlayerPrimaryMetric2')
                ? rawSettings.matchPlayerPrimaryMetric2
                : current.matchPlayerPrimaryMetric2,
            matchPredictionMode: hasOwn(rawSettings, 'matchPredictionMode')
                ? rawSettings.matchPredictionMode
                : current.matchPredictionMode,
            playerMatchTrendMetric: hasOwn(rawSettings, 'playerMatchTrendMetric')
                ? rawSettings.playerMatchTrendMetric
                : current.playerMatchTrendMetric,
            statsMatchHistoryRowsV2: hasOwn(rawSettings, 'statsMatchHistoryRowsV2')
                ? rawSettings.statsMatchHistoryRowsV2
                : current.statsMatchHistoryRowsV2,
            previousPeriodMetric: hasOwn(rawSettings, 'previousPeriodMetric')
                ? rawSettings.previousPeriodMetric
                : current.previousPeriodMetric,
        };
        for (const key of CURRENT_BOOLEAN_SETTING_KEYS) {
            draft[key] = hasOwn(rawSettings, key) ? rawSettings[key] : current[key];
        }
        if (!hasOwn(rawSettings, 'enableStatsTablePeriodComparison')
            && hasOwn(rawSettings, 'enablePreviousPeriodComparison')) {
            draft.enableStatsTablePeriodComparison = rawSettings.enablePreviousPeriodComparison;
        }
        if (!hasOwn(rawSettings, 'enablePlayerPagePeriodComparison')
            && hasOwn(rawSettings, 'enablePreviousPeriodComparison')) {
            draft.enablePlayerPagePeriodComparison = rawSettings.enablePreviousPeriodComparison;
        }
        draft[STATS_OPTIONAL_COLUMNS_KEY] = hasOwn(
            rawSettings,
            STATS_OPTIONAL_COLUMNS_KEY,
        )
            ? rawSettings[STATS_OPTIONAL_COLUMNS_KEY]
            : hasOwn(rawSettings, 'enableKprEstimate')
                || hasOwn(rawSettings, 'enableKprMatchHistory')
                || hasOwn(rawSettings, 'enableDerivedStatsColumns')
                ? normaliseStatsOptionalColumns(null, rawSettings)
                : current[STATS_OPTIONAL_COLUMNS_KEY];
        if (hasOwn(rawSettings, STATS_OPTIONAL_COLUMNS_KEY)) {
            draft.enableWinAdjustedRatings = Array.isArray(
                rawSettings[STATS_OPTIONAL_COLUMNS_KEY]?.ranking,
            ) && rawSettings[STATS_OPTIONAL_COLUMNS_KEY].ranking.includes('war');
        } else if (hasOwn(rawSettings, 'enableWinAdjustedRatings')) {
            const selected = new Set(draft[STATS_OPTIONAL_COLUMNS_KEY].ranking);
            if (toBoolean(rawSettings.enableWinAdjustedRatings, true)) selected.add('war');
            else selected.delete('war');
            draft[STATS_OPTIONAL_COLUMNS_KEY] = {
                ...draft[STATS_OPTIONAL_COLUMNS_KEY],
                ranking: [...selected],
            };
            draft.enableWinAdjustedRatings = selected.has('war');
        }

        const settings = normaliseStoredSettings(draft);
        const selectedForumIds = settings.selectedSources.filter((sourceId) => (
            FORUM_IDS.has(sourceId)
        ));
        const payload = {
            activitySourcesV2: settings.selectedSources,
            displayedForumsV1: selectedForumIds,
            selectedForums: selectedForumIds,
            hideMatches: !settings.selectedSources.includes('matches'),
            hideNews: !settings.selectedSources.includes('news'),
            forumThreadLimits: settings.sourceLimits,
            activitySourceColorsV1: settings.sourceColors,
            layoutWidthPreset: settings.layoutWidthPreset,
            hiddenUserTags: settings.hiddenUserTags,
            matchPlayerPrimaryMetrics: settings.matchPlayerPrimaryMetrics,
            matchPlayerPrimaryMetric1: settings.matchPlayerPrimaryMetric1,
            matchPlayerPrimaryMetric2: settings.matchPlayerPrimaryMetric2,
            matchPredictionMode: settings.matchPredictionMode,
            playerMatchTrendMetric: settings.playerMatchTrendMetric,
            statsMatchHistoryRowsV2: settings.statsMatchHistoryRowsV2,
            previousPeriodMetric: settings.previousPeriodMetric,
            [STATS_OPTIONAL_COLUMNS_KEY]: settings[STATS_OPTIONAL_COLUMNS_KEY],
        };
        for (const key of CURRENT_BOOLEAN_SETTING_KEYS) payload[key] = settings[key];

        payload[EXTENDED_MATCH_TEAMS_KEY] = {
            schema: 1,
            teams: normaliseExtendedMatchTeams(hasOwn(rawSettings, 'additionalMatchTeams')
                ? rawSettings.additionalMatchTeams
                : current.additionalMatchTeams),
        };
        payload.sortOrder = normaliseSortOrder(hasOwn(rawSettings, 'sortOrder')
            ? rawSettings.sortOrder
            : current.sortOrder);
        payload.winAdjustedAutoRun = toBoolean(
            hasOwn(rawSettings, 'winAdjustedAutoRun')
                ? rawSettings.winAdjustedAutoRun
                : current.winAdjustedAutoRun,
            false,
        );
        payload.statsColumnLayoutV2 = normaliseStatsColumnLayouts(
            hasOwn(rawSettings, 'statsColumnLayout')
                ? rawSettings.statsColumnLayout
                : current.statsColumnLayout,
        );
        payload.statsMultiSortV2 = normaliseStatsMultiSort(
            hasOwn(rawSettings, 'statsMultiSort')
                ? rawSettings.statsMultiSort
                : current.statsMultiSort,
        );
        payload[SYNC_PULSE_KEY] = syncPulse(['settings']);
        return payload;
    }

    function normaliseImportedUserTags(value) {
        if (!Array.isArray(value)) throw new TypeError('User tags must be an array.');
        const entries = [];
        for (const rawEntry of value.slice(0, MAX_USER_TAGS * 4)) {
            const userId = String(rawEntry?.userId ?? '');
            const tag = normaliseTag(rawEntry?.tag);
            const timestamp = Number(rawEntry?.updatedAt);
            const updatedAt = Number.isFinite(timestamp)
                && timestamp >= 0
                && timestamp <= Date.now() + FUTURE_TIMESTAMP_SKEW_MS
                ? timestamp
                : 0;
            if (!/^\d{1,20}$/.test(userId) || !tag) continue;
            entries.push({
                userId,
                name: cleanExportText(rawEntry?.name, MAX_USER_NAME_CHARS),
                tag,
                updatedAt,
            });
        }
        return entries;
    }

    function mergeUserTags(currentValue, importedValue) {
        const merged = new Map(normaliseUserTagsForExport(currentValue)
            .map((entry) => [entry.userId, entry]));
        for (const entry of normaliseImportedUserTags(importedValue)) {
            const current = merged.get(entry.userId);
            if (!current || entry.updatedAt >= current.updatedAt) {
                merged.set(entry.userId, entry);
            }
        }
        const entries = [...merged.values()]
            .sort((first, second) => (
                second.updatedAt - first.updatedAt
                || first.userId.localeCompare(second.userId)
            ))
            .slice(0, MAX_USER_TAGS);
        return {
            schema: 1,
            updatedAt: Math.max(0, ...entries.map((entry) => entry.updatedAt)),
            users: Object.fromEntries(entries.map((entry) => [entry.userId, {
                name: entry.name,
                tag: entry.tag,
                note: entry.tag,
                updatedAt: entry.updatedAt,
            }])),
        };
    }

    function normaliseImportedReadState(value) {
        if (!Array.isArray(value)) throw new TypeError('Read state must be an array.');
        const entries = {};
        for (const rawEntry of value.slice(0, MAX_READ_ENTRIES * 4)) {
            const threadId = readThreadId(rawEntry?.threadId);
            if (!threadId || !isPlainRecord(rawEntry)) continue;
            const visitedAt = Number(rawEntry.visitedAt);
            if (!Number.isFinite(visitedAt)) continue;
            const candidate = {
                seenReplyCount: clampInteger(rawEntry.seenReplyCount, 0, 10_000_000, 0),
                maxPostNo: clampInteger(rawEntry.maxPostNo, 0, 10_000_000, 0),
                selfPostNumbers: Array.isArray(rawEntry.selfPostNumbers)
                    ? rawEntry.selfPostNumbers
                    : [],
                visitedAt,
            };
            if (!entries[threadId] || visitedAt >= entries[threadId].visitedAt) {
                entries[threadId] = candidate;
            }
        }
        return normaliseReadStateForExport({ schema: 2, entries });
    }

    function mergeReadState(currentValue, importedValue) {
        const merged = new Map(normaliseReadStateForExport(currentValue)
            .map((entry) => [entry.threadId, entry]));
        for (const entry of normaliseImportedReadState(importedValue)) {
            const current = merged.get(entry.threadId);
            if (!current || entry.visitedAt >= current.visitedAt) {
                merged.set(entry.threadId, entry);
            }
        }
        const entries = [...merged.values()]
            .sort((first, second) => second.visitedAt - first.visitedAt)
            .slice(0, MAX_READ_ENTRIES);
        return {
            schema: 2,
            updatedAt: Math.max(0, ...entries.map((entry) => entry.visitedAt)),
            entries: Object.fromEntries(entries.map((entry) => [entry.threadId, {
                seenReplyCount: entry.seenReplyCount,
                maxPostNo: entry.maxPostNo,
                selfPostNumbers: entry.selfPostNumbers,
                visitedAt: entry.visitedAt,
            }])),
        };
    }

    function mergeImportedReactions(currentValue, importedValue) {
        if (!Array.isArray(importedValue)) throw new TypeError('Reactions must be an array.');
        const state = normaliseReactionRecord(currentValue);
        for (const rawEntry of importedValue.slice(0, MAX_LOCAL_REACTIONS * 4)) {
            const reactionKey = String(rawEntry?.reactionKey || '');
            const authorId = String(rawEntry?.authorId || '');
            const value = Number(rawEntry?.value);
            const updatedAt = validResetTimestamp(rawEntry?.updatedAt);
            if (!/^(?:thread|reply):\d{1,20}$/.test(reactionKey)
                || !/^\d{1,20}$/.test(authorId)
                || ![-1, 1].includes(value)
                || !updatedAt
                || updatedAt <= state.resetAt) continue;
            const current = state.reactions.get(reactionKey);
            if (current && updatedAt < current.updatedAt) continue;
            state.reactions.set(reactionKey, {
                authorId,
                value,
                updatedAt,
                mutationId: randomToken('popup-import-reaction').slice(0, 80),
            });
        }
        return serialiseReactionRecord(state);
    }

    function normaliseImportedProvisionalUpvotes(value) {
        if (!Array.isArray(value)) {
            throw new TypeError('Provisional upvotes must be an array.');
        }
        return value.slice(0, MAX_LOCAL_REACTIONS * 4)
            .map((rawEntry) => ({
                reactionKey: String(rawEntry?.reactionKey || ''),
                authorId: String(rawEntry?.authorId || ''),
                updatedAt: validResetTimestamp(rawEntry?.updatedAt),
            }))
            .filter((entry) => (
                /^(?:thread|reply):\d{1,20}$/.test(entry.reactionKey)
                && /^\d{1,20}$/.test(entry.authorId)
                && entry.updatedAt
            ));
    }

    function mergeProvisionalUpvotes(currentValue, importedValue, reactionsValue) {
        const reactionState = normaliseReactionRecord(reactionsValue);
        const source = currentValue?.schema === 1 && isPlainRecord(currentValue.upvotes)
            ? Object.entries(currentValue.upvotes).map(([reactionKey, entry]) => ({
                reactionKey,
                authorId: String(entry?.authorId || ''),
                updatedAt: validResetTimestamp(entry?.updatedAt),
            }))
            : [];
        const merged = new Map();
        for (const entry of [
            ...source,
            ...normaliseImportedProvisionalUpvotes(importedValue),
        ]) {
            const reaction = reactionState.reactions.get(entry.reactionKey);
            if (!reaction
                || reaction.value !== 1
                || reaction.authorId !== entry.authorId
                || !entry.updatedAt) continue;
            const existing = merged.get(entry.reactionKey);
            if (!existing || entry.updatedAt >= existing.updatedAt) {
                merged.set(entry.reactionKey, entry);
            }
        }
        const entries = [...merged.values()]
            .sort((first, second) => second.updatedAt - first.updatedAt)
            .slice(0, MAX_LOCAL_REACTIONS);
        return {
            schema: 1,
            updatedAt: Math.max(0, ...entries.map((entry) => entry.updatedAt)),
            upvotes: Object.fromEntries(entries.map((entry) => {
                const reaction = reactionState.reactions.get(entry.reactionKey);
                return [entry.reactionKey, {
                    authorId: entry.authorId,
                    reactionMutationId: reaction.mutationId,
                    updatedAt: entry.updatedAt,
                }];
            })),
        };
    }

    function mergeExtendedMatchTeams(currentValue, importedValue) {
        const merged = new Map(normaliseExtendedMatchTeams(currentValue)
            .map((team) => [team.id, team]));
        for (const team of normaliseExtendedMatchTeams(importedValue)) {
            merged.set(team.id, team);
        }
        return [...merged.values()].slice(0, MAX_EXTENDED_MATCH_TEAMS);
    }

    function normaliseImportedUserData(rawData, currentStored) {
        if (!isPlainRecord(rawData)) {
            throw new TypeError('The user-data payload must be an object.');
        }
        const importableKeys = [
            'userTags',
            'readState',
            'reactions',
            'provisionalLocalUpvotes',
            'additionalMatchTeams',
        ];
        if (!importableKeys.some((key) => hasOwn(rawData, key))) {
            throw new TypeError('The file contains no supported user data.');
        }
        for (const key of importableKeys) {
            if (hasOwn(rawData, key) && !Array.isArray(rawData[key])) {
                throw new TypeError(`${key} must be an array.`);
            }
        }

        const userTags = mergeUserTags(
            currentStored?.[USER_TAGS_KEY],
            hasOwn(rawData, 'userTags') ? rawData.userTags : [],
        );
        const readState = mergeReadState(
            currentStored?.[READ_STATE_KEY],
            hasOwn(rawData, 'readState') ? rawData.readState : [],
        );
        const reactions = hasOwn(rawData, 'reactions')
            ? mergeImportedReactions(
                currentStored?.[LOCAL_REACTIONS_KEY],
                rawData.reactions,
            )
            : serialiseReactionRecord(normaliseReactionRecord(
                currentStored?.[LOCAL_REACTIONS_KEY],
            ));
        const provisional = hasOwn(rawData, 'provisionalLocalUpvotes')
            ? mergeProvisionalUpvotes(
                currentStored?.[PROVISIONAL_LOCAL_UPVOTES_KEY],
                rawData.provisionalLocalUpvotes,
                reactions,
            )
            : mergeProvisionalUpvotes(
                currentStored?.[PROVISIONAL_LOCAL_UPVOTES_KEY],
                [],
                reactions,
            );
        const teams = hasOwn(rawData, 'additionalMatchTeams')
            ? mergeExtendedMatchTeams(
                currentStored?.[EXTENDED_MATCH_TEAMS_KEY],
                rawData.additionalMatchTeams,
            )
            : normaliseExtendedMatchTeams(currentStored?.[EXTENDED_MATCH_TEAMS_KEY]);

        return {
            [USER_TAGS_KEY]: userTags,
            [READ_STATE_KEY]: readState,
            [LOCAL_REACTIONS_KEY]: reactions,
            [PROVISIONAL_LOCAL_UPVOTES_KEY]: provisional,
            [EXTENDED_MATCH_TEAMS_KEY]: { schema: 1, teams },
            [SYNC_PULSE_KEY]: syncPulse([
                'notes',
                'readState',
                'reactions',
                'matchTeams',
            ]),
        };
    }

    async function readImportFile(file) {
        if (!file || typeof file !== 'object') {
            throw new TypeError('Choose a JSON export file.');
        }
        const fileSize = Number(file.size);
        if (!Number.isFinite(fileSize) || fileSize < 0 || fileSize > MAX_IMPORT_BYTES) {
            throw new RangeError('Import files must be no larger than 5 MiB.');
        }
        let textValue;
        if (typeof file.text === 'function') {
            textValue = await file.text();
        } else {
            textValue = await new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.addEventListener('load', () => resolve(reader.result), { once: true });
                reader.addEventListener('error', () => reject(reader.error), { once: true });
                reader.readAsText(file);
            });
        }
        const text = String(textValue || '');
        if (text.length > MAX_IMPORT_BYTES) {
            throw new RangeError('Import files must be no larger than 5 MiB.');
        }
        return JSON.parse(text);
    }

    async function importSelectedFile(input, button, expectedFormat) {
        if (popupState.importing) return;
        const file = input.files?.[0];
        if (!file) return;
        popupState.importing = true;
        button.disabled = true;
        button.setAttribute('aria-busy', 'true');
        setStatus('Importing local file…');
        try {
            const envelope = await readImportFile(file);
            if (!isPlainRecord(envelope) || envelope.schemaVersion !== 1) {
                throw new TypeError('Unsupported export schema.');
            }
            if (envelope.format !== expectedFormat) {
                throw new TypeError(expectedFormat === 'hltv-enhancements-settings'
                    ? 'Choose an HLTV Enhancements settings export.'
                    : 'Choose an HLTV Enhancements user-data export.');
            }
            if (envelope.format === 'hltv-enhancements-settings') {
                const current = await extensionApi.storage.local.get(
                    SETTINGS_EXPORT_READ_KEYS,
                );
                const payload = normaliseImportedSettings(envelope.settings, current || {});
                await extensionApi.storage.local.set(payload);
                applySettingsToUi(normaliseStoredSettings(payload));
                popupState.dirty = false;
                popupState.externalChangeWhileDirty = false;
                setStatus('Saved settings were imported.');
            } else if (envelope.format === 'hltv-enhancements-user-data') {
                await withReactionLease(async (assertOwner) => {
                    const current = await extensionApi.storage.local.get(
                        USER_DATA_EXPORT_READ_KEYS,
                    );
                    const payload = normaliseImportedUserData(
                        envelope.data,
                        current || {},
                    );
                    await assertOwner();
                    await extensionApi.storage.local.set(payload);
                    await assertOwner();
                });
                setStatus('User data was imported and merged.');
            } else {
                throw new TypeError('Unsupported export format.');
            }
        } catch (error) {
            const expectedKindMessage = /^Choose an HLTV Enhancements (?:settings|user-data) export\.$/
                .test(String(error?.message || ''));
            const message = error instanceof RangeError || expectedKindMessage
                ? error.message
                : 'The selected file is not a supported HLTV Enhancements export.';
            setStatus(message, true);
        } finally {
            input.value = '';
            button.disabled = false;
            button.setAttribute('aria-busy', 'false');
            popupState.importing = false;
        }
    }

    function scrubDebugText(value, maximumLength = 240) {
        return String(value || '')
            .replace(/[\u0000-\u001f\u007f]/g, ' ')
            .replace(/\b(?:https?|moz-extension|chrome-extension):\/\/[^\s)]+/gi, '[url]')
            .replace(/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi, '[email]')
            .replace(/\b(?:\d{1,3}\.){3}\d{1,3}\b/g, '[ip]')
            .replace(/\b[A-Za-z0-9_-]{32,}\b/g, '[token]')
            .replace(/\b\d{3,}\b/g, '#')
            .replace(/\s+/g, ' ')
            .trim()
            .slice(0, maximumLength);
    }

    function normaliseDebugLogForExport(value) {
        const now = Date.now();
        const source = value?.schema === 1 && Array.isArray(value.entries)
            ? value.entries
            : [];
        const allowedLevels = new Set(['debug', 'info', 'warn', 'error']);
        const allowedRoutes = new Set([
            'home',
            'forum-create',
            'thread',
            'forum',
            'stats-player-matches',
            'stats-players',
            'stats',
            'profile',
            'matches',
            'news',
            'other',
        ]);
        const entries = [];
        for (const rawEntry of source.slice(-MAX_DEBUG_ENTRIES * 2)) {
            if (!rawEntry || typeof rawEntry !== 'object' || Array.isArray(rawEntry)) continue;
            const at = Math.trunc(Number(rawEntry.at));
            const level = allowedLevels.has(rawEntry.level) ? rawEntry.level : '';
            const storedEvent = scrubDebugText(rawEntry.event, 80);
            const event = /^extension-(?:diagnostics|settings|storage|action-lock|reaction|reply|thread-preview|activity|user-action|read-state|match-filter|layout|war|kpr|sync|request|export|module|event)$/.test(storedEvent)
                ? storedEvent
                : 'extension-event';
            const route = allowedRoutes.has(rawEntry.route) ? rawEntry.route : 'other';
            if (!Number.isFinite(at)
                || at < now - DEBUG_RETENTION_MS
                || at > now + FUTURE_TIMESTAMP_SKEW_MS
                || !level
                || !event) continue;
            const rawError = rawEntry.error && typeof rawEntry.error === 'object'
                && !Array.isArray(rawEntry.error)
                ? rawEntry.error
                : null;
            let error = null;
            if (rawError) {
                const name = /^[A-Za-z][A-Za-z0-9_.-]{0,79}$/.test(String(rawError.name || ''))
                    ? String(rawError.name)
                    : 'Error';
                const code = /^[A-Za-z0-9_.:-]{1,80}$/.test(String(rawError.code || ''))
                    ? String(rawError.code)
                    : '';
                const stack = (Array.isArray(rawError.stack) ? rawError.stack : [])
                    .map(String)
                    .filter((frame) => /^(?:content|background|popup|ui)\/[A-Za-z0-9._/-]+\.js:\d+:\d+$/.test(frame))
                    .slice(0, 8);
                error = {
                    name,
                    ...(code ? { code } : {}),
                    ...(stack.length ? { stack } : {}),
                };
            }
            entries.push({
                at,
                level,
                event,
                route,
                count: clampInteger(rawEntry.count, 1, 10_000, 1),
                ...(error ? { error } : {}),
            });
        }
        return entries.slice(-MAX_DEBUG_ENTRIES);
    }

    async function exportDebugLog(button) {
        await runExport(button, 'Debug log was exported.', async () => {
            const stored = await extensionApi.storage.local.get([DEBUG_LOG_KEY]);
            downloadJson(
                exportFilename('debug-log'),
                exportEnvelope('hltv-enhancements-debug-log', {
                    log: {
                        localOnly: true,
                        automaticallyTransmitted: false,
                        retentionDays: 7,
                        redaction: 'No drafts, post text, usernames, tags, cookies, credentials, raw HTML, response bodies, full URLs, query strings, fragments, or numeric profile/thread identifiers.',
                        entries: normaliseDebugLogForExport(stored?.[DEBUG_LOG_KEY]),
                    },
                }),
            );
        });
    }

    async function clearDebugLog(button) {
        let confirmed = false;
        try {
            confirmed = globalThis.confirm('Clear the entire local diagnostic log?');
        } catch {
            confirmed = false;
        }
        if (!confirmed) return;
        button.disabled = true;
        button.setAttribute('aria-busy', 'true');
        setStatus('Clearing local debug log…');
        try {
            await extensionApi.storage.local.remove(DEBUG_LOG_KEY);
            setStatus('Local debug log was cleared.');
        } catch {
            setStatus('The local debug log could not be cleared.', true);
        } finally {
            button.disabled = false;
            button.setAttribute('aria-busy', 'false');
        }
    }

    function applySettingsToUi(settings) {
        const selected = new Set(settings.selectedSources);
        for (const source of SOURCES) {
            const checkbox = document.querySelector(`[data-source-id="${source.id}"]`);
            const limit = document.querySelector(`[data-source-limit="${source.id}"]`);
            const color = document.querySelector(`[data-source-color="${source.id}"]`);
            if (checkbox) checkbox.checked = selected.has(source.id);
            if (limit) limit.value = String(settings.sourceLimits[source.id]);
            if (color) {
                color.value = settings.sourceColors[source.id];
                color.closest('.source-row')?.style.setProperty(
                    '--source-color',
                    color.value,
                );
            }
        }

        const width = document.querySelector('[data-setting-select="layoutWidthPreset"]');
        if (width) width.value = settings.layoutWidthPreset;
        for (const select of document.querySelectorAll('[data-setting-select]')) {
            const key = select.dataset.settingSelect;
            select.querySelector('option[data-page-selected]')?.remove();
            if (key === 'previousPeriodMetric' && settings[key] != null
                && ![...select.options].some((option) => option.value === settings[key])) {
                const pageSelected = document.createElement('option');
                pageSelected.value = settings[key];
                pageSelected.textContent = `Page-selected: ${settings[key]}`;
                pageSelected.dataset.pageSelected = 'true';
                select.appendChild(pageSelected);
            }
            if (settings[key] != null && [...select.options].some((option) => option.value === settings[key])) {
                select.value = settings[key];
            }
        }
        const selectedMatchMetrics = new Set(settings.matchPlayerPrimaryMetrics);
        for (const input of document.querySelectorAll(
            '[data-match-player-metric-options] input[data-match-player-metric]',
        )) {
            input.checked = selectedMatchMetrics.has(input.value);
        }
        for (const input of document.querySelectorAll('[data-setting-key]')) {
            input.checked = Boolean(settings[input.dataset.settingKey]);
        }
        popupState.hiddenTags = [...settings.hiddenUserTags];
        popupState.statsOptionalColumns = normaliseStatsOptionalColumns(
            settings[STATS_OPTIONAL_COLUMNS_KEY],
        );
        cancelHiddenTagEdit();
        renderHiddenTags();
        syncHiddenTagControls();
        const sourceGroup = document.querySelector('[data-sync-source-controls="true"]');
        if (typeof sourceGroup?.syncSourceControls === 'function') {
            sourceGroup.syncSourceControls();
        }
    }

    function randomToken(prefix) {
        const bytes = new Uint32Array(3);
        if (globalThis.crypto?.getRandomValues) {
            globalThis.crypto.getRandomValues(bytes);
        } else {
            bytes[0] = Date.now() >>> 0;
            bytes[1] = Math.floor(Math.random() * 0xffffffff);
            bytes[2] = Math.floor(Math.random() * 0xffffffff);
        }
        return `${prefix}:${[...bytes].map((value) => value.toString(36)).join(':')}`;
    }

    function syncPulse(changed) {
        return {
            schema: 1,
            senderId: 'extension-popup',
            nonce: randomToken('popup-sync'),
            changed,
            at: Date.now(),
        };
    }

    function checkboxValue(settingKey) {
        return Boolean(
            document.querySelector(`[data-setting-key="${settingKey}"]`)?.checked,
        );
    }

    function selectValue(settingKey, fallback) {
        return document.querySelector(`[data-setting-select="${settingKey}"]`)?.value || fallback;
    }

    function settingsPayload() {
        const selectedSources = SOURCES
            .filter((source) => (
                document.querySelector(`[data-source-id="${source.id}"]`)?.checked
            ))
            .map((source) => source.id);
        const selectedForumIds = selectedSources.filter((sourceId) => (
            FORUM_IDS.has(sourceId)
        ));
        const sourceLimits = Object.fromEntries(SOURCES.map((source) => {
            const input = document.querySelector(`[data-source-limit="${source.id}"]`);
            return [
                source.id,
                clampInteger(
                    input?.value,
                    1,
                    MAX_SOURCE_LIMIT,
                    DEFAULTS.sourceLimits[source.id],
                ),
            ];
        }));
        const sourceColors = Object.fromEntries(SOURCES.map((source) => {
            const input = document.querySelector(`[data-source-color="${source.id}"]`);
            return [
                source.id,
                normaliseSourceColor(input?.value, DEFAULT_SOURCE_COLORS[source.id]),
            ];
        }));
        const width = document.querySelector('[data-setting-select="layoutWidthPreset"]');
        const layoutWidthPreset = ['default', 'wide', 'extra'].includes(width?.value)
            ? width.value
            : DEFAULTS.layoutWidthPreset;

        const matchPlayerPrimaryMetrics = matchPlayerMetricsFromUi();
        const [
            matchPlayerPrimaryMetric1,
            matchPlayerPrimaryMetric2,
        ] = legacyMatchPlayerMetricPair(matchPlayerPrimaryMetrics);

        return {
            activitySourcesV2: selectedSources,
            displayedForumsV1: selectedForumIds,
            selectedForums: selectedForumIds,
            hideMatches: !selectedSources.includes('matches'),
            hideNews: !selectedSources.includes('news'),
            forumThreadLimits: sourceLimits,
            activitySourceColorsV1: sourceColors,
            enableCustomThreadFetching: checkboxValue('enableCustomThreadFetching'),
            enableCustomThreadColors: checkboxValue('enableCustomThreadColors'),
            layoutWidthPreset,
            largeSidebarText: checkboxValue('largeSidebarText'),
            movePostNewTopicToTop: checkboxValue('movePostNewTopicToTop'),
            showRelativeAges: checkboxValue('showRelativeAges'),
            enableExtendedMatchFilter: checkboxValue('enableExtendedMatchFilter'),
            strictSelectedTeamMatches: checkboxValue('strictSelectedTeamMatches'),
            enableThreadPreviews: checkboxValue('enableThreadPreviews'),
            enableOriginalPosterHighlight: checkboxValue('enableOriginalPosterHighlight'),
            enableReadStatus: checkboxValue('enableReadStatus'),
            replyComposerAfterOriginalPost: checkboxValue(
                'replyComposerAfterOriginalPost',
            ),
            enableSavedDrafts: checkboxValue('enableSavedDrafts'),
            enableUserTags: checkboxValue('enableUserTags'),
            hiddenUserTags: normaliseHiddenTags(popupState.hiddenTags),
            enableLocalUserScores: checkboxValue('enableLocalUserScores'),
            enableLocalDownvotes: checkboxValue('enableLocalDownvotes'),
            changeUpvoteStyle: checkboxValue('changeUpvoteStyle'),
            enableSignedOutLocalVoting: checkboxValue(
                'enableSignedOutLocalVoting',
            ),
            enableUsernameBlocking: checkboxValue('enableUsernameBlocking'),
            enableWinAdjustedRatings: checkboxValue('enableStatsColumnChooser')
                && popupState.statsOptionalColumns.ranking.includes('war'),
            showFullMapNames: checkboxValue('showFullMapNames'),
            enableDiagnosticLogging: checkboxValue('enableDiagnosticLogging'),
            enableStickyMatchHeader: checkboxValue('enableStickyMatchHeader'),
            enableMatchPlayerFormOverlays: checkboxValue('enableMatchPlayerFormOverlays'),
            enableMatchPrediction: checkboxValue('enableMatchPrediction'),
            enableTeamPerformanceDifference: checkboxValue(
                'enableTeamPerformanceDifference',
            ),
            matchPlayerPrimaryMetrics,
            matchPlayerPrimaryMetric1,
            matchPlayerPrimaryMetric2,
            enableStatsColumnChooser: checkboxValue('enableStatsColumnChooser'),
            enableStatsMultiSort: checkboxValue('enableStatsMultiSort'),
            enableStatsCsvExport: checkboxValue('enableStatsCsvExport'),
            enablePlayerMatchSparklines: checkboxValue('enablePlayerMatchSparklines'),
            enableExtendedMatchHistoryLoading: checkboxValue(
                'enableExtendedMatchHistoryLoading',
            ),
            enablePlayerMapMatrix: checkboxValue('enablePlayerMapMatrix'),
            enablePlayerComparisonEnhancements: checkboxValue('enablePlayerComparisonEnhancements'),
            enablePlayerConsistencyScore: checkboxValue('enablePlayerConsistencyScore'),
            enableStatsTablePeriodComparison: checkboxValue(
                'enableStatsTablePeriodComparison',
            ),
            enablePlayerPagePeriodComparison: checkboxValue(
                'enablePlayerPagePeriodComparison',
            ),
            previousPeriodMetric: normalisePreviousPeriodMetric(
                selectValue('previousPeriodMetric', DEFAULTS.previousPeriodMetric),
            ),
            [STATS_OPTIONAL_COLUMNS_KEY]: normaliseStatsOptionalColumns(
                popupState.statsOptionalColumns,
            ),
            [SYNC_PULSE_KEY]: syncPulse(['settings']),
        };
    }

    async function saveSettings(event) {
        event.preventDefault();
        if (!popupState.ready) return;
        if (popupState.externalChangeWhileDirty) {
            setStatus(
                'Settings changed elsewhere while this popup was open. Close and reopen it before saving.',
                true,
            );
            return;
        }
        const saveButton = event.currentTarget.querySelector('button[type="submit"]');
        if (saveButton) saveButton.disabled = true;
        popupState.saving = true;
        setStatus('Saving\u2026');
        try {
            await extensionApi.storage.local.set(settingsPayload());
            popupState.dirty = false;
            setStatus('Saved. Open HLTV tabs will update automatically.');
        } catch {
            setStatus('Settings could not be saved.', true);
        } finally {
            popupState.saving = false;
            if (saveButton) saveButton.disabled = false;
        }
    }

    async function handleExternalStorageChange(changes, areaName) {
        if (!popupState.ready
            || popupState.saving
            || popupState.importing
            || areaName !== 'local'
            || !changes
            || !SETTINGS_READ_KEYS.some((key) => Object.hasOwn(changes, key))) return;
        if (popupState.dirty) {
            popupState.externalChangeWhileDirty = true;
            setStatus(
                'Settings changed elsewhere. Close and reopen this popup before saving.',
                true,
            );
            return;
        }
        try {
            const stored = await extensionApi.storage.local.get(SETTINGS_READ_KEYS);
            applySettingsToUi(normaliseStoredSettings(stored || {}));
            popupState.dirty = false;
            setStatus('Settings refreshed from another extension view.');
        } catch {
            setStatus('Updated settings could not be reloaded.', true);
        }
    }

    function sleep(milliseconds) {
        return new Promise((resolve) => globalThis.setTimeout(resolve, milliseconds));
    }

    function parseActiveLease(value) {
        if (typeof value !== 'string') return null;
        try {
            const lease = JSON.parse(value);
            const owner = String(lease?.owner || '');
            const expiresAt = Number(lease?.expiresAt);
            if (!/^[A-Za-z0-9_:-]{1,100}$/.test(owner)
                || !Number.isFinite(expiresAt)
                || expiresAt <= Date.now()
                || expiresAt > Date.now() + 30_000) return null;
            return { owner, expiresAt };
        } catch {
            return null;
        }
    }

    async function acquireReactionLease(owner) {
        const deadline = Date.now() + 5000;
        while (Date.now() < deadline) {
            const currentResult = await extensionApi.storage.local.get(
                REACTION_LEASE_KEY,
            );
            const current = parseActiveLease(currentResult?.[REACTION_LEASE_KEY]);
            if (current && current.owner !== owner) {
                await sleep(25);
                continue;
            }
            await extensionApi.storage.local.set({
                [REACTION_LEASE_KEY]: JSON.stringify({
                    owner,
                    expiresAt: Date.now() + 10_000,
                }),
            });
            await sleep(25);
            const confirmedResult = await extensionApi.storage.local.get(
                REACTION_LEASE_KEY,
            );
            if (parseActiveLease(confirmedResult?.[REACTION_LEASE_KEY])?.owner === owner) {
                return owner;
            }
        }
        throw new Error('Timed out acquiring the local reaction reset lease.');
    }

    async function ownsReactionLease(owner) {
        const result = await extensionApi.storage.local.get(REACTION_LEASE_KEY);
        return parseActiveLease(result?.[REACTION_LEASE_KEY])?.owner === owner;
    }

    function reactionLeaseLostError() {
        const error = new Error('The local reaction reset lease changed owners.');
        error.code = 'reaction-lease-lost';
        return error;
    }

    async function assertReactionLeaseOwner(owner) {
        if (!await ownsReactionLease(owner)) throw reactionLeaseLostError();
    }

    async function releaseReactionLease(owner) {
        const result = await extensionApi.storage.local.get(REACTION_LEASE_KEY);
        if (parseActiveLease(result?.[REACTION_LEASE_KEY])?.owner === owner) {
            await extensionApi.storage.local.remove(REACTION_LEASE_KEY);
        }
    }

    async function withReactionLease(operation) {
        const deadline = Date.now() + 5000;
        while (Date.now() < deadline) {
            const owner = randomToken('popup-reset');
            await acquireReactionLease(owner);
            let renewing = false;
            const heartbeat = globalThis.setInterval(() => {
                if (renewing) return;
                renewing = true;
                (async () => {
                    if (!await ownsReactionLease(owner)) return;
                    await extensionApi.storage.local.set({
                        [REACTION_LEASE_KEY]: JSON.stringify({
                            owner,
                            expiresAt: Date.now() + 10_000,
                        }),
                    });
                })().catch(() => undefined).finally(() => {
                    renewing = false;
                });
            }, 2000);

            let result;
            let operationError = null;
            try {
                result = await operation(() => assertReactionLeaseOwner(owner));
            } catch (error) {
                operationError = error;
            } finally {
                globalThis.clearInterval(heartbeat);
            }

            let stillOwner = false;
            try {
                stillOwner = await ownsReactionLease(owner);
            } catch {
                stillOwner = false;
            }
            if (stillOwner) {
                try {
                    await releaseReactionLease(owner);
                } catch (error) {
                    if (!operationError) operationError = error;
                }
            }
            if (!operationError && stillOwner) return result;
            if (!operationError) operationError = reactionLeaseLostError();
            if (operationError?.code !== 'reaction-lease-lost') throw operationError;
            await sleep(25);
        }
        throw new Error('Timed out completing the local reaction reset safely.');
    }

    function validResetTimestamp(value, now = Date.now()) {
        const timestamp = Number(value);
        return Number.isFinite(timestamp)
            && timestamp >= MIN_VALID_TIMESTAMP
            && timestamp <= now + 300_000
            ? timestamp
            : 0;
    }

    function resetReactionRecord(value) {
        const now = Date.now();
        const source = (value?.schema === 1 || value?.schema === 2)
            && value.reactions
            && typeof value.reactions === 'object'
            && !Array.isArray(value.reactions)
            ? value.reactions
            : {};
        const entries = [];
        let inspected = 0;
        for (const [key, rawEntry] of Object.entries(source)) {
            inspected += 1;
            if (inspected > MAX_LOCAL_REACTIONS * 4) break;
            if (!/^(?:thread|reply):\d{1,20}$/.test(key)
                || !rawEntry
                || typeof rawEntry !== 'object') continue;
            const authorId = String(rawEntry.authorId ?? '');
            const reactionValue = Number(rawEntry.value);
            const updatedAt = validResetTimestamp(rawEntry.updatedAt, now);
            if (!/^\d{1,20}$/.test(authorId)
                || ![-1, 0, 1].includes(reactionValue)
                || !updatedAt) continue;
            entries.push([key, { authorId, updatedAt }]);
            if (entries.length >= MAX_LOCAL_REACTIONS) break;
        }
        const newest = Math.max(0, ...entries.map(([, entry]) => entry.updatedAt));
        const previousResetAt = value?.schema === 2
            ? validResetTimestamp(value.resetAt, now)
            : 0;
        const resetAt = Math.max(now, previousResetAt + 1, newest);
        const reactions = {};
        entries.forEach(([key, entry], index) => {
            reactions[key] = {
                authorId: entry.authorId,
                value: 0,
                updatedAt: Math.max(resetAt + index + 1, entry.updatedAt + 1),
                mutationId: randomToken('popup-reaction-reset').slice(0, 80),
            };
        });
        return {
            schema: 2,
            resetAt,
            updatedAt: now,
            reactions,
        };
    }

    function compareReactionEntries(first, second) {
        const timestampDifference = Number(first?.updatedAt || 0)
            - Number(second?.updatedAt || 0);
        if (timestampDifference) return timestampDifference;
        return String(first?.mutationId || '').localeCompare(
            String(second?.mutationId || ''),
        );
    }

    function normaliseReactionRecord(value, minimumResetAt = 0) {
        const now = Date.now();
        const resetAt = Math.max(
            validResetTimestamp(minimumResetAt, now),
            value?.schema === 2 ? validResetTimestamp(value.resetAt, now) : 0,
        );
        const source = (value?.schema === 1 || value?.schema === 2)
            && value.reactions
            && typeof value.reactions === 'object'
            && !Array.isArray(value.reactions)
            ? value.reactions
            : {};
        const entries = [];
        let inspected = 0;
        for (const [key, rawEntry] of Object.entries(source)) {
            inspected += 1;
            if (inspected > MAX_LOCAL_REACTIONS * 4) break;
            const authorId = String(rawEntry?.authorId ?? '');
            const reactionValue = Number(rawEntry?.value);
            const updatedAt = validResetTimestamp(rawEntry?.updatedAt, now);
            if (!/^(?:thread|reply):\d{1,20}$/.test(key)
                || !/^\d{1,20}$/.test(authorId)
                || ![-1, 0, 1].includes(reactionValue)
                || !updatedAt
                || updatedAt <= resetAt) continue;
            const rawMutationId = String(rawEntry?.mutationId || `${updatedAt}:legacy`);
            const mutationId = /^[A-Za-z0-9_.:-]{1,80}$/.test(rawMutationId)
                ? rawMutationId
                : `${updatedAt}:legacy`;
            entries.push([key, {
                authorId,
                value: reactionValue,
                updatedAt,
                mutationId,
            }]);
        }
        entries.sort((first, second) => compareReactionEntries(second[1], first[1]));
        return {
            resetAt,
            reactions: new Map(entries.slice(0, MAX_LOCAL_REACTIONS)),
        };
    }

    function serialiseReactionRecord(state) {
        return {
            schema: 2,
            resetAt: state.resetAt,
            updatedAt: Date.now(),
            reactions: Object.fromEntries(
                [...state.reactions.entries()]
                    .sort((first, second) => compareReactionEntries(second[1], first[1]))
                    .slice(0, MAX_LOCAL_REACTIONS),
            ),
        };
    }

    function mergeReactionRecords(firstValue, secondValue) {
        const resetAt = Math.max(
            firstValue?.schema === 2 ? validResetTimestamp(firstValue.resetAt) : 0,
            secondValue?.schema === 2 ? validResetTimestamp(secondValue.resetAt) : 0,
        );
        const first = normaliseReactionRecord(firstValue, resetAt);
        const second = normaliseReactionRecord(secondValue, resetAt);
        const merged = new Map(first.reactions);
        for (const [key, incoming] of second.reactions) {
            const current = merged.get(key);
            if (!current || compareReactionEntries(incoming, current) > 0) {
                merged.set(key, incoming);
            }
        }
        return serialiseReactionRecord({
            resetAt,
            reactions: merged,
        });
    }

    function reactionRecordSignature(value) {
        const normalised = normaliseReactionRecord(
            value,
            value?.schema === 2 ? validResetTimestamp(value.resetAt) : 0,
        );
        return JSON.stringify([
            normalised.resetAt,
            [...normalised.reactions.entries()]
                .sort(([firstKey], [secondKey]) => firstKey.localeCompare(secondKey)),
        ]);
    }

    async function writeResetReactionState(assertOwner) {
        const stored = await extensionApi.storage.local.get(LOCAL_REACTIONS_KEY);
        let desired = resetReactionRecord(stored?.[LOCAL_REACTIONS_KEY]);
        for (let attempt = 0; attempt < 3; attempt += 1) {
            await assertOwner();
            await extensionApi.storage.local.set({
                [LOCAL_REACTIONS_KEY]: desired,
                [PROVISIONAL_LOCAL_UPVOTES_KEY]: {
                    schema: 1,
                    updatedAt: Date.now(),
                    upvotes: {},
                },
                [SYNC_PULSE_KEY]: syncPulse(['reactions']),
            });
            await assertOwner();
            const confirmedResult = await extensionApi.storage.local.get(
                LOCAL_REACTIONS_KEY,
            );
            const confirmed = confirmedResult?.[LOCAL_REACTIONS_KEY];
            const merged = mergeReactionRecords(desired, confirmed);
            if (reactionRecordSignature(merged) === reactionRecordSignature(confirmed)) {
                return merged;
            }
            desired = merged;
        }
        throw new Error('Could not confirm the local reaction reset without losing an update.');
    }

    async function resetLocalReactionCounts(button) {
        let confirmed = false;
        try {
            confirmed = globalThis.confirm(
                'Are you sure you want to reset all local user reaction counts?',
            );
            if (confirmed) {
                confirmed = globalThis.confirm(
                    'Are you REALLY sure? This permanently clears every local upvote and downvote count.',
                );
            }
        } catch {
            confirmed = false;
        }
        if (!confirmed) return;

        button.disabled = true;
        button.setAttribute('aria-busy', 'true');
        setStatus('Resetting local reaction counts\u2026');
        try {
            await withReactionLease(writeResetReactionState);
            setStatus('All local reaction counts were reset.');
        } catch {
            setStatus('Local reaction counts could not be reset.', true);
        } finally {
            button.disabled = false;
            button.setAttribute('aria-busy', 'false');
        }
    }

    async function reloadActiveHltvTab() {
        if (typeof extensionApi?.tabs?.query !== 'function'
            || typeof extensionApi?.tabs?.reload !== 'function') return;
        try {
            const tabs = await extensionApi.tabs.query({
                active: true,
                currentWindow: true,
            });
            const tab = Array.isArray(tabs) ? tabs[0] : null;
            if (!Number.isInteger(tab?.id)) return;
            const tabUrl = typeof tab.url === 'string' ? tab.url : '';
            if (tabUrl === HLTV_ORIGIN || tabUrl.startsWith(`${HLTV_ORIGIN}/`)) {
                await extensionApi.tabs.reload(tab.id);
            }
        } catch {
            // The grant still persists if the active tab cannot be inspected or reloaded.
        }
    }

    async function requestSiteAccess(button, panel) {
        button.disabled = true;
        button.setAttribute('aria-busy', 'true');
        setStatus('Waiting for the browser to allow HLTV.org access…');
        try {
            const granted = await extensionApi.permissions.request({
                origins: [HLTV_HOST_PERMISSION],
            });
            if (!granted) {
                setStatus('HLTV.org access was not granted.', true);
                return;
            }
            panel.hidden = true;
            setStatus('HLTV.org access enabled. Reloading the page…');
            await reloadActiveHltvTab();
        } catch {
            setStatus('HLTV.org access could not be requested.', true);
        } finally {
            button.disabled = false;
            button.setAttribute('aria-busy', 'false');
        }
    }

    async function initialiseSiteAccess() {
        const panel = document.querySelector('#site-access-panel');
        const button = document.querySelector('#site-access-grant');
        if (extensionApi?.runtime?.getURL('').startsWith('chrome-extension:')) return;
        if (!panel || !button
            || typeof extensionApi?.permissions?.contains !== 'function'
            || typeof extensionApi.permissions.request !== 'function') return;

        button.addEventListener('click', () => requestSiteAccess(button, panel));
        try {
            const granted = await extensionApi.permissions.contains({
                origins: [HLTV_HOST_PERMISSION],
            });
            panel.hidden = Boolean(granted);
        } catch {
            panel.hidden = false;
        }
    }

    async function initialise() {
        buildSettingsUi();
        const form = document.querySelector('#settings-form');
        const saveButton = form?.querySelector('button[type="submit"]');
        const cancelButton = document.querySelector('#settings-cancel');
        if (saveButton) saveButton.disabled = true;
        form?.addEventListener('submit', saveSettings);
        cancelButton?.addEventListener('click', () => globalThis.close?.());
        form?.addEventListener('input', () => {
            if (popupState.ready) popupState.dirty = true;
        });
        form?.addEventListener('change', () => {
            if (popupState.ready) popupState.dirty = true;
        });

        try {
            const manifest = extensionApi.runtime.getManifest();
            const version = String(manifest?.version || '');
            const versionElement = document.querySelector('#popup-version');
            if (versionElement) {
                versionElement.textContent = version ? `Version ${version}` : 'Settings';
            }
            const stored = await extensionApi.storage.local.get(SETTINGS_READ_KEYS);
            applySettingsToUi(normaliseStoredSettings(stored || {}));
            popupState.ready = true;
            popupState.dirty = false;
            extensionApi.storage.onChanged?.addListener?.(
                handleExternalStorageChange,
            );
            if (saveButton) saveButton.disabled = false;
            setStatus('');
            initialiseSiteAccess();
        } catch {
            setStatus('Extension settings could not be loaded.', true);
        }
    }

    if (!extensionApi?.storage?.local
        || typeof extensionApi.storage.local.get !== 'function'
        || typeof extensionApi.storage.local.set !== 'function'
        || typeof extensionApi.storage.local.remove !== 'function'
        || typeof extensionApi?.runtime?.getManifest !== 'function'
        || typeof extensionApi.runtime.getURL !== 'function') {
        document.addEventListener('DOMContentLoaded', () => {
            setStatus('Browser extension APIs are unavailable.', true);
        }, { once: true });
        return;
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initialise, { once: true });
    } else {
        initialise();
    }
})();
