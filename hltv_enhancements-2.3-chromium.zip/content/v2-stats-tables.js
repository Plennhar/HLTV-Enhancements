// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Plennhar

(() => {
    'use strict';

    const PREFIX = 'hltv-v2-stats';
    const SETTINGS = Object.freeze({
        enableStatsColumnChooser: true,
        enableStatsMultiSort: true,
        enableStatsCsvExport: true,
        enablePlayerMatchSparklines: true,
        enableExtendedMatchHistoryLoading: true,
        enableStatsTablePeriodComparison: true,
        enableWinAdjustedRatings: true,
        playerMatchTrendMetric: 'rating',
        statsMatchHistoryRowsV2: 100,
        statsColumnLayoutV2: {},
        statsOptionalColumnsV2: {},
        statsMultiSortV2: {},
    });
    const SETTING_KEYS = Object.freeze(Object.keys(SETTINGS));
    const BOOLEAN_SETTING_KEYS = Object.freeze(SETTING_KEYS.filter((key) => key.startsWith('enable')));
    const TABLE_SELECTORS = Object.freeze({
        ranking: 'table.player-ratings-table',
        matches: 'table.stats-matches-table',
    });
    const SUPPORTED_TABLE_SELECTOR = Object.values(TABLE_SELECTORS).join(', ');
    const MATCH_HISTORY_PATH_PATTERN = /^\/stats\/players\/matches\/(\d{1,20})\/([a-z0-9_-]{1,100})\/?$/i;
    const MAP_STATS_PATH_PATTERN = /^\/stats\/matches\/mapstatsid\/(\d{1,20})\/[a-z0-9_-]{1,160}\/?$/i;
    const TEAM_STATS_PATH_PATTERN = /^\/stats\/teams\/(\d{1,20})\/[a-z0-9_-]{1,160}\/?$/i;
    const MATCH_HISTORY_ROW_OPTIONS = Object.freeze([100, 200, 300, 400, 500, 'all']);
    const MATCH_HISTORY_INITIAL_DELAY_MS = 500;
    const MATCH_HISTORY_FETCH_SPACING_MS = 500;
    const MATCH_HISTORY_RETRY_DELAYS_MS = Object.freeze([3000, 5000]);
    const MATCH_HISTORY_MAX_PAGES = 100;
    const MATCH_HISTORY_MAX_ROWS_PER_PAGE = 100;
    const MATCH_HISTORY_MAX_ROWS = 10_000;
    const MATCH_HISTORY_MAX_PAGE_BYTES = 20 * 1024 * 1024;
    const MATCH_HISTORY_MAX_TOTAL_BYTES = 128 * 1024 * 1024;
    const MATCH_HISTORY_IMAGE_ORIGINS = new Set([
        'https://www.hltv.org',
        'https://img-cdn.hltv.org',
    ]);
    const NUMERIC_COLUMNS = new Set([
        'maps', 'rounds', 'kpr', 'kd-diff', 'kd', 'rating',
        'dpr', 'kills-per-map', 'plus-minus', 'kills', 'deaths',
        'war', 'period-delta',
    ]);
    const OPTIONAL_COLUMNS = Object.freeze({
        ranking: Object.freeze([
            Object.freeze({
                id: 'kpr',
                label: 'KPR (est.)',
                title: 'Estimated kills per round. A range is shown because HLTV rounds K/D.',
                digits: 2,
            }),
            Object.freeze({
                id: 'dpr',
                label: 'DPR (est.)',
                title: 'Estimated deaths per round. A range is shown because HLTV rounds K/D.',
                digits: 2,
            }),
            Object.freeze({
                id: 'kills-per-map',
                label: 'Kills/map (est.)',
                title: 'Estimated kills per map. A range is shown because HLTV rounds K/D.',
                digits: 1,
            }),
            Object.freeze({
                id: 'war',
                label: 'WAR',
                title: 'Win-adjusted Rating.',
                external: true,
            }),
        ]),
        matches: Object.freeze([
            Object.freeze({
                id: 'kpr',
                label: 'KPR',
                title: 'Kills per round, calculated from the exact map totals.',
                digits: 2,
            }),
            Object.freeze({
                id: 'dpr',
                label: 'DPR',
                title: 'Deaths per round, calculated from the exact map totals.',
                digits: 2,
            }),
        ]),
    });
    const COLUMN_EXPLANATIONS = Object.freeze({
        ranking: Object.freeze({
            kpr: 'Estimated kills per round (KPR). HLTV supplies rounds played, K-D difference, and K/D rounded to two decimals. The extension finds the integer kill and death totals that are compatible with the displayed K/D rounding and K-D difference, divides the lowest and highest compatible kill totals by rounds played, and shows that possible range. Sorting uses the midpoint of the displayed range.',
            dpr: 'Estimated deaths per round (DPR). The extension first reconstructs the range of integer kill and death totals compatible with HLTV\'s rounded K/D, exact K-D difference, and rounds played. It divides the lowest and highest compatible death totals by rounds played and shows the resulting range. Sorting uses the midpoint of that range.',
            'kills-per-map': 'Estimated kills per map. The extension reconstructs the possible integer kill totals from HLTV\'s rounded K/D, exact K-D difference, and rounds played, then divides the minimum and maximum compatible kill totals by maps played. The result is a range because HLTV displays K/D to only two decimals. Sorting uses the midpoint of the range.',
            war: 'Win-adjusted Rating (WAR) starts with each player\'s normal HLTV Rating. For each one-team player, it converts team wins, draws, and losses into team win percentage. Across usable rows it estimates beta = Cov(team win percentage, Rating) / Var(team win percentage), then calculates WAR = Rating - beta * (team win percentage - average team win percentage). Stronger-than-average team context therefore pulls a rating down and weaker-than-average context lifts it. Multi-team players show ? because their rating cannot be assigned reliably between teams. WAR is a simple team-win correction, not a complete measure of individual skill.',
            'period-delta': 'Baseline delta compares the table\'s selected current statistic with the same statistic over the chosen baseline date range. For each matched player, Delta = current-period value - baseline-period value. Positive values mean the current period is higher. The comparison keeps the page\'s compatible filters, stores baseline dates in the URL, and is disabled for a specific-event filter because that event has no meaningful equivalent baseline.',
        }),
        matches: Object.freeze({
            kpr: 'Exact kills per round (KPR) for this map. The extension reads the displayed K-D totals, adds both teams\' final map scores to obtain rounds played, and calculates KPR = kills / rounds. Unlike the ranking-table estimate, this uses exact map kills and rounds, so no range is needed.',
            dpr: 'Exact deaths per round (DPR) for this map. The extension reads the displayed K-D totals, adds both teams\' final map scores to obtain rounds played, and calculates DPR = deaths / rounds. Exact map deaths and rounds are available, so no estimated range is needed.',
        }),
    });
    const RETIRED_COLUMN_IDS = new Set(['net-kpr']);
    const METRIC_LABELS = Object.freeze({
        kpr: 'KPR',
        dpr: 'DPR',
        kd: 'K/D',
        'kd-diff': 'K-D differential',
        'kills-deaths': 'K-D',
        'kills-per-map': 'Kills per map',
        'plus-minus': 'K-D differential',
        'period-delta': 'Baseline delta',
        rating: 'Rating',
        rounds: 'Rounds',
        maps: 'Maps',
        kills: 'Kills',
        deaths: 'Deaths',
        war: 'WAR',
    });
    const storage = globalThis.GM;
    if (!storage || typeof storage.getValue !== 'function' || typeof storage.setValue !== 'function') return;
    if (!/^\/stats\/players(?:\/matches\/\d{1,20}\/[^/?#]+)?\/?$/.test(location.pathname)) return;

    const state = {
        settings: { ...SETTINGS },
        models: new Map(),
        listeners: [],
        observer: null,
        documentClickListener: null,
        syncTimer: 0,
        syncing: false,
        active: false,
        infoIdSequence: 0,
        historySanitizer: null,
    };

    function safeObject(value) {
        return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
    }

    function clampText(value, maximum = 100) {
        return String(value ?? '').trim().slice(0, maximum);
    }

    function finiteNumber(value) {
        const number = Number(value);
        return Number.isFinite(number) ? number : null;
    }

    function finiteAttributeNumber(value) {
        const text = String(value ?? '').trim();
        return text ? finiteNumber(text) : null;
    }

    function parseNumber(text) {
        const match = String(text ?? '').replace(/,/g, '').match(/[+-]?(?:\d+(?:\.\d+)?|\.\d+)/);
        return match ? finiteNumber(match[0]) : null;
    }

    function normaliseMetric(value, fallback = 'rating') {
        const metric = clampText(value, 40).toLowerCase();
        return NUMERIC_COLUMNS.has(metric) ? metric : fallback;
    }

    function normaliseMatchHistoryRows(value) {
        if (String(value).toLowerCase() === 'all') return 'all';
        const numeric = Number(value);
        return MATCH_HISTORY_ROW_OPTIONS.includes(numeric) ? numeric : 100;
    }

    function normaliseLayout(value) {
        const source = safeObject(value);
        const result = {};
        for (const type of Object.keys(TABLE_SELECTORS)) {
            const item = safeObject(source[type]);
            const allowed = (id) => !RETIRED_COLUMN_IDS.has(id)
                && !(type === 'matches' && id === 'kills-per-map');
            const order = Array.isArray(item.order)
                ? [...new Set(item.order.map((entry) => clampText(entry, 40)).filter((entry) => entry && allowed(entry)))].slice(0, 40)
                : [];
            const hidden = Array.isArray(item.hidden)
                ? [...new Set(item.hidden.map((entry) => clampText(entry, 40)).filter((entry) => entry && allowed(entry)))].slice(0, 40)
                : [];
            result[type] = { order, hidden };
        }
        return result;
    }

    function normaliseOptionalColumns(value, legacyWarEnabled = null) {
        const source = safeObject(value);
        const hasExplicitValue = value && typeof value === 'object' && !Array.isArray(value);
        const result = {};
        for (const type of Object.keys(TABLE_SELECTORS)) {
            const allowed = new Set(OPTIONAL_COLUMNS[type].map((definition) => definition.id));
            const selected = Array.isArray(source[type]) ? source[type] : [];
            const migrated = new Set(selected);
            if (type === 'ranking' && hasExplicitValue
                && legacyWarEnabled === true && !migrated.has('war')) {
                migrated.add('war');
            }
            result[type] = OPTIONAL_COLUMNS[type]
                .map((definition) => definition.id)
                .filter((id) => allowed.has(id) && migrated.has(id));
        }
        return result;
    }

    function migrateOptionalColumns(
        enableKprEstimate,
        enableKprMatchHistory,
        enableDerivedStatsColumns,
        layout,
        legacyWarEnabled = null,
    ) {
        const hidden = safeObject(layout);
        const rankingHidden = new Set(hidden.ranking?.hidden || []);
        const matchesHidden = new Set(hidden.matches?.hidden || []);
        const hasLegacySelection = enableKprEstimate !== null
            || enableKprMatchHistory !== null
            || enableDerivedStatsColumns !== null;
        if (!hasLegacySelection) {
            return normaliseOptionalColumns(Object.fromEntries(
                Object.keys(TABLE_SELECTORS).map((type) => {
                    const hiddenIds = new Set(hidden[type]?.hidden || []);
                    return [
                        type,
                        OPTIONAL_COLUMNS[type]
                            .map((definition) => definition.id)
                            .filter((id) => !hiddenIds.has(id)),
                    ];
                }),
            ));
        }
        const matchHistoryKpr = enableKprMatchHistory === null
            ? enableKprEstimate === true
            : enableKprMatchHistory === true;
        return normaliseOptionalColumns({
            ranking: [
                ...(enableKprEstimate === true && !rankingHidden.has('kpr') ? ['kpr'] : []),
                ...(enableDerivedStatsColumns === true && !rankingHidden.has('dpr') ? ['dpr'] : []),
                ...(enableDerivedStatsColumns === true && !rankingHidden.has('kills-per-map') ? ['kills-per-map'] : []),
                ...(legacyWarEnabled !== false ? ['war'] : []),
            ],
            matches: [
                ...(matchHistoryKpr && !matchesHidden.has('kpr') ? ['kpr'] : []),
                ...(enableDerivedStatsColumns === true && !matchesHidden.has('dpr') ? ['dpr'] : []),
            ],
        });
    }

    function normaliseSort(value) {
        const source = safeObject(value);
        const result = {};
        for (const type of Object.keys(TABLE_SELECTORS)) {
            const rows = Array.isArray(source[type]) ? source[type] : [];
            result[type] = rows.slice(0, 12).map((entry) => ({
                id: clampText(entry?.id, 40),
                direction: entry?.direction === 'asc' ? 'asc' : 'desc',
            })).filter((entry) => entry.id);
        }
        return result;
    }

    async function loadSettings() {
        const values = await Promise.all(SETTING_KEYS.map((key) => (
            storage.getValue(
                key,
                key === 'statsOptionalColumnsV2' || key === 'enableWinAdjustedRatings'
                    ? null
                    : SETTINGS[key],
            )
        )));
        SETTING_KEYS.forEach((key, index) => {
            state.settings[key] = values[index];
        });
        const legacyWarEnabled = state.settings.enableWinAdjustedRatings;
        for (const key of BOOLEAN_SETTING_KEYS) {
            state.settings[key] = state.settings[key] === true;
        }
        state.settings.playerMatchTrendMetric = normaliseMetric(state.settings.playerMatchTrendMetric);
        state.settings.statsMatchHistoryRowsV2 = normaliseMatchHistoryRows(
            state.settings.statsMatchHistoryRowsV2,
        );
        state.settings.statsColumnLayoutV2 = normaliseLayout(state.settings.statsColumnLayoutV2);
        if (state.settings.statsOptionalColumnsV2 === null) {
            const [legacyKpr, legacyMatchHistoryKpr, legacyDerived] = await Promise.all([
                storage.getValue('enableKprEstimate', null),
                storage.getValue('enableKprMatchHistory', null),
                storage.getValue('enableDerivedStatsColumns', null),
            ]);
            state.settings.statsOptionalColumnsV2 = migrateOptionalColumns(
                legacyKpr,
                legacyMatchHistoryKpr,
                legacyDerived,
                state.settings.statsColumnLayoutV2,
                legacyWarEnabled,
            );
            storage.setValue('statsOptionalColumnsV2', state.settings.statsOptionalColumnsV2)
                .catch((error) => console.warn(
                    '[HLTV Enhancements] Could not migrate stats-table columns.',
                    error,
                ));
        } else {
            const original = state.settings.statsOptionalColumnsV2;
            state.settings.statsOptionalColumnsV2 = normaliseOptionalColumns(
                original,
                legacyWarEnabled,
            );
            if (JSON.stringify(original) !== JSON.stringify(state.settings.statsOptionalColumnsV2)) {
                storage.setValue('statsOptionalColumnsV2', state.settings.statsOptionalColumnsV2)
                    .catch((error) => console.warn(
                        '[HLTV Enhancements] Could not migrate the WAR column selection.',
                        error,
                    ));
            }
        }
        state.settings.enableWinAdjustedRatings = state.settings.enableStatsColumnChooser
            && state.settings.statsOptionalColumnsV2.ranking.includes('war');
        state.settings.statsMultiSortV2 = normaliseSort(state.settings.statsMultiSortV2);
    }

    function selectedOptionalIds(type) {
        return new Set(normaliseOptionalColumns(state.settings.statsOptionalColumnsV2)[type] || []);
    }

    function pageTableType() {
        return /^\/stats\/players\/matches\//.test(globalThis.location?.pathname || '')
            ? 'matches'
            : 'ranking';
    }

    function documentHasCustomColumn() {
        const currentDocument = globalThis.document;
        if (!currentDocument) return false;
        return [...currentDocument.querySelectorAll(SUPPORTED_TABLE_SELECTOR)].some((table) => Boolean(
            table.querySelector(
                'th.tmKprRangeCol, '
                + 'th[data-hltv-win-adjusted-col], '
                + 'th.hltv-v2-period-header',
            ),
        ));
    }

    function anyFeatureEnabled() {
        if (pageTableType() === 'matches' && state.settings.enableExtendedMatchHistoryLoading) {
            return true;
        }
        if (state.settings.enableStatsColumnChooser
            || state.settings.enableStatsMultiSort
            || state.settings.enableStatsCsvExport) return true;
        const type = pageTableType();
        if (type === 'matches' && state.settings.enablePlayerMatchSparklines) return true;
        if (type === 'ranking' && (
            state.settings.enableStatsTablePeriodComparison
            || state.settings.enableWinAdjustedRatings
        )) return true;
        return documentHasCustomColumn();
    }

    function persist(key, value) {
        state.settings[key] = value;
        storage.setValue(key, value).catch((error) => {
            console.warn('[HLTV Enhancements] Could not save stats-table preference.', error);
        });
    }

    function injectStyle() {
        if (document.getElementById(`${PREFIX}-style`)) return;
        const style = document.createElement('style');
        style.id = `${PREFIX}-style`;
        style.textContent = `
            .${PREFIX}-toolbar { align-items:center; background:#263442; border:1px solid #435568; display:flex; flex-wrap:wrap; gap:6px; margin:0 0 8px; padding:6px; }
            .${PREFIX}-toolbar button, .${PREFIX}-toolbar select { background:#34495e; border:1px solid #52677b; color:#d6dde3; font:inherit; min-height:25px; padding:3px 7px; }
            .${PREFIX}-toolbar button { cursor:pointer; }
            .${PREFIX}-toolbar button:disabled { cursor:default; }
            .${PREFIX}-toolbar button:hover, .${PREFIX}-toolbar button:focus-visible { border-color:#87a3bf; }
            .${PREFIX}-chooser { background:#202b35; border:1px solid #52677b; box-shadow:0 4px 14px rgba(0,0,0,.45); display:grid; gap:4px; max-height:360px; min-width:240px; overflow:auto; padding:7px; position:absolute; z-index:10020; }
            .${PREFIX}-chooser[hidden] { display:none; }
            .${PREFIX}-chooser-row { align-items:center; display:grid; gap:5px; grid-template-columns:18px 1fr 27px 27px 24px; }
            .${PREFIX}-chooser-row button { min-height:23px; padding:0; }
            .${PREFIX}-column-info { align-items:center; border-radius:50%; display:inline-flex; font-size:11px; font-weight:700; height:20px; justify-content:center; line-height:1; min-height:20px !important; padding:0 !important; width:20px; }
            .${PREFIX}-column-info[aria-expanded="true"] { border-color:#87a3bf; color:#87a3bf; }
            .${PREFIX}-column-info svg { display:block; height:12px; width:12px; }
            .${PREFIX}-column-help { background:#18222c; border-left:2px solid #87a3bf; color:#b7c1ca; font-size:10px; line-height:1.5; margin:0 0 3px 23px; max-width:390px; padding:6px 8px; white-space:normal; }
            .${PREFIX}-column-help[hidden] { display:none; }
            .${PREFIX}-col-hidden { display:none !important; }
            .${PREFIX}-sort-badge { color:#87a3bf; font-size:9px; margin-left:4px; white-space:nowrap; }
            .${PREFIX}-derived { text-align:center; white-space:nowrap; }
            th[data-hltv-v2-managed-column], th.tmKprRangeCol { color:#929a9e !important; }
            .stats-matches-table th[data-hltv-v2-managed-column="kpr"],
            .stats-matches-table th[data-hltv-v2-managed-column="dpr"],
            .stats-matches-table th.tmKprRangeCol { color:#87a3bf !important; }
            td[data-hltv-v2-managed-column], td.tmKprRangeCol { color:#929a9e !important; }
            table.player-ratings-table td[data-hltv-v2-managed-column="kpr"],
            table.player-ratings-table td[data-hltv-v2-managed-column="dpr"] { color:#929a9e !important; }
            .${PREFIX}-autofit-wrap { max-width:100%; overflow-x:auto; overscroll-behavior-inline:contain; }
            .${PREFIX}-autofit-wrap > table.${PREFIX}-autofit {
                box-sizing:border-box !important;
                min-width:100% !important;
                table-layout:auto !important;
                width:100% !important;
            }
            .${PREFIX}-autofit-wrap > table.${PREFIX}-autofit .${PREFIX}-derived,
            .${PREFIX}-autofit-wrap > table.${PREFIX}-autofit .hltv-v2-period-header,
            .${PREFIX}-autofit-wrap > table.${PREFIX}-autofit .hltv-v2-period-cell,
            .${PREFIX}-autofit-wrap > table.${PREFIX}-autofit [data-hltv-win-adjusted-col] {
                min-width:58px !important;
                white-space:nowrap !important;
                width:1% !important;
            }
            table.${PREFIX}-sortable > thead > tr > th[data-hltv-v2-column-id] { cursor:pointer !important; }
            .${PREFIX}-trend { background:#202b35; border:1px solid #435568; box-sizing:border-box; margin:0 0 8px; padding:7px; position:relative; }
            .${PREFIX}-trend-title { color:#c7d0d9; display:flex; justify-content:space-between; margin-bottom:4px; }
            .${PREFIX}-trend svg { display:block; height:160px; width:100%; }
            .${PREFIX}-trend-base { fill:none; stroke:#6c8297; stroke-width:1.5; }
            .${PREFIX}-trend-roll { fill:none; stroke:#ffae00; stroke-width:2; }
            .${PREFIX}-trend-axis { fill:none; stroke:#718294; stroke-width:1; }
            .${PREFIX}-trend-grid { fill:none; stroke:#3b4956; stroke-width:1; }
            .${PREFIX}-trend-label { fill:#9faab4; font-size:10px; }
            .${PREFIX}-trend-point { cursor:pointer; fill:#a8bfd3; stroke:#202b35; stroke-width:1; }
            .${PREFIX}-trend-point:focus { outline:none; stroke:#87a3bf; stroke-width:2; }
            .${PREFIX}-trend-point.${PREFIX}-trend-point-marked { fill:#87a3bf; stroke:#fff; stroke-width:2; }
            .${PREFIX}-trend-popup {
                background:#111820;
                border:1px solid #718294;
                box-shadow:0 3px 10px rgba(0,0,0,.5);
                color:#d7e2eb;
                line-height:1.45;
                max-width:280px;
                padding:5px 7px;
                pointer-events:none;
                position:absolute;
                transform:translate(-50%, calc(-100% - 8px));
                white-space:pre-line;
                z-index:3;
            }
            .${PREFIX}-trend-popup[hidden] { display:none; }
            .${PREFIX}-csv-status { color:#9faab4; font-size:10px; }
            .${PREFIX}-history-size { align-items:center; color:#aeb8c2; display:flex; flex-wrap:wrap; font-size:11px; gap:7px; justify-content:flex-end; margin:7px 0 0; min-height:28px; }
            .${PREFIX}-history-size label { align-items:center; display:inline-flex; gap:5px; }
            .${PREFIX}-history-size select, .${PREFIX}-history-size button { background:#34495e; border:1px solid #52677b; color:#d6dde3; font:inherit; min-height:25px; padding:3px 7px; }
            .${PREFIX}-history-size button { cursor:pointer; }
            .${PREFIX}-history-size button[hidden] { display:none; }
            .${PREFIX}-history-size button:hover, .${PREFIX}-history-size button:focus-visible,
            .${PREFIX}-history-size select:hover, .${PREFIX}-history-size select:focus-visible { border-color:#87a3bf; }
            .${PREFIX}-history-status[data-kind="error"], .${PREFIX}-history-status[data-kind="warning"] { color:#e2b35a; }
        `;
        document.documentElement.append(style);
    }

    function tableType(table) {
        if (table.matches(TABLE_SELECTORS.ranking)) return 'ranking';
        if (table.matches(TABLE_SELECTORS.matches)) return 'matches';
        return null;
    }

    function rawHistoryHeaders(model) {
        return model.nativeHeaders.filter((header) => (
            !header.classList.contains('smartphone-only')
            && !header.hasAttribute('data-hltv-v2-managed-column')
            && !header.classList.contains('tmKprRangeCol')
            && !header.hasAttribute('data-hltv-win-adjusted-col')
            && !header.classList.contains('hltv-v2-period-header')
        ));
    }

    function makeAbortError() {
        try {
            return new DOMException('Aborted', 'AbortError');
        } catch {
            const error = new Error('Aborted');
            error.name = 'AbortError';
            return error;
        }
    }

    function throwIfAborted(signal) {
        if (signal?.aborted) throw makeAbortError();
    }

    function abortableDelay(milliseconds, signal) {
        throwIfAborted(signal);
        return new Promise((resolve, reject) => {
            const timer = globalThis.setTimeout(() => {
                signal?.removeEventListener('abort', onAbort);
                resolve();
            }, Math.max(0, milliseconds));
            const onAbort = () => {
                globalThis.clearTimeout(timer);
                signal?.removeEventListener('abort', onAbort);
                reject(makeAbortError());
            };
            signal?.addEventListener('abort', onAbort, { once: true });
        });
    }

    function historyOffset(url) {
        const value = String(url?.searchParams?.get('offset') || '0');
        return /^\d{1,8}$/.test(value) ? Number(value) : 0;
    }

    function historyFilterSignature(url) {
        const entries = [];
        url.searchParams.forEach((value, key) => {
            if (key === 'offset' || /^hltvSp/i.test(key)) return;
            entries.push([key, value]);
        });
        entries.sort((left, right) => (
            left[0].localeCompare(right[0]) || left[1].localeCompare(right[1])
        ));
        return JSON.stringify(entries);
    }

    function historyUrlKey(url) {
        const copy = new URL(url.href);
        copy.hash = '';
        copy.searchParams.sort();
        return copy.href;
    }

    function parsePaginationRange(value) {
        const match = String(value || '').match(/(\d+)\s*-\s*(\d+)\s+(?:of|\/)\s*(\d+)/i);
        if (!match) return null;
        const start = Number(match[1]);
        const end = Number(match[2]);
        const total = Number(match[3]);
        if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end)
            || !Number.isSafeInteger(total) || start < 1 || end < start || total < end) return null;
        return Object.freeze({ start, end, total });
    }

    function historyPagers(table) {
        const scope = table.parentElement || document;
        return [...scope.querySelectorAll('.pagination-component')].filter((pager) => (
            pager.querySelector('.pagination-data')
            && (pager.classList.contains('pagination-top')
                || pager.classList.contains('pagination-bottom'))
        ));
    }

    function pagerSnapshot(pager) {
        const data = pager.querySelector('.pagination-data');
        const previous = pager.querySelector('.pagination-prev');
        const next = pager.querySelector('.pagination-next');
        return Object.freeze({
            dataText: data?.textContent ?? null,
            previousClass: previous?.getAttribute('class') ?? null,
            previousHref: previous?.getAttribute('href') ?? null,
            nextClass: next?.getAttribute('class') ?? null,
            nextHref: next?.getAttribute('href') ?? null,
        });
    }

    function restorePagerSnapshot(pager, snapshot) {
        if (!pager?.isConnected || !snapshot) return;
        const data = pager.querySelector('.pagination-data');
        const previous = pager.querySelector('.pagination-prev');
        const next = pager.querySelector('.pagination-next');
        if (data && snapshot.dataText !== null) data.textContent = snapshot.dataText;
        for (const [anchor, className, href] of [
            [previous, snapshot.previousClass, snapshot.previousHref],
            [next, snapshot.nextClass, snapshot.nextHref],
        ]) {
            if (!anchor) continue;
            if (className === null) anchor.removeAttribute('class');
            else anchor.setAttribute('class', className);
            if (href === null) anchor.removeAttribute('href');
            else anchor.setAttribute('href', href);
        }
    }

    function rowMatchHistoryId(row) {
        const href = row?.querySelector?.('a[href*="/stats/matches/mapstatsid/"]')
            ?.getAttribute('href');
        try {
            const url = new URL(String(href || ''), globalThis.location.href);
            if (url.origin !== globalThis.location.origin) return '';
            return url.pathname.match(MAP_STATS_PATH_PATTERN)?.[1] || '';
        } catch {
            return '';
        }
    }

    function validateHistoryPageUrl(value, pagination) {
        let url;
        try {
            url = new URL(String(value || ''), globalThis.location.href);
        } catch {
            throw new Error('HLTV supplied an invalid match-history page link.');
        }
        if (url.protocol !== 'https:' || url.username || url.password
            || url.origin !== globalThis.location.origin
            || url.pathname !== pagination.pathname
            || !MATCH_HISTORY_PATH_PATTERN.test(url.pathname)) {
            throw new Error('Refused a match-history page outside the current player route.');
        }
        if (historyFilterSignature(url) !== pagination.filterSignature) {
            throw new Error('Refused a match-history page with different filters.');
        }
        const offsetText = url.searchParams.get('offset');
        if (!offsetText || !/^\d{1,8}$/.test(offsetText)) {
            throw new Error('HLTV supplied an invalid match-history offset.');
        }
        url.hash = '';
        return url;
    }

    function activeNextPageUrl(root, pagination, currentOffset) {
        const candidates = [
            ...root.querySelectorAll('.pagination-bottom .pagination-next[href], '
                + '.pagination-top .pagination-next[href]'),
        ];
        for (const anchor of candidates) {
            if (anchor.classList.contains('inactive')) continue;
            const url = validateHistoryPageUrl(anchor.getAttribute('href'), pagination);
            if (historyOffset(url) <= currentOffset) {
                throw new Error('HLTV supplied a non-advancing match-history page link.');
            }
            return url;
        }
        return null;
    }

    function createPaginationState(model) {
        const currentUrl = new URL(globalThis.location.href);
        currentUrl.hash = '';
        const pagers = historyPagers(model.table);
        const range = pagers.map((pager) => parsePaginationRange(
            pager.querySelector('.pagination-data')?.textContent,
        )).find(Boolean) || null;
        const baseRows = [...model.nativeRows];
        const baseOffset = historyOffset(currentUrl);
        const pagination = {
            model,
            pathname: currentUrl.pathname,
            filterSignature: historyFilterSignature(currentUrl),
            baseOffset,
            baseRows,
            baseRowIds: new Set(baseRows.map(rowMatchHistoryId).filter(Boolean)),
            total: Math.max(range?.total || 0, baseOffset + baseRows.length),
            baseTotal: Math.max(range?.total || 0, baseOffset + baseRows.length),
            pagers,
            pagerSnapshots: new Map(pagers.map((pager) => [pager, pagerSnapshot(pager)])),
            baseNextUrl: null,
            nextUrl: null,
            loadedRows: [],
            seenRowIds: new Set(),
            visitedUrls: new Set(),
            pageSignatures: new Set(),
            pagesFetched: 0,
            responseBytes: 0,
            requestCount: 0,
            lastRequestStartedAt: 0,
            appliedTarget: null,
            controller: null,
            runId: 0,
            loading: false,
            failed: false,
            settled: false,
            warning: '',
            error: '',
            control: null,
            select: null,
            status: null,
            retry: null,
            initialError: '',
            statusText: '',
            statusKind: '',
        };
        try {
            pagination.baseNextUrl = activeNextPageUrl(
                model.table.parentElement || document,
                pagination,
                baseOffset,
            );
        } catch (error) {
            pagination.initialError = clampText(error?.message, 240);
        }
        return pagination;
    }

    function getHistorySanitizer() {
        if (state.historySanitizer) return state.historySanitizer;
        if (typeof globalThis.Sanitizer !== 'function') {
            throw new Error('Secure match-history parsing requires a supported browser with the Sanitizer API.');
        }
        state.historySanitizer = new globalThis.Sanitizer({
            removeElements: [
                'applet', 'audio', 'base', 'button', 'embed', 'form', 'frame', 'frameset',
                'iframe', 'input', 'link', 'meta', 'noscript', 'object', 'picture', 'portal',
                'script', 'select', 'source', 'style', 'textarea', 'track', 'video',
                { name: 'svg', namespace: 'http://www.w3.org/2000/svg' },
                { name: 'math', namespace: 'http://www.w3.org/1998/Math/MathML' },
            ],
            removeAttributes: [
                'background', 'data', 'imagesizes', 'imagesrcset', 'manifest', 'ping',
                'poster', 'src', 'srcset', 'style',
            ],
            comments: false,
        });
        return state.historySanitizer;
    }

    function neutraliseHistoryImageAttributes(value) {
        return String(value ?? '')
            .replace(/(\s)srcset(\s*=)/gi, '$1data-hltv-v2-inert-srcset$2')
            .replace(/(\s)src(\s*=)/gi, '$1data-hltv-v2-inert-src$2');
    }

    function parseHistoryFragment(value) {
        const template = document.createElement('template');
        if (typeof template.setHTML !== 'function') {
            throw new Error('Secure match-history parsing is unavailable.');
        }
        template.setHTML(neutraliseHistoryImageAttributes(value), {
            sanitizer: getHistorySanitizer(),
        });
        const fragment = template.content;
        const title = clampText(fragment.querySelector('title')?.textContent, 200);
        const leadingText = clampText(fragment.textContent, 1200);
        if (/just a moment|access denied|forbidden|attention required/i.test(title)
            || /cloudflare|access denied|checking your browser/i.test(leadingText)) {
            throw new Error('HLTV returned a protection page instead of match history.');
        }
        return fragment;
    }

    function safeHistoryLink(value, responseUrl) {
        try {
            const url = new URL(String(value || ''), responseUrl.href);
            if (url.protocol !== 'https:' || url.username || url.password
                || url.origin !== globalThis.location.origin
                || !(MAP_STATS_PATH_PATTERN.test(url.pathname)
                    || TEAM_STATS_PATH_PATTERN.test(url.pathname))) return null;
            url.hash = '';
            return url;
        } catch {
            return null;
        }
    }

    function safeHistoryImage(value, responseUrl, image) {
        try {
            const url = new URL(String(value || ''), responseUrl.href);
            if (url.protocol !== 'https:' || url.username || url.password
                || url.href.length > 2048 || !MATCH_HISTORY_IMAGE_ORIGINS.has(url.origin)) return null;
            const extension = image.classList.contains('flag')
                ? /\.(?:gif|jpe?g|png|webp)$/i
                : /\.(?:avif|gif|jpe?g|png|svg|webp)$/i;
            if (!extension.test(url.pathname)
                || !(image.classList.contains('flag') || image.classList.contains('statsLogo'))) return null;
            return url;
        } catch {
            return null;
        }
    }

    function prepareHistoryRow(sourceRow, responseUrl, expectedCellCount) {
        const row = document.importNode(sourceRow, true);
        if (row.tagName !== 'TR' || row.cells.length !== expectedCellCount) return null;
        for (const element of [row, ...row.querySelectorAll('*')]) {
            element.removeAttribute('id');
            element.removeAttribute('data-tooltip-id');
            element.removeAttribute('style');
            for (const attribute of [...element.attributes]) {
                if (/^on/i.test(attribute.name)) element.removeAttribute(attribute.name);
            }
        }
        for (const anchor of [...row.querySelectorAll('a[href]')]) {
            const safe = safeHistoryLink(anchor.getAttribute('href'), responseUrl);
            anchor.removeAttribute('target');
            anchor.removeAttribute('ping');
            if (safe) anchor.href = safe.href;
            else anchor.replaceWith(...anchor.childNodes);
        }
        for (const image of [...row.querySelectorAll('img')]) {
            const safe = safeHistoryImage(
                image.getAttribute('data-hltv-v2-inert-src'),
                responseUrl,
                image,
            );
            image.removeAttribute('data-hltv-v2-inert-src');
            image.removeAttribute('data-hltv-v2-inert-srcset');
            if (!safe) {
                image.remove();
                continue;
            }
            image.src = safe.href;
            image.loading = 'lazy';
            image.referrerPolicy = 'no-referrer';
        }
        const id = rowMatchHistoryId(row);
        if (!id) return null;
        row.dataset.hltvV2PaginatedRow = 'true';
        row.dataset.hltvV2HistoryId = id;
        return Object.freeze({ id, row });
    }

    function parseHistoryPage(html, responseUrl, pagination) {
        const fragment = parseHistoryFragment(html);
        const table = fragment.querySelector('table.stats-matches-table');
        if (!table) throw new Error('Fetched match history did not contain the expected table.');
        const expectedCellCount = rawHistoryHeaders(pagination.model).length;
        const sourceRows = [...table.querySelectorAll(':scope > tbody > tr')];
        if (!expectedCellCount || expectedCellCount > 20
            || sourceRows.length > MATCH_HISTORY_MAX_ROWS_PER_PAGE) {
            throw new Error('Fetched match history exceeded its table-shape safety limit.');
        }
        const rows = sourceRows.map((row) => (
            prepareHistoryRow(row, responseUrl, expectedCellCount)
        ));
        if (!sourceRows.length || rows.some((row) => !row)) {
            throw new Error('Fetched match history contained malformed rows.');
        }
        const range = [...fragment.querySelectorAll('.pagination-data')]
            .map((node) => parsePaginationRange(node.textContent))
            .find(Boolean) || null;
        const offset = historyOffset(responseUrl);
        if (!range || range.start !== offset + 1
            || range.end - range.start + 1 !== rows.length) {
            throw new Error('Fetched match-history pagination did not match its rows.');
        }
        if (pagination.total && range.total !== pagination.total) {
            throw new Error('Fetched match history changed the result total.');
        }
        const nextUrl = activeNextPageUrl(fragment, pagination, offset);
        return Object.freeze({ rows, range, nextUrl });
    }

    function historyRequestError(message, retryable = false) {
        const error = new Error(message);
        error.retryable = retryable;
        return error;
    }

    async function cancelResponse(response, reason) {
        try {
            await response?.body?.cancel?.(reason);
        } catch {
            // Best-effort cleanup only.
        }
    }

    function historyResponseTooLarge(bytes = 0) {
        const error = new Error('HLTV match-history response was too large.');
        error.historyResponseBytes = Math.max(0, Number(bytes) || 0);
        return error;
    }

    function recordHistoryResponseBytes(pagination, value) {
        const bytes = Math.max(0, Number(value) || 0);
        pagination.responseBytes = Math.min(
            Number.MAX_SAFE_INTEGER,
            pagination.responseBytes + bytes,
        );
    }

    async function readBoundedHistoryResponse(response, maximumBytes) {
        const contentType = String(response.headers?.get?.('content-type') || '').toLowerCase();
        if (contentType && !/(?:text\/html|application\/xhtml\+xml)/.test(contentType)) {
            await cancelResponse(response, 'Unexpected match-history content type.');
            throw new Error('HLTV returned a non-HTML match-history response.');
        }
        const declared = Number(response.headers?.get?.('content-length'));
        if (Number.isFinite(declared) && declared > maximumBytes) {
            await cancelResponse(response, 'Oversized match-history response.');
            throw historyResponseTooLarge();
        }
        const reader = response.body?.getReader?.();
        if (!reader) {
            const text = await response.text();
            const bytes = new TextEncoder().encode(text).byteLength;
            if (bytes > maximumBytes) throw historyResponseTooLarge(bytes);
            return Object.freeze({ text, bytes });
        }
        const decoder = new TextDecoder();
        const chunks = [];
        let bytes = 0;
        let completed = false;
        try {
            while (true) {
                const { done, value } = await reader.read();
                if (done) {
                    completed = true;
                    break;
                }
                bytes += value?.byteLength || 0;
                if (bytes > maximumBytes) throw historyResponseTooLarge(bytes);
                chunks.push(decoder.decode(value, { stream: true }));
            }
            chunks.push(decoder.decode());
            return Object.freeze({ text: chunks.join(''), bytes });
        } catch (error) {
            try {
                if (error && typeof error === 'object' && !error.historyResponseBytes) {
                    error.historyResponseBytes = bytes;
                }
            } catch {
                // A non-extensible platform error can still be surfaced normally.
            }
            if (!completed) {
                try {
                    await reader.cancel?.(error);
                } catch {
                    // Best-effort cleanup only.
                }
            }
            throw error;
        } finally {
            try {
                reader.releaseLock?.();
            } catch {
                // Ignore non-standard reader cleanup failures.
            }
        }
    }

    async function waitForHistoryRequestSlot(pagination, signal) {
        const wait = pagination.requestCount === 0
            ? MATCH_HISTORY_INITIAL_DELAY_MS
            : Math.max(
                0,
                MATCH_HISTORY_FETCH_SPACING_MS
                    - (Date.now() - pagination.lastRequestStartedAt),
            );
        await abortableDelay(wait, signal);
        pagination.lastRequestStartedAt = Date.now();
        pagination.requestCount += 1;
    }

    async function fetchHistoryPage(url, pagination, signal) {
        let lastError = null;
        const retryDelays = [0, ...MATCH_HISTORY_RETRY_DELAYS_MS];
        for (let attempt = 0; attempt < retryDelays.length; attempt += 1) {
            if (attempt > 0) {
                const delay = retryDelays[attempt];
                setPaginationStatus(
                    pagination,
                    `Request failed; retrying in ${delay / 1000} seconds…`,
                    'warning',
                );
                await abortableDelay(delay, signal);
            }
            if (pagination.responseBytes >= MATCH_HISTORY_MAX_TOTAL_BYTES) {
                throw new Error('Match-history response safety limit reached.');
            }
            await waitForHistoryRequestSlot(pagination, signal);
            try {
                let response;
                try {
                    response = await globalThis.fetch(url.href, {
                        credentials: 'include',
                        redirect: 'error',
                        signal,
                        headers: { Accept: 'text/html' },
                    });
                } catch (error) {
                    recordHistoryResponseBytes(pagination, error?.historyResponseBytes);
                    if (error?.name === 'AbortError') throw error;
                    if (error instanceof TypeError || error?.name === 'TypeError') {
                        throw historyRequestError(
                            error.message || 'The HLTV request failed.',
                            true,
                        );
                    }
                    throw error;
                }
                if (!response.ok) {
                    await cancelResponse(response, `HTTP ${response.status}`);
                    const retryable = response.status === 403 || response.status === 408
                        || response.status === 429 || response.status >= 500;
                    throw historyRequestError(`HLTV returned HTTP ${response.status}.`, retryable);
                }
                const finalUrl = validateHistoryPageUrl(response.url || url.href, pagination);
                if (historyUrlKey(finalUrl) !== historyUrlKey(url)) {
                    await cancelResponse(response, 'Unexpected match-history redirect.');
                    throw new Error('HLTV redirected to a different match-history page.');
                }
                const remaining = MATCH_HISTORY_MAX_TOTAL_BYTES - pagination.responseBytes;
                if (remaining <= 0) {
                    await cancelResponse(response, 'Match-history response safety limit reached.');
                    throw new Error('Match-history response safety limit reached.');
                }
                let result;
                try {
                    result = await readBoundedHistoryResponse(
                        response,
                        Math.min(MATCH_HISTORY_MAX_PAGE_BYTES, remaining),
                    );
                } catch (error) {
                    recordHistoryResponseBytes(pagination, error?.historyResponseBytes);
                    if (error?.name === 'AbortError') throw error;
                    if (error instanceof TypeError || error?.name === 'TypeError') {
                        throw historyRequestError(
                            error.message || 'The HLTV response stream failed.',
                            true,
                        );
                    }
                    throw error;
                }
                recordHistoryResponseBytes(pagination, result.bytes);
                return Object.freeze({
                    ...parseHistoryPage(result.text, finalUrl, pagination),
                    finalUrl,
                });
            } catch (error) {
                if (error?.name === 'AbortError') throw error;
                lastError = error;
                if (lastError?.retryable !== true || attempt === retryDelays.length - 1) {
                    throw lastError;
                }
            }
        }
        throw lastError || new Error('HLTV match history could not be loaded.');
    }

    function rememberAttribute(model, node, name) {
        let attributes = model.attributeSnapshots.get(node);
        if (!attributes) {
            attributes = new Map();
            model.attributeSnapshots.set(node, attributes);
        }
        if (!attributes.has(name)) attributes.set(name, node.hasAttribute(name) ? node.getAttribute(name) : null);
    }

    function setManagedAttribute(model, node, name, value) {
        rememberAttribute(model, node, name);
        node.setAttribute(name, value);
    }

    function restoreRememberedAttribute(model, node, name) {
        const attributes = model.attributeSnapshots.get(node);
        if (!attributes?.has(name)) return;
        const value = attributes.get(name);
        if (value === null) node.removeAttribute(name);
        else node.setAttribute(name, value);
    }

    function toggleManagedClass(model, node, className, enabled) {
        rememberAttribute(model, node, 'class');
        node.classList.toggle(className, enabled);
    }

    function createModel(table, type) {
        const model = {
            table,
            type,
            nativeHeaderRow: table.querySelector(':scope > thead > tr:first-child'),
            nativeBody: table.tBodies[0] || null,
            nativeHeaders: [],
            nativeHeaderNodes: [],
            nativeBodyNodes: [],
            nativeRows: [],
            nativeCells: new Map(),
            nativeRowNodes: new Map(),
            attributeSnapshots: new Map(),
            toolbar: null,
            toolbarSignature: '',
            chooser: null,
            autoFitWrapper: null,
            trend: null,
            trendSignature: '',
            layoutWasApplied: false,
            sortWasApplied: false,
            headerListenerTarget: null,
            headerClickListener: null,
            pagination: null,
        };
        state.models.set(table, model);
        captureNativeStructure(model);
        if (type === 'matches' && state.settings.enableExtendedMatchHistoryLoading) {
            model.pagination = createPaginationState(model);
        }
        return model;
    }

    function rememberNodeAtObservedPosition(order, node, observedNodes) {
        if (order.includes(node)) return;
        const observedIndex = observedNodes.indexOf(node);
        if (observedIndex <= 0) {
            order.unshift(node);
            return;
        }
        if (observedIndex === observedNodes.length - 1) {
            order.push(node);
            return;
        }
        for (let index = observedIndex - 1; index >= 0; index -= 1) {
            const anchorIndex = order.indexOf(observedNodes[index]);
            if (anchorIndex >= 0) {
                order.splice(anchorIndex + 1, 0, node);
                return;
            }
        }
        for (let index = observedIndex + 1; index < observedNodes.length; index += 1) {
            const anchorIndex = order.indexOf(observedNodes[index]);
            if (anchorIndex >= 0) {
                order.splice(anchorIndex, 0, node);
                return;
            }
        }
        order.push(node);
    }

    function captureNativeStructure(model) {
        const headerRow = model.table.querySelector(':scope > thead > tr:first-child');
        const body = model.table.tBodies[0] || null;
        if (headerRow) {
            model.nativeHeaderRow = headerRow;
            if (!model.nativeHeaderNodes.length) model.nativeHeaderNodes = [...headerRow.childNodes];
            const observedHeaderNodes = [...headerRow.childNodes];
            const observedHeaders = [...headerRow.children];
            for (const header of headerRow.children) {
                if (!header.hasAttribute('data-hltv-v2-managed-column') && !model.nativeHeaders.includes(header)) {
                    rememberNodeAtObservedPosition(model.nativeHeaders, header, observedHeaders);
                    rememberNodeAtObservedPosition(model.nativeHeaderNodes, header, observedHeaderNodes);
                }
            }
        }
        if (body) {
            model.nativeBody = body;
            if (!model.nativeBodyNodes.length) model.nativeBodyNodes = [...body.childNodes];
            const observedBodyNodes = [...body.childNodes];
            const observedRows = [...body.rows];
            for (const row of body.rows) {
                if (!model.nativeRows.includes(row)) {
                    rememberNodeAtObservedPosition(model.nativeRows, row, observedRows);
                    rememberNodeAtObservedPosition(model.nativeBodyNodes, row, observedBodyNodes);
                }
                if (!model.nativeRowNodes.has(row)) model.nativeRowNodes.set(row, [...row.childNodes]);
                const nativeCells = model.nativeCells.get(row) || [];
                const observedRowNodes = [...row.childNodes];
                const observedCells = [...row.children];
                for (const cell of row.children) {
                    if (!cell.hasAttribute('data-hltv-v2-managed-column') && !nativeCells.includes(cell)) {
                        rememberNodeAtObservedPosition(nativeCells, cell, observedCells);
                        rememberNodeAtObservedPosition(model.nativeRowNodes.get(row), cell, observedRowNodes);
                    }
                }
                model.nativeCells.set(row, nativeCells);
            }
        }
    }

    function headerId(model, header, type, index) {
        if (header.hasAttribute('data-hltv-win-adjusted-col')) {
            setManagedAttribute(model, header, 'data-hltv-v2-column-id', 'war');
            return 'war';
        }
        if (header.classList.contains('hltv-v2-period-header')) {
            setManagedAttribute(model, header, 'data-hltv-v2-column-id', 'period-delta');
            return 'period-delta';
        }
        if (header.dataset.hltvV2ColumnId) return header.dataset.hltvV2ColumnId;
        const classes = header.classList;
        let id = '';
        if (type === 'ranking') {
            if (classes.contains('playerCol')) id = 'player';
            else if (classes.contains('teamCol')) id = 'team';
            else if (classes.contains('mapsCol')) id = 'maps';
            else if (classes.contains('rounds-col')) id = 'rounds';
            else if (classes.contains('tmKprRangeCol')) id = 'kpr';
            else if (classes.contains('kdDiffCol')) id = 'kd-diff';
            else if (classes.contains('kdCol')) id = 'kd';
            else if (classes.contains('ratingCol')) id = 'rating';
        } else {
            if (classes.contains('statsPlayerMatchesDate')) id = 'date';
            else if (classes.contains('statsPlayerMatchesTeam1')) id = 'player-team';
            else if (classes.contains('statsPlayerMatchesTeam2')) id = 'opponent';
            else if (classes.contains('statsPlayerMatchesMap')) id = 'map';
            else if (classes.contains('tmKprRangeCol')) id = 'kpr';
            else if (classes.contains('statsPlayerMatchesK-D')) id = 'kills-deaths';
            else if (classes.contains('statsPlayerMatchesPlus-Minus')) id = 'plus-minus';
            else if (classes.contains('statsPlayerMatchesRating')) id = 'rating';
        }
        if (!id) {
            const label = clampText(header.textContent, 40).toLowerCase().replace(/[^a-z0-9]+/g, '-') || 'column';
            id = `unknown-${label}-${index}`;
        }
        setManagedAttribute(model, header, 'data-hltv-v2-column-id', id);
        return id;
    }

    function labelForGroup(group) {
        if (METRIC_LABELS[group.id]) return METRIC_LABELS[group.id];
        const header = group.headers.find((item) => !item.classList.contains('smartphone-only')) || group.headers[0];
        if (!header) return group.id;
        const copy = header.cloneNode(true);
        for (const badge of copy.querySelectorAll(`.${PREFIX}-sort-badge`)) badge.remove();
        return clampText(copy.textContent, 80) || group.id;
    }

    function optionalDefinition(type, id) {
        return OPTIONAL_COLUMNS[type].find((definition) => definition.id === id) || null;
    }

    function columnLabel(model, id) {
        return optionalDefinition(model.type, id)?.label
            || METRIC_LABELS[id]
            || labelForGroup(model.groups.get(id) || { id, headers: [] });
    }

    function catalogueOrder(model) {
        const physical = [...model.groups.keys()].filter((id) => (
            !RETIRED_COLUMN_IDS.has(id)
            && !(model.type === 'matches' && id === 'kills-per-map')
        ));
        const optional = OPTIONAL_COLUMNS[model.type].map((definition) => definition.id);
        const order = [...physical];
        const ratingIndex = order.indexOf('rating');
        const insertionIndex = ratingIndex >= 0 ? ratingIndex : order.length;
        order.splice(
            insertionIndex,
            0,
            ...optional.filter((id) => !order.includes(id)),
        );
        if (model.type === 'ranking' && !order.includes('period-delta')) {
            order.push('period-delta');
        }
        return order;
    }

    function assignColumnIds(model) {
        const { table, type } = model;
        const headers = [...table.querySelectorAll(':scope > thead > tr:first-child > th')];
        headers.forEach((header, index) => headerId(model, header, type, index));
        const physicalHeaders = type === 'matches'
            ? headers.filter((header) => !header.classList.contains('smartphone-only'))
            : headers;
        const physicalIds = physicalHeaders.map((header, index) => (
            headerId(model, header, type, index)
        ));
        const canonicalHeaders = type === 'matches'
            ? rawHistoryHeaders(model)
            : model.nativeHeaders;
        const canonicalIds = canonicalHeaders.map((header, index) => (
            headerId(model, header, type, index)
        ));
        for (const row of table.querySelectorAll(':scope > tbody > tr')) {
            const ids = row.dataset.hltvV2PaginatedRow === 'true'
                ? canonicalIds
                : physicalIds;
            [...row.children].forEach((cell, index) => {
                let id = row.dataset.hltvV2PaginatedRow === 'true'
                    && cell.dataset.hltvV2ColumnId
                    ? cell.dataset.hltvV2ColumnId
                    : ids[index] || '';
                if (cell.hasAttribute('data-hltv-win-adjusted-col')) id = 'war';
                else if (cell.classList.contains('hltv-v2-period-cell')) id = 'period-delta';
                else if (cell.classList.contains('tmKprRangeCol')) id = 'kpr';
                if (id && !cell.hasAttribute('data-hltv-v2-managed-column')) {
                    setManagedAttribute(model, cell, 'data-hltv-v2-column-id', id);
                }
                if (!cell.dataset.hltvV2OriginalIndex && !cell.hasAttribute('data-hltv-v2-managed-column')) {
                    setManagedAttribute(model, cell, 'data-hltv-v2-original-index', String(index));
                }
            });
            if (!row.dataset.hltvV2OriginalIndex) {
                setManagedAttribute(model, row, 'data-hltv-v2-original-index', String(model.nativeRows.indexOf(row)));
            }
        }
        physicalHeaders.forEach((header, index) => {
            if (!header.dataset.hltvV2OriginalIndex && !header.hasAttribute('data-hltv-v2-managed-column')) {
                setManagedAttribute(model, header, 'data-hltv-v2-original-index', String(index));
            }
        });
    }

    function refreshModel(table) {
        const type = tableType(table);
        if (!type) return null;
        let model = state.models.get(table);
        if (!model) model = createModel(table, type);
        captureNativeStructure(model);
        assignColumnIds(model);
        const groups = new Map();
        for (const header of table.querySelectorAll(':scope > thead > tr:first-child > th')) {
            const id = header.dataset.hltvV2ColumnId;
            if (!groups.has(id)) groups.set(id, { id, headers: [] });
            groups.get(id).headers.push(header);
        }
        model.groups = groups;
        model.rows = [...table.querySelectorAll(':scope > tbody > tr')];
        return model;
    }

    function sameNodeOrder(parent, desiredNodes, elementsOnly = false) {
        const current = elementsOnly ? [...parent.children] : [...parent.childNodes];
        const desired = desiredNodes.filter((node) => node.parentNode === parent);
        return current.length === desired.length
            && current.every((node, index) => node === desired[index]);
    }

    function reconcileNodeOrder(parent, desiredNodes, elementsOnly = false) {
        const desired = desiredNodes.filter((node) => node.parentNode === parent);
        if (sameNodeOrder(parent, desired, elementsOnly)) return false;
        let cursor = elementsOnly ? parent.firstElementChild : parent.firstChild;
        for (const node of desired) {
            if (node === cursor) {
                cursor = elementsOnly ? cursor.nextElementSibling : cursor.nextSibling;
            } else {
                parent.insertBefore(node, cursor);
            }
        }
        return true;
    }

    function managedNodesBeforeRating(nativeNodes, managedNodes) {
        const desired = [...nativeNodes];
        const ratingIndex = desired.findIndex(
            (node) => node.dataset?.hltvV2ColumnId === 'rating',
        );
        desired.splice(ratingIndex >= 0 ? ratingIndex : desired.length, 0, ...managedNodes);
        return desired;
    }

    function restoreNativeColumnOrder(model, keepManaged = false) {
        const headerRow = model.table.querySelector(':scope > thead > tr:first-child');
        if (!headerRow) return;
        if (!keepManaged) {
            reconcileNodeOrder(headerRow, model.nativeHeaderNodes);
            for (const row of model.nativeRows) {
                if (row.isConnected) {
                    reconcileNodeOrder(row, model.nativeRowNodes.get(row) || []);
                }
            }
            return;
        }
        const managedHeaders = OPTIONAL_COLUMNS[model.type]
            .map((definition) => headerRow.querySelector(
                `:scope > [data-hltv-v2-managed-column="${CSS.escape(definition.id)}"]`,
            ))
            .filter(Boolean);
        reconcileNodeOrder(
            headerRow,
            managedNodesBeforeRating(model.nativeHeaders, managedHeaders),
            true,
        );
        for (const row of model.nativeRows) {
            if (!row.isConnected) continue;
            const managedCells = OPTIONAL_COLUMNS[model.type]
                .map((definition) => row.querySelector(
                    `:scope > [data-hltv-v2-managed-column="${CSS.escape(definition.id)}"]`,
                ))
                .filter(Boolean);
            reconcileNodeOrder(
                row,
                managedNodesBeforeRating(model.nativeCells.get(row) || [], managedCells),
                true,
            );
        }
    }

    function restoreNativeRowOrder(model) {
        const body = model.table.tBodies[0];
        if (!body) return;
        reconcileNodeOrder(body, model.nativeBodyNodes);
    }

    function removeHeaderListener(model) {
        if (model.headerListenerTarget && model.headerClickListener) {
            model.headerListenerTarget.removeEventListener('click', model.headerClickListener, true);
        }
        model.headerListenerTarget = null;
        model.headerClickListener = null;
    }

    function tableSurface(model) {
        return model.autoFitWrapper?.isConnected ? model.autoFitWrapper : model.table;
    }

    function enableAutoFit(model) {
        if (model.autoFitWrapper?.isConnected && model.table.parentElement === model.autoFitWrapper) {
            toggleManagedClass(model, model.table, `${PREFIX}-autofit`, true);
            return;
        }
        const wrapper = document.createElement('div');
        wrapper.className = `${PREFIX}-autofit-wrap`;
        model.table.before(wrapper);
        wrapper.append(model.table);
        model.autoFitWrapper = wrapper;
        toggleManagedClass(model, model.table, `${PREFIX}-autofit`, true);
    }

    function disableAutoFit(model) {
        restoreRememberedAttribute(model, model.table, 'class');
        const wrapper = model.autoFitWrapper;
        if (wrapper?.parentNode) {
            const parent = wrapper.parentNode;
            while (wrapper.firstChild) parent.insertBefore(wrapper.firstChild, wrapper);
            wrapper.remove();
        }
        model.autoFitWrapper = null;
    }

    function syncAutoFit(model) {
        const customHeaders = [...model.table.querySelectorAll(
            ':scope > thead > tr:first-child > '
            + 'th.tmKprRangeCol, '
            + ':scope > thead > tr:first-child > th[data-hltv-win-adjusted-col], '
            + ':scope > thead > tr:first-child > th.hltv-v2-period-header, '
            + ':scope > thead > tr:first-child > th[data-hltv-v2-managed-column]',
        )];
        const hasVisibleCustomColumn = customHeaders.some((header) => (
            !header.classList.contains(`${PREFIX}-col-hidden`)
        ));
        if (hasVisibleCustomColumn) enableAutoFit(model);
        else disableAutoFit(model);
    }

    function restoreModel(model) {
        cleanupPagination(model);
        removeHeaderListener(model);
        model.toolbar?.remove();
        model.toolbar = null;
        model.chooser = null;
        model.toolbarSignature = '';
        removeTrend(model);
        disableAutoFit(model);
        for (const badge of model.table.querySelectorAll(`.${PREFIX}-sort-badge`)) badge.remove();
        for (const node of model.table.querySelectorAll('[data-hltv-v2-managed-column]')) node.remove();
        restoreNativeColumnOrder(model, false);
        restoreNativeRowOrder(model);
        for (const [node, attributes] of model.attributeSnapshots) {
            if (!node.isConnected && !model.table.contains(node) && node !== model.table) continue;
            for (const [name, value] of attributes) {
                if (value === null) node.removeAttribute(name);
                else node.setAttribute(name, value);
            }
        }
    }

    function releaseModel(model) {
        removeHeaderListener(model);
        model.attributeSnapshots.clear();
        model.nativeCells.clear();
        model.nativeRowNodes.clear();
        model.groups?.clear();
        model.nativeHeaders.length = 0;
        model.nativeHeaderNodes.length = 0;
        model.nativeBodyNodes.length = 0;
        model.nativeRows.length = 0;
        model.rows = [];
        model.table = null;
        model.nativeHeaderRow = null;
        model.nativeBody = null;
        model.toolbar = null;
        model.chooser = null;
        model.toolbarSignature = '';
        model.autoFitWrapper = null;
        model.trend = null;
        model.trendSignature = '';
        model.pagination = null;
    }

    function disposeModel(model) {
        try {
            restoreModel(model);
        } finally {
            releaseModel(model);
        }
    }

    function paginationVisibleRows(pagination) {
        return pagination.baseRows.length + pagination.loadedRows.length;
    }

    function paginationTargetCount(pagination) {
        return pagination.appliedTarget === 'all'
            ? MATCH_HISTORY_MAX_ROWS
            : pagination.appliedTarget;
    }

    function setPaginationStatus(pagination, value, kind = '') {
        pagination.statusText = clampText(value, 360);
        pagination.statusKind = kind;
        if (pagination.status) {
            setTextIfChanged(pagination.status, pagination.statusText);
            if (kind) pagination.status.dataset.kind = kind;
            else delete pagination.status.dataset.kind;
        }
        if (pagination.control) {
            pagination.control.setAttribute('aria-busy', String(pagination.loading));
        }
        if (pagination.retry) {
            pagination.retry.hidden = !(pagination.failed && pagination.nextUrl);
        }
    }

    function removeNodeSnapshots(model, root) {
        model.attributeSnapshots.delete(root);
        for (const node of root.querySelectorAll('*')) model.attributeSnapshots.delete(node);
    }

    function removePaginatedRows(model) {
        const pagination = model.pagination;
        if (!pagination?.loadedRows.length) return false;
        const removed = new Set(pagination.loadedRows);
        for (const row of pagination.loadedRows) {
            removeNodeSnapshots(model, row);
            model.nativeCells.delete(row);
            model.nativeRowNodes.delete(row);
            row.remove();
        }
        model.nativeRows.splice(
            0,
            model.nativeRows.length,
            ...model.nativeRows.filter((row) => !removed.has(row)),
        );
        model.nativeBodyNodes.splice(
            0,
            model.nativeBodyNodes.length,
            ...model.nativeBodyNodes.filter((node) => !removed.has(node)),
        );
        model.rows = (model.rows || []).filter((row) => !removed.has(row));
        pagination.loadedRows = [];
        return true;
    }

    function abortPagination(pagination) {
        pagination.runId += 1;
        pagination.controller?.abort();
        pagination.controller = null;
        pagination.loading = false;
    }

    function resetPaginationSelection(model, target) {
        const pagination = model.pagination;
        abortPagination(pagination);
        removePaginatedRows(model);
        pagination.appliedTarget = target;
        pagination.total = pagination.baseTotal;
        pagination.nextUrl = pagination.baseNextUrl;
        pagination.seenRowIds = new Set(pagination.baseRowIds);
        pagination.visitedUrls.clear();
        pagination.pageSignatures.clear();
        pagination.pagesFetched = 0;
        pagination.responseBytes = 0;
        pagination.requestCount = 0;
        pagination.lastRequestStartedAt = 0;
        pagination.failed = Boolean(pagination.initialError);
        pagination.error = pagination.initialError;
        pagination.warning = '';
        pagination.statusText = '';
        pagination.statusKind = '';
        const shown = paginationVisibleRows(pagination);
        const targetCount = paginationTargetCount(pagination);
        pagination.settled = pagination.failed
            || shown >= targetCount
            || shown >= Math.max(0, pagination.total - pagination.baseOffset)
            || !pagination.nextUrl;
    }

    function prepareMatchHistoryPagination(model) {
        if (model.type !== 'matches' || !model.pagination) return;
        const target = normaliseMatchHistoryRows(state.settings.statsMatchHistoryRowsV2);
        if (model.pagination.appliedTarget !== target) {
            resetPaginationSelection(model, target);
        }
    }

    function reconcileMatchHistoryPagination(model) {
        if (model.type !== 'matches') return;
        if (!state.settings.enableExtendedMatchHistoryLoading) {
            if (model.pagination) {
                cleanupPagination(model);
                model.pagination = null;
            }
            return;
        }
        if (!model.pagination) model.pagination = createPaginationState(model);
    }

    function setPagerAnchor(anchor, href) {
        if (!anchor) return;
        anchor.classList.toggle('inactive', !href);
        if (href) anchor.setAttribute('href', href);
        else anchor.removeAttribute('href');
    }

    function historyNavigationUrl(offset) {
        const url = new URL(globalThis.location.href);
        url.hash = '';
        if (offset > 0) url.searchParams.set('offset', String(offset));
        else url.searchParams.delete('offset');
        return url.href;
    }

    function rewriteHistoryPagers(pagination) {
        const shown = paginationVisibleRows(pagination);
        const end = Math.min(pagination.total, pagination.baseOffset + shown);
        const start = shown ? pagination.baseOffset + 1 : 0;
        const terminal = end >= pagination.total || (pagination.settled && !pagination.nextUrl);
        const targetStep = pagination.appliedTarget === 'all'
            ? Math.max(1, pagination.total - pagination.baseOffset)
            : pagination.appliedTarget;
        for (const pager of pagination.pagers) {
            if (!pager.isConnected) continue;
            const data = pager.querySelector('.pagination-data');
            if (data) setTextIfChanged(data, `${start} - ${end} of ${pagination.total} `);
            const previous = pager.querySelector('.pagination-prev');
            const next = pager.querySelector('.pagination-next');
            if (pagination.loading) {
                setPagerAnchor(previous, null);
                setPagerAnchor(next, null);
                continue;
            }
            const previousOffset = pagination.appliedTarget === 'all'
                ? 0
                : Math.max(0, pagination.baseOffset - targetStep);
            setPagerAnchor(
                previous,
                pagination.baseOffset > 0 ? historyNavigationUrl(previousOffset) : null,
            );
            const nextStep = pagination.failed
                ? shown
                : pagination.appliedTarget === 'all' ? shown : pagination.appliedTarget;
            setPagerAnchor(
                next,
                !terminal && nextStep > 0
                    ? historyNavigationUrl(pagination.baseOffset + nextStep)
                    : null,
            );
        }
    }

    function paginationSummary(pagination) {
        const shown = paginationVisibleRows(pagination);
        const available = Math.max(shown, pagination.total - pagination.baseOffset);
        if (pagination.warning) return `${shown} of ${available} rows shown. ${pagination.warning}`;
        if (pagination.failed) {
            return `${shown} of ${available} rows shown. ${pagination.error || 'More rows could not be loaded.'}`;
        }
        if (pagination.loading) return `Loading more rows… ${shown} of ${available} shown.`;
        return `${shown} of ${available} rows shown.`;
    }

    function ensurePaginationControl(model) {
        const pagination = model.pagination;
        if (pagination.control?.isConnected) return pagination.control;
        const control = document.createElement('div');
        control.className = `${PREFIX}-history-size`;
        control.setAttribute('aria-busy', 'false');
        const label = document.createElement('label');
        const labelText = document.createElement('span');
        labelText.textContent = 'Rows to show';
        const select = document.createElement('select');
        select.setAttribute('aria-label', 'Match-history rows to show');
        for (const value of MATCH_HISTORY_ROW_OPTIONS) {
            const option = document.createElement('option');
            option.value = String(value);
            option.textContent = value === 'all' ? 'ALL' : String(value);
            select.append(option);
        }
        select.addEventListener('change', () => {
            const value = normaliseMatchHistoryRows(select.value);
            if (value === state.settings.statsMatchHistoryRowsV2) return;
            abortPagination(pagination);
            persist('statsMatchHistoryRowsV2', value);
            scheduleSync();
        });
        label.append(labelText, select);
        const status = document.createElement('span');
        status.className = `${PREFIX}-history-status`;
        status.setAttribute('role', 'status');
        status.setAttribute('aria-live', 'polite');
        const retry = document.createElement('button');
        retry.type = 'button';
        retry.textContent = 'Retry';
        retry.hidden = true;
        retry.addEventListener('click', () => {
            if (pagination.loading || !pagination.nextUrl) return;
            pagination.failed = false;
            pagination.error = '';
            pagination.settled = false;
            startPaginationLoad(model);
        });
        control.append(label, status, retry);
        const bottom = pagination.pagers.find((pager) => (
            pager.isConnected && pager.classList.contains('pagination-bottom')
        ));
        if (bottom) bottom.after(control);
        else tableSurface(model).after(control);
        pagination.control = control;
        pagination.select = select;
        pagination.status = status;
        pagination.retry = retry;
        return control;
    }

    function updatePaginationUi(model) {
        const pagination = model.pagination;
        ensurePaginationControl(model);
        pagination.select.value = String(pagination.appliedTarget);
        rewriteHistoryPagers(pagination);
        setPaginationStatus(
            pagination,
            pagination.statusText || paginationSummary(pagination),
            pagination.statusKind,
        );
    }

    function annotatePaginatedRowColumns(model, row) {
        const headers = model.type === 'matches'
            ? rawHistoryHeaders(model)
            : model.nativeHeaders;
        const ids = headers.map((header, index) => headerId(model, header, model.type, index));
        [...row.children].forEach((cell, index) => {
            if (ids[index]) cell.dataset.hltvV2ColumnId = ids[index];
            cell.dataset.hltvV2OriginalIndex = String(index);
        });
    }

    function appendHistoryRows(model, entries, runId) {
        const pagination = model.pagination;
        if (!entries.length || runId !== pagination.runId || !model.table.isConnected) return 0;
        const body = model.table.tBodies[0];
        if (!body) throw new Error('The match-history table disappeared while loading.');
        const rows = entries.map((entry) => entry.row);
        for (const row of rows) annotatePaginatedRowColumns(model, row);
        const wasSyncing = state.syncing;
        state.syncing = true;
        state.observer?.disconnect();
        try {
            for (const row of rows) {
                if (!model.nativeRows.includes(row)) model.nativeRows.push(row);
                if (!model.nativeBodyNodes.includes(row)) model.nativeBodyNodes.push(row);
                if (!model.nativeRowNodes.has(row)) {
                    model.nativeRowNodes.set(row, [...row.childNodes]);
                }
                if (!model.nativeCells.has(row)) model.nativeCells.set(row, [...row.children]);
            }
            body.append(...rows);
            pagination.loadedRows.push(...rows);
            for (const entry of entries) pagination.seenRowIds.add(entry.id);
            syncTable(model.table);
        } finally {
            state.syncing = wasSyncing;
            if (state.active && state.observer && document.body) {
                state.observer.observe(document.body, { childList: true, subtree: true });
            }
        }
        return rows.length;
    }

    function finishPaginationAtSafetyLimit(pagination, message) {
        pagination.warning = message;
        pagination.settled = true;
        pagination.failed = false;
        pagination.error = '';
    }

    async function runPaginationLoad(model, runId, signal) {
        const pagination = model.pagination;
        while (runId === pagination.runId && !signal.aborted) {
            const shown = paginationVisibleRows(pagination);
            const target = paginationTargetCount(pagination);
            if (shown >= target || shown >= pagination.total - pagination.baseOffset) {
                pagination.settled = true;
                break;
            }
            if (!pagination.nextUrl) {
                pagination.settled = true;
                break;
            }
            if (pagination.pagesFetched >= MATCH_HISTORY_MAX_PAGES) {
                finishPaginationAtSafetyLimit(
                    pagination,
                    `Stopped at the ${MATCH_HISTORY_MAX_PAGES}-page safety limit.`,
                );
                break;
            }
            if (shown >= MATCH_HISTORY_MAX_ROWS) {
                finishPaginationAtSafetyLimit(
                    pagination,
                    `Stopped at the ${MATCH_HISTORY_MAX_ROWS.toLocaleString()}-row safety limit.`,
                );
                break;
            }
            if (pagination.responseBytes >= MATCH_HISTORY_MAX_TOTAL_BYTES) {
                finishPaginationAtSafetyLimit(
                    pagination,
                    'Stopped at the cumulative response-size safety limit.',
                );
                break;
            }
            const pageUrl = pagination.nextUrl;
            const pageKey = historyUrlKey(pageUrl);
            if (pagination.visitedUrls.has(pageKey)) {
                throw new Error('HLTV repeated a match-history page; loading stopped safely.');
            }
            pagination.loading = true;
            pagination.failed = false;
            pagination.error = '';
            setPaginationStatus(pagination, paginationSummary(pagination));
            rewriteHistoryPagers(pagination);
            const page = await fetchHistoryPage(pageUrl, pagination, signal);
            throwIfAborted(signal);
            if (runId !== pagination.runId || !model.table.isConnected) throw makeAbortError();
            pagination.pagesFetched += 1;
            const ids = page.rows.map((entry) => entry.id);
            const signature = `${ids.length}:${ids[0] || ''}:${ids.at(-1) || ''}:${ids.join(',')}`;
            if (pagination.pageSignatures.has(signature)) {
                throw new Error('HLTV repeated match-history results; loading stopped safely.');
            }
            const unique = page.rows.filter((entry) => !pagination.seenRowIds.has(entry.id));
            if (!unique.length) {
                throw new Error('HLTV returned only duplicate match-history rows.');
            }
            const remaining = Math.min(
                target - paginationVisibleRows(pagination),
                MATCH_HISTORY_MAX_ROWS - paginationVisibleRows(pagination),
            );
            appendHistoryRows(model, unique.slice(0, Math.max(0, remaining)), runId);
            pagination.pageSignatures.add(signature);
            pagination.visitedUrls.add(pageKey);
            pagination.total = page.range.total;
            pagination.nextUrl = page.nextUrl;
            setPaginationStatus(pagination, paginationSummary(pagination));
            rewriteHistoryPagers(pagination);
        }
    }

    function startPaginationLoad(model) {
        const pagination = model.pagination;
        if (!pagination || pagination.loading || pagination.settled || pagination.failed
            || !pagination.nextUrl || !model.table.isConnected) return;
        const controller = new AbortController();
        pagination.controller?.abort();
        pagination.controller = controller;
        pagination.runId += 1;
        const runId = pagination.runId;
        pagination.loading = true;
        setPaginationStatus(pagination, paginationSummary(pagination));
        rewriteHistoryPagers(pagination);
        runPaginationLoad(model, runId, controller.signal).catch((error) => {
            if (error?.name === 'AbortError' || controller.signal.aborted
                || runId !== pagination.runId) return;
            pagination.failed = true;
            pagination.settled = false;
            pagination.error = clampText(
                error?.message || 'More match-history rows could not be loaded.',
                260,
            );
        }).finally(() => {
            if (runId !== pagination.runId) return;
            pagination.loading = false;
            if (pagination.controller === controller) pagination.controller = null;
            setPaginationStatus(
                pagination,
                paginationSummary(pagination),
                pagination.failed ? 'error' : pagination.warning ? 'warning' : '',
            );
            rewriteHistoryPagers(pagination);
        });
    }

    function syncMatchHistoryPagination(model) {
        if (model.type !== 'matches' || !model.pagination) return;
        updatePaginationUi(model);
        const pagination = model.pagination;
        if (!pagination.loading && !pagination.failed && !pagination.settled) {
            startPaginationLoad(model);
        }
    }

    function cleanupPagination(model) {
        const pagination = model.pagination;
        if (!pagination) return;
        abortPagination(pagination);
        removePaginatedRows(model);
        pagination.control?.remove();
        pagination.control = null;
        pagination.select = null;
        pagination.status = null;
        pagination.retry = null;
        for (const [pager, snapshot] of pagination.pagerSnapshots) {
            restorePagerSnapshot(pager, snapshot);
        }
    }

    function cellFor(row, id) {
        const cells = [...row.querySelectorAll(`:scope > [data-hltv-v2-column-id="${CSS.escape(id)}"]`)];
        return cells.find((cell) => !cell.classList.contains('smartphone-only')) || cells[0] || null;
    }

    function kprBounds(cell) {
        if (!cell) return null;
        const rawMinimum = String(cell.dataset.kprMin ?? '').trim();
        const rawMaximum = String(cell.dataset.kprMax ?? '').trim();
        const minimum = rawMinimum ? finiteNumber(rawMinimum) : null;
        const maximum = rawMaximum ? finiteNumber(rawMaximum) : null;
        if (minimum !== null && maximum !== null) return { minimum, maximum };
        const values = [...String(cell.textContent).matchAll(/\d+(?:\.\d+)?/g)].map((match) => Number(match[0]));
        if (!values.length) return null;
        return { minimum: values[0], maximum: values[1] ?? values[0] };
    }

    function estimateKprBounds(rounds, difference, shownKd) {
        if (!Number.isFinite(rounds) || rounds <= 0
            || !Number.isFinite(difference)
            || !Number.isFinite(shownKd) || shownKd <= 0) return null;
        const roundedKd = Math.round(shownKd * 100);
        const q = 200 * difference;
        const lowerCoefficient = 2 * roundedKd - 201;
        const upperCoefficient = 2 * roundedKd - 199;
        let minimumDeaths = Math.max(1, -difference);
        let maximumDeaths = Math.min(rounds, 5 * rounds - difference);
        if (lowerCoefficient > 0) maximumDeaths = Math.min(maximumDeaths, Math.floor(q / lowerCoefficient));
        else if (lowerCoefficient < 0) minimumDeaths = Math.max(minimumDeaths, Math.ceil(q / lowerCoefficient));
        else if (q < 0) return null;
        if (upperCoefficient > 0) minimumDeaths = Math.max(minimumDeaths, Math.floor(q / upperCoefficient) + 1);
        else if (upperCoefficient < 0) maximumDeaths = Math.min(maximumDeaths, Math.ceil(q / upperCoefficient) - 1);
        else if (q >= 0) return null;
        minimumDeaths = Math.ceil(minimumDeaths);
        maximumDeaths = Math.floor(maximumDeaths);
        if (minimumDeaths > maximumDeaths) return null;
        return {
            minimum: (minimumDeaths + difference) / rounds,
            maximum: (maximumDeaths + difference) / rounds,
        };
    }

    function formatRange(minimum, maximum, digits = 2) {
        if (!Number.isFinite(minimum) || !Number.isFinite(maximum)) return '?';
        const low = Math.min(minimum, maximum);
        const high = Math.max(minimum, maximum);
        if (Math.abs(high - low) < (0.5 * (10 ** -digits))) return low.toFixed(digits);
        return `${low.toFixed(digits)}-${high.toFixed(digits)}`;
    }

    function rankingDerived(row) {
        const maps = parseNumber(cellFor(row, 'maps')?.textContent);
        const rounds = parseNumber(cellFor(row, 'rounds')?.textContent);
        const difference = parseNumber(cellFor(row, 'kd-diff')?.textContent);
        const bounds = kprBounds(cellFor(row, 'kpr'))
            || estimateKprBounds(rounds, difference, parseNumber(cellFor(row, 'kd')?.textContent));
        if (!maps || !rounds || difference === null || !bounds) return null;
        const killsMinimum = Math.max(0, bounds.minimum * rounds);
        const killsMaximum = Math.max(killsMinimum, bounds.maximum * rounds);
        const deathsMinimum = Math.max(0, killsMinimum - difference);
        const deathsMaximum = Math.max(deathsMinimum, killsMaximum - difference);
        return {
            kpr: [bounds.minimum, bounds.maximum],
            dpr: [deathsMinimum / rounds, deathsMaximum / rounds],
            'kills-per-map': [killsMinimum / maps, killsMaximum / maps],
        };
    }

    function matchDerived(row) {
        const killDeath = cellFor(row, 'kills-deaths')?.textContent.match(/(\d+)\s*-\s*(\d+)/);
        if (!killDeath) return null;
        const kills = Number(killDeath[1]);
        const deaths = Number(killDeath[2]);
        const scoreValues = ['player-team', 'opponent'].map((id) => {
            const text = cellFor(row, id)?.querySelector('.gtSmartphone-only')?.textContent || cellFor(row, id)?.textContent || '';
            const matches = [...text.matchAll(/\((\d+)\)/g)];
            return matches.length ? Number(matches[matches.length - 1][1]) : null;
        });
        const rounds = scoreValues.every(Number.isFinite)
            ? scoreValues[0] + scoreValues[1]
            : (() => {
                const bounds = kprBounds(cellFor(row, 'kpr'));
                return bounds?.minimum ? Math.round(kills / bounds.minimum) : null;
            })();
        if (!rounds) return null;
        return {
            kpr: [kills / rounds, kills / rounds],
            dpr: [deaths / rounds, deaths / rounds],
            kills: [kills, kills],
            deaths: [deaths, deaths],
        };
    }

    function removeManagedColumn(model, id) {
        for (const node of model.table.querySelectorAll(`[data-hltv-v2-managed-column="${CSS.escape(id)}"]`)) node.remove();
    }

    function setTextIfChanged(element, value) {
        const text = String(value);
        if (element.textContent !== text) element.textContent = text;
    }

    function setLeadingTextIfChanged(element, value) {
        const text = String(value);
        const first = element.firstChild;
        if (first?.nodeType === 3) {
            if (first.nodeValue !== text) first.nodeValue = text;
            return;
        }
        element.insertBefore(document.createTextNode(text), first);
    }

    function setAttributeIfChanged(element, name, value) {
        const text = String(value);
        if (element.getAttribute(name) !== text) element.setAttribute(name, text);
    }

    function syncManagedColumn(model, definition, values) {
        const headerRow = model.table.querySelector(':scope > thead > tr:first-child');
        if (!headerRow) return;
        const selector = `[data-hltv-v2-managed-column="${CSS.escape(definition.id)}"]`;
        const headers = [...headerRow.querySelectorAll(`:scope > ${selector}`)];
        let header = headers.shift() || null;
        for (const duplicate of headers) duplicate.remove();
        if (!header) {
            header = document.createElement('th');
            header.dataset.hltvV2ColumnId = definition.id;
            header.dataset.hltvV2ManagedColumn = definition.id;
            header.dataset.hltvV2OriginalIndex = '500';
            header.className = `${PREFIX}-derived gtSmartphone-only`;
            header.scope = 'col';
            const ratingHeader = [...headerRow.children].find((node) => node.dataset.hltvV2ColumnId === 'rating');
            headerRow.insertBefore(header, ratingHeader || null);
        }
        header.classList.add(`${PREFIX}-derived`, 'gtSmartphone-only');
        setAttributeIfChanged(header, 'title', definition.title);
        setLeadingTextIfChanged(header, definition.label);
        model.rows.forEach((row, index) => {
            const cells = [...row.querySelectorAll(`:scope > ${selector}`)];
            let cell = cells.shift() || null;
            for (const duplicate of cells) duplicate.remove();
            if (!cell) {
                cell = document.createElement('td');
                cell.dataset.hltvV2ColumnId = definition.id;
                cell.dataset.hltvV2ManagedColumn = definition.id;
                cell.dataset.hltvV2OriginalIndex = '500';
                cell.className = `${PREFIX}-derived gtSmartphone-only`;
                const ratingCell = [...row.children].find((node) => node.dataset.hltvV2ColumnId === 'rating');
                row.insertBefore(cell, ratingCell || null);
            }
            cell.classList.add(`${PREFIX}-derived`, 'gtSmartphone-only');
            const range = values[index]?.[definition.id];
            if (range) {
                setTextIfChanged(cell, formatRange(range[0], range[1], definition.digits));
                setAttributeIfChanged(cell, 'data-sort', (range[0] + range[1]) / 2);
                setAttributeIfChanged(cell, 'title', definition.title);
            } else {
                setTextIfChanged(cell, '?');
                cell.removeAttribute('data-sort');
                cell.removeAttribute('title');
            }
        });
    }

    function syncOptionalColumns(model) {
        removeManagedColumn(model, 'net-kpr');
        if (model.type === 'matches') removeManagedColumn(model, 'kills-per-map');
        const selected = state.settings.enableStatsColumnChooser
            ? selectedOptionalIds(model.type)
            : new Set();
        const values = model.rows.map((row) => model.type === 'ranking' ? rankingDerived(row) : matchDerived(row));
        OPTIONAL_COLUMNS[model.type].forEach((definition) => {
            if (definition.external) return;
            if (selected.has(definition.id)) syncManagedColumn(model, definition, values);
            else removeManagedColumn(model, definition.id);
        });
    }

    function rowMetric(row, id) {
        if (id === 'kills' || id === 'deaths') {
            const derived = matchDerived(row);
            return derived?.[id]?.[0] ?? null;
        }
        const cell = cellFor(row, id);
        if (!cell) return null;
        if (id === 'date') return finiteNumber(cell.querySelector('[data-unix]')?.dataset.unix);
        const explicit = finiteAttributeNumber(cell.dataset.sort);
        if (explicit !== null) return explicit;
        const bounds = id === 'kpr' ? kprBounds(cell) : null;
        if (bounds) return (bounds.minimum + bounds.maximum) / 2;
        return parseNumber(cell.textContent);
    }

    function availableMetrics(model) {
        const metrics = [...model.groups.keys()].filter((id) => (
            NUMERIC_COLUMNS.has(id) && model.rows.some((row) => rowMetric(row, id) !== null)
        ));
        if (model.type === 'matches') {
            for (const id of ['kills', 'deaths']) {
                if (!metrics.includes(id) && model.rows.some((row) => rowMetric(row, id) !== null)) {
                    metrics.push(id);
                }
            }
        }
        return metrics;
    }

    function groupOrder(model) {
        return [...model.groups.keys()];
    }

    function savedLayout(model) {
        const layout = normaliseLayout(state.settings.statsColumnLayoutV2)[model.type]
            || { order: [], hidden: [] };
        return {
            order: layout.order,
            hidden: layout.hidden.filter((id) => (
                !optionalDefinition(model.type, id)
                && !(model.type === 'ranking' && id === 'period-delta')
            )),
        };
    }

    function applyColumnLayout(model) {
        refreshModel(model.table);
        if (!state.settings.enableStatsColumnChooser) {
            if (!model.layoutWasApplied) return;
            for (const [node, attributes] of model.attributeSnapshots) {
                if (attributes.has('class') && node.isConnected) restoreRememberedAttribute(model, node, 'class');
            }
            restoreNativeColumnOrder(model, true);
            model.layoutWasApplied = false;
            refreshModel(model.table);
            return;
        }
        if (!model.layoutWasApplied) restoreNativeColumnOrder(model, true);
        refreshModel(model.table);
        const nativeOrder = [...model.groups.keys()];
        const layout = savedLayout(model);
        const requested = layout.order;
        const order = [...requested.filter((id) => model.groups.has(id)), ...nativeOrder.filter((id) => !requested.includes(id))];
        const hidden = new Set(layout.hidden);
        const headerRow = model.table.querySelector(':scope > thead > tr:first-child');
        const desiredHeaders = order.flatMap((id) => model.groups.get(id)?.headers || []);
        reconcileNodeOrder(headerRow, desiredHeaders, true);
        for (const row of model.rows) {
            const desiredCells = order.flatMap((id) => [
                ...row.querySelectorAll(
                    `:scope > [data-hltv-v2-column-id="${CSS.escape(id)}"]`,
                ),
            ]);
            reconcileNodeOrder(row, desiredCells, true);
        }
        for (const id of nativeOrder) {
            const shouldHide = hidden.has(id);
            for (const node of model.table.querySelectorAll(`[data-hltv-v2-column-id="${CSS.escape(id)}"]`)) {
                if (shouldHide) toggleManagedClass(model, node, `${PREFIX}-col-hidden`, true);
                else restoreRememberedAttribute(model, node, 'class');
            }
        }
        model.layoutWasApplied = true;
        refreshModel(model.table);
    }

    function saveLayout(model, order, hidden) {
        const layouts = normaliseLayout(state.settings.statsColumnLayoutV2);
        layouts[model.type] = { order, hidden };
        persist('statsColumnLayoutV2', layouts);
        applyColumnLayout(model);
        renderChooser(model);
    }

    function saveOptionalSelection(model, id, checked, order, hidden) {
        const selected = normaliseOptionalColumns(state.settings.statsOptionalColumnsV2);
        const values = new Set(selected[model.type]);
        if (checked) values.add(id);
        else values.delete(id);
        selected[model.type] = OPTIONAL_COLUMNS[model.type]
            .map((definition) => definition.id)
            .filter((columnId) => values.has(columnId));
        state.settings.statsOptionalColumnsV2 = selected;
        if (model.type === 'ranking' && id === 'war') {
            state.settings.enableWinAdjustedRatings = checked;
            persist('enableWinAdjustedRatings', checked);
            globalThis.HLTV_SP_WIN_ADJUSTED_RATINGS?.setEnabled?.(checked);
        }
        persist('statsOptionalColumnsV2', selected);
        const layouts = normaliseLayout(state.settings.statsColumnLayoutV2);
        layouts[model.type] = { order, hidden: hidden.filter((columnId) => columnId !== id) };
        persist('statsColumnLayoutV2', layouts);
        scheduleSync();
    }

    function savePeriodDeltaSelection(model, checked, order, hidden) {
        state.settings.enableStatsTablePeriodComparison = checked;
        persist('enableStatsTablePeriodComparison', checked);
        const layouts = normaliseLayout(state.settings.statsColumnLayoutV2);
        layouts[model.type] = { order, hidden: hidden.filter((id) => id !== 'period-delta') };
        persist('statsColumnLayoutV2', layouts);
        scheduleSync();
    }

    function renderChooser(model) {
        const chooser = model.chooser;
        if (!chooser) return;
        chooser.replaceChildren();
        const layout = savedLayout(model);
        const current = catalogueOrder(refreshModel(model.table));
        const order = [...layout.order.filter((id) => current.includes(id)), ...current.filter((id) => !layout.order.includes(id))];
        const hidden = new Set(layout.hidden);
        const selectedOptional = selectedOptionalIds(model.type);
        order.forEach((id, index) => {
            const group = model.groups.get(id);
            const row = document.createElement('div');
            row.className = `${PREFIX}-chooser-row`;
            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            const isOptional = Boolean(optionalDefinition(model.type, id));
            const isPeriodDelta = model.type === 'ranking' && id === 'period-delta';
            checkbox.checked = isOptional
                ? selectedOptional.has(id)
                : isPeriodDelta ? state.settings.enableStatsTablePeriodComparison : !hidden.has(id);
            checkbox.setAttribute('aria-label', `Show ${columnLabel(model, id)}`);
            checkbox.addEventListener('change', () => {
                if (isOptional) {
                    saveOptionalSelection(model, id, checkbox.checked, order, [...hidden]);
                } else if (isPeriodDelta) {
                    savePeriodDeltaSelection(model, checkbox.checked, order, [...hidden]);
                } else {
                    if (checkbox.checked) hidden.delete(id); else hidden.add(id);
                    saveLayout(model, order, [...hidden]);
                }
            });
            const label = document.createElement('span');
            label.textContent = columnLabel(model, id);
            const up = document.createElement('button');
            up.type = 'button';
            up.textContent = '↑';
            up.title = 'Move column left';
            up.disabled = index === 0;
            up.addEventListener('click', () => {
                [order[index - 1], order[index]] = [order[index], order[index - 1]];
                saveLayout(model, order, [...hidden]);
            });
            const down = document.createElement('button');
            down.type = 'button';
            down.textContent = '↓';
            down.title = 'Move column right';
            down.disabled = index === order.length - 1;
            down.addEventListener('click', () => {
                [order[index], order[index + 1]] = [order[index + 1], order[index]];
                saveLayout(model, order, [...hidden]);
            });
            const explanation = COLUMN_EXPLANATIONS[model.type]?.[id] || '';
            let info = null;
            let help = null;
            if (explanation) {
                info = document.createElement('button');
                info.type = 'button';
                info.className = `${PREFIX}-column-info`;
                info.title = `How ${columnLabel(model, id)} is calculated`;
                info.setAttribute('aria-label', info.title);
                info.setAttribute('aria-expanded', 'false');
                const icon = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
                icon.setAttribute('viewBox', '0 0 16 16');
                icon.setAttribute('aria-hidden', 'true');
                icon.setAttribute('focusable', 'false');
                const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
                circle.setAttribute('cx', '8');
                circle.setAttribute('cy', '8');
                circle.setAttribute('r', '6.5');
                circle.setAttribute('fill', 'none');
                circle.setAttribute('stroke', 'currentColor');
                circle.setAttribute('stroke-width', '1.5');
                const stem = document.createElementNS('http://www.w3.org/2000/svg', 'path');
                stem.setAttribute('d', 'M8 7v4');
                stem.setAttribute('fill', 'none');
                stem.setAttribute('stroke', 'currentColor');
                stem.setAttribute('stroke-linecap', 'round');
                stem.setAttribute('stroke-width', '1.5');
                const dot = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
                dot.setAttribute('cx', '8');
                dot.setAttribute('cy', '4.5');
                dot.setAttribute('r', '1');
                dot.setAttribute('fill', 'currentColor');
                icon.append(circle, stem, dot);
                info.append(icon);
                help = document.createElement('div');
                help.className = `${PREFIX}-column-help`;
                help.id = `${PREFIX}-column-help-${++state.infoIdSequence}`;
                help.hidden = true;
                help.textContent = explanation;
                info.setAttribute('aria-controls', help.id);
                info.addEventListener('click', () => {
                    const open = help.hidden;
                    for (const other of chooser.querySelectorAll(`.${PREFIX}-column-help`)) {
                        other.hidden = true;
                    }
                    for (const other of chooser.querySelectorAll(`.${PREFIX}-column-info`)) {
                        other.setAttribute('aria-expanded', 'false');
                    }
                    help.hidden = !open;
                    info.setAttribute('aria-expanded', String(open));
                });
            }
            row.append(checkbox, label, up, down);
            if (info) row.append(info);
            chooser.append(row);
            if (help) chooser.append(help);
        });
    }

    function csvCell(value) {
        let text = String(value ?? '').replace(/\s+/g, ' ').trim();
        if (/^[=+\-@]/.test(text)) text = `'${text}`;
        return `"${text.replace(/"/g, '""')}"`;
    }

    function cleanCellText(value) {
        return String(value ?? '').replace(/\s+/g, ' ').trim();
    }

    function teamNameFromLink(link) {
        const text = cleanCellText(link?.textContent);
        if (text) return text;
        const image = link?.querySelector('img[alt], img[title]');
        return cleanCellText(image?.getAttribute('alt') || image?.getAttribute('title'));
    }

    function teamNamesFromCell(cell) {
        const names = [];
        const seen = new Set();
        for (const link of cell?.querySelectorAll('a[href*="/stats/teams/"]') || []) {
            const name = teamNameFromLink(link);
            const key = name.toLocaleLowerCase();
            if (!name || seen.has(key)) continue;
            seen.add(key);
            names.push(name);
        }
        return names;
    }

    function flagNameFromCell(cell) {
        for (const image of cell?.querySelectorAll('img.flag') || []) {
            const name = cleanCellText(image.getAttribute('title') || image.getAttribute('alt'));
            if (name) return name;
        }
        return '';
    }

    function displayedTeamValue(cell) {
        const preferred = cell?.querySelector('.gtSmartphone-only') || cell;
        return cleanCellText(preferred?.textContent);
    }

    function csvValueFor(model, row, id) {
        const cell = cellFor(row, id);
        if (!cell) return '';
        if (model.type === 'ranking' && id === 'team') {
            return teamNamesFromCell(cell).join(',');
        }
        if (model.type === 'matches' && (id === 'player-team' || id === 'opponent')) {
            return displayedTeamValue(cell);
        }
        return cleanCellText(cell.textContent);
    }

    function csvColumns(model) {
        const visibleOrder = groupOrder(model).filter((id) => (
            !model.groups.get(id)?.headers.every((header) => header.classList.contains(`${PREFIX}-col-hidden`))
        ));
        const columns = [];
        for (const id of visibleOrder) {
            if (model.type === 'ranking' && id === 'player') {
                columns.push({ heading: 'Country', value: (row) => flagNameFromCell(cellFor(row, id)) });
            }
            columns.push({
                heading: labelForGroup(model.groups.get(id)),
                value: (row) => csvValueFor(model, row, id),
            });
            if (model.type === 'matches' && id === 'player-team') {
                columns.push({
                    heading: 'Player team nation',
                    value: (row) => flagNameFromCell(cellFor(row, id)),
                });
            } else if (model.type === 'matches' && id === 'opponent') {
                columns.push({
                    heading: 'Opponent nation',
                    value: (row) => flagNameFromCell(cellFor(row, id)),
                });
            }
        }
        return columns;
    }

    function exportCsv(model, status) {
        refreshModel(model.table);
        const columns = csvColumns(model);
        const lines = [columns.map((column) => csvCell(column.heading)).join(',')];
        for (const row of model.rows) {
            lines.push(columns.map((column) => csvCell(column.value(row))).join(','));
        }
        const blob = new Blob([`\uFEFF${lines.join('\r\n')}\r\n`], { type: 'text/csv;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const anchor = document.createElement('a');
        anchor.href = url;
        anchor.download = `hltv-${model.type}-stats-${new Date().toISOString().replace(/[:.]/g, '-')}.csv`;
        anchor.click();
        globalThis.setTimeout(() => URL.revokeObjectURL(url), 1000);
        status.textContent = `${model.rows.length} rows exported.`;
    }

    function sortConfig(model) {
        return normaliseSort(state.settings.statsMultiSortV2)[model.type] || [];
    }

    function rowComparable(row, id) {
        if (id === 'date' || NUMERIC_COLUMNS.has(id)) {
            const numeric = rowMetric(row, id);
            if (numeric !== null) return { numeric: true, value: numeric };
        }
        const cell = cellFor(row, id);
        let value = '';
        if (id === 'team') {
            value = cleanCellText(cell?.dataset.sort) || teamNamesFromCell(cell).join(',');
        } else if (id === 'player-team' || id === 'opponent') {
            value = teamNamesFromCell(cell).join(',') || displayedTeamValue(cell);
        } else if (id === 'player') {
            value = cleanCellText(cell?.querySelector('a[href*="/stats/players/"]')?.textContent)
                || cleanCellText(cell?.textContent);
        } else {
            value = cleanCellText(cell?.textContent);
        }
        return { numeric: false, value: clampText(value, 500).toLocaleLowerCase() };
    }

    function syncSortBadges(model, config) {
        const retained = new Set();
        config.forEach((item, index) => {
            const header = model.groups.get(item.id)?.headers[0];
            if (!header) return;
            const badges = [...header.querySelectorAll(`:scope > .${PREFIX}-sort-badge`)];
            let badge = badges.shift() || null;
            for (const duplicate of badges) duplicate.remove();
            if (!badge) {
                badge = document.createElement('span');
                badge.className = `${PREFIX}-sort-badge`;
                header.append(badge);
            }
            setTextIfChanged(badge, `${index + 1}${item.direction === 'asc' ? '↑' : '↓'}`);
            retained.add(badge);
        });
        for (const badge of model.table.querySelectorAll(`.${PREFIX}-sort-badge`)) {
            if (!retained.has(badge)) badge.remove();
        }
    }

    function applySort(model) {
        const config = state.settings.enableStatsMultiSort
            ? sortConfig(model).filter((item) => model.groups.has(item.id))
            : [];
        syncSortBadges(model, config);
        if (!config.length) {
            if (model.sortWasApplied) restoreNativeRowOrder(model);
            model.sortWasApplied = false;
            return;
        }
        const body = model.table.tBodies[0];
        if (!body) return;
        const nativeIndices = new Map(model.nativeRows.map((row, index) => [row, index]));
        const comparables = config.map((item) => ({
            ...item,
            values: new Map(model.rows.map((row) => [row, rowComparable(row, item.id)])),
        }));
        const sortedRows = [...model.rows].sort((a, b) => {
            for (const item of comparables) {
                const left = item.values.get(a);
                const right = item.values.get(b);
                let comparison;
                if (left.numeric && right.numeric) comparison = left.value - right.value;
                else comparison = String(left.value).localeCompare(String(right.value), undefined, { numeric: true, sensitivity: 'base' });
                if (comparison) return item.direction === 'asc' ? comparison : -comparison;
            }
            return (nativeIndices.get(a) ?? 0) - (nativeIndices.get(b) ?? 0);
        });
        reconcileNodeOrder(body, sortedRows, true);
        model.sortWasApplied = true;
    }

    function handleHeaderClick(event, model) {
        if (!state.settings.enableStatsMultiSort) return;
        const header = event.target.closest('th[data-hltv-v2-column-id]');
        if (!header || !model.table.contains(header)) return;
        event.preventDefault();
        event.stopImmediatePropagation();
        const id = header.dataset.hltvV2ColumnId;
        let config = sortConfig(model);
        const existing = config.find((item) => item.id === id);
        const next = existing
            ? (existing.direction === 'desc' ? 'asc' : 'desc')
            : (NUMERIC_COLUMNS.has(id) ? 'desc' : 'asc');
        if (!event.shiftKey) config = [{ id, direction: next }];
        else if (existing) config = config.map((item) => item.id === id ? { id, direction: next } : item);
        else config = [...config, { id, direction: NUMERIC_COLUMNS.has(id) ? 'desc' : 'asc' }].slice(0, 12);
        const stored = normaliseSort(state.settings.statsMultiSortV2);
        stored[model.type] = config;
        persist('statsMultiSortV2', stored);
        applySort(model);
    }

    function syncHeaderListener(model) {
        toggleManagedClass(model, model.table, `${PREFIX}-sortable`, state.settings.enableStatsMultiSort);
        const target = state.settings.enableStatsMultiSort ? model.table.tHead : null;
        if (target === model.headerListenerTarget && model.headerClickListener) return;
        removeHeaderListener(model);
        if (!target) return;
        model.headerClickListener = (event) => handleHeaderClick(event, model);
        model.headerListenerTarget = target;
        target.addEventListener('click', model.headerClickListener, true);
    }

    function makeSelect(labelText, values, selected, onChange) {
        const label = document.createElement('label');
        label.textContent = `${labelText} `;
        const select = document.createElement('select');
        for (const value of values) {
            const option = document.createElement('option');
            option.value = value;
            option.textContent = METRIC_LABELS[value]
                || value.replace(/-/g, ' ').replace(/\b\w/g, (letter) => letter.toUpperCase());
            option.selected = value === selected;
            select.append(option);
        }
        select.addEventListener('change', () => onChange(select.value));
        label.append(select);
        return label;
    }

    function ensureToolbar(model) {
        if (model.toolbar?.isConnected) return model.toolbar;
        const toolbar = document.createElement('div');
        toolbar.className = `${PREFIX}-toolbar`;
        tableSurface(model).before(toolbar);
        model.toolbar = toolbar;
        return toolbar;
    }

    function legacyKprSortHeaders(model) {
        return [...model.table.querySelectorAll('th[data-tm-kpr-sort-dir]')];
    }

    function hasActiveSort(model) {
        return sortConfig(model).length > 0
            || model.sortWasApplied
            || legacyKprSortHeaders(model).length > 0;
    }

    function resetSort(model) {
        const stored = normaliseSort(state.settings.statsMultiSortV2);
        stored[model.type] = [];
        for (const header of legacyKprSortHeaders(model)) {
            delete header.dataset.tmKprSortDir;
        }
        persist('statsMultiSortV2', stored);
        for (const badge of model.table.querySelectorAll(`.${PREFIX}-sort-badge`)) badge.remove();
        restoreNativeRowOrder(model);
        model.sortWasApplied = false;
    }

    function toolbarRenderSignature(model, legacyKprSortActive, metrics) {
        const layout = normaliseLayout(state.settings.statsColumnLayoutV2)[model.type]
            || { order: [], hidden: [] };
        const catalogue = catalogueOrder(model);
        return JSON.stringify({
            chooser: state.settings.enableStatsColumnChooser,
            multiSort: state.settings.enableStatsMultiSort,
            csv: state.settings.enableStatsCsvExport,
            sparklines: model.type === 'matches' && state.settings.enablePlayerMatchSparklines,
            periodComparison: model.type === 'ranking' && state.settings.enableStatsTablePeriodComparison,
            legacyKprSortActive,
            optional: [...selectedOptionalIds(model.type)],
            layout,
            sort: sortConfig(model),
            trendMetric: model.type === 'matches' ? state.settings.playerMatchTrendMetric : '',
            catalogue,
            groups: groupOrder(model),
            metrics,
        });
    }

    function syncToolbar(model) {
        const legacyKprSortActive = legacyKprSortHeaders(model).length > 0;
        const needed = state.settings.enableStatsColumnChooser
            || state.settings.enableStatsMultiSort
            || state.settings.enableStatsCsvExport
            || legacyKprSortActive
            || (model.type === 'matches' && state.settings.enablePlayerMatchSparklines);
        if (!needed) {
            model.toolbar?.remove();
            model.toolbar = null;
            model.chooser = null;
            model.toolbarSignature = '';
            return;
        }
        const metrics = availableMetrics(model);
        const signature = toolbarRenderSignature(model, legacyKprSortActive, metrics);
        const toolbar = ensureToolbar(model);
        if (model.toolbarSignature === signature && toolbar.childElementCount) return;
        const chooserWasOpen = Boolean(model.chooser && !model.chooser.hidden);
        toolbar.replaceChildren();
        if (state.settings.enableStatsColumnChooser) {
            const button = document.createElement('button');
            button.type = 'button';
            button.textContent = 'Columns';
            const chooser = document.createElement('div');
            chooser.className = `${PREFIX}-chooser`;
            chooser.hidden = !chooserWasOpen;
            chooser.addEventListener('click', (event) => event.stopPropagation());
            button.addEventListener('click', (event) => {
                event.stopPropagation();
                chooser.hidden = !chooser.hidden;
            });
            toolbar.append(button, chooser);
            model.chooser = chooser;
            renderChooser(model);
        }
        if (state.settings.enableStatsMultiSort || legacyKprSortActive) {
            const reset = document.createElement('button');
            reset.type = 'button';
            reset.textContent = 'Reset sort';
            reset.disabled = !hasActiveSort(model);
            reset.addEventListener('click', () => {
                reset.disabled = true;
                resetSort(model);
            });
            toolbar.append(reset);
        }
        if (model.type === 'matches' && state.settings.enablePlayerMatchSparklines && metrics.length) {
            toolbar.append(makeSelect('Performance metric', metrics, state.settings.playerMatchTrendMetric, (metric) => {
                persist('playerMatchTrendMetric', metric);
                scheduleSync();
            }));
        }
        if (state.settings.enableStatsCsvExport) {
            const button = document.createElement('button');
            button.type = 'button';
            button.textContent = 'Export CSV';
            const status = document.createElement('span');
            status.className = `${PREFIX}-csv-status`;
            button.addEventListener('click', () => exportCsv(model, status));
            toolbar.append(button, status);
        }
        model.toolbarSignature = signature;
    }

    function svgElement(name, attributes = {}) {
        const element = document.createElementNS('http://www.w3.org/2000/svg', name);
        for (const [key, value] of Object.entries(attributes)) {
            element.setAttribute(key, String(value));
        }
        return element;
    }

    function trendCoordinates(value, index, count, bounds) {
        const x = count <= 1
            ? bounds.left + (bounds.width / 2)
            : bounds.left + ((index / (count - 1)) * bounds.width);
        const range = bounds.maximum - bounds.minimum || 1;
        const y = bounds.top + bounds.height - (((value - bounds.minimum) / range) * bounds.height);
        return { x, y };
    }

    function svgPointString(value, index, count, bounds) {
        const point = trendCoordinates(value, index, count, bounds);
        return `${point.x.toFixed(2)},${point.y.toFixed(2)}`;
    }

    function graphNumber(value, range) {
        if (range >= 100) return value.toFixed(0);
        if (range >= 10) return value.toFixed(1);
        return value.toFixed(2);
    }

    function graphDate(row) {
        return cleanCellText(cellFor(row, 'date')?.textContent) || 'Unknown date';
    }

    function trendTimestamp(row) {
        const explicit = finiteNumber(row.querySelector('[data-unix]')?.dataset.unix);
        if (explicit !== null) return explicit;
        const dateMatch = graphDate(row).match(/^(\d{1,2})\/(\d{1,2})\/(\d{2}|\d{4})$/);
        if (!dateMatch) return 0;
        const year = Number(dateMatch[3]);
        return Date.UTC(year < 100 ? 2000 + year : year, Number(dateMatch[2]) - 1, Number(dateMatch[1]));
    }

    function trendPointDescription(entry, metric) {
        const row = entry.row;
        const playerTeam = displayedTeamValue(cellFor(row, 'player-team')) || 'Player team';
        const opponent = displayedTeamValue(cellFor(row, 'opponent')) || 'Opponent';
        const map = cleanCellText(cellFor(row, 'map')?.textContent) || 'unknown map';
        const score = cleanCellText(cellFor(row, 'kills-deaths')?.textContent);
        const metricName = METRIC_LABELS[metric] || metric;
        return [
            `${playerTeam} vs ${opponent}`,
            `${graphDate(row)} · ${map}${score ? ` · K-D ${score}` : ''}`,
            `${metricName}: ${entry.value.toFixed(2)}`,
        ].join('\n');
    }

    function rollingAverage(values, windowSize = 5) {
        return values.map((_, index) => {
            const window = values.slice(Math.max(0, index - windowSize + 1), index + 1);
            return window.reduce((sum, value) => sum + value, 0) / window.length;
        });
    }

    function removeTrend(model) {
        model.trend?.remove();
        model.trend = null;
        model.trendSignature = '';
    }

    function canonicalTrendEntries(model, metric, maximum = 100) {
        const entries = model.nativeRows.map((row, nativeIndex) => {
            const link = row.querySelector('a[href*="/stats/matches/mapstatsid/"]');
            return {
                row,
                nativeIndex,
                key: link?.getAttribute('href') || `native-row-${nativeIndex}`,
                value: rowMetric(row, metric),
                timestamp: trendTimestamp(row),
            };
        }).filter((entry) => (
            entry.row.isConnected
            && model.table.contains(entry.row)
            && Number.isFinite(entry.value)
        ));
        return entries
            .sort((first, second) => (
                second.timestamp - first.timestamp
                || first.nativeIndex - second.nativeIndex
            ))
            .slice(0, maximum)
            .sort((first, second) => (
                first.timestamp - second.timestamp
                || first.nativeIndex - second.nativeIndex
            ));
    }

    function canonicalTrendSignature(metric, entries) {
        return JSON.stringify([
            metric,
            ...entries.map((entry) => [
                entry.key,
                entry.timestamp,
                entry.value,
                trendPointDescription(entry, metric),
            ]),
        ]);
    }

    function positionTrendPopup(box, popup, point) {
        popup.hidden = false;
        const boxRect = box.getBoundingClientRect();
        const pointRect = point.getBoundingClientRect();
        const popupRect = popup.getBoundingClientRect();
        let left = pointRect.left - boxRect.left + (pointRect.width / 2);
        const minimumLeft = (popupRect.width / 2) + 6;
        const maximumLeft = boxRect.width - minimumLeft;
        if (maximumLeft >= minimumLeft) left = Math.max(minimumLeft, Math.min(maximumLeft, left));
        const aboveTop = pointRect.top - boxRect.top;
        if (aboveTop - popupRect.height - 8 >= 0) {
            popup.style.top = `${aboveTop}px`;
            popup.style.transform = 'translate(-50%, calc(-100% - 8px))';
        } else {
            popup.style.top = `${pointRect.bottom - boxRect.top}px`;
            popup.style.transform = 'translate(-50%, 8px)';
        }
        popup.style.left = `${left}px`;
    }

    function attachTrendPointInteractions(box, svg, popup, pointDetails) {
        const pointSelector = `.${PREFIX}-trend-point`;
        const markedClass = `${PREFIX}-trend-point-marked`;
        let hoveredPoint = null;
        let focusedPoint = null;
        const clearMarkedPoint = () => {
            const marked = svg.querySelector(`${pointSelector}.${markedClass}`);
            if (marked) {
                marked.classList.remove(markedClass);
                marked.setAttribute('aria-pressed', 'false');
            }
            popup.hidden = true;
            popup.textContent = '';
        };
        const activatePoint = (point) => {
            if (point.classList.contains(markedClass)) return;
            clearMarkedPoint();
            point.classList.add(markedClass);
            point.setAttribute('aria-pressed', 'true');
            popup.textContent = pointDetails.get(point) || '';
            positionTrendPopup(box, popup, point);
        };
        const syncActivePoint = () => {
            const point = hoveredPoint || focusedPoint;
            if (point?.isConnected && svg.contains(point)) {
                activatePoint(point);
            } else {
                clearMarkedPoint();
            }
        };
        svg.addEventListener('pointerover', (event) => {
            const point = event.target.closest?.(pointSelector);
            if (!point || !svg.contains(point)) return;
            hoveredPoint = point;
            activatePoint(point);
        });
        svg.addEventListener('pointerout', (event) => {
            const point = event.target.closest?.(pointSelector);
            if (!point || !svg.contains(point) || hoveredPoint !== point) return;
            const nextPoint = event.relatedTarget?.closest?.(pointSelector);
            if (nextPoint === point) return;
            hoveredPoint = null;
            syncActivePoint();
        });
        svg.addEventListener('focusin', (event) => {
            const point = event.target.closest?.(pointSelector);
            if (!point || !svg.contains(point)) return;
            focusedPoint = point;
            syncActivePoint();
        });
        svg.addEventListener('focusout', (event) => {
            const point = event.target.closest?.(pointSelector);
            if (!point || !svg.contains(point) || focusedPoint !== point) return;
            const nextPoint = event.relatedTarget?.closest?.(pointSelector);
            focusedPoint = nextPoint && svg.contains(nextPoint) ? nextPoint : null;
            syncActivePoint();
        });
        svg.addEventListener('keydown', (event) => {
            const point = event.target.closest?.(pointSelector);
            if (!point || !svg.contains(point)) return;
            if (event.key === 'Escape') {
                event.preventDefault();
                hoveredPoint = null;
                focusedPoint = null;
                clearMarkedPoint();
            } else if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                activatePoint(point);
            }
        });
    }

    function syncTrend(model) {
        if (model.type !== 'matches') {
            removeTrend(model);
            return;
        }
        const metrics = availableMetrics(model);
        const metric = metrics.includes(state.settings.playerMatchTrendMetric) ? state.settings.playerMatchTrendMetric : metrics[0];
        if (!metric) {
            removeTrend(model);
            return;
        }
        if (metric !== state.settings.playerMatchTrendMetric) persist('playerMatchTrendMetric', metric);
        const latest = canonicalTrendEntries(model, metric);
        if (!state.settings.enablePlayerMatchSparklines || latest.length < 2) {
            removeTrend(model);
            return;
        }
        const signature = canonicalTrendSignature(metric, latest);
        if (model.trend?.isConnected && model.trendSignature === signature) return;
        removeTrend(model);
        const values = latest.map((entry) => entry.value);
        const rolling = rollingAverage(values);
        const rawMinimum = Math.min(...values, ...rolling);
        const rawMaximum = Math.max(...values, ...rolling);
        const rawRange = rawMaximum - rawMinimum;
        const padding = rawRange > 0
            ? rawRange * 0.08
            : Math.max(Math.abs(rawMaximum) * 0.1, 0.05);
        const bounds = {
            left: 52,
            top: 10,
            width: 568,
            height: 116,
            minimum: rawMinimum - padding,
            maximum: rawMaximum + padding,
        };
        const box = document.createElement('div');
        box.className = `${PREFIX}-trend`;
        const title = document.createElement('div');
        title.className = `${PREFIX}-trend-title`;
        const name = document.createElement('strong');
        const metricName = METRIC_LABELS[metric] || metric;
        name.textContent = `${metricName} trend; last ${values.length} loaded maps`;
        const range = document.createElement('span');
        range.textContent = `${rawMinimum.toFixed(2)} to ${rawMaximum.toFixed(2)}; orange = 5-map average`;
        title.append(name, range);
        const svg = svgElement('svg', {
            viewBox: '0 0 640 160',
            role: 'img',
            'aria-label': `${metricName} trend over the last ${values.length} loaded maps`,
        });
        const popup = document.createElement('div');
        popup.className = `${PREFIX}-trend-popup`;
        popup.hidden = true;
        popup.setAttribute('role', 'status');
        popup.setAttribute('aria-live', 'polite');
        const pointDetails = new WeakMap();
        const yTicks = 5;
        for (let index = 0; index < yTicks; index += 1) {
            const ratio = index / (yTicks - 1);
            const y = bounds.top + (ratio * bounds.height);
            const value = bounds.maximum - (ratio * (bounds.maximum - bounds.minimum));
            svg.append(
                svgElement('line', {
                    class: `${PREFIX}-trend-grid`,
                    x1: bounds.left,
                    x2: bounds.left + bounds.width,
                    y1: y,
                    y2: y,
                }),
            );
            const label = svgElement('text', {
                class: `${PREFIX}-trend-label ${PREFIX}-trend-y-tick`,
                x: bounds.left - 7,
                y: y + 3,
                'text-anchor': 'end',
            });
            label.textContent = graphNumber(value, bounds.maximum - bounds.minimum);
            svg.append(label);
        }
        svg.append(
            svgElement('line', {
                class: `${PREFIX}-trend-axis`,
                x1: bounds.left,
                x2: bounds.left,
                y1: bounds.top,
                y2: bounds.top + bounds.height,
            }),
            svgElement('line', {
                class: `${PREFIX}-trend-axis`,
                x1: bounds.left,
                x2: bounds.left + bounds.width,
                y1: bounds.top + bounds.height,
                y2: bounds.top + bounds.height,
            }),
        );
        const xIndices = [...new Set([0, Math.floor((latest.length - 1) / 2), latest.length - 1])];
        for (const index of xIndices) {
            const point = trendCoordinates(values[index], index, latest.length, bounds);
            const label = svgElement('text', {
                class: `${PREFIX}-trend-label ${PREFIX}-trend-x-tick`,
                x: point.x,
                y: bounds.top + bounds.height + 17,
                'text-anchor': index === 0 ? 'start' : index === latest.length - 1 ? 'end' : 'middle',
            });
            label.textContent = graphDate(latest[index].row);
            svg.append(label);
        }
        const yLabel = svgElement('text', {
            class: `${PREFIX}-trend-label ${PREFIX}-trend-axis-label`,
            x: 11,
            y: bounds.top + (bounds.height / 2),
            transform: `rotate(-90 11 ${bounds.top + (bounds.height / 2)})`,
            'text-anchor': 'middle',
        });
        yLabel.textContent = metricName;
        const xLabel = svgElement('text', {
            class: `${PREFIX}-trend-label ${PREFIX}-trend-axis-label`,
            x: bounds.left + (bounds.width / 2),
            y: 157,
            'text-anchor': 'middle',
        });
        xLabel.textContent = 'Map date';
        const base = svgElement('polyline', {
            class: `${PREFIX}-trend-base`,
            points: values.map((value, index) => (
                svgPointString(value, index, values.length, bounds)
            )).join(' '),
        });
        const roll = svgElement('polyline', {
            class: `${PREFIX}-trend-roll`,
            points: rolling.map((value, index) => (
                svgPointString(value, index, rolling.length, bounds)
            )).join(' '),
        });
        svg.append(yLabel, xLabel, base, roll);
        latest.forEach((entry, index) => {
            const point = trendCoordinates(entry.value, index, latest.length, bounds);
            const description = trendPointDescription(entry, metric);
            const circle = svgElement('circle', {
                class: `${PREFIX}-trend-point`,
                cx: point.x,
                cy: point.y,
                r: 3.2,
                tabindex: 0,
                role: 'button',
                'aria-label': description.replace(/\n/g, '. '),
                'aria-pressed': 'false',
            });
            const link = entry.row.querySelector('a[href*="/stats/matches/mapstatsid/"]');
            if (link) circle.dataset.matchUrl = link.getAttribute('href') || '';
            pointDetails.set(circle, description);
            svg.append(circle);
        });
        attachTrendPointInteractions(box, svg, popup, pointDetails);
        box.append(title, svg, popup);
        tableSurface(model).before(box);
        model.trend = box;
        model.trendSignature = signature;
    }

    function syncTable(table) {
        let model = refreshModel(table);
        if (!model) return;
        reconcileMatchHistoryPagination(model);
        prepareMatchHistoryPagination(model);
        model = refreshModel(table);
        syncOptionalColumns(model);
        model = refreshModel(table);
        applyColumnLayout(model);
        model = refreshModel(table);
        syncAutoFit(model);
        syncToolbar(model);
        applySort(model);
        model = refreshModel(table);
        syncTrend(model);
        syncHeaderListener(model);
        syncMatchHistoryPagination(model);
    }

    function scheduleSync() {
        globalThis.clearTimeout(state.syncTimer);
        if (!anyFeatureEnabled()) {
            deactivate();
            return;
        }
        if (!state.active) {
            activate();
            return;
        }
        state.syncTimer = globalThis.setTimeout(syncAll, 80);
    }

    function syncAll() {
        if (!state.active || state.syncing) return;
        state.syncing = true;
        state.observer?.disconnect();
        let deactivateAfterSync = false;
        try {
            for (const [table, model] of state.models) {
                if (!table.isConnected) {
                    state.models.delete(table);
                    disposeModel(model);
                }
            }
            for (const selector of Object.values(TABLE_SELECTORS)) {
                for (const table of document.querySelectorAll(selector)) syncTable(table);
            }
            syncDocumentClickListener();
        } finally {
            state.syncing = false;
            deactivateAfterSync = state.active && !anyFeatureEnabled();
            if (!deactivateAfterSync && state.active && state.observer && document.body) {
                state.observer.observe(document.body, { childList: true, subtree: true });
            }
        }
        if (deactivateAfterSync) deactivate();
    }

    function watchSettings() {
        for (const key of SETTING_KEYS) {
            const id = globalThis.GM_addValueChangeListener?.(key, (_name, _oldValue, newValue) => {
                if (key === 'statsColumnLayoutV2') state.settings[key] = normaliseLayout(newValue);
                else if (key === 'statsOptionalColumnsV2') state.settings[key] = normaliseOptionalColumns(newValue);
                else if (key === 'statsMultiSortV2') state.settings[key] = normaliseSort(newValue);
                else if (key === 'playerMatchTrendMetric') state.settings[key] = normaliseMetric(newValue);
                else if (key === 'statsMatchHistoryRowsV2') {
                    state.settings[key] = normaliseMatchHistoryRows(newValue);
                }
                else if (BOOLEAN_SETTING_KEYS.includes(key)) state.settings[key] = newValue === true;
                else state.settings[key] = newValue;
                if (key === 'enableStatsColumnChooser') {
                    const warEnabled = state.settings.enableStatsColumnChooser
                        && selectedOptionalIds('ranking').has('war');
                    state.settings.enableWinAdjustedRatings = warEnabled;
                    globalThis.HLTV_SP_WIN_ADJUSTED_RATINGS?.setEnabled?.(warEnabled);
                }
                scheduleSync();
            });
            if (id !== undefined) state.listeners.push(id);
        }
    }

    function watchDom() {
        if (state.observer || !state.active || !document.body) return;
        const nodeContainsSupportedTable = (node) => (
            Boolean(node?.matches?.(SUPPORTED_TABLE_SELECTOR))
            || Boolean(node?.querySelector?.(SUPPORTED_TABLE_SELECTOR))
        );
        const nodeContainsModeledTable = (node) => {
            for (const table of state.models.keys()) {
                if (node === table || node?.contains?.(table)) return true;
            }
            return false;
        };
        const targetTouchesModeledTable = (target) => {
            if (target?.closest?.(SUPPORTED_TABLE_SELECTOR)) return true;
            for (const table of state.models.keys()) {
                if (target === table || table.contains?.(target)) return true;
            }
            return false;
        };
        state.observer = new MutationObserver((mutations) => {
            if (!state.active || state.syncing) return;
            if (mutations.some((mutation) => targetTouchesModeledTable(mutation.target)
                || [...mutation.addedNodes, ...mutation.removedNodes].some((node) => (
                    nodeContainsSupportedTable(node) || nodeContainsModeledTable(node)
                )))) {
                scheduleSync();
            }
        });
        state.observer.observe(document.body, { childList: true, subtree: true });
    }

    function syncDocumentClickListener() {
        const currentDocument = globalThis.document;
        if (!currentDocument) {
            state.documentClickListener = null;
            return;
        }
        const needed = state.active && state.settings.enableStatsColumnChooser;
        if (needed && !state.documentClickListener) {
            state.documentClickListener = (event) => {
                const target = event.target instanceof Element ? event.target : null;
                if (!target?.closest(`.${PREFIX}-chooser, .${PREFIX}-toolbar button`)) {
                    for (const model of state.models.values()) if (model.chooser) model.chooser.hidden = true;
                }
            };
            currentDocument.addEventListener('click', state.documentClickListener);
        } else if (!needed && state.documentClickListener) {
            currentDocument.removeEventListener('click', state.documentClickListener);
            state.documentClickListener = null;
        }
    }

    function deactivate() {
        globalThis.clearTimeout(state.syncTimer);
        state.syncTimer = 0;
        state.active = false;
        state.observer?.disconnect();
        state.observer = null;
        syncDocumentClickListener();
        for (const model of state.models.values()) disposeModel(model);
        state.models.clear();
        globalThis.document?.getElementById(`${PREFIX}-style`)?.remove();
    }

    function activate() {
        if (!anyFeatureEnabled()) return;
        if (state.active) {
            scheduleSync();
            return;
        }
        state.active = true;
        injectStyle();
        watchDom();
        syncAll();
    }

    async function init() {
        await loadSettings();
        watchSettings();
        const api = Object.freeze({
            getTableModel(type) {
                if (!state.active) return null;
                const table = document.querySelector(TABLE_SELECTORS[type]);
                return table ? refreshModel(table) : null;
            },
            sync: scheduleSync,
        });
        try {
            Object.defineProperty(globalThis, 'HLTV_SP_STATS_TABLES', {
                value: api,
                configurable: false,
                enumerable: false,
                writable: false,
            });
        } catch {
            // The module remains functional if the page blocks extension globals.
        }
        if (anyFeatureEnabled()) activate();
    }

    init().catch((error) => {
        console.warn('[HLTV Enhancements] Stats-table enhancements failed.', error);
    });
})();
