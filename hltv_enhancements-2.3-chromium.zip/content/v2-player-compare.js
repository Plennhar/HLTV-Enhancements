// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Plennhar

(() => {
    'use strict';

    const GLOBAL_NAME = 'HLTV_SP_PLAYER_COMPARE_V2';
    if (Object.hasOwn(globalThis, GLOBAL_NAME)) return;

    const extensionApi = globalThis.browser;
    const SETTING_DEFAULTS = Object.freeze({
        enablePlayerMapMatrix: true,
        enablePlayerComparisonEnhancements: true,
        enablePlayerConsistencyScore: true,
        enableStatsTablePeriodComparison: true,
        enablePlayerPagePeriodComparison: true,
        previousPeriodMetric: 'rating',
    });
    const BOOLEAN_SETTINGS = new Set([
        'enablePlayerMapMatrix',
        'enablePlayerComparisonEnhancements',
        'enablePlayerConsistencyScore',
        'enableStatsTablePeriodComparison',
        'enablePlayerPagePeriodComparison',
    ]);
    const STYLE_ID = 'hltv-v2-player-compare-style';
    const HISTORY_CACHE_TTL_MS = 15 * 60 * 1000;
    const PAGE_CACHE_TTL_MS = 5 * 60 * 1000;
    const MAX_HISTORY_CACHE_ENTRIES = 4;
    // A normal 10,000-row history is only a few MiB after parsing.  Keep generous headroom for
    // real HLTV data while preventing unusually large remote labels from accumulating without a
    // per-run or aggregate cache boundary.
    const MAX_HISTORY_RETAINED_WEIGHT_BYTES = 16 * 1024 * 1024;
    const MAX_HISTORY_CACHE_WEIGHT_BYTES = 32 * 1024 * 1024;
    const MAX_HISTORY_CUMULATIVE_RESPONSE_BYTES = 128 * 1024 * 1024;
    const HISTORY_ROW_FIXED_WEIGHT_BYTES = 192;
    const MAX_HISTORY_ID_CHARS = 256;
    const MAX_HISTORY_URL_CHARS = 2048;
    const MAX_HISTORY_DATE_CHARS = 64;
    const MAX_HISTORY_TEAM_CHARS = 160;
    const MAX_HISTORY_MAP_CHARS = 80;
    const MAX_PAGE_CACHE_ENTRIES = 16;
    // Bound the serialized size as well as the entry count. DOM nodes have additional runtime
    // overhead, so this conservative byte-weight prevents a run of large pages from leaving 16
    // large sanitized fragments resident at once.
    const MAX_PAGE_CACHE_WEIGHT_BYTES = 8 * 1024 * 1024;
    const FETCH_THROTTLE_MS = 500;
    const MAX_HISTORY_PAGES = 100;
    const MAX_HISTORY_ROWS = 10_000;
    const MAX_COMPARE_HOVER_POINTS_PER_SERIES = 600;
    const COMPARE_DAILY_HIT_RADIUS_PX = 9;
    const COMPARE_MAP_AVERAGE_WINDOW = 10;
    const COMPARE_SERIES_COLORS = Object.freeze({
        first: '#ffae00',
        second: '#037dcc',
    });
    const MILLISECONDS_PER_UTC_DAY = 24 * 60 * 60 * 1000;
    const DEFAULT_COMPARE_DAY_WINDOW = 30;
    const MIN_COMPARE_DAY_WINDOW = 1;
    const MAX_COMPARE_DAY_WINDOW = 365;
    // A real Counter-Strike career fits comfortably inside this bound.  It prevents hostile or
    // malformed timestamps from expanding a daily graph into an unbounded number of DOM points.
    const MAX_COMPARE_CALENDAR_DAYS = 20_000;
    const MAX_RESPONSE_CHARS = 5 * 1024 * 1024;
    const MAX_RESPONSE_BYTES = MAX_RESPONSE_CHARS * 4;
    const CONSISTENCY_INITIAL_DELAY_MS = 500;
    const CONSISTENCY_RETRY_DELAY_MS = 3000;
    const CONSISTENCY_SECOND_RETRY_DELAY_MS = 5000;
    const BASELINE_START_PARAM = 'hltvSpBaselineStartDate';
    const BASELINE_END_PARAM = 'hltvSpBaselineEndDate';
    const PLAYER_PATH_PATTERN = /^\/stats\/players\/(\d{1,20})\/([a-z0-9-]{1,100})\/?$/i;
    const PLAYER_INDIVIDUAL_PATH_PATTERN = /^\/stats\/players\/individual\/(\d{1,20})\/([a-z0-9-]{1,100})\/?$/i;
    const PLAYER_MATCHES_PATH_PATTERN = /^\/stats\/players\/matches\/(\d{1,20})\/([a-z0-9-]{1,100})\/?$/i;
    const COMPARE_PATH_PATTERN = /^\/stats\/players\/compare(?:\/|$)/i;
    const COMPARE_PAIR_PATH_PATTERN = /^\/stats\/players\/compare\/(\d{1,20})\/([a-z0-9-]{1,100})\/(\d{1,20})\/([a-z0-9-]{1,100})\/?$/i;
    const COMPARE_SINGLE_PATH_PATTERN = /^\/stats\/players\/compare\/(\d{1,20})\/([a-z0-9-]{1,100})\/?$/i;
    const RANKING_PATH_PATTERN = /^\/stats\/players\/?$/i;
    const NATIVE_STATS_DECORATION_CLASSES = new Set([
        'hltv-v2-stats-autofit',
        'hltv-v2-stats-sortable',
        'hltv-v2-stats-col-hidden',
    ]);
    const EXTENSION_MOVED_NATIVE_MUTATION_SELECTOR = [
        '[data-hltv-v2-column-id]',
        '[data-hltv-v2-original-index]',
        'table.hltv-v2-stats-autofit',
        'table.hltv-v2-stats-sortable',
    ].join(', ');
    const NATIVE_STATS_TABLE_SELECTOR = 'table.player-ratings-table, table.stats-matches-table';
    const MAP_STATS_PATH_PATTERN = /^\/stats\/matches\/mapstatsid\/(\d{1,20})\/[a-z0-9-]{1,160}\/?$/i;
    const ALLOWED_FILTERS = new Set([
        'startDate',
        'endDate',
        'matchType',
        'rankingFilter',
        'maps',
        'bestOfX',
        'valveRanked',
        'playoffMatchType',
        'event',
        'eventId',
        'eventIds',
        'teamId',
        'minMapCount',
        'csVersion',
    ]);
    const MAP_NAMES = Object.freeze({
        anc: 'Ancient',
        ancient: 'Ancient',
        anb: 'Anubis',
        anubis: 'Anubis',
        cch: 'Cache',
        cache: 'Cache',
        cbl: 'Cobblestone',
        cobblestone: 'Cobblestone',
        d2: 'Dust2',
        dust2: 'Dust2',
        inf: 'Inferno',
        inferno: 'Inferno',
        mrg: 'Mirage',
        mirage: 'Mirage',
        nuke: 'Nuke',
        ovp: 'Overpass',
        overpass: 'Overpass',
        ssn: 'Season',
        season: 'Season',
        trn: 'Train',
        train: 'Train',
        tcn: 'Tuscan',
        tuscan: 'Tuscan',
        vtg: 'Vertigo',
        vertigo: 'Vertigo',
    });
    const HIGHER_IS_BETTER = /(?:rating|kpr|kills?|assists?|apr|adr|damage|kast|surviv|impact|headshot|hs\s*%|opening kpr|flash)/i;
    const LOWER_IS_BETTER = /(?:deaths?|dpr|opening deaths?)/i;
    const COMPARE_TREND_METRICS = Object.freeze([
        Object.freeze({ key: 'rating', label: 'Rating', digits: 2 }),
        Object.freeze({ key: 'kpr', label: 'KPR', digits: 2 }),
        Object.freeze({ key: 'dpr', label: 'DPR', digits: 2 }),
        Object.freeze({ key: 'kd', label: 'K/D', digits: 2 }),
        Object.freeze({ key: 'plusMinus', label: 'K-D differential', digits: 0 }),
        Object.freeze({ key: 'kills', label: 'Kills', digits: 0 }),
        Object.freeze({ key: 'deaths', label: 'Deaths', digits: 0 }),
    ]);
    const STYLES = `
        .hltv-v2-player-tab {
            box-sizing: border-box;
            cursor: pointer;
            min-width: 0;
            overflow: hidden;
            text-align: center;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        [data-hltv-v2-player-tabs="true"] {
            column-gap: 2px;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(84px, 1fr));
            height: auto !important;
            min-width: 0;
            row-gap: 2px;
        }
        [data-hltv-v2-player-tabs="true"] > .stats-top-menu-item {
            align-items: center;
            box-sizing: border-box;
            display: flex;
            justify-content: center;
            min-height: 40px;
            min-width: 0;
            overflow: hidden;
            padding-left: 6px;
            padding-right: 6px;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        .hltv-v2-player-analytics,
        .hltv-v2-period-panel,
        .hltv-v2-compare-tools,
        .hltv-v2-compare-sync-tools {
            background: #2d3844;
            border: 1px solid #495867;
            box-sizing: border-box;
            color: #929a9e;
            margin: 8px 0;
            padding: 10px;
            width: 100%;
        }
        .hltv-v2-player-analytics { min-width: 0; overflow: hidden; }
        .hltv-v2-player-analytics button,
        .hltv-v2-period-panel button,
        .hltv-v2-compare-tools button,
        .hltv-v2-compare-sync-tools button,
        button.hltv-v2-button { cursor: pointer; }
        .hltv-v2-player-analytics[hidden] { display: none; }
        .hltv-v2-toolbar,
        .hltv-v2-compare-actions,
        .hltv-v2-period-values,
        .hltv-v2-baseline-controls {
            align-items: center;
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }
        .hltv-v2-toolbar { justify-content: space-between; }
        .hltv-v2-title { color: #c7d0d5; font-weight: 700; }
        .hltv-v2-status { color: #aeb5b9; margin: 7px 0; }
        .hltv-v2-status[data-kind="error"] { color: #ff8585; }
        .hltv-v2-status[data-kind="warning"] { color: #e8bb67; }
        .hltv-v2-button,
        .hltv-v2-link,
        .hltv-v2-select {
            background: #43566a;
            border: 1px solid #596f84;
            border-radius: 2px;
            box-sizing: border-box;
            color: #d7e2eb;
            cursor: pointer;
            font: inherit;
            min-height: 26px;
            padding: 3px 8px;
            text-decoration: none;
        }
        .hltv-v2-button:disabled { cursor: default; opacity: .55; }
        .hltv-v2-matrix-wrap { box-sizing: border-box; max-width: 100%; overflow-x: auto; width: 100%; }
        .hltv-v2-matrix { border-collapse: collapse; min-width: 600px; width: 100%; }
        .hltv-v2-matrix th,
        .hltv-v2-matrix td {
            border: 1px solid #495867;
            padding: 5px 7px;
            text-align: right;
            white-space: nowrap;
        }
        .hltv-v2-matrix th:first-child,
        .hltv-v2-matrix td:first-child { text-align: left; }
        .hltv-v2-matrix th[data-hltv-v2-sort-key] { cursor: pointer; }
        .hltv-v2-matrix th[data-hltv-v2-sort-key]:focus-visible {
            outline: 2px solid #5f89b3;
            outline-offset: -2px;
        }
        .hltv-v2-unavailable { color: #727b80; }
        .player-summary-stat-box[data-hltv-v2-consistency-card="true"] {
            height: auto !important;
            min-height: 278px;
            overflow: visible;
        }
        @media (max-width: 500px) {
            .player-summary-stat-box[data-hltv-v2-consistency-card="true"] {
                min-height: 220px;
            }
        }
        .player-summary-stat-box-right[data-hltv-v2-consistency-summary="true"] {
            height: auto !important;
            min-height: 0;
            overflow: visible;
        }
        .player-summary-stat-box-right-bottom[data-hltv-v2-consistency-layout="true"] {
            align-content: start;
            display: grid;
            grid-auto-rows: auto;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            height: auto !important;
            min-height: 0;
            overflow: visible;
        }
        .player-summary-stat-box-right-bottom[data-hltv-v2-consistency-layout="true"]
        > .player-summary-stat-box-data-wrapper {
            box-sizing: border-box;
            max-width: none;
            min-width: 0;
            width: auto;
        }
        .player-summary-stat-box-right-bottom[data-hltv-v2-consistency-layout="true"]
        > .hltv-v2-consistency-stat {
            grid-column: 2;
        }
        .hltv-v2-consistency-stat .player-summary-stat-box-data-text:focus-visible {
            outline: 2px solid #5f89b3;
            outline-offset: 2px;
        }
        .hltv-v2-compare-summary { font-weight: 700; margin-right: auto; }
        .hltv-v2-compare-tools {
            align-items: center;
            display: flex;
            flex-wrap: wrap;
            gap: 6px;
            margin: 0 0 6px;
            padding: 5px 7px;
        }
        .hltv-v2-compare-actions { gap: 6px; }
        .hltv-v2-compare-sync-tools {
            margin: 0 0 6px;
            padding: 5px 7px;
        }
        .hltv-v2-compare-delta {
            font-variant-numeric: tabular-nums;
            padding-left: 4px !important;
            padding-right: 4px !important;
            text-align: right;
            white-space: nowrap;
            width: 1%;
        }
        .hltv-v2-period-header,
        .hltv-v2-period-cell {
            text-align: center !important;
        }
        .hltv-v2-compare-higher { box-shadow: inset 3px 0 #5d9bd3; }
        .hltv-v2-compare-lower { opacity: .82; }
        .stats-player-compare .stats-bar-graph,
        .stats-player-compare .stats-bar-table { box-sizing: border-box; width: 100% !important; }
        .hltv-v2-compare-trends {
            background: #2d3844;
            border: 1px solid #495867;
            box-sizing: border-box;
            margin: 8px 0;
            padding: 8px;
            width: 100%;
        }
        .hltv-v2-compare-trend-controls {
            align-items: center;
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-bottom: 7px;
        }
        .hltv-v2-compare-trend-controls .hltv-v2-status { margin: 0; }
        .hltv-v2-compare-series-toggle,
        .hltv-v2-compare-average-toggle,
        .hltv-v2-compare-day-window-toggle,
        .hltv-v2-compare-day-window-length,
        .hltv-v2-compare-trend-line-toggle,
        .hltv-v2-compare-points-toggle {
            align-items: center;
            display: inline-flex;
            gap: 4px;
            white-space: nowrap;
        }
        .hltv-v2-compare-day-window-length input { width: 64px; }
        .hltv-v2-compare-chart { position: relative; }
        .hltv-v2-compare-chart svg {
            background: #25313c;
            border: 1px solid #495867;
            display: block;
            height: auto;
            width: 100%;
        }
        .hltv-v2-compare-axis,
        .hltv-v2-compare-grid { stroke: #596571; vector-effect: non-scaling-stroke; }
        .hltv-v2-compare-grid { opacity: .45; stroke-dasharray: 3 4; }
        .hltv-v2-compare-axis-label,
        .hltv-v2-compare-tick-label { fill: #aeb5b9; font-size: 11px; }
        .hltv-v2-compare-series-left { fill: none; stroke: ${COMPARE_SERIES_COLORS.first}; stroke-width: 2; }
        .hltv-v2-compare-series-right { fill: none; stroke: ${COMPARE_SERIES_COLORS.second}; stroke-width: 2; }
        .hltv-v2-compare-trend-line {
            fill: none;
            opacity: .9;
            pointer-events: none;
            stroke-dasharray: 7 5;
            stroke-width: 1.5;
            vector-effect: non-scaling-stroke;
        }
        .hltv-v2-compare-trend-line-left { stroke: ${COMPARE_SERIES_COLORS.first}; }
        .hltv-v2-compare-trend-line-right { stroke: ${COMPARE_SERIES_COLORS.second}; }
        .hltv-v2-compare-point-left { fill: ${COMPARE_SERIES_COLORS.first}; }
        .hltv-v2-compare-point-right { fill: ${COMPARE_SERIES_COLORS.second}; }
        .hltv-v2-compare-daily-hover-point { pointer-events: none; }
        .hltv-v2-compare-point-left,
        .hltv-v2-compare-point-right { cursor: pointer; }
        .hltv-v2-compare-point-left:focus,
        .hltv-v2-compare-point-right:focus,
        .hltv-v2-compare-point-pinned {
            outline: none;
            stroke: #f4f7f9;
            stroke-width: 2;
        }
        .hltv-v2-compare-point-popup {
            background: #151d24;
            border: 1px solid #6c7c8a;
            box-shadow: 0 2px 8px rgba(0, 0, 0, .45);
            color: #d7e2eb;
            left: 0;
            max-width: min(360px, calc(100% - 16px));
            padding: 5px 7px;
            pointer-events: none;
            position: absolute;
            top: 0;
            transform: translate(-50%, calc(-100% - 7px));
            white-space: pre-line;
            z-index: 2;
        }
        .hltv-v2-compare-point-popup[hidden] { display: none; }
        .hltv-v2-compare-legend { display: flex; flex-wrap: wrap; gap: 12px; margin-top: 5px; }
        .hltv-v2-compare-legend span::before {
            background: var(--hltv-v2-legend-color);
            content: '';
            display: inline-block;
            height: 3px;
            margin-right: 5px;
            vertical-align: middle;
            width: 16px;
        }
        .hltv-v2-period-panel select { max-width: 260px; }
        .hltv-v2-baseline-controls label {
            align-items: center;
            display: inline-flex;
            gap: 4px;
        }
        .hltv-v2-baseline-controls input[type="date"] {
            background: #25313c;
            border: 1px solid #596f84;
            color: #d7e2eb;
            font: inherit;
            min-height: 26px;
            padding: 2px 5px;
        }
        .hltv-v2-period-value { background: #25313c; padding: 5px 8px; }
        .hltv-v2-period-positive { color: #64c987; }
        .hltv-v2-period-negative { color: #e78181; }
    `;

    const state = {
        settings: { ...SETTING_DEFAULTS },
        ready: false,
        destroyed: false,
        syncTimer: 0,
        mutationObserver: null,
        historyController: null,
        consistencyController: null,
        previousController: null,
        compareController: null,
        storageListener: null,
        routeListener: null,
        previousPeriodModel: null,
    };
    const historyCache = new Map();
    const pageCache = new Map();
    let historyCacheWeightBytes = 0;
    let pageCacheWeightBytes = 0;
    let lastFetchStartedAt = 0;
    let inertSanitizer = null;

    function cleanText(value) {
        return String(value ?? '').replace(/\s+/g, ' ').trim();
    }

    function parameterEntries(searchParams) {
        const entries = [];
        searchParams.forEach((value, key) => entries.push([key, value]));
        return entries;
    }

    function clampHistoryText(value, maximumChars) {
        return cleanText(value).slice(0, maximumChars);
    }

    function directText(element) {
        if (!element) return '';
        return cleanText([...element.childNodes]
            .filter((node) => node.nodeType === Node.TEXT_NODE)
            .map((node) => node.textContent)
            .join(' '));
    }

    function createElement(tagName, className = '', text = '') {
        const element = document.createElement(tagName);
        if (className) element.className = className;
        if (text) element.textContent = text;
        return element;
    }

    function normaliseMetricKey(value) {
        return cleanText(value)
            .toLowerCase()
            .replace(/\brating\s*[123](?:\.0)?\b/g, 'rating')
            .replace(/[^a-z0-9%]+/g, '-')
            .replace(/^-+|-+$/g, '')
            .slice(0, 80);
    }

    function canonicalMetricKey(label) {
        const key = normaliseMetricKey(label);
        if (key === 'rating' || key.startsWith('rating-')) return 'rating';
        if (/^(?:kpr|kills?-per-round|kills?-round)$/.test(key)) return 'kpr';
        if (/^(?:dpr|deaths?-per-round|deaths?-round)$/.test(key)) return 'dpr';
        if (/^(?:adr|damage-per-round|damage-round)$/.test(key)) return 'adr';
        if (/^kast(?:-|$)/.test(key)) return 'kast';
        if (/^(?:net-kpr|net-kills?-per-round)$/.test(key)) return 'net-kpr';
        if (/^(?:kd-diff|k-d-diff|kill-death-diff(?:erence)?)$/.test(key)) return 'kd-diff';
        if (/^(?:kd|k-d|kill-death-ratio)$/.test(key)) return 'kd';
        if (/^(?:kills?-per-map|kills?-map)$/.test(key)) return 'kills-per-map';
        return key;
    }

    function parseNumericText(value) {
        const text = cleanText(value).replace(/\*/g, '');
        const match = text.match(/[+-]?(?:\d+(?:\.\d+)?|\.\d+)/);
        if (!match) return null;
        const number = Number(match[0]);
        return Number.isFinite(number) ? number : null;
    }

    function decimalPlaces(value) {
        const text = cleanText(value).replace(/[%*]/g, '');
        const dot = text.indexOf('.');
        return dot < 0 ? 0 : Math.min(4, text.length - dot - 1);
    }

    function directionForMetric(label) {
        if (LOWER_IS_BETTER.test(label)) return -1;
        if (HIGHER_IS_BETTER.test(label)) return 1;
        return 0;
    }

    function normaliseSettings(stored) {
        const next = { ...SETTING_DEFAULTS };
        const source = stored && typeof stored === 'object' ? stored : {};
        const hasLegacyPeriodSetting = Object.hasOwn(source, 'enablePreviousPeriodComparison');
        const legacyPeriodValue = source.enablePreviousPeriodComparison === true;
        for (const key of BOOLEAN_SETTINGS) {
            const isSplitPeriodSetting = key === 'enableStatsTablePeriodComparison'
                || key === 'enablePlayerPagePeriodComparison';
            if (Object.hasOwn(source, key)) {
                next[key] = source[key] === true;
            } else if (isSplitPeriodSetting && hasLegacyPeriodSetting) {
                next[key] = legacyPeriodValue;
            } else {
                next[key] = SETTING_DEFAULTS[key];
            }
        }
        const metric = canonicalMetricKey(source.previousPeriodMetric);
        next.previousPeriodMetric = metric || SETTING_DEFAULTS.previousPeriodMetric;
        return next;
    }

    function anyFeatureEnabled() {
        return [...BOOLEAN_SETTINGS].some((key) => state.settings[key]);
    }

    function playerStatsRouteIdentity(pathname = globalThis.location.pathname) {
        const segments = String(pathname || '').split('/').filter(Boolean);
        if (segments[0] !== 'stats' || segments[1] !== 'players'
            || segments[2]?.toLowerCase() === 'compare' || segments.length < 4
            || segments.length > 8
            || segments.some((segment) => !/^[a-z0-9-]{1,100}$/i.test(segment))) {
            return null;
        }
        const playerIndex = segments.findIndex(
            (segment, index) => index >= 2 && /^\d{1,20}$/.test(segment),
        );
        const slug = segments.at(-1) || '';
        if (playerIndex < 2 || playerIndex >= segments.length - 1
            || !/^[a-z0-9-]{1,100}$/i.test(slug)) return null;
        return Object.freeze([segments.join('/'), segments[playerIndex], slug]);
    }

    function routeSupportsFeatures(pathname = globalThis.location.pathname) {
        return Boolean(playerStatsRouteIdentity(pathname))
            || COMPARE_PATH_PATTERN.test(pathname)
            || RANKING_PATH_PATTERN.test(pathname);
    }

    function ensureStyles() {
        if (!anyFeatureEnabled()) {
            document.getElementById(STYLE_ID)?.remove();
            return;
        }
        if (document.getElementById(STYLE_ID)) return;
        const style = createElement('style');
        style.id = STYLE_ID;
        style.textContent = STYLES;
        (document.head || document.documentElement).appendChild(style);
    }

    function delay(milliseconds, signal = null) {
        return new Promise((resolve, reject) => {
            let settled = false;
            let timer = 0;
            const cleanup = () => {
                if (timer) globalThis.clearTimeout(timer);
                signal?.removeEventListener?.('abort', onAbort);
            };
            const finish = (callback, value) => {
                if (settled) return;
                settled = true;
                cleanup();
                callback(value);
            };
            const onAbort = () => {
                finish(
                    reject,
                    new DOMException('The operation was aborted.', 'AbortError'),
                );
            };
            if (signal?.aborted) {
                onAbort();
                return;
            }
            signal?.addEventListener?.('abort', onAbort, { once: true });
            timer = globalThis.setTimeout(() => finish(resolve), Math.max(0, milliseconds));
        });
    }

    function responseHeaderValue(response, name) {
        try {
            if (typeof response?.headers?.get !== 'function') return null;
            const value = response.headers.get(name);
            return value === null || value === undefined ? null : String(value).trim();
        } catch {
            return null;
        }
    }

    function utf8ByteLength(value, stopAfter = Number.POSITIVE_INFINITY) {
        const text = String(value);
        let bytes = 0;
        for (let index = 0; index < text.length; index += 1) {
            const code = text.charCodeAt(index);
            if (code <= 0x7f) bytes += 1;
            else if (code <= 0x7ff) bytes += 2;
            else if (code >= 0xd800 && code <= 0xdbff
                && text.charCodeAt(index + 1) >= 0xdc00
                && text.charCodeAt(index + 1) <= 0xdfff) {
                bytes += 4;
                index += 1;
            } else bytes += 3;
            if (bytes > stopAfter) return bytes;
        }
        return bytes;
    }

    async function cancelResponseBody(body, reason) {
        try {
            await body?.cancel?.(reason);
        } catch {
            // The response may already have errored or released its stream lock.
        }
    }

    function responseSizeError(message, code, processedBytes = 0) {
        const error = new Error(message);
        error.code = code;
        error.processedBytes = Number.isFinite(processedBytes) && processedBytes > 0
            ? Math.floor(processedBytes)
            : 0;
        return error;
    }

    function annotateProcessedBytes(error, processedBytes) {
        if (!error || (typeof error !== 'object' && typeof error !== 'function')) return error;
        const safeBytes = Number.isFinite(processedBytes) && processedBytes > 0
            ? Math.floor(processedBytes)
            : 0;
        const currentBytes = Number.isFinite(error.processedBytes) && error.processedBytes > 0
            ? Math.floor(error.processedBytes)
            : 0;
        try {
            error.processedBytes = Math.max(currentBytes, safeBytes);
        } catch {
            // Some host errors are non-extensible.  Preserve the original error in that case.
        }
        return error;
    }

    async function readBoundedHtmlResponse(
        response,
        maximumBytes = MAX_RESPONSE_BYTES,
        sizeLimitCode = 'response-too-large',
    ) {
        const byteLimit = Math.max(
            0,
            Math.min(MAX_RESPONSE_BYTES, Number(maximumBytes) || 0),
        );
        const contentLength = responseHeaderValue(response, 'content-length');
        if (contentLength !== null) {
            if (!/^(?:0|[1-9]\d*)$/.test(contentLength)
                || !Number.isSafeInteger(Number(contentLength))) {
                const error = new Error('HLTV returned an invalid Content-Length header.');
                await cancelResponseBody(response?.body, error);
                throw error;
            }
            if (Number(contentLength) > byteLimit) {
                const error = responseSizeError(
                    'HLTV response was too large.',
                    sizeLimitCode,
                );
                await cancelResponseBody(response?.body, error);
                throw error;
            }
        }

        const rawContentType = responseHeaderValue(response, 'content-type');
        // HLTV advertises text/html. Header-less legacy Response mocks are tolerated, but an
        // advertised MIME type must be HTML before any response bytes are processed.
        if (rawContentType !== null) {
            const mimeType = rawContentType.split(';', 1)[0].trim().toLowerCase();
            if (mimeType !== 'text/html' && mimeType !== 'application/xhtml+xml') {
                const error = new Error('HLTV returned an unexpected response type.');
                await cancelResponseBody(response?.body, error);
                throw error;
            }
        }

        const body = response?.body;
        if (!body || typeof body.getReader !== 'function') {
            // Older Response-compatible test doubles only expose text(); bound that fallback
            // immediately after its unavoidable full-buffer read.
            if (typeof response?.text !== 'function') {
                throw new Error('HLTV response body was unavailable.');
            }
            const text = String(await response.text());
            const byteLength = utf8ByteLength(text);
            if (text.length > MAX_RESPONSE_CHARS
                || byteLength > byteLimit) {
                throw responseSizeError(
                    'HLTV response was too large.',
                    byteLength > byteLimit ? sizeLimitCode : 'response-too-large',
                    byteLength,
                );
            }
            return { text, byteLength };
        }
        if (typeof globalThis.TextDecoder !== 'function') {
            throw new Error('HLTV response could not be decoded safely.');
        }

        const reader = body.getReader();
        const decoder = new globalThis.TextDecoder('utf-8');
        const chunks = [];
        let totalBytes = 0;
        let totalChars = 0;
        let completed = false;
        try {
            while (true) {
                const result = await reader.read();
                if (result?.done) {
                    completed = true;
                    break;
                }
                const rawChunk = result?.value;
                const chunk = rawChunk instanceof ArrayBuffer
                    ? new Uint8Array(rawChunk)
                    : ArrayBuffer.isView(rawChunk)
                        ? new Uint8Array(rawChunk.buffer, rawChunk.byteOffset, rawChunk.byteLength)
                        : null;
                if (!chunk) throw new Error('HLTV returned an invalid response stream.');
                totalBytes += chunk.byteLength;
                if (totalBytes > byteLimit) {
                    throw responseSizeError(
                        'HLTV response was too large.',
                        sizeLimitCode,
                        totalBytes,
                    );
                }
                const decoded = decoder.decode(chunk, { stream: true });
                totalChars += decoded.length;
                if (totalChars > MAX_RESPONSE_CHARS) {
                    throw new Error('HLTV response was too large.');
                }
                chunks.push(decoded);
            }
            const tail = decoder.decode();
            totalChars += tail.length;
            if (totalChars > MAX_RESPONSE_CHARS) {
                completed = false;
                throw new Error('HLTV response was too large.');
            }
            chunks.push(tail);
            return { text: chunks.join(''), byteLength: totalBytes };
        } catch (error) {
            annotateProcessedBytes(error, totalBytes);
            if (!completed) await cancelResponseBody(reader, error);
            throw error;
        } finally {
            try {
                reader.releaseLock?.();
            } catch {
                // Ignore non-standard Response reader cleanup failures.
            }
        }
    }

    function validateSameOriginUrl(value, allowedPathPatterns) {
        let url;
        try {
            url = new URL(String(value), globalThis.location.href);
        } catch {
            throw new Error('Invalid HLTV URL.');
        }
        if (url.origin !== globalThis.location.origin
            || !allowedPathPatterns.some((pattern) => pattern.test(url.pathname))) {
            throw new Error('Refused a URL outside the allowed HLTV statistics paths.');
        }
        url.hash = '';
        return url;
    }

    function getInertSanitizer() {
        if (inertSanitizer) return inertSanitizer;
        if (typeof globalThis.Sanitizer !== 'function') {
            throw new Error('Secure HTML parsing requires a supported browser with the Sanitizer API.');
        }
        inertSanitizer = new globalThis.Sanitizer({
            removeElements: [
                'applet', 'audio', 'base', 'embed', 'frame', 'frameset', 'iframe',
                'img', 'link', 'meta', 'noscript', 'object', 'picture', 'portal',
                'script', 'source', 'style', 'track', 'video',
                { name: 'svg', namespace: 'http://www.w3.org/2000/svg' },
                { name: 'math', namespace: 'http://www.w3.org/1998/Math/MathML' },
            ],
            removeAttributes: [
                'background', 'data', 'imagesizes', 'imagesrcset', 'manifest',
                'ping', 'poster', 'src', 'srcset', 'style',
            ],
            comments: false,
        });
        return inertSanitizer;
    }

    function parseInertHtml(value) {
        const template = document.createElement('template');
        if (typeof template.setHTML !== 'function') {
            throw new Error('Secure HTML parsing is unavailable.');
        }
        template.setHTML(String(value ?? ''), { sanitizer: getInertSanitizer() });
        return template.content;
    }

    async function throttledFetch(url, signal, maximumBytes = MAX_RESPONSE_BYTES) {
        const wait = Math.max(0, FETCH_THROTTLE_MS - (Date.now() - lastFetchStartedAt));
        await delay(wait, signal);
        lastFetchStartedAt = Date.now();
        const response = await globalThis.fetch(url.href, {
            credentials: 'include',
            redirect: 'error',
            signal,
            headers: { Accept: 'text/html' },
        });
        if (!response.ok) throw new Error(`HLTV returned HTTP ${response.status}.`);
        const finalUrl = validateSameOriginUrl(response.url || url.href, [
            PLAYER_MATCHES_PATH_PATTERN,
            PLAYER_PATH_PATTERN,
            PLAYER_INDIVIDUAL_PATH_PATTERN,
            RANKING_PATH_PATTERN,
        ]);
        const sizeLimitCode = maximumBytes < MAX_RESPONSE_BYTES
            ? 'history-cumulative-response-limit'
            : 'response-too-large';
        const { text, byteLength } = await readBoundedHtmlResponse(
            response,
            maximumBytes,
            sizeLimitCode,
        );
        try {
            return {
                fragment: parseInertHtml(text),
                finalUrl,
                responseBytes: byteLength,
            };
        } catch (error) {
            annotateProcessedBytes(error, byteLength);
            throw error;
        }
    }

    function headerIndex(headers, classPattern, textPattern) {
        return headers.findIndex((header) => (
            classPattern.test(header.className) || textPattern.test(cleanText(header.textContent))
        ));
    }

    function normaliseMapName(value) {
        const original = cleanText(value);
        const key = original.toLowerCase().replace(/^de_/, '').replace(/[^a-z0-9]/g, '');
        return MAP_NAMES[key] || original || 'Unknown map';
    }

    function scoreFromCell(cell) {
        if (!cell) return null;
        const preferred = cell.querySelector('.gtSmartphone-only') || cell;
        const matches = cleanText(preferred.textContent).match(/\((-?\d{1,3})\)/g);
        if (!matches?.length) return null;
        const value = Number(matches[0].replace(/[^\d-]/g, ''));
        return Number.isFinite(value) && value >= 0 ? value : null;
    }

    function teamNameFromMatchCell(cell) {
        if (!cell) return '';
        const preferred = cell.querySelector('.gtSmartphone-only') || cell;
        const linkedName = cleanText(
            preferred.querySelector('a[href*="/stats/teams/"]')?.textContent,
        );
        if (linkedName) return linkedName;
        return cleanText(preferred.textContent).replace(/\s*\(-?\d{1,3}\)\s*$/, '');
    }

    function matchIdentityFromLink(link) {
        if (!link) return Object.freeze({ id: '', href: '' });
        try {
            const url = validateSameOriginUrl(link.getAttribute('href'), [MAP_STATS_PATH_PATTERN]);
            const id = url.pathname.match(MAP_STATS_PATH_PATTERN)?.[1] || '';
            const href = id ? url.href : '';
            return Object.freeze({ id, href });
        } catch {
            return Object.freeze({ id: '', href: '' });
        }
    }

    function parseMatchRows(root) {
        const table = root?.querySelector?.('.stats-matches-table');
        if (!table) return [];
        // HLTV renders separate smartphone-only T1/T2 headers, but their mobile and desktop
        // values share the same two body cells.  Exclude those duplicate headers before mapping
        // logical column indices to direct body cells.
        const headers = [...table.querySelectorAll('thead tr:first-child > th')]
            .filter((header) => !header.classList.contains('smartphone-only'));
        const indices = {
            team1: headerIndex(headers, /statsPlayerMatchesTeam1/, /player team|^t1$/i),
            team2: headerIndex(headers, /statsPlayerMatchesTeam2/, /opponent|^t2$/i),
            map: headerIndex(headers, /statsPlayerMatchesMap/, /^map$/i),
            kd: headerIndex(headers, /statsPlayerMatchesK-D/, /k\s*-\s*d/i),
            kpr: headerIndex(headers, /tmKpr/, /^kpr$/i),
            plusMinus: headerIndex(headers, /statsPlayerMatchesPlus-Minus/, /^\+\/-$/i),
            rating: headerIndex(headers, /statsPlayerMatchesRating/, /^rating/i),
        };
        const parsed = [];
        for (const row of table.querySelectorAll('tbody tr')) {
            const cells = [...row.children].filter((cell) => cell.tagName === 'TD');
            const identityLink = row.querySelector('a[href*="/stats/matches/mapstatsid/"]');
            const identity = matchIdentityFromLink(identityLink);
            const timestamp = Number(row.querySelector('.time[data-unix]')?.dataset.unix);
            const dateText = clampHistoryText(
                row.querySelector('.time')?.textContent,
                MAX_HISTORY_DATE_CHARS,
            );
            const kdText = indices.kd >= 0
                ? clampHistoryText(cells[indices.kd]?.textContent, 64)
                : '';
            const kdMatch = kdText.match(/(\d+)\s*-\s*(\d+)/);
            const kills = kdMatch ? Number(kdMatch[1]) : null;
            const deaths = kdMatch ? Number(kdMatch[2]) : null;
            const teamScore = indices.team1 >= 0 ? scoreFromCell(cells[indices.team1]) : null;
            const opponentScore = indices.team2 >= 0 ? scoreFromCell(cells[indices.team2]) : null;
            const rounds = Number.isFinite(teamScore) && Number.isFinite(opponentScore)
                ? teamScore + opponentScore
                : null;
            const explicitKpr = indices.kpr >= 0
                ? parseNumericText(cells[indices.kpr]?.dataset.kprMin
                    || cells[indices.kpr]?.textContent)
                : null;
            const rating = indices.rating >= 0
                ? parseNumericText(cells[indices.rating]?.textContent)
                : null;
            const plusMinus = indices.plusMinus >= 0
                ? parseNumericText(cells[indices.plusMinus]?.textContent)
                : Number.isFinite(kills) && Number.isFinite(deaths) ? kills - deaths : null;
            const map = indices.map >= 0
                ? clampHistoryText(
                    normaliseMapName(cells[indices.map]?.textContent),
                    MAX_HISTORY_MAP_CHARS,
                )
                : 'Unknown map';
            const team = indices.team1 >= 0
                ? clampHistoryText(
                    teamNameFromMatchCell(cells[indices.team1]),
                    MAX_HISTORY_TEAM_CHARS,
                )
                : '';
            const opponent = indices.team2 >= 0
                ? clampHistoryText(
                    teamNameFromMatchCell(cells[indices.team2]),
                    MAX_HISTORY_TEAM_CHARS,
                )
                : '';
            const id = clampHistoryText(
                identity.id
                    || `${Number.isFinite(timestamp) ? timestamp : 'unknown'}:${map}:${kdText}`,
                MAX_HISTORY_ID_CHARS,
            );
            parsed.push(Object.freeze({
                id,
                matchUrl: clampHistoryText(identity.href, MAX_HISTORY_URL_CHARS),
                timestamp: Number.isFinite(timestamp) ? timestamp : 0,
                dateText,
                team,
                opponent,
                map,
                kills: Number.isFinite(kills) ? kills : null,
                deaths: Number.isFinite(deaths) ? deaths : null,
                rounds: Number.isFinite(rounds) && rounds > 0 ? rounds : null,
                rating,
                kpr: Number.isFinite(explicitKpr)
                    ? explicitKpr
                    : Number.isFinite(kills) && Number.isFinite(rounds) && rounds > 0
                        ? kills / rounds
                        : null,
                dpr: Number.isFinite(deaths) && Number.isFinite(rounds) && rounds > 0
                    ? deaths / rounds
                    : null,
                kd: Number.isFinite(kills) && Number.isFinite(deaths) && deaths > 0
                    ? kills / deaths
                    : null,
                plusMinus,
                adr: null,
                kast: null,
            }));
        }
        return parsed;
    }

    function historyRowWeightBytes(row) {
        let weight = HISTORY_ROW_FIXED_WEIGHT_BYTES;
        for (const key of ['id', 'matchUrl', 'dateText', 'team', 'opponent', 'map']) {
            weight += utf8ByteLength(row?.[key] || '');
        }
        return weight;
    }

    function matchesPageKey(url) {
        const copy = new URL(url.href);
        copy.hash = '';
        copy.searchParams.sort();
        return copy.href;
    }

    function deleteHistoryCacheEntry(key) {
        const entry = historyCache.get(key);
        if (!entry) return false;
        historyCache.delete(key);
        historyCacheWeightBytes = Math.max(
            0,
            historyCacheWeightBytes - (entry.weightBytes || 0),
        );
        return true;
    }

    function pruneExpiredHistoryCache(now = Date.now()) {
        for (const [key, entry] of historyCache) {
            if (!entry || entry.expiresAt <= now) deleteHistoryCacheEntry(key);
        }
    }

    function getFreshHistoryCacheEntry(key, now = Date.now()) {
        pruneExpiredHistoryCache(now);
        const entry = historyCache.get(key);
        if (!entry) return null;
        historyCache.delete(key);
        historyCache.set(key, entry);
        return entry;
    }

    function setHistoryCacheEntry(key, value, expiresAt, weightBytes) {
        pruneExpiredHistoryCache();
        deleteHistoryCacheEntry(key);
        const safeWeight = Number.isFinite(weightBytes) && weightBytes >= 0
            ? Math.floor(weightBytes)
            : MAX_HISTORY_CACHE_WEIGHT_BYTES + 1;
        if (safeWeight > MAX_HISTORY_CACHE_WEIGHT_BYTES) return false;
        historyCache.set(key, { expiresAt, value, weightBytes: safeWeight });
        historyCacheWeightBytes += safeWeight;
        while (historyCache.size > MAX_HISTORY_CACHE_ENTRIES
            || historyCacheWeightBytes > MAX_HISTORY_CACHE_WEIGHT_BYTES) {
            deleteHistoryCacheEntry(historyCache.keys().next().value);
        }
        return historyCache.has(key);
    }

    function fragmentSerializedByteWeight(fragment) {
        let bytes = 0;
        for (const node of fragment?.childNodes || []) {
            const serialized = node.nodeType === Node.ELEMENT_NODE
                ? node.outerHTML
                : node.textContent;
            bytes += utf8ByteLength(serialized || '', MAX_PAGE_CACHE_WEIGHT_BYTES - bytes);
            if (bytes > MAX_PAGE_CACHE_WEIGHT_BYTES) break;
        }
        return bytes;
    }

    function deletePageCacheEntry(key) {
        const entry = pageCache.get(key);
        if (!entry) return false;
        pageCache.delete(key);
        pageCacheWeightBytes = Math.max(0, pageCacheWeightBytes - (entry.weightBytes || 0));
        return true;
    }

    function pruneExpiredPageCache(now = Date.now()) {
        for (const [key, entry] of pageCache) {
            if (!entry || entry.expiresAt <= now) deletePageCacheEntry(key);
        }
    }

    function getFreshPageCacheEntry(key, now = Date.now()) {
        pruneExpiredPageCache(now);
        const entry = pageCache.get(key);
        if (!entry) return null;
        pageCache.delete(key);
        pageCache.set(key, entry);
        return entry;
    }

    function setPageCacheEntry(key, fragment, expiresAt) {
        pruneExpiredPageCache();
        deletePageCacheEntry(key);
        const cachedFragment = fragment.cloneNode(true);
        const weightBytes = fragmentSerializedByteWeight(cachedFragment);
        if (weightBytes > MAX_PAGE_CACHE_WEIGHT_BYTES) return false;
        pageCache.set(key, { expiresAt, fragment: cachedFragment, weightBytes });
        pageCacheWeightBytes += weightBytes;
        while (pageCache.size > MAX_PAGE_CACHE_ENTRIES
            || pageCacheWeightBytes > MAX_PAGE_CACHE_WEIGHT_BYTES) {
            deletePageCacheEntry(pageCache.keys().next().value);
        }
        return pageCache.has(key);
    }

    function nextHistoryPage(root, currentUrl, rowCount) {
        const currentOffset = Math.max(0, Number(currentUrl.searchParams.get('offset')) || 0);
        const currentPage = Math.max(1, Number(currentUrl.searchParams.get('page')) || 1);
        const candidates = [];
        for (const anchor of root.querySelectorAll('a[href]')) {
            let candidate;
            try {
                candidate = validateSameOriginUrl(
                    new URL(anchor.getAttribute('href'), currentUrl.href).href,
                    [PLAYER_MATCHES_PATH_PATTERN],
                );
            } catch {
                continue;
            }
            if (candidate.pathname !== currentUrl.pathname) continue;
            const offset = Number(candidate.searchParams.get('offset'));
            const page = Number(candidate.searchParams.get('page'));
            const label = cleanText(anchor.textContent);
            const nextLike = anchor.getAttribute('rel') === 'next'
                || /(?:next|›|»|→)/i.test(label)
                || /(?:next|pagination-next)/i.test(anchor.className);
            if (Number.isFinite(offset) && offset > currentOffset) {
                candidates.push({ candidate, position: offset, nextLike });
            } else if (Number.isFinite(page) && page > currentPage) {
                candidates.push({ candidate, position: page, nextLike });
            } else if (nextLike && matchesPageKey(candidate) !== matchesPageKey(currentUrl)) {
                candidates.push({ candidate, position: Number.MAX_SAFE_INTEGER, nextLike });
            }
        }
        candidates.sort((first, second) => (
            Number(second.nextLike) - Number(first.nextLike) || first.position - second.position
        ));
        if (candidates.length) return candidates[0].candidate;

        const pagingText = [...root.querySelectorAll(
            '.pagination, .pagination-component, .stats-paging, .pagination-data, .pagination-info',
        )].map((element) => cleanText(element.textContent)).join(' ');
        const range = pagingText.match(/(\d+)\s*-\s*(\d+)\s+(?:of|\/)\s*(\d+)/i);
        if (range && Number(range[2]) < Number(range[3]) && rowCount > 0) {
            const next = new URL(currentUrl.href);
            next.searchParams.set('offset', String(Number(range[2])));
            return next;
        }
        return null;
    }

    async function fetchAllMatchHistory(startUrl, options = {}) {
        const initialUrl = validateSameOriginUrl(startUrl, [PLAYER_MATCHES_PATH_PATTERN]);
        const cacheKey = matchesPageKey(initialUrl);
        const cached = getFreshHistoryCacheEntry(cacheKey);
        if (cached) return cached.value;

        const signal = options.signal || null;
        const rows = [];
        const rowIds = new Set();
        const visitedUrls = new Set();
        const pageSignatures = new Set();
        let pageUrl = initialUrl;
        let pages = 0;
        let retainedWeightBytes = 0;
        let retainedWeightLimitReached = false;
        let responseBytesProcessed = 0;
        let cumulativeResponseLimitReached = false;
        let warning = '';
        while (pageUrl
            && pages < MAX_HISTORY_PAGES
            && rows.length < MAX_HISTORY_ROWS
            && !retainedWeightLimitReached
            && !cumulativeResponseLimitReached) {
            const urlKey = matchesPageKey(pageUrl);
            if (visitedUrls.has(urlKey)) {
                warning = 'Pagination loop detected; stopped safely.';
                break;
            }
            visitedUrls.add(urlKey);
            options.onProgress?.({ pages, rows: rows.length, url: pageUrl.href });
            let response;
            let remainingResponseBytes = Math.max(
                0,
                MAX_HISTORY_CUMULATIVE_RESPONSE_BYTES - responseBytesProcessed,
            );
            if (!remainingResponseBytes) {
                cumulativeResponseLimitReached = true;
                break;
            }
            const retryDelays = [0, CONSISTENCY_RETRY_DELAY_MS, CONSISTENCY_SECOND_RETRY_DELAY_MS];
            let lastError = null;
            for (let attemptIndex = 0; attemptIndex < retryDelays.length; attemptIndex += 1) {
                const retryDelayMs = retryDelays[attemptIndex];
                if (attemptIndex > 0) {
                    options.onRetry?.({
                        attempt: attemptIndex + 1,
                        delayMs: retryDelayMs,
                        pages,
                        rows: rows.length,
                        url: pageUrl.href,
                        error: lastError,
                    });
                    await delay(retryDelayMs, signal);
                }
                remainingResponseBytes = Math.max(
                    0,
                    MAX_HISTORY_CUMULATIVE_RESPONSE_BYTES - responseBytesProcessed,
                );
                if (!remainingResponseBytes) {
                    cumulativeResponseLimitReached = true;
                    break;
                }
                try {
                    response = await throttledFetch(pageUrl, signal, remainingResponseBytes);
                    lastError = null;
                    break;
                } catch (error) {
                    if (error?.name === 'AbortError') throw error;
                    responseBytesProcessed += Number.isFinite(error?.processedBytes)
                        ? Math.max(0, error.processedBytes)
                        : 0;
                    if (error?.code === 'history-cumulative-response-limit'
                        || responseBytesProcessed >= MAX_HISTORY_CUMULATIVE_RESPONSE_BYTES) {
                        cumulativeResponseLimitReached = true;
                        break;
                    }
                    lastError = error;
                }
            }
            if (cumulativeResponseLimitReached) break;
            if (!response) throw lastError || new Error('HLTV match history could not be loaded.');
            const { fragment, finalUrl, responseBytes } = response;
            responseBytesProcessed += responseBytes;
            const pageRows = parseMatchRows(fragment);
            const signature = `${pageRows.length}:${pageRows[0]?.id || ''}:${pageRows.at(-1)?.id || ''}`;
            if (pageSignatures.has(signature)) {
                warning = 'HLTV repeated a results page; stopped safely.';
                break;
            }
            pageSignatures.add(signature);
            let added = 0;
            for (const row of pageRows) {
                if (rowIds.has(row.id)) continue;
                const rowWeightBytes = historyRowWeightBytes(row);
                if (retainedWeightBytes + rowWeightBytes
                    > MAX_HISTORY_RETAINED_WEIGHT_BYTES) {
                    retainedWeightLimitReached = true;
                    break;
                }
                rowIds.add(row.id);
                rows.push(row);
                retainedWeightBytes += rowWeightBytes;
                added += 1;
                if (rows.length >= MAX_HISTORY_ROWS) break;
            }
            pages += 1;
            options.onProgress?.({
                pages,
                rows: rows.length,
                retainedWeightBytes,
                responseBytesProcessed,
                url: finalUrl.href,
            });
            if (retainedWeightLimitReached) break;
            if (!pageRows.length || !added) {
                if (pageRows.length && !warning) warning = 'Duplicate results detected; stopped safely.';
                break;
            }
            pageUrl = nextHistoryPage(fragment, finalUrl, pageRows.length);
            if (pageUrl
                && responseBytesProcessed >= MAX_HISTORY_CUMULATIVE_RESPONSE_BYTES) {
                cumulativeResponseLimitReached = true;
                break;
            }
        }
        if (cumulativeResponseLimitReached) {
            warning = 'Stopped at the cumulative response-processing safety limit; results are partial.';
        } else if (retainedWeightLimitReached) {
            warning = 'Stopped at the retained-history memory safety limit; results are partial.';
        } else if (pages >= MAX_HISTORY_PAGES) {
            warning = `Stopped at the ${MAX_HISTORY_PAGES}-page safety limit.`;
        } else if (rows.length >= MAX_HISTORY_ROWS) {
            warning = `Stopped at the ${MAX_HISTORY_ROWS}-row safety limit.`;
        }
        const value = Object.freeze({
            rows: Object.freeze(rows),
            pages,
            warning,
            retainedWeightBytes,
            responseBytesProcessed,
        });
        setHistoryCacheEntry(
            cacheKey,
            value,
            Date.now() + HISTORY_CACHE_TTL_MS,
            retainedWeightBytes,
        );
        return value;
    }

    function populationStandardDeviation(values) {
        if (!values.length) return null;
        const mean = values.reduce((sum, value) => sum + value, 0) / values.length;
        const variance = values.reduce((sum, value) => sum + ((value - mean) ** 2), 0)
            / values.length;
        return Math.sqrt(variance);
    }

    function computeConsistency(rowsOrRatings) {
        const ratings = rowsOrRatings
            .map((entry) => typeof entry === 'number' ? entry : entry?.rating)
            .filter(Number.isFinite);
        if (ratings.length < 10) return null;
        const mean = ratings.reduce((sum, value) => sum + value, 0) / ratings.length;
        const standardDeviation = populationStandardDeviation(ratings);
        const score = Math.round(100 * Math.max(0, 1 - standardDeviation));
        return Object.freeze({
            score: Math.max(0, Math.min(100, score)),
            sampleSize: ratings.length,
            mean,
            standardDeviation,
        });
    }

    function aggregateMapRows(rows) {
        const groups = new Map();
        for (const row of rows) {
            if (!groups.has(row.map)) {
                groups.set(row.map, {
                    map: row.map,
                    count: 0,
                    ratingSum: 0,
                    ratingCount: 0,
                    kprKills: 0,
                    kprRounds: 0,
                    kprCount: 0,
                    dprDeaths: 0,
                    dprRounds: 0,
                    dprCount: 0,
                    kdKills: 0,
                    kdDeaths: 0,
                    kdCount: 0,
                    plusMinus: 0,
                    plusMinusCount: 0,
                });
            }
            const group = groups.get(row.map);
            group.count += 1;
            if (Number.isFinite(row.rating)) {
                group.ratingSum += row.rating;
                group.ratingCount += 1;
            }
            if (Number.isFinite(row.kills)
                && Number.isFinite(row.rounds)
                && row.rounds > 0) {
                group.kprKills += row.kills;
                group.kprRounds += row.rounds;
                group.kprCount += 1;
            }
            if (Number.isFinite(row.deaths)
                && Number.isFinite(row.rounds)
                && row.rounds > 0) {
                group.dprDeaths += row.deaths;
                group.dprRounds += row.rounds;
                group.dprCount += 1;
            }
            if (Number.isFinite(row.kills) && Number.isFinite(row.deaths)) {
                group.kdKills += row.kills;
                group.kdDeaths += row.deaths;
                group.kdCount += 1;
            }
            if (Number.isFinite(row.plusMinus)) {
                group.plusMinus += row.plusMinus;
                group.plusMinusCount += 1;
            }
        }
        return [...groups.values()].map((group) => Object.freeze({
            map: group.map,
            maps: group.count,
            rating: group.ratingCount ? group.ratingSum / group.ratingCount : null,
            kpr: group.kprCount && group.kprRounds > 0
                ? group.kprKills / group.kprRounds : null,
            dpr: group.dprCount && group.dprRounds > 0
                ? group.dprDeaths / group.dprRounds : null,
            kd: group.kdCount && group.kdDeaths > 0
                ? group.kdKills / group.kdDeaths : null,
            plusMinus: group.plusMinusCount ? group.plusMinus / group.plusMinusCount : null,
        })).sort((first, second) => second.maps - first.maps || first.map.localeCompare(second.map));
    }

    function heatColor(value, minimum, maximum, lowerIsBetter = false) {
        if (!Number.isFinite(value) || !Number.isFinite(minimum) || !Number.isFinite(maximum)) return '';
        const rawRatio = maximum === minimum ? 0.5 : (value - minimum) / (maximum - minimum);
        const ratio = lowerIsBetter ? 1 - rawRatio : rawRatio;
        const hue = Math.round(Math.max(0, Math.min(1, ratio)) * 105);
        return `hsla(${hue}, 48%, 36%, .48)`;
    }

    function buildMatchesUrl(playerMatch) {
        const url = new URL(
            `/stats/players/matches/${playerMatch[1]}/${playerMatch[2]}`,
            globalThis.location.origin,
        );
        const current = new URL(globalThis.location.href);
        for (const [key, value] of parameterEntries(current.searchParams)) {
            if (!ALLOWED_FILTERS.has(key) || value.length > 200) continue;
            url.searchParams.append(key, value);
        }
        url.searchParams.set('sortColumn', 'Date');
        url.searchParams.set('sortDirection', 'Descending');
        return url;
    }

    function formatMetric(value, digits = 2, suffix = '') {
        return Number.isFinite(value) ? `${value.toFixed(digits)}${suffix}` : '—';
    }

    function consistencyDescription(score) {
        if (score >= 60) return 'Good';
        if (score >= 40) return 'Mixed';
        return 'Poor';
    }

    function consistencyClass(score) {
        if (score >= 60) return 'aboveAverage';
        if (score >= 40) return 'average';
        return 'belowAverage';
    }

    function createConsistencyStat() {
        const host = createElement(
            'div',
            'player-summary-stat-box-data-wrapper hltv-v2-consistency-stat',
        );
        const value = createElement(
            'div',
            'player-summary-stat-box-data',
            '…',
        );
        const label = createElement(
            'div',
            'player-summary-stat-box-data-text',
            'Consistency',
        );
        label.tabIndex = 0;
        label.setAttribute('aria-label', 'Consistency');
        const tooltip = createElement('div', 'player-summary-tooltip hiddenTooltip');
        tooltip.id = 'hltv-v2-consistency-tooltip';
        tooltip.setAttribute('role', 'tooltip');
        label.setAttribute('aria-describedby', tooltip.id);
        tooltip.append(
            createElement('b', '', 'Consistency'),
            document.createElement('br'),
            document.createTextNode(
                'A normalized 0–100 score based on the population standard deviation of Rating across every fetched map under the current player-page filters. SD 0 scores 100; SD 1.00 or higher scores 0. Scores of 60 or more are Good, 40–59 are Mixed, and scores below 40 are Poor. At least 10 rated maps are required.',
            ),
        );
        const showTooltip = () => tooltip.classList.remove('hiddenTooltip');
        const hideTooltip = () => tooltip.classList.add('hiddenTooltip');
        label.addEventListener('mouseenter', showTooltip);
        label.addEventListener('mouseleave', hideTooltip);
        label.addEventListener('focus', showTooltip);
        label.addEventListener('blur', hideTooltip);
        label.appendChild(tooltip);
        const bar = createElement('div', 'player-summary-stat-box-breakdown-bar');
        bar.append(
            createElement('div', 'player-summary-data-bar'),
            createElement('div', 'player-summary-data-bar'),
            createElement('div', 'player-summary-data-bar'),
        );
        const indicator = createElement('div', 'summaryStatIndicator');
        indicator.style.left = '0%';
        indicator.style.opacity = '0';
        bar.appendChild(indicator);
        const description = createElement(
            'div',
            'player-summary-stat-box-breakdown-description',
            'Loading',
        );
        host.append(value, label, bar, description);
        return host;
    }

    function renderConsistencyStat(host, rows, warning = '') {
        const result = computeConsistency(rows);
        const value = host.querySelector('.player-summary-stat-box-data');
        const indicator = host.querySelector('.summaryStatIndicator');
        const description = host.querySelector('.player-summary-stat-box-breakdown-description');
        if (!result) {
            host.classList.remove('aboveAverage', 'average', 'belowAverage');
            delete host.dataset.hltvV2Partial;
            if (value) value.textContent = '—';
            if (indicator) {
                indicator.style.left = '0%';
                indicator.style.opacity = '0';
            }
            if (description) description.textContent = 'Needs 10 rated maps';
            return;
        }
        host.classList.remove('aboveAverage', 'average', 'belowAverage');
        host.classList.add(consistencyClass(result.score));
        if (value) value.textContent = String(result.score);
        if (indicator) {
            indicator.style.left = `${result.score}%`;
            indicator.style.opacity = '1';
        }
        const safeWarning = cleanText(warning);
        if (description) {
            description.textContent = safeWarning
                ? `${consistencyDescription(result.score)} · Partial`
                : consistencyDescription(result.score);
        }
        if (safeWarning) host.dataset.hltvV2Partial = 'true';
        else delete host.dataset.hltvV2Partial;
    }

    function renderConsistencyFailure(host) {
        const value = host.querySelector('.player-summary-stat-box-data');
        const indicator = host.querySelector('.summaryStatIndicator');
        const description = host.querySelector('.player-summary-stat-box-breakdown-description');
        if (value) value.textContent = '—';
        host.classList.remove('aboveAverage', 'average', 'belowAverage');
        delete host.dataset.hltvV2Partial;
        if (indicator) indicator.style.opacity = '0';
        if (description) description.textContent = 'Unavailable';
    }

    function cleanupConsistency() {
        state.consistencyController?.abort();
        state.consistencyController = null;
        document.querySelectorAll('.hltv-v2-consistency-stat').forEach((element) => element.remove());
        document.querySelectorAll('[data-hltv-v2-consistency-card="true"]')
            .forEach((element) => delete element.dataset.hltvV2ConsistencyCard);
        document.querySelectorAll('[data-hltv-v2-consistency-layout="true"]')
            .forEach((element) => delete element.dataset.hltvV2ConsistencyLayout);
        document.querySelectorAll('[data-hltv-v2-consistency-summary="true"]')
            .forEach((element) => delete element.dataset.hltvV2ConsistencySummary);
    }

    function ensureConsistency() {
        const playerMatch = globalThis.location.pathname.match(PLAYER_PATH_PATTERN);
        if (!playerMatch || !state.settings.enablePlayerConsistencyScore) {
            cleanupConsistency();
            return;
        }
        if (document.querySelector('.hltv-v2-consistency-stat')) return;
        const container = document.querySelector('.player-summary-stat-box-right-bottom');
        if (!container) return;
        const host = createConsistencyStat();
        container.dataset.hltvV2ConsistencyLayout = 'true';
        const summary = container.closest('.player-summary-stat-box-right');
        if (summary) summary.dataset.hltvV2ConsistencySummary = 'true';
        const card = container.closest('.player-summary-stat-box');
        if (card) card.dataset.hltvV2ConsistencyCard = 'true';
        container.appendChild(host);
        const controller = new AbortController();
        state.consistencyController?.abort();
        state.consistencyController = controller;
        const load = async () => {
            await delay(CONSISTENCY_INITIAL_DELAY_MS, controller.signal);
            try {
                const history = await fetchAllMatchHistory(
                    buildMatchesUrl(playerMatch),
                    {
                        signal: controller.signal,
                        onProgress: ({ pages, rows }) => {
                            const description = host.querySelector(
                                '.player-summary-stat-box-breakdown-description',
                            );
                            if (description) {
                                description.textContent = pages > 0
                                    ? `Loading ${rows} maps`
                                    : 'Loading';
                            }
                        },
                        onRetry: ({ delayMs }) => {
                            const description = host.querySelector(
                                '.player-summary-stat-box-breakdown-description',
                            );
                            if (description) {
                                description.textContent = `Retrying in ${delayMs / 1000}s`;
                            }
                        },
                    },
                );
                if (!controller.signal.aborted) {
                    renderConsistencyStat(host, history.rows, history.warning);
                }
            } catch (error) {
                if (error?.name !== 'AbortError' && !controller.signal.aborted) {
                    renderConsistencyFailure(host, error);
                }
            } finally {
                if (state.consistencyController === controller) {
                    state.consistencyController = null;
                }
            }
        };
        load().catch((error) => {
            if (error?.name !== 'AbortError' && !controller.signal.aborted) {
                renderConsistencyFailure(host, error);
            }
        });
    }

    function renderMapMatrix(container, rows) {
        container.replaceChildren();
        const data = aggregateMapRows(rows);
        if (!data.length) {
            container.appendChild(createElement('p', 'hltv-v2-unavailable', 'No map rows were available.'));
            return;
        }
        const columns = [
            { key: 'maps', label: 'Maps', digits: 0 },
            { key: 'rating', label: 'Rating', digits: 2 },
            { key: 'kpr', label: 'KPR', digits: 2 },
            { key: 'dpr', label: 'DPR', digits: 2, lowerIsBetter: true },
            { key: 'kd', label: 'K/D', digits: 2 },
            { key: 'plusMinus', label: '+/− per map', digits: 2 },
        ];
        const ranges = Object.fromEntries(columns.map((column) => {
            const values = data.map((row) => row[column.key]).filter(Number.isFinite);
            return [column.key, values.length ? [Math.min(...values), Math.max(...values)] : [null, null]];
        }));
        const table = createElement('table', 'hltv-v2-matrix');
        const head = table.createTHead().insertRow();
        const sortableColumns = [
            { key: 'map', label: 'Map', type: 'text', firstDirection: 'ascending' },
            ...columns.map((column) => ({
                ...column,
                type: 'number',
                firstDirection: 'descending',
            })),
        ];
        const body = table.createTBody();
        const indexedData = data.map((row, originalIndex) => ({ row, originalIndex }));
        let activeSortKey = '';
        let activeDirection = '';
        const headers = new Map();
        const renderBody = () => {
            const descriptor = sortableColumns.find(
                (column) => column.key === activeSortKey,
            );
            const visibleData = descriptor
                ? indexedData.slice().sort((first, second) => {
                    const firstValue = first.row[activeSortKey];
                    const secondValue = second.row[activeSortKey];
                    let comparison = 0;
                    if (descriptor.type === 'number') {
                        const firstFinite = Number.isFinite(firstValue);
                        const secondFinite = Number.isFinite(secondValue);
                        if (firstFinite !== secondFinite) return firstFinite ? -1 : 1;
                        if (firstFinite) comparison = firstValue - secondValue;
                    } else {
                        comparison = String(firstValue || '').localeCompare(
                            String(secondValue || ''),
                            undefined,
                            { numeric: true, sensitivity: 'base' },
                        );
                    }
                    if (activeDirection === 'descending') comparison *= -1;
                    return comparison || first.originalIndex - second.originalIndex;
                })
                : indexedData;
            body.replaceChildren();
            for (const { row } of visibleData) {
                const tr = body.insertRow();
                tr.appendChild(createElement('td', '', row.map));
                for (const column of columns) {
                    const value = row[column.key];
                    const cell = createElement(
                        'td',
                        Number.isFinite(value) ? '' : 'hltv-v2-unavailable',
                        formatMetric(value, column.digits, column.suffix || ''),
                    );
                    if (!Number.isFinite(value)) {
                        cell.title = 'Unavailable from the fetched match-history table; not guessed.';
                    } else if (column.key !== 'maps') {
                        const [minimum, maximum] = ranges[column.key];
                        cell.style.backgroundColor = heatColor(
                            value,
                            minimum,
                            maximum,
                            column.lowerIsBetter === true,
                        );
                        cell.title = column.lowerIsBetter
                            ? 'Color is relative only to this player’s maps under the current filters; lower is better.'
                            : 'Color is relative only to this player’s maps under the current filters; higher is better.';
                    }
                    tr.appendChild(cell);
                }
            }
        };
        const applySort = (descriptor) => {
            if (activeSortKey === descriptor.key) {
                activeDirection = activeDirection === 'ascending'
                    ? 'descending'
                    : 'ascending';
            } else {
                activeSortKey = descriptor.key;
                activeDirection = descriptor.firstDirection;
            }
            for (const [key, header] of headers) {
                const headerDescriptor = sortableColumns.find(
                    (column) => column.key === key,
                );
                header.setAttribute(
                    'aria-sort',
                    key === activeSortKey ? activeDirection : 'none',
                );
                const nextDirection = key === activeSortKey
                    ? activeDirection === 'ascending' ? 'descending' : 'ascending'
                    : headerDescriptor.firstDirection;
                header.title = `${headerDescriptor.label}: click to sort ${nextDirection}.`;
            }
            renderBody();
        };
        for (const descriptor of sortableColumns) {
            const th = createElement('th', '', descriptor.label);
            th.scope = 'col';
            th.tabIndex = 0;
            th.dataset.hltvV2SortKey = descriptor.key;
            th.setAttribute('aria-sort', 'none');
            th.title = `${descriptor.label}: click to sort ${descriptor.firstDirection}.`;
            th.addEventListener('click', () => applySort(descriptor));
            th.addEventListener('keydown', (event) => {
                if (event.key !== 'Enter' && event.key !== ' ') return;
                event.preventDefault();
                applySort(descriptor);
            });
            headers.set(descriptor.key, th);
            head.appendChild(th);
        }
        renderBody();
        const wrap = createElement('div', 'hltv-v2-matrix-wrap');
        wrap.appendChild(table);
        container.appendChild(wrap);
    }

    function cleanupPlayerAnalytics() {
        state.historyController?.abort();
        state.historyController = null;
        for (const tab of document.querySelectorAll('.hltv-v2-player-tab')) {
            const menu = tab.parentElement;
            tab.classList.remove('selected');
            for (const nativeTab of menu?.querySelectorAll('[data-hltv-v2-map-was-selected="true"]') || []) {
                nativeTab.classList.add('selected');
                delete nativeTab.dataset.hltvV2MapWasSelected;
            }
            if (menu) delete menu.dataset.hltvV2PlayerTabs;
        }
        document.querySelectorAll('.hltv-v2-player-tab, .hltv-v2-player-analytics')
            .forEach((element) => element.remove());
    }

    function setMapMatrixTabSelected(tab, selected) {
        const menu = tab.parentElement;
        if (!menu) return;
        if (selected) {
            for (const nativeTab of menu.querySelectorAll('.stats-top-menu-item.selected')) {
                if (nativeTab === tab) continue;
                nativeTab.dataset.hltvV2MapWasSelected = 'true';
                nativeTab.classList.remove('selected');
            }
            tab.classList.add('selected');
        } else {
            tab.classList.remove('selected');
            for (const nativeTab of menu.querySelectorAll('[data-hltv-v2-map-was-selected="true"]')) {
                nativeTab.classList.add('selected');
                delete nativeTab.dataset.hltvV2MapWasSelected;
            }
        }
        tab.setAttribute('aria-selected', String(selected));
    }

    function ensurePlayerAnalytics() {
        const playerMatch = playerStatsRouteIdentity();
        if (!playerMatch || !state.settings.enablePlayerMapMatrix) {
            cleanupPlayerAnalytics();
            return;
        }
        if (document.querySelector('.hltv-v2-player-analytics')) return;
        const menu = document.querySelector(
            '.stats-section.stats-player .stats-top-menu > .tabs.standard-box',
        );
        const section = document.querySelector('.stats-player');
        if (!menu || !section) return;

        const tab = createElement(
            'a',
            'stats-top-menu-item stats-top-menu-item-link hltv-v2-player-tab',
            'Map matrix',
        );
        tab.href = '#hltv-v2-player-analytics';
        tab.setAttribute('role', 'tab');
        tab.setAttribute('aria-selected', 'false');
        tab.setAttribute('aria-controls', 'hltv-v2-player-analytics');
        tab.title = 'Map matrix';
        const panel = createElement('section', 'hltv-v2-player-analytics');
        panel.id = 'hltv-v2-player-analytics';
        panel.hidden = true;
        panel.setAttribute('role', 'tabpanel');

        const toolbar = createElement('div', 'hltv-v2-toolbar');
        toolbar.appendChild(createElement('span', 'hltv-v2-title', 'Player map analytics'));
        const refresh = createElement('button', 'hltv-v2-button', 'Fetch map history');
        refresh.type = 'button';
        toolbar.appendChild(refresh);
        const status = createElement('div', 'hltv-v2-status', 'Open this tab and fetch to load HLTV match-history pages.');
        status.setAttribute('aria-live', 'polite');
        const matrix = createElement('div', 'hltv-v2-matrix-container');
        panel.append(toolbar, status, matrix);

        async function load(force = false) {
            state.historyController?.abort();
            const controller = new AbortController();
            state.historyController = controller;
            if (force) deleteHistoryCacheEntry(matchesPageKey(buildMatchesUrl(playerMatch)));
            refresh.disabled = true;
            refresh.textContent = 'Fetching…';
            status.dataset.kind = '';
            try {
                const result = await fetchAllMatchHistory(buildMatchesUrl(playerMatch), {
                    signal: controller.signal,
                    onProgress(progress) {
                        status.textContent = progress.pages
                            ? `Fetched ${progress.pages} page(s), ${progress.rows} unique maps…`
                            : 'Fetching first match-history page…';
                    },
                });
                if (controller.signal.aborted) return;
                status.textContent = `Loaded ${result.rows.length} unique maps from ${result.pages} page(s).`;
                if (result.warning) {
                    status.textContent += ` ${result.warning}`;
                    status.dataset.kind = 'warning';
                }
                renderMapMatrix(matrix, result.rows);
                refresh.textContent = 'Refresh map history';
            } catch (error) {
                if (error?.name === 'AbortError') return;
                status.textContent = cleanText(error?.message || 'Map history could not be loaded.');
                status.dataset.kind = 'error';
                refresh.textContent = 'Try again';
            } finally {
                if (state.historyController === controller) {
                    state.historyController = null;
                    refresh.disabled = false;
                }
            }
        }

        tab.addEventListener('click', (event) => {
            event.preventDefault();
            panel.hidden = !panel.hidden;
            setMapMatrixTabSelected(tab, !panel.hidden);
            if (!panel.hidden && !panel.dataset.loaded) {
                panel.dataset.loaded = 'true';
                load(false);
            }
        });
        refresh.addEventListener('click', () => load(true));
        menu.dataset.hltvV2PlayerTabs = 'true';
        menu.appendChild(tab);
        menu.after(panel);
    }

    function extractPlayerMetrics(root) {
        const metrics = new Map();
        function add(label, valueText) {
            const key = canonicalMetricKey(label);
            const value = parseNumericText(valueText);
            if (!key || !Number.isFinite(value) || metrics.has(key)) return;
            metrics.set(key, Object.freeze({
                key,
                label: cleanText(label),
                value,
                valueText: cleanText(valueText),
                percentage: /%/.test(String(valueText)),
                direction: directionForMetric(label),
            }));
        }
        for (const row of root.querySelectorAll('.statistics .stats-row')) {
            const parts = [...row.children];
            if (parts.length >= 2) add(parts[0].textContent, parts.at(-1).textContent);
        }
        for (const row of root.querySelectorAll('.role-stats-row.stats-side-combined')) {
            add(
                row.querySelector('.role-stats-title')?.textContent,
                row.querySelector('.role-stats-data')?.textContent,
            );
        }
        const rating = root.querySelector('.player-summary-stat-box-rating-data-text');
        if (rating) add('Rating', rating.textContent);
        for (const wrapper of root.querySelectorAll('.player-summary-stat-box-data-wrapper')) {
            const label = wrapper.querySelector(
                '.player-summary-stat-box-data-text.traditionalData:not(.hidden), '
                + '.player-summary-stat-box-data-text:not(.hidden)',
            );
            const value = wrapper.querySelector(
                '.player-summary-stat-box-data.traditionalData:not(.hidden), '
                + '.player-summary-stat-box-data:not(.hidden)',
            );
            add(
                directText(label),
                value?.textContent,
            );
        }
        const kpr = metrics.get('kpr');
        const dpr = metrics.get('dpr');
        if (kpr && dpr && !metrics.has('net-kpr')) {
            const value = kpr.value - dpr.value;
            metrics.set('net-kpr', Object.freeze({
                key: 'net-kpr',
                label: 'Net KPR',
                value,
                valueText: value.toFixed(2),
                percentage: false,
                direction: 1,
            }));
        }
        return metrics;
    }

    function hasSpecificEventFilter(url) {
        for (const [key, value] of parameterEntries(url.searchParams)) {
            if (/^event(?:id|ids)?$/i.test(key) && value && !/^all$/i.test(value)) return true;
        }
        return false;
    }

    function parseIsoDate(value) {
        const text = String(value || '');
        const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(text);
        if (!match) return null;
        const year = Number(match[1]);
        if (year < 1900 || year > 2100) return null;
        const milliseconds = Date.parse(`${text}T00:00:00Z`);
        return Number.isFinite(milliseconds) && isoDate(milliseconds) === text
            ? milliseconds
            : null;
    }

    function isoDate(milliseconds) {
        return new Date(milliseconds).toISOString().slice(0, 10);
    }

    function previousPeriodUrl(currentUrl, requestedStart = null, requestedEnd = null) {
        if (hasSpecificEventFilter(currentUrl)) {
            return Object.freeze({
                url: null,
                startDate: '',
                endDate: '',
                reason: 'Unavailable for a specific-event filter.',
            });
        }
        const customStart = requestedStart === null
            ? currentUrl.searchParams.get(BASELINE_START_PARAM)
            : requestedStart;
        const customEnd = requestedEnd === null
            ? currentUrl.searchParams.get(BASELINE_END_PARAM)
            : requestedEnd;
        const hasCustomStart = customStart !== null && customStart !== '';
        const hasCustomEnd = customEnd !== null && customEnd !== '';
        const hasBaselineParameters = requestedStart === null && requestedEnd === null
            && (currentUrl.searchParams.has(BASELINE_START_PARAM)
                || currentUrl.searchParams.has(BASELINE_END_PARAM));
        let baselineStart = parseIsoDate(customStart);
        let baselineEnd = parseIsoDate(customEnd);
        if (hasCustomStart || hasCustomEnd || hasBaselineParameters
            || requestedStart !== null || requestedEnd !== null) {
            if (!Number.isFinite(baselineStart) || !Number.isFinite(baselineEnd)) {
                return Object.freeze({
                    url: null,
                    startDate: String(customStart || ''),
                    endDate: String(customEnd || ''),
                    reason: 'Choose valid baseline start and end dates.',
                });
            }
            if (baselineEnd < baselineStart) {
                return Object.freeze({
                    url: null,
                    startDate: String(customStart),
                    endDate: String(customEnd),
                    reason: 'The baseline end date must not be before its start date.',
                });
            }
        } else {
            const start = parseIsoDate(currentUrl.searchParams.get('startDate'));
            const end = parseIsoDate(currentUrl.searchParams.get('endDate'));
            if (!Number.isFinite(start) || !Number.isFinite(end) || end < start) {
                return Object.freeze({
                    url: null,
                    startDate: '',
                    endDate: '',
                    reason: 'Choose baseline start and end dates.',
                });
            }
            const day = 24 * 60 * 60 * 1000;
            const duration = end - start + day;
            baselineEnd = start - day;
            baselineStart = baselineEnd - duration + day;
        }
        const startDate = isoDate(baselineStart);
        const endDate = isoDate(baselineEnd);
        if (!Number.isFinite(parseIsoDate(startDate)) || !Number.isFinite(parseIsoDate(endDate))) {
            return Object.freeze({
                url: null,
                startDate: '',
                endDate: '',
                reason: 'The automatically derived baseline is outside the supported date range (1900 to 2100). Choose baseline dates manually.',
            });
        }
        const url = new URL(currentUrl.href);
        url.searchParams.delete(BASELINE_START_PARAM);
        url.searchParams.delete(BASELINE_END_PARAM);
        url.searchParams.set('startDate', startDate);
        url.searchParams.set('endDate', endDate);
        url.searchParams.delete('offset');
        return Object.freeze({ url, startDate, endDate, reason: '' });
    }

    function storeBaselineDatesInUrl(startDate, endDate) {
        const url = new URL(globalThis.location.href);
        url.searchParams.set(BASELINE_START_PARAM, startDate);
        url.searchParams.set(BASELINE_END_PARAM, endDate);
        globalThis.history.replaceState(globalThis.history.state, '', url.href);
    }

    function baselinePeriodForApply(currentUrl, startDate, endDate) {
        if (startDate || endDate) {
            return previousPeriodUrl(currentUrl, startDate, endDate);
        }
        const cleanUrl = new URL(currentUrl.href);
        cleanUrl.searchParams.delete(BASELINE_START_PARAM);
        cleanUrl.searchParams.delete(BASELINE_END_PARAM);
        return previousPeriodUrl(cleanUrl);
    }

    function inactiveBaselinePeriod(currentUrl) {
        if (hasSpecificEventFilter(currentUrl)) return previousPeriodUrl(currentUrl);
        return Object.freeze({
            url: null,
            startDate: '',
            endDate: '',
            reason: 'Choose baseline dates or press Compare dates to use the preceding date range.',
        });
    }

    function createBaselineControls(currentUrl) {
        const controls = createElement('div', 'hltv-v2-baseline-controls');
        const startLabel = createElement('label', '', 'Baseline start');
        const start = createElement('input');
        start.type = 'date';
        start.setAttribute('aria-label', 'Baseline comparison start date');
        const endLabel = createElement('label', '', 'Baseline end');
        const end = createElement('input');
        end.type = 'date';
        end.setAttribute('aria-label', 'Baseline comparison end date');
        const apply = createElement('button', 'hltv-v2-button', 'Compare dates');
        apply.type = 'button';
        const hasExplicitBaseline = currentUrl.searchParams.has(BASELINE_START_PARAM)
            || currentUrl.searchParams.has(BASELINE_END_PARAM);
        const initial = hasExplicitBaseline
            ? previousPeriodUrl(currentUrl)
            : inactiveBaselinePeriod(currentUrl);
        start.value = initial.startDate;
        end.value = initial.endDate;
        startLabel.appendChild(start);
        endLabel.appendChild(end);
        controls.append(startLabel, endLabel, apply);
        return { controls, start, end, apply, initial };
    }

    async function fetchCachedPage(url, signal) {
        const safeUrl = validateSameOriginUrl(url, [
            PLAYER_PATH_PATTERN,
            PLAYER_INDIVIDUAL_PATH_PATTERN,
            RANKING_PATH_PATTERN,
        ]);
        const key = matchesPageKey(safeUrl);
        const cached = getFreshPageCacheEntry(key);
        if (cached) return cached.fragment.cloneNode(true);
        const result = await throttledFetch(safeUrl, signal);
        setPageCacheEntry(key, result.fragment, Date.now() + PAGE_CACHE_TTL_MS);
        return result.fragment;
    }

    function formatPeriodDelta(current, previous) {
        const delta = current.value - previous.value;
        const places = Math.max(decimalPlaces(current.valueText), decimalPlaces(previous.valueText), 2);
        const suffix = current.percentage ? ' pp' : '';
        const absolute = `${delta >= 0 ? '+' : ''}${delta.toFixed(places)}${suffix}`;
        const relative = previous.value === 0
            ? 'relative change unavailable'
            : `${delta >= 0 ? '+' : ''}${((delta / Math.abs(previous.value)) * 100).toFixed(1)}%`;
        return { delta, absolute, relative };
    }

    function metricNameFromKey(key) {
        const known = {
            rating: 'Rating',
            kpr: 'KPR',
            dpr: 'DPR',
            adr: 'ADR',
            kast: 'KAST',
            'net-kpr': 'Net K/R',
            maps: 'Maps',
            rounds: 'Rounds',
            'kd-diff': 'K-D Diff',
            kd: 'K/D',
            'kills-per-map': 'Kills per map',
        };
        return known[key] || cleanText(key)
            .split('-')
            .filter(Boolean)
            .map((part) => part.length <= 3
                ? part.toUpperCase()
                : `${part[0].toUpperCase()}${part.slice(1)}`)
            .join(' ');
    }

    function comparableMetrics(currentMetrics, previousMetrics) {
        return new Map([...currentMetrics].filter(([key]) => previousMetrics.has(key)));
    }

    function populatePeriodMetricSelect(select, metrics, requestedKey, unavailableSuffix) {
        select.replaceChildren();
        const requested = canonicalMetricKey(requestedKey) || SETTING_DEFAULTS.previousPeriodMetric;
        const available = metrics.has(requested);
        if (!available) {
            const unavailable = createElement(
                'option',
                '',
                `${metricNameFromKey(requested)} (${unavailableSuffix})`,
            );
            unavailable.value = requested;
            unavailable.disabled = true;
            unavailable.selected = true;
            select.appendChild(unavailable);
        }
        for (const metric of metrics.values()) {
            const option = createElement('option', '', metric.label);
            option.value = metric.key;
            select.appendChild(option);
        }
        select.disabled = metrics.size === 0;
        if (available) select.value = requested;
        return { available, requested };
    }

    function savePreviousPeriodMetric(value) {
        const metric = canonicalMetricKey(value);
        if (!metric) return;
        state.settings.previousPeriodMetric = metric;
        extensionApi?.storage?.local?.set?.({ previousPeriodMetric: metric })
            ?.catch?.(() => undefined);
    }

    function cleanupPreviousPeriod() {
        state.previousController?.abort();
        state.previousController = null;
        document.querySelectorAll(
            '.hltv-v2-period-panel, .hltv-v2-period-header, .hltv-v2-period-cell',
        ).forEach((element) => element.remove());
        state.previousPeriodModel = null;
    }

    async function ensurePlayerPreviousPeriod() {
        if (!state.settings.enablePlayerPagePeriodComparison) return;
        const pathMatches = globalThis.location.pathname.match(PLAYER_PATH_PATTERN)
            || globalThis.location.pathname.match(PLAYER_INDIVIDUAL_PATH_PATTERN);
        if (!pathMatches || document.querySelector('.hltv-v2-period-panel')) return;
        const section = document.querySelector('.stats-player');
        const currentMetrics = extractPlayerMetrics(document);
        if (!section || !currentMetrics.size) return;

        const panel = createElement('section', 'hltv-v2-period-panel');
        panel.appendChild(createElement('div', 'hltv-v2-title', 'Baseline date comparison'));
        const status = createElement('div', 'hltv-v2-status', 'Preparing comparison…');
        status.setAttribute('aria-live', 'polite');
        const select = createElement('select', 'hltv-v2-select');
        select.setAttribute('aria-label', 'Metric for previous-period comparison');
        select.disabled = true;
        const values = createElement('div', 'hltv-v2-period-values');
        const dateControls = createBaselineControls(new URL(globalThis.location.href));
        panel.append(dateControls.controls, select, status, values);
        const insertion = document.querySelector('.statistics') || section.lastElementChild;
        if (insertion) insertion.after(panel);
        else section.appendChild(panel);

        async function load(period) {
            state.previousController?.abort();
            state.previousPeriodModel = null;
            values.replaceChildren();
            select.replaceChildren();
            select.disabled = true;
            status.dataset.kind = '';
            if (!period.url) {
                status.textContent = period.reason;
                status.dataset.kind = 'warning';
                return;
            }
            const controller = new AbortController();
            state.previousController = controller;
            status.textContent = `Loading baseline ${period.startDate} to ${period.endDate}…`;
            try {
                const previousFragment = await fetchCachedPage(period.url, controller.signal);
                if (controller.signal.aborted) return;
                const previousMetrics = extractPlayerMetrics(previousFragment);
                const metrics = comparableMetrics(currentMetrics, previousMetrics);
                const selection = populatePeriodMetricSelect(
                    select,
                    metrics,
                    state.settings.previousPeriodMetric,
                    'unavailable in one of these periods',
                );
                function render() {
                    values.replaceChildren();
                    const metric = metrics.get(select.value);
                    const current = metric && currentMetrics.get(metric.key);
                    const previous = metric && previousMetrics.get(metric.key);
                    if (!current || !previous) {
                        values.appendChild(createElement(
                            'span',
                            'hltv-v2-unavailable',
                            'This metric is unavailable in one of the two periods.',
                        ));
                        return;
                    }
                    const change = formatPeriodDelta(current, previous);
                    const direction = current.direction || previous.direction || 0;
                    const preferredChange = change.delta * direction;
                    const deltaClass = preferredChange > 0
                        ? 'hltv-v2-period-positive'
                        : preferredChange < 0 ? 'hltv-v2-period-negative' : '';
                    values.append(
                        createElement('span', 'hltv-v2-period-value', `Current: ${current.valueText}`),
                        createElement('span', 'hltv-v2-period-value', `Baseline: ${previous.valueText}`),
                        createElement(
                            'span',
                            `hltv-v2-period-value ${deltaClass}`.trim(),
                            `Change: ${change.absolute} (${change.relative})`,
                        ),
                    );
                    state.previousPeriodModel = Object.freeze({
                        route: 'player',
                        current: Object.freeze({ ...current }),
                        previous: Object.freeze({ ...previous }),
                        delta: change.delta,
                        previousUrl: period.url.href,
                    });
                }
                status.textContent = `Baseline: ${period.startDate} to ${period.endDate}`;
                if (!selection.available) {
                    status.textContent += ` · ${metricNameFromKey(selection.requested)} is unavailable in one of these periods. Choose a listed metric.`;
                    status.dataset.kind = 'warning';
                }
                if (selection.available) render();
                else values.appendChild(createElement(
                    'span',
                    'hltv-v2-unavailable',
                    'No comparison is shown until an available metric is selected.',
                ));
                select.onchange = () => {
                    savePreviousPeriodMetric(select.value);
                    status.textContent = `Baseline: ${period.startDate} to ${period.endDate}`;
                    status.dataset.kind = '';
                    render();
                };
            } catch (error) {
                if (error?.name === 'AbortError') return;
                status.textContent = cleanText(error?.message || 'Baseline period could not be loaded.');
                status.dataset.kind = 'error';
            } finally {
                if (state.previousController === controller) state.previousController = null;
            }
        }

        dateControls.apply.addEventListener('click', () => {
            const period = baselinePeriodForApply(
                new URL(globalThis.location.href),
                dateControls.start.value,
                dateControls.end.value,
            );
            if (period.url) {
                dateControls.start.value = period.startDate;
                dateControls.end.value = period.endDate;
                storeBaselineDatesInUrl(period.startDate, period.endDate);
            }
            load(period).catch(() => undefined);
        });
        await load(dateControls.initial);
    }

    function rankingPlayerId(row) {
        const link = row.querySelector('a[href*="/stats/players/"], a[href*="/player/"]');
        if (!link) return '';
        try {
            return new URL(link.getAttribute('href'), globalThis.location.origin)
                .pathname.match(/^\/(?:stats\/players|player)\/(\d{1,20})\//)?.[1] || '';
        } catch {
            return '';
        }
    }

    function rankingColumnDescriptor(header, index) {
        if (header.matches(
            '.tmKprRangeCol, .hltv-v2-period-header, '
            + '[data-hltv-v2-managed-column], [data-hltv-win-adjusted-col]',
        )) return null;
        const classes = header.classList;
        let key = '';
        let label = cleanText(header.textContent);
        if (classes.contains('playerCol') || classes.contains('teamCol')) return null;
        if (classes.contains('mapsCol')) [key, label] = ['maps', 'Maps'];
        else if (classes.contains('rounds-col')) [key, label] = ['rounds', 'Rounds'];
        else if (classes.contains('kdDiffCol')) [key, label] = ['kd-diff', 'K-D Diff'];
        else if (classes.contains('kdCol')) [key, label] = ['kd', 'K/D'];
        else if (classes.contains('ratingCol')) [key, label] = ['rating', 'Rating'];
        else key = canonicalMetricKey(label);
        if (!key || key === 'player' || key === 'team') return null;
        return Object.freeze({ index, key, label: label || metricNameFromKey(key) });
    }

    function estimateRankingKprBounds(rounds, difference, shownKd) {
        if (!Number.isFinite(rounds) || rounds <= 0
            || !Number.isFinite(difference)
            || !Number.isFinite(shownKd) || shownKd <= 0) return null;
        const roundedKd = Math.round(shownKd * 100);
        const q = 200 * difference;
        const lowerCoefficient = 2 * roundedKd - 201;
        const upperCoefficient = 2 * roundedKd - 199;
        let minimumDeaths = Math.max(1, -difference);
        let maximumDeaths = Math.min(rounds, (5 * rounds) - difference);
        if (lowerCoefficient > 0) {
            maximumDeaths = Math.min(maximumDeaths, Math.floor(q / lowerCoefficient));
        } else if (lowerCoefficient < 0) {
            minimumDeaths = Math.max(minimumDeaths, Math.ceil(q / lowerCoefficient));
        } else if (q < 0) return null;
        if (upperCoefficient > 0) {
            minimumDeaths = Math.max(minimumDeaths, Math.floor(q / upperCoefficient) + 1);
        } else if (upperCoefficient < 0) {
            maximumDeaths = Math.min(maximumDeaths, Math.ceil(q / upperCoefficient) - 1);
        } else if (q >= 0) return null;
        minimumDeaths = Math.ceil(minimumDeaths);
        maximumDeaths = Math.floor(maximumDeaths);
        if (minimumDeaths > maximumDeaths) return null;
        return {
            minimum: (minimumDeaths + difference) / rounds,
            maximum: (maximumDeaths + difference) / rounds,
        };
    }

    function boundedMetricValue(minimum, maximum, digits = 2) {
        if (!Number.isFinite(minimum) || !Number.isFinite(maximum)) return null;
        const low = Math.min(minimum, maximum);
        const high = Math.max(minimum, maximum);
        const lowText = low.toFixed(digits);
        const highText = high.toFixed(digits);
        return Object.freeze({
            value: (low + high) / 2,
            minimum: low,
            maximum: high,
            valueText: lowText === highText ? lowText : `${lowText}–${highText}`,
        });
    }

    function extractRankingMetrics(root) {
        const table = root.querySelector('.player-ratings-table');
        if (!table) return null;
        const descriptors = [...table.querySelectorAll('thead tr:first-child > th')]
            .map(rankingColumnDescriptor)
            .filter(Boolean);
        const rowValues = new Map();
        const rowElements = new Map();
        for (const row of table.querySelectorAll('tbody tr')) {
            const id = rankingPlayerId(row);
            if (!id) continue;
            const cells = [...row.children].filter((cell) => cell.tagName === 'TD');
            const values = new Map();
            for (const descriptor of descriptors) {
                if (values.has(descriptor.key)) continue;
                const cell = cells[descriptor.index];
                const valueText = cleanText(cell?.textContent);
                const value = parseNumericText(cell?.dataset?.sort || valueText);
                if (!Number.isFinite(value)) continue;
                values.set(
                    descriptor.key,
                    boundedMetricValue(value, value, decimalPlaces(valueText)),
                );
            }
            rowValues.set(id, values);
            rowElements.set(id, row);
        }
        const metrics = new Map();
        function addMetric(key, label, direction = directionForMetric(label), estimated = false) {
            const rows = new Map();
            for (const [id, values] of rowValues) {
                const value = values.get(key);
                if (value) rows.set(id, value);
            }
            if (rows.size) metrics.set(key, Object.freeze({
                key, label, direction, estimated, rows,
            }));
        }
        for (const descriptor of descriptors) {
            addMetric(
                descriptor.key,
                descriptor.label,
                ['rating', 'kd', 'kd-diff'].includes(descriptor.key) ? 1 : 0,
            );
        }
        for (const values of rowValues.values()) {
            const rounds = values.get('rounds')?.value;
            const difference = values.get('kd-diff')?.value;
            const shownKd = values.get('kd')?.value;
            const kpr = estimateRankingKprBounds(rounds, difference, shownKd);
            if (!kpr) continue;
            values.set('kpr', boundedMetricValue(kpr.minimum, kpr.maximum));
            values.set('dpr', boundedMetricValue(
                kpr.minimum - (difference / rounds),
                kpr.maximum - (difference / rounds),
            ));
            values.set('net-kpr', boundedMetricValue(
                difference / rounds,
                difference / rounds,
            ));
            const maps = values.get('maps')?.value;
            if (Number.isFinite(maps) && maps > 0) {
                values.set('kills-per-map', boundedMetricValue(
                    (kpr.minimum * rounds) / maps,
                    (kpr.maximum * rounds) / maps,
                    1,
                ));
            }
        }
        addMetric('kpr', 'KPR (estimated midpoint)', 1, true);
        addMetric('dpr', 'DPR (estimated midpoint)', -1, true);
        addMetric('net-kpr', 'Net K/R', 1);
        addMetric('kills-per-map', 'Kills per map (estimated midpoint)', 1, true);
        return { table, metrics, rowElements };
    }

    function comparableRankingMetrics(current, previous) {
        const preferred = [
            'rating', 'kpr', 'dpr', 'net-kpr', 'maps', 'rounds',
            'kd-diff', 'kd', 'kills-per-map',
        ];
        const common = new Map();
        for (const key of [...preferred, ...current.metrics.keys()]) {
            if (common.has(key)) continue;
            const metric = current.metrics.get(key);
            const prior = previous.metrics.get(key);
            if (!metric || !prior) continue;
            if ([...metric.rows.keys()].some((id) => prior.rows.has(id))) {
                common.set(key, metric);
            }
        }
        return common;
    }

    function signedFixed(value) {
        return `${value >= 0 ? '+' : ''}${value.toFixed(2)}`;
    }

    function renderRankingPeriodColumn(current, previous, metric, period) {
        document.querySelectorAll('.hltv-v2-period-header, .hltv-v2-period-cell')
            .forEach((element) => element.remove());
        const priorMetric = previous.metrics.get(metric.key);
        if (!priorMetric) return;
        const header = createElement('th', 'hltv-v2-period-header', `Δ ${metric.label}`);
        header.title = metric.estimated
            ? `Difference between estimated ${metricNameFromKey(metric.key)} range midpoints. Cell tooltips show both ranges and the full possible delta range.`
            : `Change in ${metric.label} versus the selected baseline date period.`;
        current.table.querySelector('thead tr')?.appendChild(header);
        const resultRows = [];
        for (const [id, row] of current.rowElements) {
            const currentValue = metric.rows.get(id);
            const previousValue = priorMetric.rows.get(id);
            const cell = createElement('td', 'hltv-v2-period-cell');
            if (currentValue && previousValue) {
                const delta = currentValue.value - previousValue.value;
                const deltaMinimum = currentValue.minimum - previousValue.maximum;
                const deltaMaximum = currentValue.maximum - previousValue.minimum;
                cell.textContent = metric.estimated
                    ? `${signedFixed(delta)} est.`
                    : signedFixed(delta);
                cell.dataset.sort = String(delta);
                if (metric.estimated) {
                    cell.title = [
                        `Current range: ${currentValue.valueText}`,
                        `Previous range: ${previousValue.valueText}`,
                        `Possible delta range: ${signedFixed(deltaMinimum)} to ${signedFixed(deltaMaximum)}`,
                        `Displayed delta is the midpoint difference: ${signedFixed(delta)}.`,
                    ].join('\n');
                }
                const preferredChange = delta * metric.direction;
                if (preferredChange > 0) cell.classList.add('hltv-v2-period-positive');
                else if (preferredChange < 0) cell.classList.add('hltv-v2-period-negative');
                resultRows.push(Object.freeze({
                    id,
                    current: currentValue.value,
                    previous: previousValue.value,
                    delta,
                    currentBounds: Object.freeze([currentValue.minimum, currentValue.maximum]),
                    previousBounds: Object.freeze([previousValue.minimum, previousValue.maximum]),
                }));
            } else {
                cell.textContent = '—';
                cell.classList.add('hltv-v2-unavailable');
            }
            row.appendChild(cell);
        }
        state.previousPeriodModel = Object.freeze({
            route: 'ranking',
            metric: metric.key,
            label: metric.label,
            estimated: metric.estimated,
            previousUrl: period.url.href,
            rows: Object.freeze(resultRows),
        });
    }

    async function ensureRankingPreviousPeriod() {
        if (!state.settings.enableStatsTablePeriodComparison
            || !RANKING_PATH_PATTERN.test(globalThis.location.pathname)
            || document.querySelector('.hltv-v2-period-panel')) return;
        const current = extractRankingMetrics(document);
        if (!current) return;
        const panel = createElement('section', 'hltv-v2-period-panel');
        panel.appendChild(createElement('div', 'hltv-v2-title', 'Baseline date comparison'));
        const select = createElement('select', 'hltv-v2-select');
        select.setAttribute('aria-label', 'Metric for ranking previous-period comparison');
        select.disabled = true;
        const status = createElement('div', 'hltv-v2-status', 'Preparing comparison…');
        status.setAttribute('aria-live', 'polite');
        const dateControls = createBaselineControls(new URL(globalThis.location.href));
        panel.append(dateControls.controls, select, status);
        current.table.parentElement?.insertBefore(panel, current.table);

        async function load(period) {
            state.previousController?.abort();
            state.previousPeriodModel = null;
            document.querySelectorAll('.hltv-v2-period-header, .hltv-v2-period-cell')
                .forEach((element) => element.remove());
            select.replaceChildren();
            select.disabled = true;
            status.dataset.kind = '';
            if (!period.url) {
                status.textContent = period.reason;
                status.dataset.kind = 'warning';
                return;
            }
            const controller = new AbortController();
            state.previousController = controller;
            status.textContent = `Loading baseline ${period.startDate} to ${period.endDate}…`;
            try {
                const previousFragment = await fetchCachedPage(period.url, controller.signal);
                const previous = extractRankingMetrics(previousFragment);
                if (!previous || controller.signal.aborted) return;
                const metrics = comparableRankingMetrics(current, previous);
                const selection = populatePeriodMetricSelect(
                    select,
                    metrics,
                    state.settings.previousPeriodMetric,
                    'unavailable on player ranking tables',
                );
                const dateSummary = `Baseline: ${period.startDate} to ${period.endDate}`;
                status.textContent = dateSummary;
                if (!selection.available) {
                    status.textContent += ` · ${metricNameFromKey(selection.requested)} is unavailable on player ranking tables. Choose a listed table metric. No per-player pages were fetched.`;
                    status.dataset.kind = 'warning';
                    state.previousPeriodModel = null;
                } else {
                    renderRankingPeriodColumn(
                        current,
                        previous,
                        metrics.get(selection.requested),
                        period,
                    );
                }
                select.onchange = () => {
                    const metric = metrics.get(select.value);
                    if (!metric) return;
                    savePreviousPeriodMetric(metric.key);
                    status.textContent = dateSummary;
                    status.dataset.kind = '';
                    renderRankingPeriodColumn(current, previous, metric, period);
                };
            } catch (error) {
                if (error?.name === 'AbortError') return;
                status.textContent = cleanText(error?.message || 'Baseline period could not be loaded.');
                status.dataset.kind = 'error';
            } finally {
                if (state.previousController === controller) state.previousController = null;
            }
        }

        dateControls.apply.addEventListener('click', () => {
            const period = baselinePeriodForApply(
                new URL(globalThis.location.href),
                dateControls.start.value,
                dateControls.end.value,
            );
            if (period.url) {
                dateControls.start.value = period.startDate;
                dateControls.end.value = period.endDate;
                storeBaselineDatesInUrl(period.startDate, period.endDate);
            }
            load(period).catch(() => undefined);
        });
        await load(dateControls.initial);
    }

    function parseCompareModel(root = document) {
        const table = root.querySelector('.stats-bar-table');
        if (!table) return null;
        const rows = [...table.querySelectorAll('tbody tr')];
        if (rows.length < 2) return null;
        const firstRow = rows[0];
        const names = [
            cleanText(firstRow.querySelector('.player1-col .nickname')?.textContent) || 'Player 1',
            cleanText(firstRow.querySelector('.player2-col .nickname')?.textContent) || 'Player 2',
        ];
        const filters = [
            cleanText(firstRow.querySelector('.player1-col .filter-text')?.textContent),
            cleanText(firstRow.querySelector('.player2-col .filter-text')?.textContent),
        ];
        const comparisonRows = [];
        const metrics = [];
        for (const row of rows.slice(1)) {
            const label = cleanText(row.querySelector('.stat-name-col')?.textContent);
            const leftText = cleanText(row.querySelector('.player1-col .stat-value')?.textContent);
            const rightText = cleanText(row.querySelector('.player2-col .stat-value')?.textContent);
            const left = parseNumericText(leftText);
            const right = parseNumericText(rightText);
            const comparisonRow = Object.freeze({
                row,
                label,
                left,
                right,
                leftText,
                rightText,
                percentage: /%/.test(leftText) || /%/.test(rightText),
                direction: directionForMetric(label),
                available: Boolean(label) && Number.isFinite(left) && Number.isFinite(right),
            });
            comparisonRows.push(comparisonRow);
            if (comparisonRow.available) metrics.push(comparisonRow);
        }
        return { table, firstRow, names, filters, comparisonRows, metrics };
    }

    function compareActionUrls() {
        const url = new URL(globalThis.location.href);
        const match = url.pathname.match(COMPARE_PAIR_PATH_PATTERN);
        if (!match) return { swap: null, sync: null };
        const swap = new URL(url.href);
        swap.pathname = `/stats/players/compare/${match[3]}/${match[4]}/${match[1]}/${match[2]}`;
        const pairs = [
            ['p1TimeFilter', 'p2TimeFilter'],
            ['p1MatchFilter', 'p2MatchFilter'],
            ['p1MapFilter', 'p2MapFilter'],
        ];
        for (const [left, right] of pairs) {
            const leftValue = url.searchParams.get(left);
            const rightValue = url.searchParams.get(right);
            if (rightValue === null) swap.searchParams.delete(left);
            else swap.searchParams.set(left, rightValue);
            if (leftValue === null) swap.searchParams.delete(right);
            else swap.searchParams.set(right, leftValue);
        }
        const sync = new URL(url.href);
        for (const [left, right] of pairs) {
            const value = sync.searchParams.get(left);
            if (value === null) sync.searchParams.delete(right);
            else sync.searchParams.set(right, value);
        }
        return { swap, sync };
    }

    function subtractUtcCalendarMonths(milliseconds, monthCount) {
        const date = new Date(milliseconds);
        const sourceDay = date.getUTCDate();
        const targetMonthIndex = date.getUTCMonth() - monthCount;
        const targetYear = date.getUTCFullYear() + Math.floor(targetMonthIndex / 12);
        const targetMonth = ((targetMonthIndex % 12) + 12) % 12;
        const lastTargetDay = new Date(Date.UTC(targetYear, targetMonth + 1, 0)).getUTCDate();
        return Date.UTC(targetYear, targetMonth, Math.min(sourceDay, lastTargetDay));
    }

    function compareTimeFilter(timeFilter, nowMilliseconds = Date.now()) {
        const value = cleanText(timeFilter || 'allTime');
        if (value === 'allTime') return Object.freeze({ startDate: 'all', endDate: '' });
        const today = Date.UTC(
            new Date(nowMilliseconds).getUTCFullYear(),
            new Date(nowMilliseconds).getUTCMonth(),
            new Date(nowMilliseconds).getUTCDate(),
        );
        if (value === 'past1months' || value === 'past3months') {
            const months = value === 'past1months' ? 1 : 3;
            return Object.freeze({
                startDate: isoDate(subtractUtcCalendarMonths(today, months)),
                endDate: isoDate(today),
            });
        }
        if (/^(?:19|20|21)\d{2}$/.test(value)) {
            const year = Number(value);
            if (year >= 1900 && year <= 2100) {
                return Object.freeze({
                    startDate: `${value}-01-01`,
                    endDate: `${value}-12-31`,
                });
            }
        }
        throw new Error(`Unsupported comparison time filter: ${value || 'empty'}.`);
    }

    function compareHistoryRequests(nowMilliseconds = Date.now(), requestedSeriesIndices = null) {
        const current = new URL(globalThis.location.href);
        const pairMatch = current.pathname.match(COMPARE_PAIR_PATH_PATTERN);
        const singleMatch = current.pathname.match(COMPARE_SINGLE_PATH_PATTERN);
        const players = pairMatch
            ? [
                Object.freeze({ id: pairMatch[1], slug: pairMatch[2], prefix: 'p1', sourceIndex: 0 }),
                Object.freeze({ id: pairMatch[3], slug: pairMatch[4], prefix: 'p2', sourceIndex: 1 }),
            ]
            : singleMatch
                ? [Object.freeze({
                    id: singleMatch[1],
                    slug: singleMatch[2],
                    prefix: 'p1',
                    sourceIndex: 0,
                })]
                : [];
        if (!players.length) {
            throw new Error('Select at least one comparison player before fetching trends.');
        }
        const requested = Array.isArray(requestedSeriesIndices)
            ? new Set(requestedSeriesIndices.filter(Number.isInteger))
            : null;
        const selectedPlayers = requested
            ? players.filter((player) => requested.has(player.sourceIndex))
            : players;
        if (!selectedPlayers.length) {
            throw new Error('Select at least one available player trend before fetching.');
        }
        const allowedMatchTypes = new Set([
            'allMatches', 'Majors', 'BigEvents', 'MvpEvents', 'Lan', 'Online',
        ]);
        return selectedPlayers.map((player) => {
            const time = compareTimeFilter(
                current.searchParams.get(`${player.prefix}TimeFilter`) || 'allTime',
                nowMilliseconds,
            );
            const matchType = cleanText(
                current.searchParams.get(`${player.prefix}MatchFilter`) || 'allMatches',
            );
            if (!allowedMatchTypes.has(matchType)) {
                throw new Error(`Unsupported comparison match filter: ${matchType || 'empty'}.`);
            }
            const map = cleanText(
                current.searchParams.get(`${player.prefix}MapFilter`) || 'allMaps',
            );
            if (map !== 'allMaps') {
                const mapKey = map.toLowerCase().replace(/^de_/, '').replace(/[^a-z0-9]/g, '');
                if (!/^de_[a-z0-9]{2,20}$/i.test(map) || !Object.hasOwn(MAP_NAMES, mapKey)) {
                    throw new Error(`Unsupported comparison map filter: ${map || 'empty'}.`);
                }
            }
            const url = new URL(
                `/stats/players/matches/${player.id}/${player.slug}`,
                globalThis.location.origin,
            );
            url.searchParams.set('startDate', time.startDate);
            if (time.endDate) url.searchParams.set('endDate', time.endDate);
            if (matchType !== 'allMatches') url.searchParams.set('matchType', matchType);
            if (map !== 'allMaps') url.searchParams.set('maps', map);
            url.searchParams.set('sortColumn', 'Date');
            url.searchParams.set('sortDirection', 'Descending');
            return Object.freeze({ ...player, url });
        });
    }

    function availableCompareTrendMetrics(histories) {
        return COMPARE_TREND_METRICS.filter((metric) => histories.every((history) => (
            history.rows.some((row) => Number.isFinite(row.timestamp)
                && row.timestamp > 0
                && Number.isFinite(row[metric.key]))
        )));
    }

    function syncMetricOptions(select, histories, seriesIndices) {
        const currentMetric = select.value;
        const selectedHistories = [...new Set(seriesIndices)]
            .filter((index) => Number.isInteger(index)
                && index >= 0
                && index < histories.length
                && histories[index]?.rows)
            .map((index) => histories[index]);
        const availableMetrics = selectedHistories.length
            ? availableCompareTrendMetrics(selectedHistories)
            : [];
        select.replaceChildren();
        for (const metric of availableMetrics) {
            const option = createElement('option', '', metric.label);
            option.value = metric.key;
            select.appendChild(option);
        }
        const requested = availableMetrics.some((metric) => metric.key === currentMetric)
            ? currentMetric
            : availableMetrics.some((metric) => metric.key === 'rating')
                ? 'rating'
                : availableMetrics[0]?.key || '';
        if (requested) select.value = requested;
        select.disabled = availableMetrics.length === 0;
        select.hidden = availableMetrics.length === 0;
        return availableMetrics;
    }

    function createSvgElement(tagName, className = '') {
        const element = document.createElementNS('http://www.w3.org/2000/svg', tagName);
        if (className) element.setAttribute('class', className);
        return element;
    }

    function graphDateLabel(timestamp) {
        return new Date(timestamp).toISOString().slice(0, 10);
    }

    function sampledGraphRows(rows, maximum = MAX_COMPARE_HOVER_POINTS_PER_SERIES) {
        if (rows.length <= maximum) return rows;
        const sampled = [];
        const lastIndex = rows.length - 1;
        for (let index = 0; index < maximum; index += 1) {
            sampled.push(rows[Math.round((index / (maximum - 1)) * lastIndex)]);
        }
        return sampled;
    }

    function trailingAverageRows(
        rows,
        metricKey,
        windowSize = COMPARE_MAP_AVERAGE_WINDOW,
    ) {
        const size = Math.max(1, Math.trunc(Number(windowSize)) || 1);
        if (rows.length < size) return [];
        const averaged = [];
        let sum = 0;
        for (let index = 0; index < rows.length; index += 1) {
            sum += rows[index][metricKey];
            if (index >= size) sum -= rows[index - size][metricKey];
            if (index < size - 1) continue;
            averaged.push(Object.freeze({
                ...rows[index],
                [metricKey]: sum / size,
                hltvV2AverageWindow: size,
                hltvV2AverageStartTimestamp: rows[index - size + 1].timestamp,
            }));
        }
        return averaged;
    }

    function utcCalendarDay(timestamp) {
        const value = Number(timestamp);
        if (!Number.isFinite(value) || value <= 0) return null;
        const day = Math.floor(value / MILLISECONDS_PER_UTC_DAY) * MILLISECONDS_PER_UTC_DAY;
        return Number.isFinite(new Date(day).getTime()) ? day : null;
    }

    function normaliseCompareDayWindow(value) {
        const parsed = Number(value);
        return Number.isInteger(parsed)
            && parsed >= MIN_COMPARE_DAY_WINDOW
            && parsed <= MAX_COMPARE_DAY_WINDOW
            ? parsed
            : DEFAULT_COMPARE_DAY_WINDOW;
    }

    function trailingCalendarDayRows(
        rows,
        metricKey,
        windowDays = DEFAULT_COMPARE_DAY_WINDOW,
        displayedStartTimestamp = null,
        displayedEndTimestamp = null,
    ) {
        const size = normaliseCompareDayWindow(windowDays);
        const usableRows = rows.filter((row) => (
            utcCalendarDay(row?.timestamp) !== null && Number.isFinite(row?.[metricKey])
        )).slice().sort((first, second) => first.timestamp - second.timestamp);
        if (!usableRows.length) return [];
        const firstDay = utcCalendarDay(
            displayedStartTimestamp ?? usableRows[0].timestamp,
        );
        const lastDay = utcCalendarDay(
            displayedEndTimestamp ?? usableRows[usableRows.length - 1].timestamp,
        );
        if (firstDay === null || lastDay === null || lastDay < firstDay) {
            throw new RangeError('The comparison calendar span is invalid.');
        }
        const dayCount = Math.floor(
            (lastDay - firstDay) / MILLISECONDS_PER_UTC_DAY,
        ) + 1;
        if (!Number.isSafeInteger(dayCount) || dayCount > MAX_COMPARE_CALENDAR_DAYS) {
            throw new RangeError(
                `The selected histories span more than ${MAX_COMPARE_CALENDAR_DAYS.toLocaleString('en-US')} calendar days and cannot be graphed safely.`,
            );
        }

        const result = [];
        let left = 0;
        let right = 0;
        let sum = 0;
        let count = 0;
        for (let dayIndex = 0; dayIndex < dayCount; dayIndex += 1) {
            const day = firstDay + (dayIndex * MILLISECONDS_PER_UTC_DAY);
            const nextDay = day + MILLISECONDS_PER_UTC_DAY;
            const windowStart = day - ((size - 1) * MILLISECONDS_PER_UTC_DAY);
            while (right < usableRows.length && usableRows[right].timestamp < nextDay) {
                sum += usableRows[right][metricKey];
                count += 1;
                right += 1;
            }
            while (left < right && usableRows[left].timestamp < windowStart) {
                sum -= usableRows[left][metricKey];
                count -= 1;
                left += 1;
            }
            result.push(Object.freeze({
                timestamp: day,
                [metricKey]: count === 0 ? null : sum / count,
                hltvV2CalendarWindowDays: size,
                hltvV2AverageStartTimestamp: windowStart,
                hltvV2AverageEndTimestamp: day,
                hltvV2MapCount: count,
            }));
        }
        return result;
    }

    function contiguousFiniteSegments(rows, metricKey) {
        const segments = [];
        let current = [];
        for (const row of rows) {
            if (Number.isFinite(row?.[metricKey])) {
                current.push(row);
            } else if (current.length) {
                segments.push(current);
                current = [];
            }
        }
        if (current.length) segments.push(current);
        return segments;
    }

    function linearTrendEndpoints(rows, metricKey) {
        const usableRows = rows.filter((row) => (
            Number.isFinite(row?.timestamp) && Number.isFinite(row?.[metricKey])
        ));
        if (usableRows.length < 2) return null;
        const meanTimestamp = usableRows.reduce((sum, row) => sum + row.timestamp, 0)
            / usableRows.length;
        const meanValue = usableRows.reduce((sum, row) => sum + row[metricKey], 0)
            / usableRows.length;
        let covariance = 0;
        let timestampVariance = 0;
        for (const row of usableRows) {
            const timestampDelta = row.timestamp - meanTimestamp;
            covariance += timestampDelta * (row[metricKey] - meanValue);
            timestampVariance += timestampDelta ** 2;
        }
        if (!(timestampVariance > 0)) return null;
        const slope = covariance / timestampVariance;
        const firstTimestamp = usableRows.reduce(
            (minimum, row) => Math.min(minimum, row.timestamp),
            Infinity,
        );
        const lastTimestamp = usableRows.reduce(
            (maximum, row) => Math.max(maximum, row.timestamp),
            -Infinity,
        );
        return Object.freeze({
            firstTimestamp,
            firstValue: meanValue + (slope * (firstTimestamp - meanTimestamp)),
            lastTimestamp,
            lastValue: meanValue + (slope * (lastTimestamp - meanTimestamp)),
        });
    }

    function renderComparisonTrendGraph(container, histories, names, metric, options = {}) {
        container.replaceChildren();
        const requestedSeries = Array.isArray(options.seriesIndices)
            ? options.seriesIndices
            : histories.map((_, index) => index);
        const selectedSeries = [...new Set(requestedSeries)]
            .filter((index) => Number.isInteger(index)
                && index >= 0
                && index < histories.length
                && histories[index]?.rows);
        const calendarDayWindow = options.calendarDayWindow === true;
        const calendarDayWindowDays = normaliseCompareDayWindow(
            options.calendarDayWindowDays,
        );
        const rollingAverage = !calendarDayWindow && options.rollingAverage === true;
        const showPoints = options.showPoints !== false;
        const showTrendLine = options.showTrendLine === true;
        const rawSeries = selectedSeries.map((sourceIndex) => {
            const datedRows = histories[sourceIndex].rows
                .filter((row) => utcCalendarDay(row.timestamp) !== null)
                .slice()
                .sort((first, second) => first.timestamp - second.timestamp);
            const rawRows = datedRows.filter((row) => Number.isFinite(row[metric.key]));
            return Object.freeze({
                sourceIndex,
                name: names[sourceIndex] || `Player ${sourceIndex + 1}`,
                rawCount: rawRows.length,
                rawRows,
                datedRows,
            });
        });
        if (!rawSeries.length || rawSeries.some((entry) => entry.rawRows.length === 0)) {
            const message = rollingAverage
                ? `At least ${COMPARE_MAP_AVERAGE_WINDOW} ${metric.label} maps are required for each selected player's ${COMPARE_MAP_AVERAGE_WINDOW}-map average.`
                : `${metric.label} is unavailable for one of the selected histories.`;
            container.appendChild(createElement(
                'p',
                'hltv-v2-unavailable',
                message,
            ));
            return;
        }
        const rawTimestamps = rawSeries.flatMap((entry) => (
            (calendarDayWindow ? entry.datedRows : entry.rawRows)
                .map((row) => row.timestamp)
        ));
        const sharedStartDay = utcCalendarDay(Math.min(...rawTimestamps));
        const sharedEndDay = utcCalendarDay(Math.max(...rawTimestamps));
        let series;
        try {
            series = rawSeries.map((entry) => {
                const rows = calendarDayWindow
                    ? trailingCalendarDayRows(
                        entry.rawRows,
                        metric.key,
                        calendarDayWindowDays,
                        sharedStartDay,
                        sharedEndDay,
                    )
                    : rollingAverage
                        ? trailingAverageRows(
                            entry.rawRows,
                            metric.key,
                            COMPARE_MAP_AVERAGE_WINDOW,
                        )
                        : entry.rawRows;
                return Object.freeze({
                    ...entry,
                    rows,
                    finiteRows: rows.filter((row) => Number.isFinite(row[metric.key])),
                    trend: showTrendLine ? linearTrendEndpoints(rows, metric.key) : null,
                });
            });
        } catch (error) {
            container.appendChild(createElement(
                'p',
                'hltv-v2-unavailable',
                cleanText(error?.message || 'The comparison graph could not be generated safely.'),
            ));
            return;
        }
        if (series.some((entry) => entry.finiteRows.length === 0)) {
            const message = rollingAverage
                ? `At least ${COMPARE_MAP_AVERAGE_WINDOW} ${metric.label} maps are required for each selected player's ${COMPARE_MAP_AVERAGE_WINDOW}-map average.`
                : `${metric.label} is unavailable for one of the selected histories.`;
            container.appendChild(createElement('p', 'hltv-v2-unavailable', message));
            return;
        }
        const allFiniteRows = series.flatMap((entry) => entry.finiteRows);
        const timestamps = allFiniteRows.map((row) => row.timestamp);
        const values = [
            ...allFiniteRows.map((row) => row[metric.key]),
            ...series.flatMap((entry) => entry.trend
                ? [entry.trend.firstValue, entry.trend.lastValue]
                : []),
        ];
        const minimumTimestamp = calendarDayWindow
            ? sharedStartDay
            : Math.min(...timestamps);
        const maximumTimestamp = calendarDayWindow
            ? sharedEndDay
            : Math.max(...timestamps);
        let minimumValue = Math.min(...values);
        let maximumValue = Math.max(...values);
        if (minimumValue === maximumValue) {
            const padding = Math.max(0.05, Math.abs(minimumValue) * 0.05);
            minimumValue -= padding;
            maximumValue += padding;
        } else {
            const padding = (maximumValue - minimumValue) * 0.06;
            minimumValue -= padding;
            maximumValue += padding;
        }

        const width = 900;
        const height = 310;
        const margin = Object.freeze({ top: 18, right: 20, bottom: 52, left: 68 });
        const plotWidth = width - margin.left - margin.right;
        const plotHeight = height - margin.top - margin.bottom;
        const x = (timestamp) => margin.left + (
            maximumTimestamp === minimumTimestamp
                ? plotWidth / 2
                : ((timestamp - minimumTimestamp) / (maximumTimestamp - minimumTimestamp)) * plotWidth
        );
        const y = (value) => margin.top
            + ((maximumValue - value) / (maximumValue - minimumValue)) * plotHeight;
        const svg = createSvgElement('svg');
        svg.setAttribute('viewBox', `0 0 ${width} ${height}`);
        svg.setAttribute('role', 'img');
        svg.setAttribute(
            'aria-label',
            `${calendarDayWindow
                ? `${calendarDayWindowDays}-day trailing mean `
                : rollingAverage ? `${COMPARE_MAP_AVERAGE_WINDOW}-map average ` : ''}${metric.label} by ${calendarDayWindow
                ? 'calendar date'
                : 'match date'} for ${series
                .map((entry) => entry.name).join(' and ')}`,
        );

        const yTickCount = 5;
        for (let index = 0; index < yTickCount; index += 1) {
            const ratio = index / (yTickCount - 1);
            const tickValue = maximumValue - ((maximumValue - minimumValue) * ratio);
            const tickY = margin.top + (plotHeight * ratio);
            const grid = createSvgElement('line', 'hltv-v2-compare-grid');
            grid.setAttribute('x1', String(margin.left));
            grid.setAttribute('x2', String(width - margin.right));
            grid.setAttribute('y1', String(tickY));
            grid.setAttribute('y2', String(tickY));
            svg.appendChild(grid);
            const label = createSvgElement('text', 'hltv-v2-compare-tick-label');
            label.setAttribute('x', String(margin.left - 8));
            label.setAttribute('y', String(tickY + 4));
            label.setAttribute('text-anchor', 'end');
            label.textContent = tickValue.toFixed(metric.digits);
            svg.appendChild(label);
        }

        const xTickCount = maximumTimestamp === minimumTimestamp ? 1 : 5;
        for (let index = 0; index < xTickCount; index += 1) {
            const ratio = xTickCount === 1 ? 0.5 : index / (xTickCount - 1);
            const tickTimestamp = minimumTimestamp
                + ((maximumTimestamp - minimumTimestamp) * ratio);
            const tickX = margin.left + (plotWidth * ratio);
            const tick = createSvgElement('line', 'hltv-v2-compare-axis');
            tick.setAttribute('x1', String(tickX));
            tick.setAttribute('x2', String(tickX));
            tick.setAttribute('y1', String(height - margin.bottom));
            tick.setAttribute('y2', String(height - margin.bottom + 5));
            svg.appendChild(tick);
            const label = createSvgElement('text', 'hltv-v2-compare-tick-label');
            label.setAttribute('x', String(tickX));
            label.setAttribute('y', String(height - margin.bottom + 19));
            label.setAttribute('text-anchor', 'middle');
            label.textContent = graphDateLabel(tickTimestamp);
            svg.appendChild(label);
        }

        const xAxis = createSvgElement('line', 'hltv-v2-compare-axis');
        xAxis.setAttribute('x1', String(margin.left));
        xAxis.setAttribute('x2', String(width - margin.right));
        xAxis.setAttribute('y1', String(height - margin.bottom));
        xAxis.setAttribute('y2', String(height - margin.bottom));
        const yAxis = createSvgElement('line', 'hltv-v2-compare-axis');
        yAxis.setAttribute('x1', String(margin.left));
        yAxis.setAttribute('x2', String(margin.left));
        yAxis.setAttribute('y1', String(margin.top));
        yAxis.setAttribute('y2', String(height - margin.bottom));
        svg.append(xAxis, yAxis);

        const xLabel = createSvgElement('text', 'hltv-v2-compare-axis-label');
        xLabel.setAttribute('x', String(margin.left + (plotWidth / 2)));
        xLabel.setAttribute('y', String(height - 8));
        xLabel.setAttribute('text-anchor', 'middle');
        xLabel.textContent = calendarDayWindow ? 'Calendar date' : 'Match date';
        const yLabel = createSvgElement('text', 'hltv-v2-compare-axis-label');
        yLabel.setAttribute('x', String(-(margin.top + (plotHeight / 2))));
        yLabel.setAttribute('y', '16');
        yLabel.setAttribute('text-anchor', 'middle');
        yLabel.setAttribute('transform', 'rotate(-90)');
        yLabel.textContent = metric.label;
        svg.append(xLabel, yLabel);

        const pointPopup = showPoints
            ? createElement('div', 'hltv-v2-compare-point-popup')
            : null;
        if (pointPopup) {
            pointPopup.hidden = true;
            pointPopup.setAttribute('role', 'status');
            pointPopup.setAttribute('aria-live', 'polite');
        }
        let activeCircle = null;
        let dailyHoverCircle = null;
        let activeDailyHoverKey = null;
        const clearActivePoint = () => {
            if (activeCircle) {
                activeCircle.classList.remove('hltv-v2-compare-point-pinned');
                if (activeCircle.hasAttribute('aria-pressed')) {
                    activeCircle.setAttribute('aria-pressed', 'false');
                }
                activeCircle.setAttribute('r', '3.5');
                if (activeCircle === dailyHoverCircle) {
                    activeCircle.setAttribute('visibility', 'hidden');
                }
            }
            activeCircle = null;
            activeDailyHoverKey = null;
            if (pointPopup) {
                pointPopup.hidden = true;
                pointPopup.textContent = '';
            }
        };
        const activatePoint = (circle, text) => {
            if (!pointPopup) return;
            if (activeCircle !== circle) {
                clearActivePoint();
                activeCircle = circle;
            }
            circle.classList.add('hltv-v2-compare-point-pinned');
            if (circle.hasAttribute('aria-pressed')) {
                circle.setAttribute('aria-pressed', 'true');
            }
            circle.setAttribute('r', '5.5');
            pointPopup.textContent = text;
            pointPopup.hidden = false;
            const pointRect = circle.getBoundingClientRect();
            const containerRect = container.getBoundingClientRect();
            pointPopup.style.left = `${pointRect.left - containerRect.left
                + (pointRect.width / 2)}px`;
            pointPopup.style.top = `${pointRect.top - containerRect.top}px`;
        };
        const clearPointIfActive = (circle) => {
            if (activeCircle === circle) clearActivePoint();
        };
        const pointTextForRow = (entry, row) => {
            const date = graphDateLabel(row.timestamp);
            const value = row[metric.key].toFixed(metric.digits);
            if (calendarDayWindow) {
                const windowStart = graphDateLabel(row.hltvV2AverageStartTimestamp);
                const mapCount = row.hltvV2MapCount;
                return [
                    entry.name,
                    `${windowStart} to ${date} · ${mapCount} ${mapCount === 1 ? 'map' : 'maps'}`,
                    `${metric.label} mean: ${value}`,
                ].join('\n');
            }
            const matchup = row.team || row.opponent
                ? `${row.team || 'Unknown team'} vs ${row.opponent || 'Unknown opponent'}`
                : 'Teams unavailable';
            const kd = Number.isFinite(row.kills) && Number.isFinite(row.deaths)
                ? ` · K-D ${row.kills} - ${row.deaths}`
                : '';
            return [
                entry.name,
                rollingAverage
                    ? `${COMPARE_MAP_AVERAGE_WINDOW}-map average ending ${date}`
                    : matchup,
                rollingAverage ? `End map: ${matchup}` : null,
                `${date} · ${row.map || 'Unknown map'}${kd}`,
                `${rollingAverage ? `${COMPARE_MAP_AVERAGE_WINDOW}-map average ` : ''}${metric.label}: ${value}`,
            ].filter(Boolean).join('\n');
        };

        series.forEach((entry) => {
            const {
                rows,
                finiteRows,
                sourceIndex,
                trend,
            } = entry;
            const lineClass = sourceIndex === 0
                ? 'hltv-v2-compare-series-left'
                : 'hltv-v2-compare-series-right';
            if (trend) {
                const trendLine = createSvgElement(
                    'line',
                    `hltv-v2-compare-trend-line ${sourceIndex === 0
                        ? 'hltv-v2-compare-trend-line-left'
                        : 'hltv-v2-compare-trend-line-right'}`,
                );
                trendLine.setAttribute('x1', String(x(trend.firstTimestamp)));
                trendLine.setAttribute('y1', String(y(trend.firstValue)));
                trendLine.setAttribute('x2', String(x(trend.lastTimestamp)));
                trendLine.setAttribute('y2', String(y(trend.lastValue)));
                trendLine.setAttribute('aria-hidden', 'true');
                svg.appendChild(trendLine);
            }
            const segments = contiguousFiniteSegments(rows, metric.key);
            if (calendarDayWindow) {
                const line = createSvgElement('path', lineClass);
                line.setAttribute(
                    'd',
                    segments.map((segment) => segment.map((row, index) => (
                        `${index === 0 ? 'M' : 'L'} ${x(row.timestamp)},${y(row[metric.key])}`
                    )).join(' ')).join(' '),
                );
                svg.appendChild(line);
            } else {
                for (const segment of segments) {
                    const line = createSvgElement('polyline', lineClass);
                    line.setAttribute(
                        'points',
                        segment.map((row) => (
                            `${x(row.timestamp)},${y(row[metric.key])}`
                        )).join(' '),
                    );
                    svg.appendChild(line);
                }
            }
            if (!showPoints) return;
            for (const row of sampledGraphRows(finiteRows)) {
                const circle = createSvgElement(
                    'circle',
                    sourceIndex === 0
                        ? 'hltv-v2-compare-point-left'
                        : 'hltv-v2-compare-point-right',
                );
                circle.setAttribute('cx', String(x(row.timestamp)));
                circle.setAttribute('cy', String(y(row[metric.key])));
                circle.setAttribute('r', '3.5');
                const pointText = pointTextForRow(entry, row);
                if (!calendarDayWindow && row.id) {
                    circle.dataset.hltvV2MatchId = String(row.id);
                }
                circle.setAttribute('role', 'button');
                circle.setAttribute('tabindex', '0');
                circle.setAttribute('aria-pressed', 'false');
                circle.setAttribute(
                    'aria-label',
                    `${pointText.replace(/\n/g, '. ')}. Focus or hover to inspect this point.`,
                );
                circle.addEventListener('pointerenter', () => activatePoint(circle, pointText));
                circle.addEventListener('pointerleave', () => clearPointIfActive(circle));
                circle.addEventListener('focus', () => activatePoint(circle, pointText));
                circle.addEventListener('blur', () => clearPointIfActive(circle));
                circle.addEventListener('keydown', (event) => {
                    if (event.key === 'Enter' || event.key === ' ') {
                        event.preventDefault();
                        activatePoint(circle, pointText);
                    } else if (event.key === 'Escape' && activeCircle === circle) {
                        event.preventDefault();
                        clearActivePoint();
                    }
                });
                svg.appendChild(circle);
            }
        });

        if (calendarDayWindow && showPoints) {
            const lowerBoundTimestamp = (rows, timestamp) => {
                let low = 0;
                let high = rows.length;
                while (low < high) {
                    const middle = low + Math.floor((high - low) / 2);
                    if (rows[middle].timestamp < timestamp) low = middle + 1;
                    else high = middle;
                }
                return low;
            };
            const nearestDailyPoint = (event) => {
                const rect = svg.getBoundingClientRect();
                if (!(rect.width > 0) || !(rect.height > 0)
                    || !Number.isFinite(event.clientX) || !Number.isFinite(event.clientY)) {
                    return null;
                }
                const pointerX = ((event.clientX - rect.left) / rect.width) * width;
                const pointerY = ((event.clientY - rect.top) / rect.height) * height;
                const scale = Math.max(width / rect.width, height / rect.height);
                const hitRadius = COMPARE_DAILY_HIT_RADIUS_PX * scale;
                if (pointerX < margin.left - hitRadius
                    || pointerX > width - margin.right + hitRadius
                    || pointerY < margin.top - hitRadius
                    || pointerY > height - margin.bottom + hitRadius) {
                    return null;
                }
                const timestamp = maximumTimestamp === minimumTimestamp
                    ? minimumTimestamp
                    : minimumTimestamp + (
                        ((pointerX - margin.left) / plotWidth)
                        * (maximumTimestamp - minimumTimestamp)
                    );
                let nearest = null;
                for (const entry of series) {
                    const insertionIndex = lowerBoundTimestamp(entry.finiteRows, timestamp);
                    const firstCandidate = Math.max(0, insertionIndex - 2);
                    const lastCandidate = Math.min(
                        entry.finiteRows.length - 1,
                        insertionIndex + 1,
                    );
                    for (let index = firstCandidate; index <= lastCandidate; index += 1) {
                        const row = entry.finiteRows[index];
                        const pointX = x(row.timestamp);
                        const pointY = y(row[metric.key]);
                        const distanceSquared = ((pointX - pointerX) ** 2)
                            + ((pointY - pointerY) ** 2);
                        if (!nearest || distanceSquared < nearest.distanceSquared) {
                            nearest = {
                                distanceSquared,
                                entry,
                                pointX,
                                pointY,
                                row,
                            };
                        }
                    }
                }
                return nearest && nearest.distanceSquared <= hitRadius ** 2
                    ? nearest
                    : null;
            };
            const showNearestDailyPoint = (event) => {
                const nearest = nearestDailyPoint(event);
                if (!nearest) {
                    clearPointIfActive(dailyHoverCircle);
                    return;
                }
                const nearestKey = `${nearest.entry.sourceIndex}:${nearest.row.timestamp}`;
                if (activeCircle === dailyHoverCircle
                    && activeDailyHoverKey === nearestKey) {
                    return;
                }
                if (!dailyHoverCircle) {
                    dailyHoverCircle = createSvgElement(
                        'circle',
                        'hltv-v2-compare-daily-hover-point',
                    );
                    dailyHoverCircle.setAttribute('aria-hidden', 'true');
                    dailyHoverCircle.setAttribute('visibility', 'hidden');
                    svg.appendChild(dailyHoverCircle);
                }
                dailyHoverCircle.setAttribute(
                    'class',
                    `hltv-v2-compare-daily-hover-point ${nearest.entry.sourceIndex === 0
                        ? 'hltv-v2-compare-point-left'
                        : 'hltv-v2-compare-point-right'}`,
                );
                dailyHoverCircle.setAttribute('cx', String(nearest.pointX));
                dailyHoverCircle.setAttribute('cy', String(nearest.pointY));
                dailyHoverCircle.setAttribute('visibility', 'visible');
                activatePoint(
                    dailyHoverCircle,
                    pointTextForRow(nearest.entry, nearest.row),
                );
                activeDailyHoverKey = nearestKey;
            };
            svg.addEventListener('pointermove', showNearestDailyPoint);
            svg.addEventListener('pointerleave', () => {
                clearPointIfActive(dailyHoverCircle);
            });
        }

        container.appendChild(svg);
        if (pointPopup) container.appendChild(pointPopup);
        if (showPoints
            && series.some((entry) => (
                entry.finiteRows.length > MAX_COMPARE_HOVER_POINTS_PER_SERIES
            ))) {
            container.appendChild(createElement(
                'p',
                'hltv-v2-status',
                calendarDayWindow
                    ? `The lines include every calendar-day mean, and every finite daily value is mouse-inspectable. Visible keyboard-focusable markers are evenly sampled to ${MAX_COMPARE_HOVER_POINTS_PER_SERIES} per player for performance.`
                    : `The lines include every ${rollingAverage ? `${COMPARE_MAP_AVERAGE_WINDOW}-map average` : 'loaded map'}. Interactive points are evenly sampled to ${MAX_COMPARE_HOVER_POINTS_PER_SERIES} per player for performance.`,
            ));
        }
        const legend = createElement('div', 'hltv-v2-compare-legend');
        for (const entry of series) {
            const item = createElement('span', '', entry.name);
            item.style.setProperty(
                '--hltv-v2-legend-color',
                entry.sourceIndex === 0
                    ? COMPARE_SERIES_COLORS.first
                    : COMPARE_SERIES_COLORS.second,
            );
            legend.appendChild(item);
        }
        container.appendChild(legend);
    }

    function csvCell(value) {
        let text = String(value ?? '').replace(/\r?\n/g, ' ');
        if (/^[=+\-@]/.test(text)) text = `'${text}`;
        return `"${text.replace(/"/g, '""')}"`;
    }

    function compareCsv(model) {
        const rows = [
            ['Metric', model.names[0], model.names[1], 'Absolute delta (left-right)', 'Relative delta vs right'],
            ['Filters', model.filters[0], model.filters[1], '', ''],
        ];
        for (const metric of model.metrics) {
            const delta = metric.left - metric.right;
            const relative = metric.right === 0 ? '' : (delta / Math.abs(metric.right)) * 100;
            rows.push([
                metric.label,
                metric.leftText,
                metric.rightText,
                delta,
                relative === '' ? '' : `${relative.toFixed(1)}%`,
            ]);
        }
        return `${rows.map((row) => row.map(csvCell).join(',')).join('\r\n')}\r\n`;
    }

    function downloadCsv(model) {
        const blob = new Blob([compareCsv(model)], { type: 'text/csv;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const link = createElement('a');
        link.href = url;
        link.download = 'hltv-player-comparison.csv';
        link.hidden = true;
        document.body.appendChild(link);
        link.click();
        link.remove();
        globalThis.setTimeout(() => URL.revokeObjectURL(url), 0);
    }

    function cleanupCompareEnhancements() {
        state.compareController?.abort();
        state.compareController = null;
        document.querySelectorAll(
            '.hltv-v2-compare-tools, .hltv-v2-compare-sync-tools, '
            + '.hltv-v2-compare-delta, .hltv-v2-compare-trends',
        )
            .forEach((element) => element.remove());
        document.querySelectorAll('.hltv-v2-compare-higher, .hltv-v2-compare-lower')
            .forEach((element) => element.classList.remove(
                'hltv-v2-compare-higher', 'hltv-v2-compare-lower',
            ));
    }

    function ensureCompareEnhancements() {
        if (!state.settings.enablePlayerComparisonEnhancements
            || !COMPARE_PATH_PATTERN.test(globalThis.location.pathname)) {
            cleanupCompareEnhancements();
            return;
        }
        if (document.querySelector('.hltv-v2-compare-tools')) return;
        const model = parseCompareModel();
        if (!model?.comparisonRows.length) return;

        const headerAbs = createElement('td', 'hltv-v2-compare-delta', 'Δ abs');
        headerAbs.title = 'Left player minus right player.';
        const headerPercent = createElement('td', 'hltv-v2-compare-delta', 'Δ %');
        headerPercent.title = 'Left-minus-right delta as a percentage of the right value.';
        model.firstRow.append(headerAbs, headerPercent);
        let leftLeads = 0;
        let rightLeads = 0;
        let ties = 0;
        for (const metric of model.comparisonRows) {
            if (!metric.available) {
                metric.row.append(
                    createElement('td', 'hltv-v2-compare-delta hltv-v2-unavailable', '—'),
                    createElement('td', 'hltv-v2-compare-delta hltv-v2-unavailable', '—'),
                );
                continue;
            }
            const delta = metric.left - metric.right;
            const places = Math.max(decimalPlaces(metric.leftText), decimalPlaces(metric.rightText), 2);
            const suffix = metric.percentage ? ' pp' : '';
            const absCell = createElement(
                'td',
                'hltv-v2-compare-delta',
                `${delta >= 0 ? '+' : ''}${delta.toFixed(places)}${suffix}`,
            );
            const relative = metric.right === 0 ? null : (delta / Math.abs(metric.right)) * 100;
            const percentCell = createElement(
                'td',
                'hltv-v2-compare-delta',
                Number.isFinite(relative) ? `${relative >= 0 ? '+' : ''}${relative.toFixed(1)}%` : '—',
            );
            metric.row.append(absCell, percentCell);
            if (!metric.direction || Math.abs(delta) < (10 ** -places) / 2) {
                ties += 1;
                continue;
            }
            const leftWins = delta * metric.direction > 0;
            const winner = metric.row.querySelector(leftWins ? '.player1-col' : '.player2-col');
            const loser = metric.row.querySelector(leftWins ? '.player2-col' : '.player1-col');
            winner?.classList.add('hltv-v2-compare-higher');
            loser?.classList.add('hltv-v2-compare-lower');
            if (leftWins) leftLeads += 1;
            else rightLeads += 1;
        }

        const tools = createElement('section', 'hltv-v2-compare-tools');
        const summary = createElement(
            'div',
            'hltv-v2-compare-summary',
            `${model.names[0]} leads ${leftLeads} · ${model.names[1]} leads ${rightLeads} · ${ties} neutral/tied`,
        );
        summary.title = 'A lead only means the directionally preferred displayed value; metrics are not equally weighted.';
        const actions = createElement('div', 'hltv-v2-compare-actions');
        const urls = compareActionUrls();
        if (urls.swap) {
            const swap = createElement('a', 'hltv-v2-link', 'Swap players');
            swap.href = urls.swap.href;
            actions.appendChild(swap);
        }
        if (urls.sync) {
            const sync = createElement('a', 'hltv-v2-link', 'Sync left filters → right');
            sync.href = urls.sync.href;
            const playerColumns = document.querySelector('.stats-player-compare > .columns');
            if (playerColumns) {
                const syncTools = createElement('section', 'hltv-v2-compare-sync-tools');
                syncTools.appendChild(sync);
                playerColumns.before(syncTools);
            } else {
                actions.appendChild(sync);
            }
        }
        const csv = createElement('button', 'hltv-v2-button', 'Export comparison CSV');
        csv.type = 'button';
        csv.addEventListener('click', () => downloadCsv(model));
        actions.appendChild(csv);
        tools.append(summary, actions);

        const trends = createElement('section', 'hltv-v2-compare-trends');
        const trendControls = createElement('div', 'hltv-v2-compare-trend-controls');
        const trendTitle = createElement('span', 'hltv-v2-title', 'Match-history trends');
        const trendMetric = createElement('select', 'hltv-v2-select');
        trendMetric.setAttribute('aria-label', 'Comparison trend metric');
        trendMetric.disabled = true;
        trendMetric.hidden = true;
        let availableTrendRequests = [];
        try {
            availableTrendRequests = compareHistoryRequests();
        } catch {
            // The native page can briefly expose the comparison table before its player URL settles.
        }
        const availableTrendIndices = new Set(
            availableTrendRequests.map((request) => request.sourceIndex),
        );
        const seriesToggles = model.names.map((name, index) => {
            const label = createElement('label', 'hltv-v2-compare-series-toggle');
            const input = document.createElement('input');
            input.type = 'checkbox';
            input.checked = availableTrendIndices.has(index);
            input.dataset.seriesIndex = String(index);
            input.setAttribute('aria-label', `Show ${name} trend`);
            label.hidden = !availableTrendIndices.has(index);
            label.append(input, document.createTextNode(name));
            return input;
        });
        const seriesToggleLabels = seriesToggles.map((input) => input.parentElement);
        const averageLabel = createElement('label', 'hltv-v2-compare-average-toggle');
        const averageToggle = document.createElement('input');
        averageToggle.type = 'checkbox';
        averageToggle.checked = false;
        averageToggle.disabled = true;
        averageToggle.setAttribute(
            'aria-label',
            `Use ${COMPARE_MAP_AVERAGE_WINDOW}-map average`,
        );
        averageLabel.append(
            averageToggle,
            document.createTextNode(`${COMPARE_MAP_AVERAGE_WINDOW}-map average`),
        );
        const dayWindowLabel = createElement('label', 'hltv-v2-compare-day-window-toggle');
        const dayWindowToggle = document.createElement('input');
        dayWindowToggle.type = 'checkbox';
        dayWindowToggle.checked = false;
        dayWindowToggle.disabled = true;
        dayWindowToggle.setAttribute('aria-label', 'Use trailing daily mean');
        dayWindowLabel.append(
            dayWindowToggle,
            document.createTextNode('Trailing daily mean'),
        );
        const dayWindowLengthLabel = createElement(
            'label',
            'hltv-v2-compare-day-window-length',
        );
        dayWindowLengthLabel.hidden = true;
        dayWindowLengthLabel.appendChild(document.createTextNode('Window (days)'));
        const dayWindowLength = document.createElement('input');
        dayWindowLength.type = 'number';
        dayWindowLength.min = String(MIN_COMPARE_DAY_WINDOW);
        dayWindowLength.max = String(MAX_COMPARE_DAY_WINDOW);
        dayWindowLength.step = '1';
        dayWindowLength.value = String(DEFAULT_COMPARE_DAY_WINDOW);
        dayWindowLength.disabled = true;
        dayWindowLength.setAttribute('aria-label', 'Trailing-day window length');
        dayWindowLengthLabel.appendChild(dayWindowLength);
        const pointsLabel = createElement('label', 'hltv-v2-compare-points-toggle');
        const pointsToggle = document.createElement('input');
        pointsToggle.type = 'checkbox';
        pointsToggle.checked = true;
        pointsToggle.disabled = true;
        pointsToggle.setAttribute('aria-label', 'Show graph points');
        pointsLabel.append(pointsToggle, document.createTextNode('Show points'));
        const trendLineLabel = createElement(
            'label',
            'hltv-v2-compare-trend-line-toggle',
        );
        const trendLineToggle = document.createElement('input');
        trendLineToggle.type = 'checkbox';
        trendLineToggle.checked = false;
        trendLineToggle.disabled = true;
        trendLineToggle.setAttribute('aria-label', 'Show linear trend line');
        trendLineLabel.append(
            trendLineToggle,
            document.createTextNode('Linear trend line'),
        );
        const fetchTrends = createElement(
            'button',
            'hltv-v2-button',
            'Fetch comparison trends',
        );
        fetchTrends.type = 'button';
        const trendStatus = createElement(
            'span',
            'hltv-v2-status',
            availableTrendRequests.length === 1
                ? 'Fetches every filtered match-history page for this player.'
                : 'Fetches every filtered match-history page for the selected players.',
        );
        trendStatus.setAttribute('aria-live', 'polite');
        const trendChart = createElement('div', 'hltv-v2-compare-chart');
        trendControls.append(
            trendTitle,
            ...seriesToggleLabels,
            averageLabel,
            dayWindowLabel,
            dayWindowLengthLabel,
            trendLineLabel,
            pointsLabel,
            trendMetric,
            fetchTrends,
            trendStatus,
        );
        trends.append(trendControls, trendChart);

        let loadedHistories = null;
        let fetchingTrends = false;
        const selectedSeriesIndices = () => seriesToggles
            .filter((input) => input.checked)
            .map((input) => Number(input.dataset.seriesIndex));
        const syncTrendControls = () => {
            const selected = selectedSeriesIndices();
            for (const input of seriesToggles) {
                input.disabled = !availableTrendIndices.has(Number(input.dataset.seriesIndex))
                    || fetchingTrends
                    || (selected.length === 1 && input.checked);
            }
            averageToggle.disabled = fetchingTrends || !loadedHistories;
            dayWindowToggle.disabled = fetchingTrends || !loadedHistories;
            dayWindowLength.disabled = fetchingTrends
                || !loadedHistories
                || !dayWindowToggle.checked;
            dayWindowLengthLabel.hidden = !dayWindowToggle.checked;
            pointsToggle.disabled = fetchingTrends || !loadedHistories;
            trendLineToggle.disabled = fetchingTrends || !loadedHistories;
        };
        const renderSelectedTrend = () => {
            const descriptor = COMPARE_TREND_METRICS.find(
                (candidate) => candidate.key === trendMetric.value,
            );
            if (loadedHistories && descriptor) {
                renderComparisonTrendGraph(
                    trendChart,
                    loadedHistories,
                    model.names,
                    descriptor,
                    {
                        seriesIndices: selectedSeriesIndices(),
                        rollingAverage: averageToggle.checked,
                        calendarDayWindow: dayWindowToggle.checked,
                        calendarDayWindowDays: normaliseCompareDayWindow(
                            dayWindowLength.value,
                        ),
                        showPoints: pointsToggle.checked,
                        showTrendLine: trendLineToggle.checked,
                    },
                );
            }
        };
        trendMetric.addEventListener('change', renderSelectedTrend);
        for (const input of seriesToggles) {
            input.addEventListener('change', () => {
                if (!selectedSeriesIndices().length) input.checked = true;
                if (loadedHistories) {
                    syncMetricOptions(
                        trendMetric,
                        loadedHistories,
                        selectedSeriesIndices(),
                    );
                }
                syncTrendControls();
                renderSelectedTrend();
            });
        }
        averageToggle.addEventListener('change', () => {
            if (averageToggle.checked) dayWindowToggle.checked = false;
            syncTrendControls();
            renderSelectedTrend();
        });
        dayWindowToggle.addEventListener('change', () => {
            if (dayWindowToggle.checked) averageToggle.checked = false;
            syncTrendControls();
            renderSelectedTrend();
        });
        dayWindowLength.addEventListener('change', () => {
            dayWindowLength.value = String(normaliseCompareDayWindow(dayWindowLength.value));
            renderSelectedTrend();
        });
        pointsToggle.addEventListener('change', renderSelectedTrend);
        trendLineToggle.addEventListener('change', renderSelectedTrend);
        fetchTrends.addEventListener('click', async () => {
            state.compareController?.abort();
            const controller = new AbortController();
            state.compareController = controller;
            fetchTrends.disabled = true;
            fetchingTrends = true;
            loadedHistories = null;
            trendMetric.disabled = true;
            trendMetric.hidden = true;
            syncTrendControls();
            trendStatus.dataset.kind = '';
            trendChart.replaceChildren();
            try {
                const requests = compareHistoryRequests(Date.now(), selectedSeriesIndices());
                const histories = Array(model.names.length).fill(null);
                for (const request of requests) {
                    const playerIndex = request.sourceIndex;
                    const name = model.names[playerIndex] || `Player ${playerIndex + 1}`;
                    const history = await fetchAllMatchHistory(request.url, {
                        signal: controller.signal,
                        onProgress(progress) {
                            trendStatus.textContent = progress.pages
                                ? `${name}: ${progress.pages} page(s), ${progress.rows} unique maps…`
                                : `${name}: fetching first filtered match-history page…`;
                        },
                        onRetry(progress) {
                            trendStatus.textContent = `${name}: request failed; retrying in ${Math.round(progress.delayMs / 1000)} seconds…`;
                            trendStatus.dataset.kind = 'warning';
                        },
                    });
                    if (controller.signal.aborted) return;
                    histories[playerIndex] = history;
                }
                loadedHistories = Object.freeze(histories);
                const availableMetrics = syncMetricOptions(
                    trendMetric,
                    loadedHistories,
                    selectedSeriesIndices(),
                );
                if (!availableMetrics.length) {
                    throw new Error('No trend metric was available for the selected histories.');
                }
                syncTrendControls();
                const loaded = histories.map((history, index) => ({ history, index }))
                    .filter((entry) => entry.history?.rows);
                const warnings = loaded.map((entry) => entry.history.warning).filter(Boolean);
                trendStatus.textContent = loaded.map((entry) => (
                    `${entry.history.rows.length} ${model.names[entry.index] || `Player ${entry.index + 1}`} maps`
                )).join(' and ');
                trendStatus.textContent = `Loaded ${trendStatus.textContent}.`;
                if (warnings.length) {
                    trendStatus.textContent += ` ${warnings.join(' ')}`;
                    trendStatus.dataset.kind = 'warning';
                } else trendStatus.dataset.kind = '';
                renderSelectedTrend();
            } catch (error) {
                if (error?.name === 'AbortError') return;
                loadedHistories = null;
                trendMetric.replaceChildren();
                trendMetric.disabled = true;
                trendMetric.hidden = true;
                syncTrendControls();
                trendStatus.textContent = cleanText(
                    error?.message || 'Comparison match histories could not be loaded.',
                );
                trendStatus.dataset.kind = 'error';
            } finally {
                if (state.compareController === controller) {
                    state.compareController = null;
                    fetchTrends.disabled = false;
                    fetchingTrends = false;
                    syncTrendControls();
                }
            }
        });
        syncTrendControls();

        const nativeGraph = model.table.closest('.stats-bar-graph');
        if (nativeGraph) {
            nativeGraph.before(tools);
            nativeGraph.after(trends);
        } else {
            model.table.parentElement?.insertBefore(tools, model.table);
            model.table.parentElement?.appendChild(trends);
        }
    }

    function cleanupAll() {
        cleanupPlayerAnalytics();
        cleanupConsistency();
        cleanupPreviousPeriod();
        cleanupCompareEnhancements();
        document.getElementById(STYLE_ID)?.remove();
    }

    function stopObservingPage() {
        state.mutationObserver?.disconnect();
        state.mutationObserver = null;
    }

    async function sync() {
        if (!state.ready || state.destroyed) return;
        if (!anyFeatureEnabled()) {
            stopObservingPage();
            stopListeningForRoutes();
            cleanupAll();
            return;
        }
        startListeningForRoutes();
        if (!routeSupportsFeatures()) {
            stopObservingPage();
            cleanupAll();
            return;
        }
        observePage();
        ensureStyles();
        ensurePlayerAnalytics();
        ensureConsistency();
        const pathname = globalThis.location.pathname;
        const periodComparisonEnabled = (
            state.settings.enablePlayerPagePeriodComparison
            && (PLAYER_PATH_PATTERN.test(pathname) || PLAYER_INDIVIDUAL_PATH_PATTERN.test(pathname))
        ) || (
            state.settings.enableStatsTablePeriodComparison
            && RANKING_PATH_PATTERN.test(pathname)
        );
        if (!periodComparisonEnabled) cleanupPreviousPeriod();
        else {
            await ensurePlayerPreviousPeriod();
            await ensureRankingPreviousPeriod();
        }
        ensureCompareEnhancements();
    }

    function scheduleSync() {
        if (state.destroyed || state.syncTimer) return;
        state.syncTimer = globalThis.setTimeout(() => {
            state.syncTimer = 0;
            sync().catch(() => undefined);
        }, 40);
    }

    function mutationElementHasOwnedMarker(element) {
        if (element.hasAttribute('data-hltv-v2-managed-column')
            || element.hasAttribute('data-hltv-win-adjusted-col')
            || element.classList.contains('tmKprRangeCol')) {
            return true;
        }
        for (const className of element.classList) {
            if (className.startsWith('hltv-v2-')
                && !NATIVE_STATS_DECORATION_CLASSES.has(className)) return true;
        }
        return false;
    }

    function mutationNodeIsExtensionOwned(node) {
        const element = node instanceof Element ? node : node?.parentElement;
        if (!element) return false;
        const nativeStatsTable = element.closest(NATIVE_STATS_TABLE_SELECTOR);
        for (let current = element; current; current = current.parentElement) {
            if (current === nativeStatsTable) return false;
            if (mutationElementHasOwnedMarker(current)) return true;
        }
        return false;
    }

    function movedNativeMutationNodes(mutations) {
        const removedNodes = new Set();
        for (const mutation of mutations) {
            for (const node of mutation.removedNodes) {
                if (node instanceof Element
                    && node.matches(EXTENSION_MOVED_NATIVE_MUTATION_SELECTOR)) {
                    removedNodes.add(node);
                }
            }
        }
        const movedNodes = new Set();
        for (const mutation of mutations) {
            for (const node of mutation.addedNodes) {
                if (removedNodes.has(node)) movedNodes.add(node);
            }
        }
        return movedNodes;
    }

    function mutationChangedNodeIsExtensionOwned(node, movedNodes) {
        return mutationNodeIsExtensionOwned(node)
            || (node instanceof Element && movedNodes.has(node));
    }

    function mutationIsExtensionOwned(mutation, movedNodes) {
        if (!mutation.addedNodes.length && !mutation.removedNodes.length) {
            return mutationNodeIsExtensionOwned(mutation.target);
        }
        for (const node of mutation.addedNodes) {
            if (!mutationChangedNodeIsExtensionOwned(node, movedNodes)) return false;
        }
        for (const node of mutation.removedNodes) {
            if (!mutationChangedNodeIsExtensionOwned(node, movedNodes)) return false;
        }
        return true;
    }

    function observePage() {
        if (state.mutationObserver || typeof MutationObserver !== 'function') return;
        state.mutationObserver = new MutationObserver((mutations) => {
            if (!routeSupportsFeatures()) {
                stopObservingPage();
                cleanupAll();
                return;
            }
            const movedNodes = movedNativeMutationNodes(mutations);
            const hasNativeMutation = mutations.some(
                (mutation) => !mutationIsExtensionOwned(mutation, movedNodes),
            );
            if (hasNativeMutation) scheduleSync();
        });
        state.mutationObserver.observe(document.documentElement, { childList: true, subtree: true });
    }

    function startListeningForRoutes() {
        if (state.routeListener || typeof globalThis.addEventListener !== 'function') return;
        state.routeListener = () => {
            if (!routeSupportsFeatures()) {
                stopObservingPage();
                cleanupAll();
                return;
            }
            scheduleSync();
        };
        globalThis.addEventListener('popstate', state.routeListener);
    }

    function stopListeningForRoutes() {
        if (!state.routeListener) return;
        globalThis.removeEventListener?.('popstate', state.routeListener);
        state.routeListener = null;
    }

    async function initialise() {
        let stored = {};
        try {
            stored = await extensionApi?.storage?.local?.get?.([
                ...Object.keys(SETTING_DEFAULTS),
                'enablePreviousPeriodComparison',
            ]) || {};
        } catch {
            stored = {};
        }
        if (state.destroyed) return;
        state.settings = normaliseSettings(stored);
        if (Object.hasOwn(stored, 'enablePreviousPeriodComparison')) {
            const migrated = {};
            for (const key of [
                'enableStatsTablePeriodComparison',
                'enablePlayerPagePeriodComparison',
            ]) {
                if (!Object.hasOwn(stored, key)) migrated[key] = state.settings[key];
            }
            if (Object.keys(migrated).length) {
                try {
                    await extensionApi?.storage?.local?.set?.(migrated);
                } catch {
                    // The in-memory migration remains valid for this page session.
                }
            }
        }
        if (state.destroyed) return;
        state.ready = true;
        if (extensionApi?.storage?.onChanged?.addListener) {
            state.storageListener = (changes, areaName) => {
                if (areaName !== 'local' || !changes) return;
                let relevant = false;
                for (const key of Object.keys(SETTING_DEFAULTS)) {
                    if (!Object.hasOwn(changes, key)) continue;
                    const value = changes[key]?.newValue;
                    const normalisedValue = BOOLEAN_SETTINGS.has(key)
                        ? value === true
                        : canonicalMetricKey(value) || SETTING_DEFAULTS.previousPeriodMetric;
                    if (state.settings[key] === normalisedValue) continue;
                    state.settings[key] = normalisedValue;
                    relevant = true;
                }
                if (relevant) {
                    cleanupAll();
                    if (!anyFeatureEnabled()) {
                        if (state.syncTimer) globalThis.clearTimeout(state.syncTimer);
                        state.syncTimer = 0;
                        stopObservingPage();
                        stopListeningForRoutes();
                        return;
                    }
                    scheduleSync();
                }
            };
            extensionApi.storage.onChanged.addListener(state.storageListener);
        }
        await sync();
    }

    function destroy() {
        if (state.destroyed) return;
        state.destroyed = true;
        if (state.syncTimer) globalThis.clearTimeout(state.syncTimer);
        state.syncTimer = 0;
        stopObservingPage();
        stopListeningForRoutes();
        if (state.storageListener) {
            extensionApi?.storage?.onChanged?.removeListener?.(state.storageListener);
            state.storageListener = null;
        }
        cleanupAll();
        historyCache.clear();
        historyCacheWeightBytes = 0;
        pageCache.clear();
        pageCacheWeightBytes = 0;
    }

    const readyPromise = initialise();
    const api = Object.freeze({
        ready: () => readyPromise,
        sync,
        destroy,
        getPreviousPeriodModel: () => state.previousPeriodModel,
        constants: Object.freeze({
            settings: SETTING_DEFAULTS,
            historyCacheTtlMs: HISTORY_CACHE_TTL_MS,
            maxHistoryCacheEntries: MAX_HISTORY_CACHE_ENTRIES,
            maxHistoryRetainedWeightBytes: MAX_HISTORY_RETAINED_WEIGHT_BYTES,
            maxHistoryCacheWeightBytes: MAX_HISTORY_CACHE_WEIGHT_BYTES,
            maxHistoryCumulativeResponseBytes: MAX_HISTORY_CUMULATIVE_RESPONSE_BYTES,
            historyRowFixedWeightBytes: HISTORY_ROW_FIXED_WEIGHT_BYTES,
            maxHistoryIdChars: MAX_HISTORY_ID_CHARS,
            maxHistoryUrlChars: MAX_HISTORY_URL_CHARS,
            maxHistoryDateChars: MAX_HISTORY_DATE_CHARS,
            maxHistoryTeamChars: MAX_HISTORY_TEAM_CHARS,
            maxHistoryMapChars: MAX_HISTORY_MAP_CHARS,
            maxPageCacheEntries: MAX_PAGE_CACHE_ENTRIES,
            maxPageCacheWeightBytes: MAX_PAGE_CACHE_WEIGHT_BYTES,
            fetchThrottleMs: FETCH_THROTTLE_MS,
            consistencyInitialDelayMs: CONSISTENCY_INITIAL_DELAY_MS,
            consistencyRetryDelayMs: CONSISTENCY_RETRY_DELAY_MS,
            consistencySecondRetryDelayMs: CONSISTENCY_SECOND_RETRY_DELAY_MS,
            maxHistoryPages: MAX_HISTORY_PAGES,
            maxHistoryRows: MAX_HISTORY_ROWS,
            maxCompareHoverPointsPerSeries: MAX_COMPARE_HOVER_POINTS_PER_SERIES,
            compareMapAverageWindow: COMPARE_MAP_AVERAGE_WINDOW,
            compareSeriesColors: COMPARE_SERIES_COLORS,
            defaultCompareDayWindow: DEFAULT_COMPARE_DAY_WINDOW,
            minCompareDayWindow: MIN_COMPARE_DAY_WINDOW,
            maxCompareDayWindow: MAX_COMPARE_DAY_WINDOW,
            maxCompareCalendarDays: MAX_COMPARE_CALENDAR_DAYS,
        }),
        testing: Object.freeze({
            aggregateMapRows,
            availableCompareTrendMetrics,
            syncMetricOptions,
            compareCsv,
            compareHistoryRequests,
            computeConsistency,
            consistencyClass,
            consistencyDescription,
            csvCell,
            delay,
            extractPlayerMetrics,
            extractRankingMetrics,
            estimateRankingKprBounds,
            fetchCachedPage,
            fetchAllMatchHistory,
            historyRowWeightBytes,
            nextHistoryPage,
            normaliseMapName,
            normaliseSettings,
            parseCompareModel,
            parseMatchRows,
            previousPeriodUrl,
            renderComparisonTrendGraph,
            renderMapMatrix,
            sampledGraphRows,
            trailingAverageRows,
            trailingCalendarDayRows,
            contiguousFiniteSegments,
            linearTrendEndpoints,
            normaliseCompareDayWindow,
            cacheSizes: () => Object.freeze({
                history: historyCache.size,
                historyWeightBytes: historyCacheWeightBytes,
                page: pageCache.size,
                pageWeightBytes: pageCacheWeightBytes,
            }),
        }),
    });
    Object.defineProperty(globalThis, GLOBAL_NAME, {
        configurable: false,
        enumerable: false,
        writable: false,
        value: api,
    });
})();
