// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Plennhar

(() => {
    'use strict';

    function deepFreeze(value) {
        if (!value || typeof value !== 'object' || Object.isFrozen(value)) return value;
        for (const child of Object.values(value)) deepFreeze(child);
        return Object.freeze(value);
    }

    const CONFIG = deepFreeze({
        moduleName: 'HLTV match prediction',
        globalName: 'HLTV_MATCH_PREDICTION_V21',
        requestType: 'hltv-sp:get-match-analytics',
        fetchType: 'hltv-sp:fetch-match-analytics',
        cancelType: 'hltv-sp:cancel-match-analytics',
        transportTimeoutMs: 12_000,
        maximumTransportRequests: 8,
        styleId: 'hltv-sp-match-prediction-style',
        cardId: 'hltv-sp-match-prediction',
        cacheKey: 'matchPredictionCacheV2',
        archiveKeyPrefix: 'matchPredictionArchiveV2:',
        legacyArchiveKeyPrefix: 'matchPredictionArchiveV1:',
        archiveSchemaVersion: 2,
        predictionModelVersion: 'lineup-map-1',
        enableKey: 'enableMatchPrediction',
        modeKey: 'matchPredictionMode',
        defaultEnabled: true,
        defaultMode: 'stats',
        modes: ['market', 'stats'],
        route: /^\/matches\/(\d{1,20})(?:\/|$)/,
        analyticsRoute: /^\/betting\/analytics\/(\d{1,20})(?:\/|$)/,
        maximumNameLength: 80,
        maximumMaps: 9,
        maximumPlayersPerTeam: 12,
        maximumProviders: 100,
        maximumAnalyticsHtmlCharacters: 4 * 1024 * 1024,
        maximumInlineLineupCharacters: 128 * 1024,
        maximumChartConfigCharacters: 512 * 1024,
        maximumFormatCharacters: 300,
        maximumCacheEntries: 20,
        maximumCachedInputCharacters: 256 * 1024,
        maximumArchiveEntries: 50,
        maximumArchiveEntryCharacters: 64 * 1024,
        maximumExplanationTextCharacters: 16 * 1024,
        maximumExplanationEquations: 20,
        maximumExplanationEquationCharacters: 2 * 1024,
        timestampToleranceMs: 60_000,
        liveSafetyGraceMs: 0,
        refresh: {
            earlyMs: 30 * 60_000,
            nearMs: 5 * 60_000,
            vetoMs: 90_000,
            nearThresholdMs: 60 * 60_000,
            vetoThresholdMs: 10 * 60_000,
            minimumTimerMs: 1_000,
        },
        probability: {
            epsilon: 0.000001,
            displayMinimum: 0.02,
            displayMaximum: 0.98,
            bisectionIterations: 60,
        },
        market: {
            minimumOdds: 1.01,
            maximumOdds: 100,
            minimumImpliedSum: 0.90,
            maximumImpliedSum: 1.25,
            minimumOutlierLimit: 0.025,
            madMultiplier: 4,
            fullReliabilityProviders: 6,
            dispersionScale: 0.10,
        },
        strength: {
            vrsWeight: 0.65,
            rankWeight: 0.35,
            offset: 100,
            rankOffset: 5,
            ratioLimit: 2,
            zWeight: 1.15,
        },
        lineup: {
            ratingMinimum: 0.75,
            ratingMaximum: 1.35,
            eventShare: 0.15,
            eventDeltaLimit: 0.35,
            allWeight: 0.60,
            bottomWeight: 0.25,
            topWeight: 0.15,
            edgeMultiplier: 4,
            edgeLimit: 0.75,
            requiredPlayers: 3,
            fullTeamSize: 5,
            edgeGroupSize: 2,
        },
        form: {
            sampleSize: 5,
            levelDivisor: 50,
            slopeDivisor: 5,
            levelWeight: 0.15,
            trendWeight: 0.06,
            minimumValues: 2,
        },
        margin: {
            minimumMatches: 5,
            divisor: 10,
            zWeight: 0.12,
        },
        structural: {
            zLimit: 3,
            reliabilityWeights: {
                strength: 0.30,
                lineup: 0.30,
                form: 0.10,
                margin: 0.10,
                map: 0.15,
                veto: 0.05,
            },
            minimumStatsOnlyReliability: 0.35,
        },
        map: {
            priorWins: 4,
            priorMaps: 8,
            shrinkMaps: 10,
            deltaLimit: 0.6,
            deltaWeight: 0.65,
            fullReliabilityMapsPerTeam: 30,
        },
        veto: {
            rho: 0.60,
            temperature: 0.75,
            habitFloor: 0.005,
            utilityLimit: 4,
            expectedPoolSize: 7,
        },
        quality: {
            statsOnlyScale: 60,
            high: 70,
            medium: 45,
        },
        ui: {
            percentDigits: 1,
            factorDigits: 3,
            qualityDigits: 0,
        },
        fingerprint: {
            offsetBasis: 2166136261,
            prime: 16777619,
            radix: 16,
            length: 8,
        },
        archiveExplanationKeys: {
            stats: [
                'mode', 'scoreline', 'mapSeries', 'quality', 'structural', 'strength',
                'lineup', 'form', 'margin', 'structuralShare', 'updated',
            ],
            market: ['mode', 'quality'],
        },
        archiveModelRules: {
            'independent-modes-1': {
                minimumStatsOnlyReliability: 0.35,
                statsOnlyQualityScale: 60,
                marketQualityScale: 100,
                qualityHigh: 70,
                qualityMedium: 45,
                probabilityEpsilon: 0.000001,
                displayMinimum: 0.02,
                displayMaximum: 0.98,
            },
        },
        sanitizer: {
            removeElements: [
                'applet', 'audio', 'base', 'embed', 'frame', 'frameset', 'iframe',
                'img', 'link', 'meta', 'noscript', 'object', 'picture', 'portal',
                'script', 'source', 'style', 'track', 'video',
                { name: 'svg', namespace: 'http://www.w3.org/2000/svg' },
                { name: 'math', namespace: 'http://www.w3.org/1998/Math/MathML' },
            ],
            removeAttributes: [
                'background', 'data', 'imagesizes', 'imagesrcset', 'manifest',
                'ping', 'poster', 'src', 'srcset', 'style',
            ],
        },
    });

    const extensionApi = globalThis.browser;
    const liveModel = globalThis.HLTV_MATCH_PREDICTION_MODEL_V23;
    const sourceResults = new Map();
    const sourceLoads = new Map();
    let sourceTransport = null;
    let sourcePlan = null;
    let sourcePlanIdentity = null;
    let inertSanitizer = null;
    let explanationSequence = 0;
    let activePinnedExplanationClose = null;
    const pinExplanation = new WeakMap();
    let archiveWriteQueue = Promise.resolve();
    const state = {
        destroyed: false,
        enabled: CONFIG.defaultEnabled,
        mode: CONFIG.defaultMode,
        refreshTimer: 0,
        storageListener: null,
        requestGeneration: 0,
        currentInputs: null,
        currentRenderInputs: null,
        currentPredictions: null,
        currentExplanations: null,
        currentFetchedAt: 0,
        currentCalculatedAt: 0,
        currentArchived: false,
        currentPhase: '',
        currentRawMatchFingerprint: '',
        domObserver: null,
        domSyncTimer: 0,
    };

    function hasOwn(object, key) {
        return Object.prototype.hasOwnProperty.call(object, key);
    }

    function clip(value, minimum, maximum) {
        return Math.min(maximum, Math.max(minimum, value));
    }

    function sigmoid(value) {
        return 1 / (1 + Math.exp(-value));
    }

    function logit(probability) {
        const bounded = clip(
            probability,
            CONFIG.probability.epsilon,
            1 - CONFIG.probability.epsilon,
        );
        return Math.log(bounded / (1 - bounded));
    }

    function finiteNumber(value) {
        return typeof value === 'number' && Number.isFinite(value) ? value : null;
    }

    function parseNumber(value) {
        return liveModel.parseNumber(value);
    }

    function parseInteger(value) {
        const parsed = parseNumber(value);
        return Number.isSafeInteger(parsed) ? parsed : null;
    }

    function parsePercent(value) {
        const text = String(value ?? '').trim();
        if (!text || text === '-' || !/%$/.test(text)) return null;
        const parsed = parseNumber(text);
        return parsed === null ? null : parsed / 100;
    }

    function mean(values) {
        const valid = values.filter((value) => Number.isFinite(value));
        return valid.length ? valid.reduce((sum, value) => sum + value, 0) / valid.length : null;
    }

    function median(values) {
        const sorted = values.filter((value) => Number.isFinite(value)).sort((a, b) => a - b);
        if (!sorted.length) return null;
        const middle = Math.floor(sorted.length / 2);
        return sorted.length % 2
            ? sorted[middle]
            : (sorted[middle - 1] + sorted[middle]) / 2;
    }

    function medianAbsoluteDeviation(values, center = median(values)) {
        return center === null ? null : median(values.map((value) => Math.abs(value - center)));
    }

    function weightedMean(entries) {
        let numerator = 0;
        let denominator = 0;
        for (const [value, weight] of entries) {
            if (!Number.isFinite(value) || !Number.isFinite(weight) || weight <= 0) continue;
            numerator += value * weight;
            denominator += weight;
        }
        return denominator ? numerator / denominator : null;
    }

    function slope(values) {
        const valid = values.filter((value) => Number.isFinite(value));
        if (valid.length < CONFIG.form.minimumValues) return null;
        const xMean = (valid.length - 1) / 2;
        const yMean = mean(valid);
        let numerator = 0;
        let denominator = 0;
        for (let index = 0; index < valid.length; index += 1) {
            numerator += (index - xMean) * (valid[index] - yMean);
            denominator += (index - xMean) ** 2;
        }
        return denominator ? numerator / denominator : 0;
    }

    function solveByBisection(target, functionForProbability) {
        let low = 0;
        let high = 1;
        for (let iteration = 0; iteration < CONFIG.probability.bisectionIterations; iteration += 1) {
            const middle = (low + high) / 2;
            if (functionForProbability(middle) < target) low = middle;
            else high = middle;
        }
        return (low + high) / 2;
    }

    function boundedText(value, maximumLength = CONFIG.maximumNameLength) {
        return String(value ?? '').normalize('NFKC').replace(/\s+/g, ' ').trim().slice(0, maximumLength);
    }

    function normalisedName(value) {
        return boundedText(value).toLocaleLowerCase();
    }

    function normalisedMapName(value) {
        return boundedText(value).replace(/[^a-z0-9]/gi, '').toLocaleLowerCase();
    }

    function safeUrl(value, base = location.href) {
        try {
            return new URL(String(value || ''), base);
        } catch {
            return null;
        }

    }

    function parameterEntries(searchParams) {
        const entries = [];
        searchParams.forEach((value, key) => entries.push([key, value]));
        return entries;
    }

    function getInertSanitizer() {
        if (inertSanitizer) return inertSanitizer;
        if (typeof globalThis.Sanitizer !== 'function') {
            throw new Error('Secure analytics parsing requires a supported browser with the Sanitizer API.');
        }
        inertSanitizer = new globalThis.Sanitizer({
            removeElements: CONFIG.sanitizer.removeElements,
            removeAttributes: CONFIG.sanitizer.removeAttributes,
            comments: false,
        });
        return inertSanitizer;
    }

    function parseInertAnalyticsDocument(value) {
        const template = document.createElement('template');
        if (typeof template.setHTML !== 'function') {
            throw new Error('Secure analytics parsing is unavailable.');
        }
        template.setHTML(String(value ?? ''), { sanitizer: getInertSanitizer() });
        const parsed = new DOMParser().parseFromString(template.innerHTML, 'text/html');
        if (!parsed?.documentElement || parsed.querySelector('parsererror')) {
            throw new Error('Analytics page could not be parsed.');
        }
        return parsed;
    }

    function extractTeamId(href) {
        const url = safeUrl(href);
        if (url?.origin !== location.origin || url.protocol !== 'https:') return '';
        return /^\/team\/(\d{1,20})(?:\/|$)/.exec(url.pathname)?.[1] || '';
    }

    function extractProviderName(row, cells) {
        const dataProvider = cells.find((cell) => cell?.dataset?.provider)?.dataset?.provider;
        if (dataProvider) return boundedText(dataProvider);
        const image = row.querySelector('.provider-logo img, .betting-logo-link img');
        return boundedText(
            image?.getAttribute('title')
            || image?.getAttribute('alt')
            || row.querySelector('.betting-logo-link')?.getAttribute('aria-label')
            || row.getAttribute('data-provider')
            || '',
        ).replace(/^Go to\s+/i, '').replace(/\s+Row$/i, '');
    }

    function extractBookmakers(document, analytics = true) {
        const selector = analytics
            ? '#bookmakers table tbody tr'
            : '.betting-section .match-betting-list tr.provider';
        const rows = [...document.querySelectorAll(selector)].slice(0, CONFIG.maximumProviders);
        const bookmakers = [];
        for (const row of rows) {
            const cells = analytics
                ? [row.querySelector('.odds.team1'), row.querySelector('.odds.team2')]
                : [...row.querySelectorAll('.odds-cell')].slice(0, 2);
            if (cells.length !== 2 || cells.some((cell) => !cell)) continue;
            const oddsA = analytics
                ? parseNumber(cells[0].dataset.numericOdds)
                : parseNumber(cells[0].textContent);
            const oddsB = analytics
                ? parseNumber(cells[1].dataset.numericOdds)
                : parseNumber(cells[1].textContent);
            bookmakers.push({
                provider: extractProviderName(row, cells),
                oddsA,
                oddsB,
            });
        }
        return bookmakers;
    }

    function extractMatchIdentity(document, now = Date.now()) {
        const matchId = CONFIG.route.exec(location.pathname)?.[1] || '';
        const matchPage = matchId ? document.querySelector('.match-page') : null;
        if (!matchPage) return null;
        const teamsBox = matchPage.querySelector('.teamsBox:not(.teamsBoxDropdown)');
        const teamAnchors = teamsBox
            ? [...teamsBox.querySelectorAll('a[href*="/team/"]')]
            : [];
        const teams = [];
        for (const anchor of teamAnchors) {
            const id = extractTeamId(anchor.getAttribute('href'));
            const name = boundedText(anchor.textContent);
            if (!id || !name || teams.some((team) => team.id === id)) continue;
            teams.push({ id, name, href: safeUrl(anchor.getAttribute('href'))?.href || '' });
            if (teams.length === 2) break;
        }
        if (teams.length !== 2) return null;

        const timestamps = [...teamsBox.querySelectorAll('[data-unix]')]
            .map((element) => Number(element.getAttribute('data-unix')))
            .filter((value) => Number.isSafeInteger(value) && value > 0);
        const timestamp = median(timestamps);
        const countdown = teamsBox.querySelector('.countdown');
        const statusText = boundedText(countdown?.textContent, 60);
        const explicitLive = Boolean(countdown?.classList.contains('countdown-live'))
            || /^live$/i.test(statusText);
        const explicitFinished = !explicitLive && (
            /^(?:match over|finished)$/i.test(statusText)
            || Boolean(teamsBox.querySelector('.won, .lost'))
        );
        const hasPlayedMap = Boolean(matchPage.querySelector('.maps .results.played'));
        const scheduledStartPassed = Number.isSafeInteger(timestamp)
            && timestamp <= now + CONFIG.liveSafetyGraceMs;
        const phase = explicitFinished
            ? 'finished'
            : explicitLive
                ? 'live'
                : scheduledStartPassed || hasPlayedMap
                    ? 'started'
                    : Number.isSafeInteger(timestamp) ? 'scheduled' : 'unknown';

        return {
            matchId,
            teams,
            timestamp: Number.isSafeInteger(timestamp) ? timestamp : null,
            phase,
            statusText,
        };
    }

    function extractMatchPageData(document, identity = extractMatchIdentity(document)) {
        const raw = liveModel?.extractMatchPageData(document, identity);
        return raw ? { ...raw, bookmakers: extractBookmakers(document, false) } : null;
    }

    function extractAnalyticsPageData(document) {
        const raw = liveModel.extractAnalyticsPageData(document);
        return raw ? { ...raw, bookmakers: extractBookmakers(document, true) } : null;
    }

    function normalizePredictionInputs(rawMatch, rawAnalytics, rawTeamPlayers = [], records = []) {
        const inputs = liveModel.normalizePredictionInputs(rawMatch, rawAnalytics, rawTeamPlayers, records);
        const analyticsOdds = rawAnalytics?.bookmakers || [];
        const useAnalytics = calculateMarketProbability({ bookmakers: analyticsOdds }).available;
        return { ...inputs, bookmakers: useAnalytics ? analyticsOdds : (rawMatch.bookmakers || []),
            bookmakerSource: useAnalytics ? 'analytics' : 'match' };
    }

    function calculateMarketProbability(inputs) {
        const seenProviders = new Set();
        const accepted = [];
        const rejected = [];
        for (const bookmaker of inputs.bookmakers) {
            const providerKey = normalisedName(bookmaker.provider);
            if (!providerKey || seenProviders.has(providerKey)) {
                rejected.push({ ...bookmaker, reason: providerKey ? 'duplicate' : 'missing-provider' });
                continue;
            }
            const oddsA = bookmaker.oddsA;
            const oddsB = bookmaker.oddsB;
            const impliedSum = Number.isFinite(oddsA) && Number.isFinite(oddsB)
                ? (1 / oddsA) + (1 / oddsB)
                : null;
            if (!Number.isFinite(oddsA)
                || !Number.isFinite(oddsB)
                || oddsA < CONFIG.market.minimumOdds
                || oddsA > CONFIG.market.maximumOdds
                || oddsB < CONFIG.market.minimumOdds
                || oddsB > CONFIG.market.maximumOdds
                || impliedSum < CONFIG.market.minimumImpliedSum
                || impliedSum > CONFIG.market.maximumImpliedSum) {
                rejected.push({ ...bookmaker, reason: 'invalid-pair' });
                continue;
            }
            accepted.push({
                ...bookmaker,
                probabilityA: oddsB / (oddsA + oddsB),
            });
            seenProviders.add(providerKey);
        }
        if (!accepted.length) {
            return {
                available: false,
                probability: null,
                providerCount: 0,
                rejectedCount: rejected.length,
                medianAbsoluteDeviation: null,
                reliability: 0,
                accepted: [],
                rejected,
            };
        }
        const firstMedian = median(accepted.map((entry) => entry.probabilityA));
        const deviation = medianAbsoluteDeviation(
            accepted.map((entry) => entry.probabilityA),
            firstMedian,
        );
        const limit = Math.max(
            CONFIG.market.minimumOutlierLimit,
            CONFIG.market.madMultiplier * deviation,
        );
        const filtered = [];
        for (const entry of accepted) {
            if (Math.abs(entry.probabilityA - firstMedian) <= limit) filtered.push(entry);
            else rejected.push({ ...entry, reason: 'outlier' });
        }
        const probability = clip(
            median(filtered.map((entry) => entry.probabilityA)),
            CONFIG.probability.displayMinimum,
            CONFIG.probability.displayMaximum,
        );
        const reliability = clip(filtered.length / CONFIG.market.fullReliabilityProviders, 0, 1)
            * clip(1 - deviation / CONFIG.market.dispersionScale, 0, 1);
        return {
            available: true,
            probability,
            providerCount: filtered.length,
            rejectedCount: rejected.length,
            medianAbsoluteDeviation: deviation,
            reliability,
            accepted: filtered,
            rejected,
        };
    }

    function seriesDistribution(mapProbabilities, bestOf) {
        const winsRequired = Math.floor(bestOf / 2) + 1;
        const probabilities = Array.from({ length: bestOf }, (_, index) => (
            clip(
                Number.isFinite(mapProbabilities[index])
                    ? mapProbabilities[index]
                    : 0.5,
                0,
                1,
            )
        ));
        let states = new Map([['0:0', 1]]);
        const outcomes = {};
        for (let mapIndex = 0; mapIndex < bestOf; mapIndex += 1) {
            const next = new Map();
            for (const [key, stateProbability] of states) {
                const [winsA, winsB] = key.split(':').map(Number);
                const transitions = [
                    [winsA + 1, winsB, probabilities[mapIndex]],
                    [winsA, winsB + 1, 1 - probabilities[mapIndex]],
                ];
                for (const [nextA, nextB, transitionProbability] of transitions) {
                    const probability = stateProbability * transitionProbability;
                    if (nextA === winsRequired || nextB === winsRequired) {
                        const outcome = `${nextA}-${nextB}`;
                        outcomes[outcome] = (outcomes[outcome] || 0) + probability;
                    } else {
                        const nextKey = `${nextA}:${nextB}`;
                        next.set(nextKey, (next.get(nextKey) || 0) + probability);
                    }
                }
            }
            states = next;
            if (!states.size) break;
        }
        return outcomes;
    }

    function distributionWinProbability(distribution) {
        return Object.entries(distribution).reduce((sum, [score, probability]) => {
            const [winsA, winsB] = score.split('-').map(Number);
            return sum + (winsA > winsB ? probability : 0);
        }, 0);
    }

    function scorelineWinnerIndex(scoreline) {
        const match = /^(\d+)-(\d+)$/.exec(String(scoreline || ''));
        if (!match || match[1] === match[2]) return null;
        return Number(match[1]) > Number(match[2]) ? 0 : 1;
    }

    function sortedScorelineEntries(distribution) {
        return Object.entries(distribution || {})
            .filter(([scoreline, probability]) => (
                scorelineWinnerIndex(scoreline) !== null
                && Number.isFinite(probability)
                && probability >= 0
            ))
            .sort((first, second) => (
                second[1] - first[1] || first[0].localeCompare(second[0])
            ));
    }

    function mergeDistributions(weightedDistributions) {
        const merged = {};
        for (const [distribution, weight] of weightedDistributions) {
            for (const [score, probability] of Object.entries(distribution)) {
                merged[score] = (merged[score] || 0) + weight * probability;
            }
        }
        return merged;
    }

    function constantMapProbabilityFromSeries(probability, bestOf) {
        return solveByBisection(probability, (candidate) => (
            distributionWinProbability(seriesDistribution(
                Array(bestOf).fill(candidate),
                bestOf,
            ))
        ));
    }

    function calculateStructuralProbability(inputs) {
        return liveModel.calculateStructuralProbability(inputs);
    }

    function calculateDataQuality(market, structural, mode) {
        const numeric = mode === 'market'
            ? 100 * market.reliability
            : CONFIG.quality.statsOnlyScale * structural.reliability;
        const score = clip(numeric, 0, 100);
        return {
            score,
            label: score >= CONFIG.quality.high
                ? 'High'
                : score >= CONFIG.quality.medium ? 'Medium' : 'Low',
        };
    }

    function calculateFinalPrediction(inputs, requestedMode = CONFIG.defaultMode) {
        return liveModel.calculateFinalPrediction(inputs, requestedMode, calculateMarketProbability);
    }

    function stableStringify(value) {
        if (value === null || typeof value !== 'object') return JSON.stringify(value);
        if (Array.isArray(value)) return `[${value.map(stableStringify).join(',')}]`;
        return `{${Object.keys(value).sort().map((key) => (
            `${JSON.stringify(key)}:${stableStringify(value[key])}`
        )).join(',')}}`;
    }

    function fingerprint(value) {
        const text = stableStringify(value);
        let hash = CONFIG.fingerprint.offsetBasis;
        for (let index = 0; index < text.length; index += 1) {
            hash ^= text.charCodeAt(index);
            hash = Math.imul(hash, CONFIG.fingerprint.prime);
        }
        return (hash >>> 0)
            .toString(CONFIG.fingerprint.radix)
            .padStart(CONFIG.fingerprint.length, '0');
    }

    function createElement(tagName, className = '', text = '') {
        const element = document.createElement(tagName);
        if (className) element.className = className;
        if (text !== '') element.textContent = text;
        return element;
    }

    function installStyle() {
        if (document.getElementById(CONFIG.styleId)) return;
        const style = document.createElement('style');
        style.id = CONFIG.styleId;
        style.textContent = `
            #${CONFIG.cardId} {
                --prediction-panel: #fff;
                --prediction-strong: #f3f5f6;
                --prediction-inset: #edf0f2;
                --prediction-border: #d5d9dc;
                --prediction-text: #2d3844;
                --prediction-muted: #6d7478;
                --prediction-accent: #0878b9;
                box-sizing: border-box;
                margin: 10px 0;
                overflow: visible;
                border-top: 2px solid var(--prediction-accent);
                background: var(--prediction-panel);
                color: var(--prediction-text);
            }
            html.night-theme #${CONFIG.cardId},
            body.night-mode #${CONFIG.cardId} {
                --prediction-panel: #2d3844;
                --prediction-strong: #26313c;
                --prediction-inset: #202a34;
                --prediction-border: #435467;
                --prediction-text: #d8dde2;
                --prediction-muted: #9aa3a8;
                --prediction-accent: #87a3bf;
            }
            #${CONFIG.cardId} * { box-sizing: border-box; }
            .hltv-sp-prediction-head {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 12px;
                padding: 8px 12px;
                border-bottom: 1px solid var(--prediction-border);
                background: var(--prediction-strong);
            }
            .hltv-sp-prediction-title {
                color: var(--prediction-text);
                font-size: 12px;
                font-weight: 700;
                letter-spacing: .01em;
            }
            .hltv-sp-prediction-mode {
                min-width: 136px;
                min-height: 26px;
                border: 1px solid var(--prediction-border);
                border-radius: 2px;
                background: var(--prediction-inset);
                color: var(--prediction-text);
                cursor: pointer;
                font: inherit;
                font-size: 10px;
                padding: 3px 7px;
            }
            .hltv-sp-prediction-mode:focus-visible {
                border-color: var(--prediction-accent);
                outline: 1px solid var(--prediction-accent);
                outline-offset: 0;
            }
            .hltv-sp-prediction-body { padding: 14px; }
            .hltv-sp-prediction-history-notice {
                margin: 0 0 12px;
                padding: 8px 10px;
                border: 1px solid var(--prediction-border);
                border-radius: 2px;
                background: var(--prediction-inset);
                color: var(--prediction-muted);
                font-size: 11px;
                line-height: 1.4;
                text-align: center;
            }
            .hltv-sp-prediction-history-notice time {
                color: var(--prediction-text);
                font-weight: 700;
            }
            .hltv-sp-prediction-hero {
                max-width: 620px;
                margin: 0 auto;
                text-align: center;
            }
            .hltv-sp-prediction-eyebrow {
                color: var(--prediction-muted);
                font-size: 9px;
                font-weight: 700;
                letter-spacing: .13em;
                text-transform: uppercase;
            }
            .hltv-sp-prediction-winner {
                margin-top: 3px;
                overflow: hidden;
                color: var(--prediction-text);
                font-size: 22px;
                font-weight: 700;
                line-height: 1.15;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
            .hltv-sp-prediction-confidence {
                margin-top: 3px;
                color: var(--prediction-accent);
                font-size: 13px;
                font-weight: 700;
                font-variant-numeric: tabular-nums;
            }
            .hltv-sp-prediction-scoreline {
                display: flex;
                justify-content: center;
                width: max-content;
                max-width: calc(100% - 16px);
                margin: 7px auto 0;
                color: var(--prediction-text);
                font-size: 12px;
                font-weight: 700;
                line-height: 1.35;
                text-align: center;
                font-variant-numeric: tabular-nums;
            }
            .hltv-sp-prediction-scoreline .hltv-sp-prediction-explainer-label {
                overflow-wrap: anywhere;
            }
            .hltv-sp-prediction-scoreline .hltv-sp-prediction-explainer-popup {
                right: auto;
                left: 50%;
                transform: translateX(-50%);
            }
            .hltv-sp-prediction-scoreline-results {
                margin-top: 9px;
            }
            .hltv-sp-prediction-scoreline-table {
                width: 100%;
                border-collapse: collapse;
                table-layout: fixed;
            }
            .hltv-sp-prediction-scoreline-table caption {
                padding: 0 0 5px;
                color: var(--prediction-accent);
                font-size: 11px;
                font-weight: 700;
                text-align: left;
            }
            .hltv-sp-prediction-scoreline-table th,
            .hltv-sp-prediction-scoreline-table td {
                padding: 5px 6px;
                border-top: 1px solid var(--prediction-border);
                text-align: left;
                vertical-align: middle;
            }
            .hltv-sp-prediction-scoreline-table thead th {
                color: var(--prediction-muted);
                font-size: 9px;
                font-weight: 700;
                letter-spacing: .05em;
                text-transform: uppercase;
            }
            .hltv-sp-prediction-scoreline-table thead th:last-child {
                width: 82px;
                text-align: right;
            }
            .hltv-sp-prediction-scoreline-table tbody th {
                color: var(--prediction-text);
                font-weight: 600;
                overflow-wrap: anywhere;
            }
            .hltv-sp-prediction-scoreline-table tbody td {
                color: var(--prediction-text);
                font-weight: 700;
                text-align: right;
                white-space: nowrap;
                font-variant-numeric: tabular-nums;
            }
            .hltv-sp-prediction-data-table {
                table-layout: auto;
            }
            .hltv-sp-prediction-data-table thead th:last-child {
                width: auto;
            }
            .hltv-sp-prediction-data-table th,
            .hltv-sp-prediction-data-table td {
                padding: 6px 8px;
                text-align: right;
            }
            .hltv-sp-prediction-data-table th:first-child,
            .hltv-sp-prediction-data-table td:first-child {
                text-align: left;
            }
            .hltv-sp-prediction-scoreline-row-most-likely {
                background: color-mix(in srgb, var(--prediction-accent) 10%, transparent);
            }
            .hltv-sp-prediction-scoreline-badge {
                display: inline-block;
                margin-left: 5px;
                padding: 1px 4px;
                border: 1px solid color-mix(in srgb, var(--prediction-accent) 55%, transparent);
                border-radius: 2px;
                color: var(--prediction-accent);
                font-size: 8px;
                font-weight: 700;
                letter-spacing: .04em;
                line-height: 1.35;
                text-transform: uppercase;
                white-space: nowrap;
            }
            .hltv-sp-prediction-matchup { margin-top: 14px; }
            .hltv-sp-prediction-teams {
                display: grid;
                grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
                gap: 14px;
                margin-bottom: 5px;
            }
            .hltv-sp-prediction-team {
                display: flex;
                gap: 6px;
                min-width: 0;
                color: var(--prediction-muted);
                font-size: 10px;
            }
            .hltv-sp-prediction-team:last-child { justify-content: flex-end; text-align: right; }
            .hltv-sp-prediction-team-name {
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
            .hltv-sp-prediction-team-probability {
                flex: 0 0 auto;
                font-weight: 700;
                font-variant-numeric: tabular-nums;
            }
            .hltv-sp-prediction-team-winner { color: var(--prediction-text); }
            .hltv-sp-prediction-rail {
                display: flex;
                height: 7px;
                overflow: hidden;
                border: 1px solid var(--prediction-border);
                border-radius: 1px;
                background: var(--prediction-inset);
            }
            .hltv-sp-prediction-rail-segment { flex: 0 0 auto; }
            .hltv-sp-prediction-rail-winner { background: var(--prediction-accent); }
            .hltv-sp-prediction-rail-loser { background: var(--prediction-muted); opacity: .5; }
            .hltv-sp-prediction-meta {
                position: relative;
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
                gap: 5px;
                margin-top: 11px;
                color: var(--prediction-muted);
                font-size: 9px;
            }
            .hltv-sp-prediction-meta > .hltv-sp-prediction-meta-item {
                position: static;
                padding: 3px 6px;
                border: 1px solid var(--prediction-border);
                border-radius: 2px;
                background: var(--prediction-strong);
            }
            .hltv-sp-prediction-explainer {
                position: relative;
                display: inline-flex;
                align-items: center;
                gap: 4px;
                min-width: 0;
            }
            .hltv-sp-prediction-explainer-label { min-width: 0; }
            .hltv-sp-prediction-explainer-button {
                display: inline-grid;
                flex: 0 0 18px;
                width: 18px;
                height: 18px;
                place-items: center;
                padding: 0;
                border: 1px solid var(--prediction-border);
                border-radius: 50%;
                background: var(--prediction-panel);
                color: var(--prediction-accent);
                cursor: help;
                font: inherit;
                font-size: 10px;
                font-weight: 700;
                line-height: 1;
            }
            .hltv-sp-prediction-explainer-button::before { content: "i"; }
            .hltv-sp-prediction-explainer-button:hover,
            .hltv-sp-prediction-explainer-button:focus-visible,
            .hltv-sp-prediction-explainer-button[aria-expanded="true"] {
                border-color: var(--prediction-accent);
                background: var(--prediction-accent);
                color: var(--prediction-panel);
                outline: none;
            }
            .hltv-sp-prediction-explainer-button:focus-visible {
                box-shadow: 0 0 0 2px color-mix(in srgb, var(--prediction-accent) 30%, transparent);
            }
            .hltv-sp-prediction-explainer-popup {
                position: absolute;
                z-index: 20;
                top: calc(100% + 7px);
                left: 50%;
                width: min(520px, calc(100vw - 32px));
                max-height: min(520px, 70vh);
                overflow: auto;
                transform: translateX(-50%);
                padding: 12px;
                border: 1px solid var(--prediction-border);
                border-radius: 2px;
                background: var(--prediction-panel);
                box-shadow: 0 5px 16px rgba(0, 0, 0, .28);
                color: var(--prediction-text);
                font-size: 11px;
                font-weight: 400;
                line-height: 1.45;
                text-align: left;
                white-space: normal;
            }
            .hltv-sp-prediction-explainer-summary {
                margin: 0;
                color: var(--prediction-text);
                font-size: 12px;
                line-height: 1.45;
            }
            .hltv-sp-prediction-explainer-technical {
                margin-top: 8px;
                padding-top: 7px;
                border-top: 1px solid var(--prediction-border);
            }
            .hltv-sp-prediction-explainer-technical-heading {
                margin: 0;
                color: var(--prediction-accent);
                font-size: 11px;
                font-weight: 700;
            }
            .hltv-sp-prediction-explainer-technical-copy {
                margin: 7px 0 0;
                color: var(--prediction-muted);
            }
            .hltv-sp-prediction-explainer-formula {
                margin-top: 8px;
                padding: 7px;
                border: 1px solid var(--prediction-border);
                border-radius: 2px;
                background: var(--prediction-inset);
                overflow-x: auto;
            }
            .hltv-sp-prediction-explainer-formula-label {
                display: block;
                margin-bottom: 4px;
                color: var(--prediction-text);
                font-weight: 700;
            }
            .hltv-sp-prediction-explainer-equations {
                display: grid;
                gap: 7px;
                min-width: max-content;
                padding: 2px 1px;
            }
            .hltv-sp-prediction-explainer-equation {
                display: block;
                color: var(--prediction-text);
                font-size: 14px;
                line-height: 1.55;
                font-family: "STIX Two Math", "Cambria Math", "Latin Modern Math", serif;
            }
            .hltv-sp-prediction-explainer-formula-copy {
                margin: 7px 0 0;
                color: var(--prediction-muted);
                font-size: 10px;
                line-height: 1.5;
                overflow-wrap: anywhere;
            }
            .hltv-sp-prediction-explainer-formula-context {
                display: block;
                margin-top: 8px;
                color: var(--prediction-muted);
                font-size: 9px;
                font-weight: 700;
                letter-spacing: .05em;
                text-transform: uppercase;
            }
            .hltv-sp-prediction-explainer-formula:not(.hltv-sp-prediction-explainer-formula-math)
                .hltv-sp-prediction-explainer-formula-copy {
                margin-top: 0;
                color: var(--prediction-text);
                font-size: 11px;
            }
            .hltv-sp-prediction-status {
                display: flex;
                align-items: center;
                justify-content: center;
                min-height: 62px;
                color: var(--prediction-muted);
                text-align: center;
            }
            .hltv-sp-prediction-error { color: #c93030; }
            .hltv-sp-prediction-details {
                container-type: inline-size;
                margin-top: 12px;
                border: 1px solid var(--prediction-border);
                border-radius: 2px;
                background: var(--prediction-inset) !important;
                color: var(--prediction-text) !important;
            }
            .hltv-sp-prediction-details > summary {
                padding: 11px 12px;
                color: var(--prediction-accent);
                cursor: pointer;
                font-size: 13px;
                font-weight: 700;
                line-height: 1.3;
                transition: background-color .12s ease, color .12s ease;
            }
            .hltv-sp-prediction-details > summary:hover,
            .hltv-sp-prediction-details > summary:focus-visible {
                background: color-mix(in srgb, var(--prediction-strong) 72%, #000 28%);
                color: var(--prediction-text);
                outline: none;
            }
            .hltv-sp-prediction-details > summary:focus-visible {
                box-shadow: inset 0 0 0 1px var(--prediction-accent);
            }
            .hltv-sp-prediction-details[open] > summary {
                border-bottom: 1px solid var(--prediction-border);
            }
            .hltv-sp-prediction-details-intro {
                margin: 10px 12px 0;
                color: var(--prediction-muted);
                font-size: 11px;
                line-height: 1.45;
            }
            .hltv-sp-prediction-breakdown-groups {
                display: grid;
                grid-template-columns: repeat(2, minmax(0, 1fr));
                gap: 10px;
                padding: 10px 12px 12px;
            }
            .hltv-sp-prediction-breakdown-group {
                position: relative;
                min-width: 0;
                border: 1px solid var(--prediction-border);
                border-radius: 2px;
                background: var(--prediction-panel) !important;
            }
            .hltv-sp-prediction-breakdown-heading {
                margin: 0;
                padding: 8px 10px;
                border-bottom: 1px solid var(--prediction-border);
                background: var(--prediction-strong);
                color: var(--prediction-accent);
                font-size: 10px;
                font-weight: 700;
                letter-spacing: .08em;
                line-height: 1.3;
                text-transform: uppercase;
            }
            .hltv-sp-prediction-grid { margin: 0; }
            .hltv-sp-prediction-grid-row {
                position: relative;
                display: grid;
                grid-template-columns: minmax(0, 1fr) minmax(100px, 45%);
                align-items: center;
                gap: 12px;
                min-height: 36px;
                padding: 8px 10px;
            }
            .hltv-sp-prediction-grid-row + .hltv-sp-prediction-grid-row {
                border-top: 1px solid color-mix(in srgb, var(--prediction-border) 64%, transparent);
            }
            .hltv-sp-prediction-grid dt {
                min-width: 0;
                color: var(--prediction-muted) !important;
                font-size: 12px;
                line-height: 1.35;
            }
            .hltv-sp-prediction-grid .hltv-sp-prediction-explainer-popup {
                left: 0;
                transform: none;
            }
            .hltv-sp-prediction-grid .hltv-sp-prediction-explainer {
                position: static;
            }
            .hltv-sp-prediction-breakdown-group:nth-child(even)
                .hltv-sp-prediction-explainer-popup {
                right: 0;
                left: auto;
            }
            .hltv-sp-prediction-grid dd {
                margin: 0;
                color: var(--prediction-text) !important;
                font-size: 13px;
                font-weight: 600;
                line-height: 1.35;
                overflow-wrap: anywhere;
                text-align: right;
                font-variant-numeric: tabular-nums;
            }
            .hltv-sp-prediction-note {
                margin: 0 12px 12px;
                color: var(--prediction-muted);
                font-size: 10px;
                line-height: 1.4;
            }
            @container (max-width: 620px) {
                .hltv-sp-prediction-breakdown-groups {
                    grid-template-columns: minmax(0, 1fr);
                }
                .hltv-sp-prediction-breakdown-group:nth-child(even)
                    .hltv-sp-prediction-explainer-popup {
                    right: auto;
                    left: 0;
                }
            }
            @container (max-width: 380px) {
                .hltv-sp-prediction-grid-row {
                    grid-template-columns: minmax(0, 1fr);
                    gap: 5px;
                }
                .hltv-sp-prediction-grid dd { text-align: left; }
            }
            @media (max-width: 520px) {
                .hltv-sp-prediction-head { align-items: stretch; flex-direction: column; }
                .hltv-sp-prediction-mode { width: 100%; }
                .hltv-sp-prediction-body { padding: 11px; }
                .hltv-sp-prediction-winner { font-size: 19px; }
                .hltv-sp-prediction-explainer-popup {
                    left: 0;
                    right: auto;
                    transform: none;
                }
            }
        `;
        document.head.append(style);
    }

    function predictionCard(allowMatchHeaderFallback = false) {
        let card = document.getElementById(CONFIG.cardId);
        const analyticsSection = document.querySelector(
            '.match-page .matchpage-analytics-section',
        );
        const anchor = analyticsSection
            ? analyticsSection.closest('.analytics-pick-a-winner') || analyticsSection
            : allowMatchHeaderFallback
                ? document.querySelector('.match-page .teamsBoxDropdown')
                    || document.querySelector('.match-page .teamsBox:not(.teamsBoxDropdown)')
                : null;
        if (!anchor) return card;
        installStyle();
        if (!card) {
            card = createElement('section', 'standard-box');
            card.id = CONFIG.cardId;
            card.setAttribute('aria-live', 'polite');
        }
        if (anchor.nextElementSibling !== card) anchor.after(card);
        return card;
    }

    function renderStatus(message, isError = false, allowMatchHeaderFallback = false) {
        const card = predictionCard(allowMatchHeaderFallback);
        if (!card) return;
        delete card.dataset.predictionSource;
        card.replaceChildren();
        const head = createElement('div', 'hltv-sp-prediction-head');
        head.append(createElement('div', 'hltv-sp-prediction-title', 'Match prediction'));
        const body = createElement(
            'div',
            `hltv-sp-prediction-body hltv-sp-prediction-status${isError ? ' hltv-sp-prediction-error' : ''}`,
            message,
        );
        card.append(head, body);
    }

    function formatPercent(value) {
        return `${(100 * value).toFixed(CONFIG.ui.percentDigits)}%`;
    }

    function formatFactor(value, teams) {
        const rendered = value.toFixed(CONFIG.ui.factorDigits);
        if (Number(rendered) === 0) {
            return `${(0).toFixed(CONFIG.ui.factorDigits)} · neutral`;
        }
        const direction = teams[value > 0 ? 0 : 1].name;
        return `${value > 0 ? '+' : ''}${rendered} · toward ${direction}`;
    }

    function mapSeriesLabel(mode) {
        if (mode === 'official-maps') return 'Official maps';
        if (mode === 'partial-maps') return 'Partial official maps';
        if (mode === 'pre-veto') return 'Pre-veto estimate';
        if (mode === 'generic-maps') return 'Generic map estimate';
        return 'Map estimate';
    }

    function qualityBandDescription(label) {
        if (label === 'High') {
            return `High means an unrounded quality score of ${CONFIG.quality.high} or higher.`;
        }
        if (label === 'Medium') {
            return `Medium means an unrounded quality score of at least `
                + `${CONFIG.quality.medium} and below ${CONFIG.quality.high}.`;
        }
        return `Low means an unrounded quality score below ${CONFIG.quality.medium}.`;
    }

    function mapSeriesDescription(prediction, inputs) {
        const mode = prediction.structural.mapSeries.mode;
        if (mode === 'official-maps') {
            return `HLTV lists all ${inputs.bestOf} official maps for this best-of-${inputs.bestOf}. `
                + 'Each listed map uses its map-specific estimate when statistics are available; '
                + 'missing map statistics fall back to the base map probability.';
        }
        if (mode === 'partial-maps') {
            return `HLTV currently lists ${inputs.officialMaps.length} of ${inputs.bestOf} official `
                + `maps for this best-of-${inputs.bestOf}. Listed maps use their map-specific `
                + 'estimates and the remaining slots use the deterministic generic-map model.';
        }
        if (mode === 'pre-veto') {
            return 'No official maps are listed. For this best-of-3, the model simulates the '
                + 'seven-map veto from both possible first-action orders using each team\'s '
                + 'pick/ban habits, averages those orders, and then applies exact series math.';
        }
        return 'A complete official-map or seven-map best-of-3 veto model is not available. '
            + `For this best-of-${inputs.bestOf}, available maps are ordered deterministically `
            + 'from observed pick/ban activity; missing map data uses the base map probability.';
    }

    function predictionTechnicalDetails(prediction, inputs, fetchedAt = Date.now()) {
        const teamA = inputs.teams[0].name;
        const teamB = inputs.teams[1].name;
        const direction = (value) => {
            if (Math.abs(value) < CONFIG.probability.epsilon) return 'is neutral';
            return `favors ${value > 0 ? teamA : teamB}`;
        };
        const qualityFormula = prediction.mode === 'market'
            ? 'In Market-estimated mode the score is 100 × market reliability. '
                + `Here market reliability is ${formatPercent(prediction.market.reliability)}, `
                + `producing an unrounded score of ${prediction.quality.score.toFixed(2)}/100. `
            : 'In Page stats only mode the score is 60 × structural reliability. '
                + `Here structural reliability is `
                + `${formatPercent(prediction.structural.reliability)}, producing an unrounded `
                + `score of ${prediction.quality.score.toFixed(2)}/100. Because this formula `
                + 'has a maximum of 60, Page stats only can reach Medium data quality but never '
                + 'High. ';
        const mode = prediction.mode === 'market'
            ? prediction.market.available
                ? 'The final probability is exactly the median de-vigged bookmaker estimate '
                    + 'after provider validation and outlier filtering. Page statistics do not '
                    + 'adjust it.'
                : 'No bookmaker rows survived validation and outlier filtering. '
                    + 'Market-estimated mode does not substitute a page-statistics prediction.'
            : 'No bookmaker probability is used. Structural log-odds is multiplied by the '
                + `current structural reliability (`
                + `${formatPercent(prediction.structural.reliability)}), which pulls weak evidence `
                + `toward 50%. A stats-only result is withheld below `
                + `${formatPercent(CONFIG.structural.minimumStatsOnlyReliability)} structural `
                + 'reliability.';
        const scoreline = prediction.likelyScoreline
            ? `${prediction.likelyScoreline} is the single most probable final score. Scoreline `
                + `probabilities come from the map-series model, then are recalibrated so `
                + `${teamA}-win outcomes sum to ${formatPercent(prediction.probabilityA)} and `
                + `${teamB}-win outcomes sum to ${formatPercent(prediction.probabilityB)}. It is `
                + 'shown only when that most probable score agrees with the predicted winner.'
            : 'No likely score is shown because the most probable map-model scoreline does not '
                + 'agree with the winner from the final probability.';
        return {
            mode,
            scoreline,
            mapSeries: mapSeriesDescription(prediction, inputs),
            quality: qualityBandDescription(prediction.quality.label)
                + ` ${qualityFormula}`
                + (prediction.mode === 'market'
                    ? 'Market reliability is min(providers retained after filtering ÷ 6, 1) × '
                        + 'clip(1 − provider MAD ÷ 0.10, 0, 1).'
                    : 'Structural reliability weights available VRS/rank and lineup data at '
                        + '30% each, form and round margin at 10% each, map '
                        + 'sample-and-coverage reliability at 15%, and veto or official-map '
                        + 'coverage at 5%.'),
            market: prediction.market.available
                ? `The median de-vigged ${teamA} win probability from `
                    + `${prediction.market.providerCount} accepted bookmaker providers. Each odds `
                    + 'pair is converted to oddsB ÷ (oddsA + oddsB). Valid odds are 1.01–100 '
                    + 'with a combined implied probability from 0.90–1.25; duplicate providers '
                    + 'and outliers beyond the larger of 2.5 percentage points or 4 × median '
                    + 'absolute deviation are removed.'
                : 'No valid bookmaker consensus is available. Odds pairs must pass provider, '
                    + 'range, combined-implied-probability, duplicate, and outlier checks before use.',
            rejected: `${prediction.market.rejectedCount} bookmaker rows were excluded before the `
                + 'consensus. A row is rejected for a missing or duplicate provider, invalid '
                + 'paired odds, a combined implied probability outside 0.90–1.25, or an '
                + 'outlying probability.',
            structural: `The page-statistics series estimate for ${teamA}. VRS/rank, lineup, `
                + 'form, and round-margin effects are added and clipped to ±3, converted to a '
                + 'base map probability, adjusted with map and veto evidence, then evaluated '
                + `using exact best-of-${inputs.bestOf} series math. Current structural `
                + `reliability is ${formatPercent(prediction.structural.reliability)}.`,
            strength: 'A weighted log-ratio: 65% VRS points (with a 100-point offset) and '
                + '35% inverse world rank (with a 5-rank offset), using whichever inputs '
                + `exist. The displayed factor `
                + `${direction(prediction.structural.strength.ratio)}; the model multiplies it `
                + 'by 1.15.',
            lineup: 'Each team needs at least 3 rated players. The lineup score weights the '
                + 'full lineup 60%, the bottom two 25%, and the top two 15%; event rating '
                + 'supplies a heavily bounded 15% adjustment. The difference is multiplied '
                + `by 4, capped at ±0.75, and scaled for lineup completeness. This value `
                + `${direction(prediction.structural.lineup.z)}.`,
            form: 'Uses up to the last 5 chart values per team and requires at least 2. It '
                + 'combines the bounded average-level and trend differences with coefficients '
                + `of 0.15 and 0.06. This value `
                + `${direction(prediction.structural.form.z)}.`,
            margin: 'Uses average rounds lost in wins and rounds won in losses, with at least '
                + `5 matches per team. Positive means ${teamA} tends to win more cleanly and/or `
                + `lose more closely; negative means ${teamB}. The bounded edge is weighted by `
                + `0.12. This value ${direction(prediction.structural.margin.z)}.`,
            structuralShare: prediction.mode === 'market'
                ? 'Market-estimated mode does not use a structural coefficient because page '
                    + 'statistics do not adjust its bookmaker probability.'
                : 'Page stats only uses no market coefficient. The displayed 100% means all '
                    + 'source evidence is structural; structural reliability still scales its '
                    + 'log-odds toward 50%.',
            updated: 'The analytics payload used for this card was fetched or restored from its '
                + `validated cache at ${new Date(fetchedAt).toLocaleString()}. Refreshes run every `
                + '30 minutes early, every 5 minutes within one hour of the scheduled start, '
                + 'and every 90 seconds within ten minutes.',
        };
    }

    function legacyPredictionExplanations(prediction, inputs, fetchedAt = Date.now()) {
        const technical = predictionTechnicalDetails(prediction, inputs, fetchedAt);
        const teamA = inputs.teams[0].name;
        const teamB = inputs.teams[1].name;
        const structuralReliability = formatPercent(prediction.structural.reliability);
        const marketReliability = formatPercent(prediction.market.reliability);
        const entry = (summary, details, formula, equations = []) => ({
            summary,
            details,
            formula,
            equations,
        });
        const clipDefinition = 'clip(x, a, b) = min(b, max(a, x)).';
        const sharedFunctions = `${clipDefinition} sigmoid(x) = 1 ÷ (1 + exp(−x)); `
            + 'logit(p) = ln(p ÷ (1 − p)) after '
            + 'bounding p to [10⁻⁶, 1 − 10⁻⁶]. Reliability values are bounded to [0, 1].';
        const structuralReliabilityRule = 'Rstruct = 0.30 × Rstrength + 0.30 × Rlineup '
            + '+ 0.10 × Rform + 0.10 × Rmargin + 0.15 × Rmap + 0.05 × Rveto.';
        const mapBaseRule = 'For team i: baseline_i = (total wins_i + 4) ÷ '
            + '(total maps_i + 8); smoothed_i = (map wins_i + 10 × baseline_i) ÷ '
            + '(map count_i + 10); specialization_i = logit(smoothed_i) − '
            + 'logit(baseline_i). delta = clip(specialization_A − specialization_B, −0.6, 0.6); '
            + 'Pmap = sigmoid(logit(Pbase-map) + 0.65 × delta). '
            + 'Rmap = clip(min(total maps_A, total maps_B) ÷ 30, 0, 1) × '
            + '(paired map rows ÷ all map rows). Series calculation multiplies map outcomes '
            + 'in order and stops at floor(bestOf ÷ 2) + 1 wins.';
        let mapSummary;
        let mapModeRule;
        const mapEquations = [
            'b_i = (W_i + 4) ÷ (N_i + 8)',
            'q_i,m = (W_i,m + 10 × b_i) ÷ (N_i,m + 10)',
            'a_i,m = logit(q_i,m) − logit(b_i)',
            'δ_m = clip(a_A,m − a_B,m, −0.6, 0.6)',
            'P_m = sigmoid(logit(P_baseMap) + 0.65 × δ_m)',
            'R_map = clip(min(N_A, N_B) ÷ 30, 0, 1) × (M_paired ÷ M_all)',
            'S_BO(P_baseMap) = P_baseSeries',
        ];
        if (prediction.structural.mapSeries.mode === 'official-maps') {
            mapSummary = 'All match maps are listed, so the series uses them in order.';
            mapModeRule = 'Use each listed map\'s Pmap in order; use Pbase-map when its statistics '
                + 'are missing. Official maps means listed slots = bestOf. '
                + 'Rveto = recognized listed maps ÷ bestOf.';
        } else if (prediction.structural.mapSeries.mode === 'partial-maps') {
            mapSummary = 'Some match maps are known; the remaining slots are estimated.';
            mapModeRule = 'Use listed Pmap values in order, with Pbase-map for missing statistics; '
                + 'fill bestOf − listed slots with the generic-map rule. '
                + 'Rveto = recognized listed maps ÷ bestOf.';
        } else if (prediction.structural.mapSeries.mode === 'pre-veto') {
            mapSummary = 'No maps are official yet, so this best-of-three simulates likely vetoes.';
            mapModeRule = 'For a best-of-3 with at least 7 models, keep the 7 maps with the most '
                + 'pick/ban activity and average both legal first-action orders 50/50. Branch '
                + 'raw weight = max(0.005, habit)^(1 − 0.60) × exp(sign × 0.60 × '
                + 'clip(logit(branch P_A), −4, 4) ÷ 0.75), then each raw weight is divided '
                + 'by the sum across the available branches; sign is +1 for A and −1 for B, and '
                + 'missing habit = 1 ÷ remaining maps. '
                + 'Rveto = finite pick/ban fields ÷ (map models × 4).';
            mapEquations.push(
                'u_j = clip(logit(P_A,j), −4, 4)',
                'r_j = max(0.005, h_j)^0.4 × exp(sign_j × 0.60 × u_j ÷ 0.75)',
                'w_j = r_j ÷ sum_k r_k',
            );
        } else {
            mapSummary = 'There is not enough information for a full map or veto simulation, '
                + 'so a consistent fallback uses the available map data.';
            mapModeRule = 'Rank maps by max(0.005, mean available pick/ban habits), using '
                + '1 ÷ map count when no habits exist; break ties by name and cycle through '
                + 'ranked Pmap values to fill bestOf slots. With no models, every slot uses '
                + 'Pbase-map. Rveto = 0.';
        }
        const qualityRule = prediction.mode === 'market'
            ? 'Q = clip(100 × Rmarket, 0, 100). '
                + `Current Rmarket = ${marketReliability} and Q = `
                + `${prediction.quality.score.toFixed(2)}. `
            : 'Q = clip(60 × Rstruct, 0, 100). '
                + `Current Rstruct = ${structuralReliability} and Q = `
                + `${prediction.quality.score.toFixed(2)}; the maximum is 60, so this mode `
                + 'can never reach High. ';
        const modeSummary = prediction.mode === 'market'
            ? 'Uses only the middle estimate from bookmaker odds after invalid, repeated, and '
                + 'unusually distant entries are removed. Page statistics do not change this '
                + 'probability.'
            : 'Ignores bookmaker odds and uses the available team, player, form, and map data. '
                + 'Missing evidence pulls the result toward 50/50.';
        const modeRule = prediction.mode === 'market'
            ? prediction.market.available
                ? 'Pfinal = Pmarket = clip(median(kept de-vigged bookmaker probabilities), '
                    + `0.02, 0.98). Current Pmarket = ${formatPercent(prediction.market.probability)}. `
                    + 'Page-statistics terms do not enter Pfinal.'
                : 'Pfinal is unavailable because no bookmaker probability survived validation '
                    + 'and outlier filtering. Page statistics are not used as a fallback.'
            : 'Pfinal = clip(sigmoid(Rstruct × logit(Pstruct)), 0.02, 0.98). '
                + 'Mark insufficient when Rstruct < 0.35; exactly 0.35 is allowed. '
                + `Current Rstruct = ${structuralReliability}.`;
        const marketSummary = prediction.mode === 'stats'
            ? 'Bookmaker odds are shown only as a reference here; Page stats only does not use '
                + 'them in the prediction.'
            : 'Uses the middle bookmaker estimate after repeated, implausible, and unusually '
                + 'distant entries are removed.';
        const qualitySummary = prediction.quality.label === 'High'
            ? 'High means the evidence has strong completeness and agreement. This measures '
                + 'the evidence, not the winner\'s chance or a guarantee of accuracy.'
            : prediction.quality.label === 'Medium'
                ? 'Medium means the evidence is useful but has moderate completeness and '
                    + 'agreement. This measures the evidence, not the winner\'s chance or a '
                    + 'guarantee of accuracy.'
                : 'Low means the evidence has limited completeness or agreement. This measures '
                    + 'the evidence, not the winner\'s chance or a guarantee of accuracy.';

        return {
            mode: entry(
                modeSummary,
                technical.mode,
                `${modeRule} ${prediction.mode === 'market' ? clipDefinition : sharedFunctions}`,
                prediction.mode === 'market'
                    ? [
                        'p_i = o_B,i ÷ (o_A,i + o_B,i)',
                        'P_final = P_market = clip(median_K(p_i), 0.02, 0.98)',
                    ]
                    : [
                        'P_final = clip(sigmoid(R_struct × logit(P_struct)), 0.02, 0.98)',
                    ],
            ),
            scoreline: entry(
                prediction.likelyScoreline
                    ? 'The highlighted score is the single most likely final result. The table '
                        + 'lists every possible score and each score\'s overall chance, not its '
                        + 'chance after assuming a winner.'
                    : 'No score is shown because the map estimate and overall predicted winner '
                        + 'do not point to the same side.',
                technical.scoreline,
                'Start with structural score distribution D. OA = sum D(score) over '
                    + `${teamA}-win scores; OB = sum D(score) over ${teamB}-win scores. `
                    + 'For A-win scores, D\'(score) = D(score) × Pfinal ÷ OA; for B-win scores, '
                    + 'D\'(score) = D(score) × (1 − Pfinal) ÷ OB. Choose the largest D\', '
                    + 'breaking ties by score text, and show it only when its winner matches '
                    + 'the final winner.',
                [
                    'O_A = sum_Awin D(x)',
                    'O_B = sum_Bwin D(x)',
                    'D′(x) = { D(x) × P_final ÷ O_A for A-win x; D(x) × (1 − P_final) ÷ O_B for B-win x }',
                    'x* = argmax_x D′(x)',
                ],
            ),
            mapSeries: entry(
                mapSummary,
                technical.mapSeries,
                `${mapBaseRule} ${mapModeRule} ${sharedFunctions} S_BO is the exact `
                    + 'first-to-(floor(bestOf ÷ 2) + 1) ordered-map series probability.',
                mapEquations,
            ),
            quality: entry(
                qualitySummary,
                `${technical.quality} The score does not measure how strongly one team is favored.`,
                `${qualityRule}${prediction.mode === 'market' ? '' : structuralReliabilityRule} `
                    + `${prediction.mode === 'market' ? 'Rmarket = clip(kept providers '
                        + '÷ 6, 0, 1) × clip(1 − pre-filter MAD ÷ 0.10, 0, 1). ' : ''}Bands use `
                    + 'unrounded Q: Low if Q < 45; Medium if 45 ≤ Q < 70; High if Q ≥ 70. '
                    + 'clip(x, a, b) = min(b, max(a, x)); MAD is the median absolute deviation.',
                prediction.mode === 'market'
                    ? [
                        'Q = clip(100 × R_market, 0, 100)',
                        'R_market = clip(n ÷ 6, 0, 1) × clip(1 − MAD ÷ 0.10, 0, 1)',
                        'band(Q) = { Low if Q < 45; Medium if 45 ≤ Q < 70; High if Q ≥ 70 }',
                    ]
                    : [
                        'Q = clip(60 × R_struct, 0, 100)',
                        'R_struct = 0.30 × R_strength + 0.30 × R_lineup + 0.10 × R_form + 0.10 × R_margin + 0.15 × R_map + 0.05 × R_veto',
                        'band(Q) = { Low if Q < 45; Medium if 45 ≤ Q < 70; High if Q ≥ 70 }',
                    ],
            ),
            market: entry(
                marketSummary,
                technical.market,
                'Require a named, unique provider, both odds in [1.01, 100], and '
                    + '(1 ÷ oddsA + 1 ÷ oddsB) in [0.90, 1.25]. pA = oddsB ÷ '
                    + '(oddsA + oddsB); m = median(pA); MAD = median(|pA − m|). Keep '
                    + '|pA − m| ≤ max(0.025, 4 × MAD). Pmarket = clip(median(kept pA), '
                    + '0.02, 0.98); Rmarket = clip(kept providers ÷ 6, 0, 1) × '
                    + 'clip(1 − MAD ÷ 0.10, 0, 1). MAD is calculated before outlier removal. '
                    + 'The first named row reserves its provider before that row\'s odds are '
                    + 'validated, so a later row with the same provider is a duplicate. '
                    + clipDefinition,
                [
                    'p_i = o_B,i ÷ (o_A,i + o_B,i)',
                    'm = median_i(p_i)',
                    'MAD = median_i(|p_i − m|)',
                    'K = { i : |p_i − m| ≤ max(0.025, 4 × MAD) }',
                    'P_market = clip(median_K(p_i), 0.02, 0.98)',
                    'R_market = clip(|K| ÷ 6, 0, 1) × clip(1 − MAD ÷ 0.10, 0, 1)',
                ],
            ),
            rejected: entry(
                'These odds rows were ignored because they were incomplete, repeated, '
                    + 'implausible, or far from the group.',
                technical.rejected,
                'Reject when the provider is missing or repeated, odds fall outside '
                    + '[1.01, 100], (1 ÷ oddsA + 1 ÷ oddsB) falls outside [0.90, 1.25], or '
                    + '|pA − median(pA)| > max(0.025, 4 × MAD). Rejected count is the number '
                    + 'of rows failing at least one rule. The first named row reserves that '
                    + 'provider before its odds are validated.',
            ),
            structural: entry(
                'Shows what the match and analytics statistics say before bookmaker odds are '
                    + 'considered.',
                technical.structural,
                'z = clip(zstrength + zlineup + zform + zmargin, −3, 3); '
                    + 'Pbase-series = sigmoid(z). Find the constant Pbase-map whose exact '
                    + 'best-of series probability equals Pbase-series using 60 bisection steps; '
                    + 'apply the map/veto model and exact first-to-(floor(bestOf ÷ 2) + 1) '
                    + 'distribution; Pstruct = clip(result, 0.02, 0.98). '
                    + structuralReliabilityRule + ' ' + sharedFunctions,
                [
                    'z = clip(z_strength + z_lineup + z_form + z_margin, −3, 3)',
                    'P_baseSeries = sigmoid(z)',
                    'S_BO(P_baseMap) = P_baseSeries',
                    'P_struct = clip(P_adjusted, 0.02, 0.98)',
                    'R_struct = 0.30 × R_strength + 0.30 × R_lineup + 0.10 × R_form + 0.10 × R_margin + 0.15 × R_map + 0.05 × R_veto',
                ],
            ),
            strength: entry(
                'Compares Valve ranking strength; more points and a better (lower) rank help.',
                technical.strength,
                'v = clip(ln((pointsA + 100) ÷ (pointsB + 100)), −2, 2); '
                    + 'r = clip(ln((rankB + 5) ÷ (rankA + 5)), −2, 2); ratio = '
                    + '(0.65 × Ivrs × v + 0.35 × Irank × r) ÷ '
                    + '(0.65 × Ivrs + 0.35 × Irank) when that denominator is positive, '
                    + 'otherwise ratio = 0; '
                    + 'zstrength = 1.15 × ratio; Rstrength = 0.65 × Ivrs + 0.35 × Irank. '
                    + 'The displayed value is ratio. Ivrs and Irank are 1 only when both teams '
                    + 'have that valid input pair, and 0 otherwise. ' + clipDefinition,
                [
                    'v = clip(ln((points_A + 100) ÷ (points_B + 100)), −2, 2)',
                    'r = clip(ln((rank_B + 5) ÷ (rank_A + 5)), −2, 2)',
                    'q = { (0.65 × I_V × v + 0.35 × I_R × r) ÷ (0.65 × I_V + 0.35 × I_R) if denominator > 0; 0 otherwise }',
                    'z_strength = 1.15 × q',
                    'R_strength = 0.65 × I_V + 0.35 × I_R',
                ],
            ),
            lineup: entry(
                'Compares player ratings, with extra attention to each team\'s weakest and '
                    + 'strongest two players.',
                technical.lineup,
                'b = clip(rating, 0.75, 1.35); with event rating e, effective = '
                    + 'b + 0.15 × clip(e − b, −0.35, 0.35), otherwise effective = b. '
                    + 'L = 0.60 × mean(all) + 0.25 × mean(bottom 2) + 0.15 × mean(top 2), '
                    + 'requiring at least 3 players per team. Rlineup = '
                    + 'clip(min(validA, validB) ÷ 5, 0, 1); zlineup = Rlineup × '
                    + 'clip(4 × (LA − LB), −0.75, 0.75). Display = zlineup. If either team '
                    + 'has fewer than 3 valid players, zlineup = Rlineup = 0. '
                    + clipDefinition,
                [
                    'b_j = clip(rating_j, 0.75, 1.35)',
                    'e_j = { b_j + 0.15 × clip(event_j − b_j, −0.35, 0.35) if event rating exists; b_j otherwise }',
                    'L_i = 0.60 × mean(E_i) + 0.25 × mean(bottom_2(E_i)) + 0.15 × mean(top_2(E_i))',
                    'R_lineup = clip(min(n_A, n_B) ÷ 5, 0, 1)',
                    'z_lineup = R_lineup × clip(4 × (L_A − L_B), −0.75, 0.75)',
                ],
            ),
            form: entry(
                'Compares recent level and whether each team\'s results are improving or declining.',
                technical.form,
                'Use the last 5 finite values per team and require at least 2. For team i, '
                    + 'mean index kbar = (ni − 1) ÷ 2 and OLS slope betai = sum((k − kbar) × '
                    + '(xik − mean xi)) ÷ sum((k − kbar)^2). level = '
                    + 'clip((meanA − meanB) ÷ 50, −1, 1); trend = '
                    + 'clip((betaA − betaB) ÷ 5, −1, 1); '
                    + 'zform = 0.15 × level + 0.06 × trend; '
                    + 'Rform = clip(min(sample lengths) ÷ 5, 0, 1). Rform affects overall '
                    + 'reliability but does not multiply zform. If either team has fewer than '
                    + '2 values, all form terms are 0. ' + clipDefinition,
                [
                    'kbar_i = (n_i − 1) ÷ 2',
                    'beta_i = sum_k ((k − kbar_i) × (x_i,k − mean(x_i))) ÷ sum_k (k − kbar_i)^2',
                    'level = clip((mean(x_A) − mean(x_B)) ÷ 50, −1, 1)',
                    'trend = clip((beta_A − beta_B) ÷ 5, −1, 1)',
                    'z_form = 0.15 × level + 0.06 × trend',
                    'R_form = clip(min(n_A, n_B) ÷ 5, 0, 1)',
                ],
            ),
            margin: entry(
                'Rewards teams that tend to win by more rounds and keep their losses closer.',
                technical.margin,
                'With at least 5 matches per team: edge = clip(((B lost-in-wins − '
                    + 'A lost-in-wins) + (A won-in-losses − B won-in-losses)) ÷ 10, −1, 1); '
                    + 'zmargin = 0.12 × edge; Rmargin = '
                    + 'clip(min(matchesA, matchesB) ÷ 5, 0, 1). If either team has fewer than '
                    + '5 matches or a required value is missing, both are 0. '
                    + clipDefinition,
                [
                    'e = clip(((LW_B − LW_A) + (WL_A − WL_B)) ÷ 10, −1, 1)',
                    'z_margin = 0.12 × e',
                    'R_margin = clip(min(M_A, M_B) ÷ 5, 0, 1)',
                ],
            ),
            structuralShare: entry(
                prediction.mode === 'market'
                    ? 'Page statistics have no share in a Market-estimated probability.'
                    : 'Only page statistics are used, while missing data still pulls the result '
                        + 'toward 50/50.',
                technical.structuralShare,
                prediction.mode === 'market'
                    ? 'Displayed structural share = 0%. Pfinal = Pmarket; no structural term '
                        + 'enters the probability.'
                    : 'Displayed share = 100% because no market source is used; '
                        + 'Pfinal = clip(sigmoid(Rstruct × logit(Pstruct)), 0.02, 0.98). '
                        + structuralReliabilityRule + ' ' + sharedFunctions,
                prediction.mode === 'market'
                    ? [
                        'structural share = 0%',
                        'P_final = P_market',
                    ]
                    : [
                        'displayed source share = 100%',
                        'P_final = clip(sigmoid(R_struct × logit(P_struct)), 0.02, 0.98)',
                    ],
            ),
            updated: entry(
                'Shows when the data behind this card was last downloaded or restored from cache.',
                technical.updated,
                'Let t = scheduled start − now. Refresh every 30 minutes '
                    + 'when t > 60 minutes, every 5 minutes when 10 minutes < t ≤ 60 minutes, '
                    + 'or every 90 seconds when 0 < t ≤ 10 minutes. Timers stop at the next '
                    + 'threshold, then run one final check about 1 second after the scheduled '
                    + 'start; that check stops further refreshes.',
            ),
        };
    }

    const MATHML_NAMESPACE = 'http://www.w3.org/1998/Math/MathML';
    const MATH_FUNCTION_NAMES = new Set([
        'argmax',
        'band',
        'bottom',
        'clip',
        'exp',
        'ln',
        'logit',
        'max',
        'mean',
        'median',
        'min',
        'sigmoid',
        'sum',
        'top',
        'winner',
    ]);
    const MATH_TEXT_WORDS = new Set([
        'displayed',
        'denominator',
        'event',
        'exists',
        'for',
        'if',
        'in',
        'market',
        'otherwise',
        'rating',
        'share',
        'source',
        'High',
        'Low',
        'Medium',
        'win',
    ]);

    function createMathNode(name, text = '') {
        const node = document.createElementNS(MATHML_NAMESPACE, name);
        if (text) node.textContent = text;
        return node;
    }

    function createMathIdentifier(token) {
        const separator = token.indexOf('_');
        const base = separator < 0 ? token : token.slice(0, separator);
        const subscript = separator < 0 ? '' : token.slice(separator + 1);
        const baseNode = createMathNode('mi', base);
        if (MATH_FUNCTION_NAMES.has(base)) baseNode.setAttribute('mathvariant', 'normal');
        if (!subscript) return baseNode;
        const subscriptNode = createMathNode(
            /^[A-Za-z]$/.test(subscript) ? 'mi' : 'mtext',
            subscript.replaceAll('-', '‑'),
        );
        const wrapper = createMathNode('msub');
        wrapper.append(baseNode, subscriptNode);
        return wrapper;
    }

    function createMathExpression(expression) {
        const math = createMathNode('math');
        math.classList.add('hltv-sp-prediction-explainer-equation');
        math.setAttribute('display', 'block');
        math.setAttribute('aria-label', expression);
        const row = createMathNode('mrow');
        const tokens = expression.match(
            /10⁻⁶|[A-Za-zΑ-ω]+(?:_[A-Za-z0-9,-]+)?|\d+(?:\.\d+)?|\s+|./gu,
        ) || [];
        for (let index = 0; index < tokens.length; index += 1) {
            const token = tokens[index];
            if (/^\s+$/.test(token)) {
                const space = createMathNode('mspace');
                space.setAttribute('width', '0.2em');
                row.append(space);
                continue;
            }
            if (token === '10⁻⁶') {
                const power = createMathNode('msup');
                const exponent = createMathNode('mrow');
                exponent.append(createMathNode('mo', '−'), createMathNode('mn', '6'));
                power.append(createMathNode('mn', '10'), exponent);
                row.append(power);
                continue;
            }
            if (token === '^' && row.lastElementChild && tokens[index + 1]) {
                let base = row.lastElementChild;
                const next = tokens[index + 1];
                if (/^\d+(?:\.\d+)?$/.test(next)) {
                    if (base.localName === 'mo' && base.textContent === ')') {
                        const children = [...row.children];
                        let depth = 0;
                        let openingIndex = -1;
                        for (let cursor = children.length - 1; cursor >= 0; cursor -= 1) {
                            const child = children[cursor];
                            if (child.localName !== 'mo') continue;
                            if (child.textContent === ')') depth += 1;
                            if (child.textContent !== '(') continue;
                            depth -= 1;
                            if (depth === 0) {
                                openingIndex = cursor;
                                break;
                            }
                        }
                        if (openingIndex >= 0) {
                            const grouped = createMathNode('mrow');
                            for (const child of children.slice(openingIndex)) {
                                grouped.append(child);
                            }
                            base = grouped;
                        } else {
                            base.remove();
                        }
                    } else {
                        base.remove();
                    }
                    const power = createMathNode('msup');
                    power.append(base, createMathNode('mn', next));
                    row.append(power);
                    index += 1;
                    continue;
                }
            }
            if (/^\d+(?:\.\d+)?$/.test(token)) {
                row.append(createMathNode('mn', token));
            } else if (/^[A-Za-zΑ-ω]+(?:_[A-Za-z0-9,-]+)?$/u.test(token)) {
                if (MATH_TEXT_WORDS.has(token)) {
                    row.append(createMathNode('mtext', token));
                } else {
                    row.append(createMathIdentifier(token));
                }
            } else {
                row.append(createMathNode('mo', token));
            }
        }
        math.append(row);
        return math;
    }

    function createScorelineResults(prediction, inputs) {
        const wrapper = createElement('div', 'hltv-sp-prediction-scoreline-results');
        const table = createElement('table', 'hltv-sp-prediction-scoreline-table');
        table.append(createElement(
            'caption',
            'hltv-sp-prediction-scoreline-caption',
            'Exact score chances',
        ));
        const head = createElement('thead');
        const headRow = createElement('tr');
        const resultHeading = createElement('th', '', 'Final result');
        resultHeading.scope = 'col';
        const probabilityHeading = createElement('th', '', 'Probability');
        probabilityHeading.scope = 'col';
        headRow.append(resultHeading, probabilityHeading);
        head.append(headRow);

        const body = createElement('tbody');
        for (const [scoreline, probability] of sortedScorelineEntries(
            prediction.scorelineDistribution,
        )) {
            const scores = scoreline.split('-').map(Number);
            const winnerIndex = scorelineWinnerIndex(scoreline);
            const row = createElement(
                'tr',
                scoreline === prediction.likelyScoreline
                    ? 'hltv-sp-prediction-scoreline-row-most-likely'
                    : '',
            );
            row.dataset.scoreline = scoreline;
            const result = createElement('th');
            result.scope = 'row';
            result.append(createElement(
                'span',
                'hltv-sp-prediction-scoreline-result',
                `${inputs.teams[winnerIndex].name} wins `
                    + `${scores[winnerIndex]}–${scores[1 - winnerIndex]}`,
            ));
            if (scoreline === prediction.likelyScoreline) {
                result.append(createElement(
                    'span',
                    'hltv-sp-prediction-scoreline-badge',
                    'Most likely',
                ));
            }
            row.append(
                result,
                createElement(
                    'td',
                    'hltv-sp-prediction-scoreline-probability',
                    formatPercent(probability),
                ),
            );
            body.append(row);
        }
        table.append(head, body);
        wrapper.append(table);
        return wrapper;
    }

    function createExplainer(
        label,
        explanation,
        className = '',
        supplementalContent = null,
    ) {
        const wrapper = createElement(
            'div',
            `hltv-sp-prediction-explainer${className ? ` ${className}` : ''}`,
        );
        const labelElement = createElement(
            'span',
            'hltv-sp-prediction-explainer-label',
            label,
        );
        const button = createElement('button', 'hltv-sp-prediction-explainer-button');
        button.type = 'button';
        button.setAttribute('aria-label', `Explain ${label}`);
        const focusIdentity = `${className || label}:${explanation.summary}`;
        button.dataset.predictionFocus = `help:${focusIdentity}`;
        const popup = createElement('div', 'hltv-sp-prediction-explainer-popup');
        popup.id = `hltv-sp-prediction-explanation-${++explanationSequence}`;
        popup.setAttribute('role', 'group');
        popup.setAttribute('aria-label', `${label} explanation`);
        popup.tabIndex = 0;
        popup.dataset.predictionFocus = `popup:${focusIdentity}`;
        popup.dataset.predictionScroll = `popup:${focusIdentity}`;
        popup.hidden = true;
        const summary = createElement(
            'p',
            'hltv-sp-prediction-explainer-summary',
            explanation.summary,
        );
        summary.id = `${popup.id}-summary`;
        const technical = createElement('section', 'hltv-sp-prediction-explainer-technical');
        technical.append(createElement(
            'h4',
            'hltv-sp-prediction-explainer-technical-heading',
            'Technical details and formula',
        ));
        technical.append(createElement(
            'p',
            'hltv-sp-prediction-explainer-technical-copy',
            explanation.details,
        ));
        const hasEquations = explanation.equations.length > 0;
        const formula = createElement(
            'div',
            'hltv-sp-prediction-explainer-formula'
                + (hasEquations ? ' hltv-sp-prediction-explainer-formula-math' : ''),
        );
        formula.append(
            createElement(
                'span',
                'hltv-sp-prediction-explainer-formula-label',
                hasEquations ? 'Exact calculation' : 'Exact rule',
            ),
        );
        if (hasEquations) {
            const equations = createElement(
                'div',
                'hltv-sp-prediction-explainer-equations',
            );
            for (const expression of explanation.equations) {
                equations.append(createMathExpression(expression));
            }
            formula.append(equations);
            formula.append(createElement(
                'span',
                'hltv-sp-prediction-explainer-formula-context',
                'Definitions and conditions',
            ));
        }
        formula.append(createElement(
            'p',
            'hltv-sp-prediction-explainer-formula-copy',
            explanation.formula,
        ));
        technical.append(formula);
        popup.append(summary);
        if (supplementalContent) popup.append(supplementalContent);
        popup.append(technical);
        button.setAttribute('aria-controls', popup.id);
        button.setAttribute('aria-describedby', summary.id);
        button.setAttribute('aria-expanded', 'false');
        let pinned = false;
        let hovered = false;
        let focusWithin = false;
        let manuallyClosed = false;
        const setOpen = (open) => {
            popup.hidden = !open;
            button.setAttribute('aria-expanded', String(open));
            wrapper.classList.toggle('hltv-sp-prediction-explainer-open', open);
        };
        const syncOpen = () => setOpen(
            !manuallyClosed && (pinned || hovered || focusWithin),
        );
        const closePinned = () => {
            pinned = false;
            delete wrapper.dataset.predictionPinned;
            manuallyClosed = true;
            setOpen(false);
            if (activePinnedExplanationClose === closePinned) {
                activePinnedExplanationClose = null;
            }
        };
        wrapper.addEventListener('mouseenter', () => {
            if (activePinnedExplanationClose
                && activePinnedExplanationClose !== closePinned) {
                activePinnedExplanationClose();
            }
            hovered = true;
            manuallyClosed = false;
            syncOpen();
        });
        wrapper.addEventListener('mouseleave', () => {
            hovered = false;
            if (!pinned) syncOpen();
        });
        wrapper.addEventListener('focusin', () => {
            if (activePinnedExplanationClose
                && activePinnedExplanationClose !== closePinned) {
                activePinnedExplanationClose();
            }
            focusWithin = true;
            manuallyClosed = false;
            syncOpen();
        });
        wrapper.addEventListener('focusout', (event) => {
            if (event.relatedTarget instanceof Node
                && wrapper.contains(event.relatedTarget)) return;
            focusWithin = false;
            if (!pinned) syncOpen();
        });
        const pin = () => {
            activePinnedExplanationClose?.();
            pinned = true;
            wrapper.dataset.predictionPinned = 'true';
            manuallyClosed = false;
            activePinnedExplanationClose = closePinned;
            setOpen(true);
        };
        pinExplanation.set(button, pin);
        button.addEventListener('click', () => {
            if (pinned) closePinned();
            else pin();
        });
        wrapper.addEventListener('keydown', (event) => {
            if (event.key !== 'Escape' || popup.hidden) return;
            event.preventDefault();
            event.stopPropagation();
            hovered = false;
            pinned = false;
            delete wrapper.dataset.predictionPinned;
            if (activePinnedExplanationClose === closePinned) {
                activePinnedExplanationClose = null;
            }
            button.focus({ preventScroll: true });
            focusWithin = true;
            manuallyClosed = true;
            setOpen(false);
        });
        wrapper.append(labelElement, button, popup);
        return wrapper;
    }

    function addBreakdownRow(list, label, value, explanation) {
        const row = createElement('div', 'hltv-sp-prediction-grid-row');
        const term = createElement('dt');
        term.append(createExplainer(label, explanation));
        row.append(term, createElement('dd', '', value));
        list.append(row);
    }

    function addBreakdownGroup(groups, heading, rows) {
        const group = createElement('section', 'hltv-sp-prediction-breakdown-group');
        group.append(createElement(
            'h3',
            'hltv-sp-prediction-breakdown-heading',
            heading,
        ));
        const list = createElement('dl', 'hltv-sp-prediction-grid');
        for (const row of rows) addBreakdownRow(list, ...row);
        group.append(list);
        groups.append(group);
    }

    function predictionExplanations(prediction, inputs, fetchedAt = Date.now()) {
        if (prediction.modelVersion !== CONFIG.predictionModelVersion) {
            return legacyPredictionExplanations(prediction, inputs, fetchedAt);
        }
        const entry = (summary, details, formula) => ({ summary, details, formula, equations: [] });
        if (prediction.mode === 'market') return {
            mode: entry('Independent bookmaker consensus.',
                `${prediction.market.providerCount} valid providers; ${prediction.market.rejectedCount} rejected rows. Player and map statistics do not change these odds.`,
                'For each complete odds pair, remove the margin; take the median after the existing outlier filter.'),
            quality: entry('Bookmaker source coverage.', `${prediction.market.providerCount} valid providers. Median absolute probability deviation: ${formatPercent(prediction.market.medianAbsoluteDeviation || 0)}. Provider count and price agreement describe the available market data.`,
                'This is source coverage, not a calibrated confidence level.'),
        };
        return {
            mode: entry('A local estimate from HLTV statistics.',
                'The announced players and core map records drive the prediction. Recent team performance adjusts player ratings; VRS supplies a small reference input.',
                'Map log-odds = 0.60 × lineup + 0.30 × map record + 0.10 × VRS reference.'),
            lineup: entry('Five equally weighted announced players.',
                'Recent ratings describe games with this team. The overlapping windows are one adjusted estimate; unknown three-month sample sizes are not fabricated.',
                'Effective rating = baseline + (5/12) × N/(N+10) × (recent − baseline). With only recent data: 1 + N/(N+10) × (recent − 1). A 0.10 lineup rating gap maps to 60% map probability before pooling.'),
            maps: entry('Sample-aware core map records.',
                'Core results cover matches with at least three of the announced five. Rounded source rates yield approximate win counts. Pick/ban opportunities describe the team, not necessarily that core.',
                'Shrunk win rate = (N × win rate + 4)/(N + 8). Compare the two shrunk log-odds for this map only.'),
            veto: entry('Possible map sequences, conditioned on known veto information.',
                'First-action tendencies and opportunity-aware later choices are combined with match-winning utility. Unknown starting orders are averaged. The standard veto rules are assumptions when HLTV does not specify them.',
                'Choice weight ∝ exp((0.60 × log(habit) + 0.40 × signed clipped log-odds of the child match probability) / 0.75).'),
            strength: entry('VRS supplies 10% of the per-map log-odds input.',
                'The Glicko-style reference uses Q = ln(10)/400 and RD = 75. Its expected result is treated as a reference BO3, independently of the actual match format.',
                'Find q such that 3q² − 2q³ equals the reference series probability; use log(q/(1−q)). Missing VRS contributes zero log-odds.'),
            scoreline: entry('Winner and score probabilities come from the same calculation.',
                'For each possible veto, calculate every terminal series score exactly. Weight those distributions by the probability of each veto. The most likely score need not belong to the overall favorite.',
                'Sum terminal score probabilities for each winner. No completeness multiplier or later scoreline rescaling is applied.'),
            coverage: entry('What information was available.',
                'Missing players, rankings, map records and sources are shown explicitly. Limited estimate describes missing information, not historical prediction accuracy.',
                'Model parameters are fixed heuristics. Shared match history and opponent-schedule bias are not eliminated by the weighted pool.'),
            updated: entry('Source snapshots remain fixed for this page visit.',
                `Calculated ${new Date(fetchedAt).toLocaleString()}. Local lineup and veto changes can update the estimate until scheduled start.`,
                'At most three additional HTTP attempts per document; no ordinary retries or periodic network refresh.'),
        };
    }

    function predictionTable(headers, rows, className = '') {
        const wrapper = createElement('div', 'hltv-sp-prediction-table-scroll');
        wrapper.style.overflowX = 'auto';
        const table = createElement('table', `hltv-sp-prediction-scoreline-table hltv-sp-prediction-data-table ${className}`);
        const head = createElement('thead');
        const header = createElement('tr');
        headers.forEach((label) => {
            const cell = createElement('th', '', label);
            cell.scope = 'col';
            header.append(cell);
        });
        head.append(header);
        const body = createElement('tbody');
        rows.forEach((values) => {
            const row = createElement('tr');
            values.forEach((value) => row.append(createElement('td', '', String(value))));
            body.append(row);
        });
        table.append(head, body);
        wrapper.append(table);
        return wrapper;
    }

    function renderPrediction(prediction, inputs, fetchedAt = Date.now(), options = {}) {
        if (prediction.modelVersion !== CONFIG.predictionModelVersion) {
            renderLegacyPrediction(prediction, inputs, fetchedAt, options);
            return;
        }
        const card = predictionCard(true);
        if (!card) return;
        const explanations = options.explanations || predictionExplanations(prediction, inputs, fetchedAt);
        const pageScroll = [globalThis.scrollX, globalThis.scrollY];
        const pinnedFocus = card.querySelector('[data-prediction-pinned] button')?.dataset.predictionFocus;
        const wasOpen = card.querySelector('.hltv-sp-prediction-details')?.open === true;
        const focused = card.contains(document.activeElement)
            ? document.activeElement?.dataset?.predictionFocus : null;
        const scrollPositions = [...card.querySelectorAll('[data-prediction-scroll]')].map((element) => (
            [element.dataset.predictionScroll, element.scrollLeft, element.scrollTop]
        ));
        activePinnedExplanationClose?.();
        activePinnedExplanationClose = null;
        card.replaceChildren();
        card.dataset.predictionSource = options.archived ? 'archive' : 'current';
        card.dataset.predictionModel = prediction.modelVersion;
        const head = createElement('div', 'hltv-sp-prediction-head');
        head.append(createElement('div', 'hltv-sp-prediction-title', 'Match prediction'));
        const mode = createElement('select', 'hltv-sp-prediction-mode');
        mode.dataset.predictionFocus = 'mode';
        mode.setAttribute('aria-label', 'Prediction mode');
        for (const [value, label] of [['stats', 'HLTV stats'], ['market', 'Market-estimated']]) {
            const option = createElement('option', '', label);
            option.value = value;
            mode.append(option);
        }
        mode.value = prediction.mode;
        mode.addEventListener('change', async () => {
            state.mode = CONFIG.modes.includes(mode.value) ? mode.value : CONFIG.defaultMode;
            renderCurrentPrediction();
            document.querySelector(`#${CONFIG.cardId} .hltv-sp-prediction-mode`)?.focus({ preventScroll: true });
            try { await extensionApi.storage.local.set({ [CONFIG.modeKey]: state.mode }); } catch { /* Local choice persists for this visit. */ }
        });
        head.append(mode);
        const body = createElement('div', 'hltv-sp-prediction-body');
        if (options.archived) {
            body.append(createElement('div', 'hltv-sp-prediction-history-notice',
                `Saved pre-match estimate from ${new Date(options.calculatedAt || fetchedAt).toLocaleString()} · ${prediction.modelVersion}.`));
        }
        const available = Number.isFinite(prediction.probabilityA) && !prediction.insufficient;
        if (!available) {
            body.append(createElement('div', 'hltv-sp-prediction-status', prediction.mode === 'market'
                ? 'Bookmaker odds are unavailable for this match.'
                : 'Insufficient compatible data or unsupported match format.'));
        } else {
            const winner = inputs.teams[prediction.winnerIndex];
            const hero = createElement('div', 'hltv-sp-prediction-hero');
            hero.append(createElement('div', 'hltv-sp-prediction-eyebrow', 'Predicted winner'),
                createElement('div', 'hltv-sp-prediction-winner', winner?.name || 'Even match'),
                createElement('div', 'hltv-sp-prediction-confidence',
                    `${formatPercent(Math.max(prediction.probabilityA, prediction.probabilityB))} win probability`));
            const matchup = createElement('div', 'hltv-sp-prediction-matchup');
            const teams = createElement('div', 'hltv-sp-prediction-teams');
            const rail = createElement('div', 'hltv-sp-prediction-rail');
            rail.setAttribute('role', 'img');
            rail.setAttribute('aria-label', inputs.teams.map((team, index) => `${team.name} ${formatPercent(index ? prediction.probabilityB : prediction.probabilityA)}`).join('; '));
            inputs.teams.forEach((team, index) => {
                const probability = index ? prediction.probabilityB : prediction.probabilityA;
                const selected = index === prediction.winnerIndex;
                const label = createElement('div', `hltv-sp-prediction-team${selected ? ' hltv-sp-prediction-team-winner' : ''}`);
                label.append(createElement('span', 'hltv-sp-prediction-team-name', team.name),
                    createElement('span', 'hltv-sp-prediction-team-probability', formatPercent(probability)));
                teams.append(label);
                const segment = createElement('span', `hltv-sp-prediction-rail-segment hltv-sp-prediction-rail-${selected ? 'winner' : 'loser'}`);
                segment.style.width = `${100 * probability}%`;
                rail.append(segment);
            });
            matchup.append(teams, rail);
            hero.append(matchup);
            const meta = createElement('div', 'hltv-sp-prediction-meta');
            meta.append(createExplainer(prediction.mode === 'stats' ? 'HLTV stats' : 'Market-estimated', explanations.mode, 'hltv-sp-prediction-meta-item'));
            if (prediction.mode === 'stats') {
                meta.append(createExplainer(prediction.coverage?.limited ? 'Limited estimate' : 'Data coverage', explanations.coverage, 'hltv-sp-prediction-meta-item'));
                if (prediction.likelyScoreline) hero.append(createExplainer(
                    `Most likely score: ${prediction.likelyScoreline.replace('-', '–')} · ${formatPercent(prediction.scorelineDistribution[prediction.likelyScoreline])}`,
                    explanations.scoreline, 'hltv-sp-prediction-scoreline', createScorelineResults(prediction, inputs)));
            } else {
                meta.append(createElement('span', 'hltv-sp-prediction-meta-item', `${prediction.market.providerCount} valid providers`));
                const score = (prediction.market.reliability || 0) * 100;
                meta.append(createExplainer(`${score >= 70 ? 'High' : score >= 45 ? 'Medium' : 'Low'} odds quality`,
                    explanations.quality, 'hltv-sp-prediction-meta-item'));
            }
            hero.append(meta);
            body.append(hero);
        }
        if (prediction.mode === 'stats') {
            const details = createElement('details', 'hltv-sp-prediction-details');
            details.open = wasOpen;
            const summary = createElement('summary', '', 'How this estimate was built');
            summary.dataset.predictionFocus = 'breakdown';
            details.append(summary);
            const groups = createElement('div', 'hltv-sp-prediction-breakdown-groups');
            addBreakdownGroup(groups, 'Model inputs', [
                ['Announced lineup', '60% of map log-odds', explanations.lineup],
                ['Core map records', '30% of map log-odds', explanations.maps],
                ['VRS reference', '10% of map log-odds', explanations.strength],
            ]);
            groups.lastElementChild.style.gridColumn = '1 / -1';
            const fixed = (value) => Number.isFinite(value) ? value.toFixed(2) : '—';
            for (const [index, players] of (prediction.structural.players || []).entries()) {
                const section = createElement('section', 'hltv-sp-prediction-breakdown-group');
                section.append(createElement('h3', 'hltv-sp-prediction-breakdown-heading', `${inputs.teams[index].name} · announced players`));
                const ordered = [...players].sort((a, b) => Math.abs(b.effectiveRating - 1) - Math.abs(a.effectiveRating - 1) || a.playerId.localeCompare(b.playerId));
                const table = predictionTable(['Player', '3 months', 'Recent with team', 'Recent maps / rounds', 'Adjusted'], ordered.map((player) => [
                    player.nickname, fixed(player.baselineRating), fixed(player.monthlyRating),
                    player.monthlyRating !== null ? `${player.monthlyMaps} / ${player.monthlyRounds ?? '—'}` : '—',
                    player.available ? fixed(player.effectiveRating) : 'Unknown',
                ]));
                table.dataset.predictionScroll = `players-${index}`;
                section.append(table);
                groups.append(section);
            }
            const mapSection = createElement('section', 'hltv-sp-prediction-breakdown-group');
            mapSection.style.gridColumn = '1 / -1';
            mapSection.append(createElement('h3', 'hltv-sp-prediction-breakdown-heading', 'Map matchup'));
            const mapRows = (prediction.structural.maps || []).map((map) => {
                const record = (index) => {
                    const team = map.teams[index];
                    return Number.isFinite(team?.winRate) && Number.isFinite(team?.maps)
                        ? `${formatPercent(team.winRate)} · ${team.maps} maps${team.source === 'analytics-team' ? ' (team)' : ''}` : 'Unavailable';
                };
                const selection = map.selectionProbability ?? (prediction.structural.mapSeries?.selectedMaps || [])
                    .filter((item) => item.name.toLowerCase() === map.name.toLowerCase())
                    .reduce((total, item) => total + item.selectionProbability, 0);
                return [map.name, record(0), record(1), formatPercent(map.probability), formatPercent(selection)];
            });
            const mapsTable = predictionTable(['Map', inputs.teams[0].name, inputs.teams[1].name, `${inputs.teams[0].name} win`, 'Selected'], mapRows);
            mapsTable.dataset.predictionScroll = 'maps';
            mapSection.append(mapsTable, createElement('p', 'hltv-sp-prediction-note', 'Core records: at least 3 of the announced 5. Team labels mark supplementary Analytics records. Selection means inclusion in the series; later maps may not need to be played.'));
            groups.append(mapSection);
            const scenarios = prediction.structural.scenarios || [];
            const scenarioSection = createElement('section', 'hltv-sp-prediction-breakdown-group');
            scenarioSection.append(createElement('h3', 'hltv-sp-prediction-breakdown-heading', 'Likely map sequences'));
            const vetoMethod = prediction.structural.mapSeries?.method;
            scenarioSection.append(createExplainer(vetoMethod === 'official' ? 'Official map order'
                : vetoMethod === 'veto-mixture' ? 'Assumed veto choices' : 'Veto information unavailable', explanations.veto));
            scenarioSection.append(predictionTable(['Map sequence', 'Scenario chance', `${inputs.teams[0].name} win`], scenarios.slice(0, 3).map((scenario) => [scenario.maps.map((name) => name || 'Unknown map').join(' → '), formatPercent(scenario.probability), formatPercent(scenario.probabilityA)])));
            groups.append(scenarioSection);
            const scores = createElement('section', 'hltv-sp-prediction-breakdown-group');
            scores.append(createElement('h3', 'hltv-sp-prediction-breakdown-heading', 'Scoreline probabilities'), createScorelineResults(prediction, inputs));
            groups.append(scores);
            const coverage = prediction.coverage || {};
            const sources = coverage.sourceRecords || inputs.sourceRecords || [];
            addBreakdownGroup(groups, 'Coverage and freshness', [
                ['Available players', (coverage.lineup || [0, 0]).map((count, i) => `${inputs.teams[i].name}: ${count}/5`).join(' · '), explanations.coverage],
                ['VRS', coverage.vrs ? 'Available for both teams' : 'Unavailable or incomplete', explanations.strength],
                ['Calculated', new Date(options.calculatedAt || fetchedAt).toLocaleString(), explanations.updated],
            ]);
            if (coverage.missing?.length) {
                const missing = createElement('ul', 'hltv-sp-prediction-note');
                coverage.missing.forEach((message) => missing.append(createElement('li', '', message)));
                groups.lastElementChild.append(missing);
            }
            const sourceList = createElement('ul', 'hltv-sp-prediction-note');
            sources.forEach((source) => {
                const item = createElement('li');
                const url = safeUrl(source.href);
                const label = source.kind === 'analytics' ? 'Analytics' : `${inputs.teams.find((team) => team.id === source.teamId)?.name || 'Team'} recent players`;
                if (url?.origin === 'https://www.hltv.org') {
                    const link = createElement('a', '', label);
                    link.href = url.href;
                    link.target = '_blank';
                    link.rel = 'noopener noreferrer';
                    item.append(link);
                } else item.append(label);
                item.append(` · ${source.status || 'unavailable'}${source.fetchedAt ? ` · ${new Date(source.fetchedAt).toLocaleString()}` : ''}${source.window ? ` · ${source.window.startDate}–${source.window.endDate}` : ''}`);
                sourceList.append(item);
            });
            const sourceSection = createElement('section', 'hltv-sp-prediction-breakdown-group');
            sourceSection.append(createElement('h3', 'hltv-sp-prediction-breakdown-heading', 'Source snapshots'), sourceList);
            groups.append(sourceSection);
            details.append(groups, createElement('p', 'hltv-sp-prediction-note', 'Fixed heuristic model. Source coverage is not calibrated prediction confidence.'));
            body.append(details);
        }
        card.append(head, body);
        if (pinnedFocus) {
            const button = [...card.querySelectorAll('button[data-prediction-focus]')]
                .find((candidate) => candidate.dataset.predictionFocus === pinnedFocus);
            pinExplanation.get(button)?.();
        }
        if (focused) [...card.querySelectorAll('[data-prediction-focus]')]
            .find((element) => element.dataset.predictionFocus === focused)?.focus({ preventScroll: true });
        if (globalThis.scrollX !== pageScroll[0] || globalThis.scrollY !== pageScroll[1]) {
            globalThis.scrollTo(pageScroll[0], pageScroll[1]);
        }
        scrollPositions.forEach(([key, left, top]) => {
            const element = [...card.querySelectorAll('[data-prediction-scroll]')].find((candidate) => candidate.dataset.predictionScroll === key);
            if (element) { element.scrollLeft = left; element.scrollTop = top; }
        });
    }

    function renderLegacyPrediction(prediction, inputs, fetchedAt = Date.now(), options = {}) {
        const archived = options.archived === true;
        const calculatedAt = Number.isSafeInteger(options.calculatedAt)
            ? options.calculatedAt
            : fetchedAt;
        const explanations = options.explanations
            || (archived ? null : predictionExplanations(prediction, inputs, fetchedAt));
        if (!explanations) return;
        const card = predictionCard(archived);
        if (!card) return;
        const breakdownWasOpen = card.querySelector(
            '.hltv-sp-prediction-details',
        )?.open === true;
        activePinnedExplanationClose?.();
        activePinnedExplanationClose = null;
        card.replaceChildren();
        card.dataset.predictionSource = archived ? 'archive' : 'current';

        const head = createElement('div', 'hltv-sp-prediction-head');
        head.append(createElement('div', 'hltv-sp-prediction-title', 'Match prediction'));
        const mode = createElement('select', 'hltv-sp-prediction-mode');
        mode.setAttribute('aria-label', 'Prediction mode');
        const marketOption = createElement('option', '', 'Market-estimated');
        marketOption.value = 'market';
        const statsOption = createElement('option', '', 'Page stats only');
        statsOption.value = 'stats';
        mode.append(marketOption, statsOption);
        mode.value = prediction.mode;
        mode.addEventListener('change', async () => {
            const nextMode = CONFIG.modes.includes(mode.value)
                ? mode.value
                : CONFIG.defaultMode;
            state.mode = nextMode;
            if (state.currentPredictions && state.currentRenderInputs) {
                renderCurrentPrediction();
                document.getElementById(CONFIG.cardId)
                    ?.querySelector('.hltv-sp-prediction-mode')
                    ?.focus({ preventScroll: true });
            }
            try {
                await extensionApi.storage.local.set({ [CONFIG.modeKey]: nextMode });
            } catch {
                // The visible choice remains valid for this page session.
            }
        });
        head.append(mode);

        const body = createElement('div', 'hltv-sp-prediction-body');
        if (archived) {
            const notice = createElement('div', 'hltv-sp-prediction-history-notice');
            notice.setAttribute('role', 'note');
            const time = createElement('time', '', new Date(calculatedAt).toLocaleString());
            time.dateTime = new Date(calculatedAt).toISOString();
            notice.append('Saved pre-match estimate from ', time, '. Live and final-match data are not used.');
            body.append(notice);
        }
        if (prediction.mode === 'market' && !prediction.market.available) {
            body.append(createElement(
                'div',
                'hltv-sp-prediction-status',
                'Bookmaker odds are unavailable for this match.',
            ));
        } else if (prediction.insufficient) {
            body.append(createElement(
                'div',
                'hltv-sp-prediction-status',
                'Insufficient page data for a stats-only prediction.',
            ));
        } else {
            const winner = inputs.teams[prediction.winnerIndex];
            const winnerProbability = Math.max(
                prediction.probabilityA,
                prediction.probabilityB,
            );
            const likelyScorelineProbability = prediction.mode === 'stats'
                && prediction.likelyScoreline
                ? prediction.scorelineDistribution[prediction.likelyScoreline]
                : null;
            const displayedScoreline = Number.isFinite(likelyScorelineProbability)
                ? prediction.likelyScoreline.replace('-', '–')
                : '';
            const scorelineLabel = displayedScoreline
                ? `Most likely score: ${displayedScoreline} · `
                    + formatPercent(likelyScorelineProbability)
                : '';
            const hero = createElement('div', 'hltv-sp-prediction-hero');
            hero.setAttribute(
                'aria-label',
                `Predicted winner: ${winner.name}, ${formatPercent(winnerProbability)} win probability`
                    + (displayedScoreline
                        ? `; most likely score: ${displayedScoreline}, `
                            + `${formatPercent(likelyScorelineProbability)} probability`
                        : ''),
            );
            hero.append(
                createElement('div', 'hltv-sp-prediction-eyebrow', 'Predicted winner'),
                createElement('div', 'hltv-sp-prediction-winner', winner.name),
                createElement(
                    'div',
                    'hltv-sp-prediction-confidence',
                    `${formatPercent(winnerProbability)} win probability`,
                ),
            );
            if (scorelineLabel) {
                hero.append(createExplainer(
                    scorelineLabel,
                    explanations.scoreline,
                    'hltv-sp-prediction-scoreline',
                    createScorelineResults(prediction, inputs),
                ));
            }

            const matchup = createElement('div', 'hltv-sp-prediction-matchup');
            const teams = createElement('div', 'hltv-sp-prediction-teams');
            const teamA = createElement(
                'div',
                `hltv-sp-prediction-team${prediction.winnerIndex === 0
                    ? ' hltv-sp-prediction-team-winner'
                    : ''}`,
            );
            teamA.append(
                createElement(
                    'span',
                    'hltv-sp-prediction-team-name',
                    inputs.teams[0].name,
                ),
                createElement(
                    'span',
                    'hltv-sp-prediction-team-probability',
                    formatPercent(prediction.probabilityA),
                ),
            );
            const teamB = createElement(
                'div',
                `hltv-sp-prediction-team${prediction.winnerIndex === 1
                    ? ' hltv-sp-prediction-team-winner'
                    : ''}`,
            );
            teamB.append(
                createElement(
                    'span',
                    'hltv-sp-prediction-team-name',
                    inputs.teams[1].name,
                ),
                createElement(
                    'span',
                    'hltv-sp-prediction-team-probability',
                    formatPercent(prediction.probabilityB),
                ),
            );
            teams.append(teamA, teamB);

            const rail = createElement('div', 'hltv-sp-prediction-rail');
            rail.setAttribute('role', 'img');
            rail.setAttribute(
                'aria-label',
                `${inputs.teams[0].name} ${formatPercent(prediction.probabilityA)}; `
                    + `${inputs.teams[1].name} ${formatPercent(prediction.probabilityB)}`,
            );
            const railA = createElement(
                'span',
                `hltv-sp-prediction-rail-segment hltv-sp-prediction-rail-${prediction.winnerIndex === 0
                    ? 'winner'
                    : 'loser'}`,
            );
            railA.style.width = formatPercent(prediction.probabilityA);
            const railB = createElement(
                'span',
                `hltv-sp-prediction-rail-segment hltv-sp-prediction-rail-${prediction.winnerIndex === 1
                    ? 'winner'
                    : 'loser'}`,
            );
            railB.style.width = formatPercent(prediction.probabilityB);
            rail.append(railA, railB);
            matchup.append(teams, rail);
            hero.appendChild(matchup);

            const meta = createElement('div', 'hltv-sp-prediction-meta');
            meta.append(createExplainer(
                prediction.mode === 'market' ? 'Market-estimated' : 'Page stats only',
                explanations.mode,
                'hltv-sp-prediction-meta-item',
            ));
            meta.append(createExplainer(
                `${prediction.quality.label} ${prediction.mode === 'market'
                    ? 'odds quality'
                    : 'data quality'}`,
                explanations.quality,
                'hltv-sp-prediction-meta-item',
            ));
            if (prediction.mode === 'stats') {
                meta.append(createExplainer(
                    mapSeriesLabel(prediction.structural.mapSeries.mode),
                    explanations.mapSeries,
                    'hltv-sp-prediction-meta-item',
                ));
            }
            hero.appendChild(meta);
            body.appendChild(hero);
        }

        if (prediction.mode === 'stats') {
            const details = createElement('details', 'hltv-sp-prediction-details');
            details.open = breakdownWasOpen;
            details.append(createElement('summary', '', 'How this estimate was built'));
            details.append(createElement(
                'p',
                'hltv-sp-prediction-details-intro',
                'Select an info icon to see what a value means, how it was calculated, and the '
                    + 'evidence used for this result.',
            ));
            const groups = createElement('div', 'hltv-sp-prediction-breakdown-groups');
            addBreakdownGroup(groups, 'Sources', [
                [
                    'Prediction mode',
                    'Page stats only',
                    explanations.mode,
                ],
            ]);
            addBreakdownGroup(groups, 'Team comparison', [
                [
                    'VRS and rank',
                    formatFactor(prediction.structural.strength.ratio, inputs.teams),
                    explanations.strength,
                ],
                [
                    'Lineup edge',
                    formatFactor(prediction.structural.lineup.z, inputs.teams),
                    explanations.lineup,
                ],
                [
                    'Form edge',
                    formatFactor(prediction.structural.form.z, inputs.teams),
                    explanations.form,
                ],
                [
                    'Round-margin edge',
                    formatFactor(prediction.structural.margin.z, inputs.teams),
                    explanations.margin,
                ],
            ]);
            addBreakdownGroup(groups, 'Model output', [
                [
                    'Structural estimate',
                    `${inputs.teams[0].name} ${formatPercent(prediction.structural.probability)}`,
                    explanations.structural,
                ],
                [
                    'Map model',
                    mapSeriesLabel(prediction.structural.mapSeries.mode),
                    explanations.mapSeries,
                ],
                [
                    'Likely scoreline',
                    prediction.likelyScoreline || 'Unavailable',
                    explanations.scoreline,
                ],
                [
                    'Structural share',
                    formatPercent(prediction.structuralShare),
                    explanations.structuralShare,
                ],
            ]);
            addBreakdownGroup(groups, 'Reliability', [
                [
                    'Data quality',
                    `${prediction.quality.label} · `
                        + `${prediction.quality.score.toFixed(CONFIG.ui.qualityDigits)}/100`,
                    explanations.quality,
                ],
                [
                    archived ? 'Calculated' : 'Updated',
                    new Date(archived ? calculatedAt : fetchedAt).toLocaleString(),
                    explanations.updated,
                ],
            ]);
            details.append(groups);
            details.append(createElement(
                'p',
                'hltv-sp-prediction-note',
                archived
                    ? 'Frozen pre-match estimate restored locally without live or final-match data. Not betting advice.'
                    : 'Deterministic estimate from this match page and its same-match analytics page. Not betting advice.',
            ));
            body.append(details);
        }
        card.append(head, body);
    }

    function renderCurrentPrediction() {
        const prediction = state.currentPredictions?.[state.mode];
        if (!prediction || !state.currentRenderInputs) return;
        renderPrediction(
            prediction,
            state.currentRenderInputs,
            state.currentFetchedAt,
            {
                archived: state.currentArchived,
                calculatedAt: state.currentCalculatedAt,
                explanations: state.currentExplanations?.[state.mode],
            },
        );
    }

    function clearCurrentPredictionState() {
        state.currentInputs = null;
        state.currentRenderInputs = null;
        state.currentPredictions = null;
        state.currentExplanations = null;
        state.currentFetchedAt = 0;
        state.currentCalculatedAt = 0;
        state.currentArchived = false;
        state.currentRawMatchFingerprint = '';
    }

    function removeUi() {
        document.getElementById(CONFIG.cardId)?.remove();
        document.getElementById(CONFIG.styleId)?.remove();
    }

    function refreshInterval(timestamp, now = Date.now()) {
        const remaining = timestamp - now;
        if (remaining <= 0) return 0;
        const normalInterval = remaining <= CONFIG.refresh.vetoThresholdMs
            ? CONFIG.refresh.vetoMs
            : remaining <= CONFIG.refresh.nearThresholdMs
                ? CONFIG.refresh.nearMs
                : CONFIG.refresh.earlyMs;
        const nextBoundary = remaining > CONFIG.refresh.nearThresholdMs
            ? remaining - CONFIG.refresh.nearThresholdMs
            : remaining > CONFIG.refresh.vetoThresholdMs
                ? remaining - CONFIG.refresh.vetoThresholdMs
                : remaining + CONFIG.refresh.minimumTimerMs;
        return Math.max(
            CONFIG.refresh.minimumTimerMs,
            Math.min(
                normalInterval,
                nextBoundary,
                remaining + CONFIG.refresh.minimumTimerMs,
            ),
        );
    }

    function scheduleRefresh(timestamp) {
        if (state.refreshTimer) globalThis.clearTimeout(state.refreshTimer);
        state.refreshTimer = 0;
        const delay = timestamp - Date.now();
        if (delay <= 0 || state.destroyed) return;
        state.refreshTimer = globalThis.setTimeout(() => {
            state.refreshTimer = 0;
            sourceTransport?.cancel();
            void sync();
        }, Math.min(delay, 2_147_483_647));
    }

    function predictionSnapshot(prediction) {
        if (prediction.modelVersion === CONFIG.predictionModelVersion) {
            const snapshot = JSON.parse(JSON.stringify(prediction));
            delete snapshot.players;
            delete snapshot.maps;
            delete snapshot.scenarios;
            delete snapshot.structural.mapSeries.maps;
            delete snapshot.structural.lineup.players;
            delete snapshot.structural.coverage;
            delete snapshot.structural.diagnostics;
            return snapshot;
        }
        return {
            probabilityA: prediction.probabilityA,
            probabilityB: prediction.probabilityB,
            winnerIndex: prediction.winnerIndex,
            mode: prediction.mode,
            insufficient: prediction.insufficient,
            structuralShare: prediction.structuralShare,
            likelyScoreline: prediction.likelyScoreline,
            scorelineDistribution: { ...prediction.scorelineDistribution },
            quality: { ...prediction.quality },
            market: {
                available: prediction.market.available,
                probability: prediction.market.probability,
                providerCount: prediction.market.providerCount,
                rejectedCount: prediction.market.rejectedCount,
                reliability: prediction.market.reliability,
            },
            structural: {
                probability: prediction.structural.probability,
                reliability: prediction.structural.reliability,
                strength: { ratio: prediction.structural.strength.ratio },
                lineup: { z: prediction.structural.lineup.z },
                form: { z: prediction.structural.form.z },
                margin: { z: prediction.structural.margin.z },
                mapSeries: { mode: prediction.structural.mapSeries.mode },
            },
        };
    }

    function cacheEntryKey(matchId, teams) {
        return `${matchId}:${teams.map((team) => team.id).join(':')}`;
    }

    function rawMatchFingerprint(rawMatch) {
        return fingerprint(rawMatch);
    }

    function validPredictionTree(value, depth = 0) {
        if (depth > 16) return false;
        if (value === null || typeof value === 'boolean') return true;
        if (typeof value === 'number') return Number.isFinite(value);
        if (typeof value === 'string') return value.length <= CONFIG.maximumExplanationTextCharacters;
        if (Array.isArray(value)) return value.length <= 100 && value.every((item) => validPredictionTree(item, depth + 1));
        return isRecord(value) && Object.keys(value).length <= 100 && Object.entries(value).every(([key, item]) => (
            !['__proto__', 'constructor', 'prototype'].includes(key) && validPredictionTree(item, depth + 1)
        ));
    }


    function validLiveRenderShape(value) {
        const structure = value.structural;
        const probability = (n) => Number.isFinite(n) && n >= 0 && n <= 1;
        return Array.isArray(structure.players) && structure.players.length === 2
            && structure.players.every((team) => Array.isArray(team) && team.length === 5
                && team.every((player) => isRecord(player) && typeof player.playerId === 'string'
                    && typeof player.nickname === 'string' && typeof player.available === 'boolean'
                    && Number.isFinite(player.effectiveRating)))
            && Array.isArray(structure.maps) && structure.maps.length <= CONFIG.maximumMaps
            && structure.maps.every((map) => isRecord(map) && typeof map.name === 'string'
                && map.name.length > 0 && probability(map.probability)
                && Array.isArray(map.teams) && map.teams.length === 2 && map.teams.every(isRecord)
                && probability(map.selectionProbability))
            && isRecord(structure.mapSeries) && Array.isArray(structure.scenarios)
            && structure.scenarios.length <= 5
            && structure.scenarios.every((scenario) => isRecord(scenario)
                && probability(scenario.probability) && probability(scenario.probabilityA)
                && Array.isArray(scenario.maps) && scenario.maps.length <= 5
                && scenario.maps.every((name) => name === null || typeof name === 'string'))
            && typeof value.coverage.limited === 'boolean'
            && Array.isArray(value.coverage.lineup) && value.coverage.lineup.length === 2
            && value.coverage.lineup.every((n) => Number.isInteger(n) && n >= 0 && n <= 5)
            && Array.isArray(value.coverage.sourceRecords) && value.coverage.sourceRecords.length <= 3
            && value.coverage.sourceRecords.every((source) => isRecord(source)
                && typeof source.href === 'string' && ['analytics', 'team-players'].includes(source.kind)
                && (!source.window || isRecord(source.window)
                    && typeof source.window.startDate === 'string' && typeof source.window.endDate === 'string'));
    }

    function validCachedSources(items, rawMatch, now) {
        if (!Array.isArray(items) || items.length > 3) return false;
        const seen = new Set();
        return items.every((item) => {
            if (!isRecord(item) || !isRecord(item.source) || !isRecord(item.data)
                || item.status !== 'loaded' || !Number.isSafeInteger(item.fetchedAt)
                || item.fetchedAt <= 0 || item.fetchedAt > now || item.fetchedAt >= rawMatch.timestamp
                || !sameOrderedMatchIdentity(item.source, rawMatch)
                || seen.has(item.source.sourceKey)) return false;
            seen.add(item.source.sourceKey);
            const source = item.source;
            const href = safeUrl(source.href);
            if (href?.origin !== 'https://www.hltv.org' || href.username || href.password || href.hash) return false;
            const data = item.data;
            if (source.kind === 'analytics') {
                if (source.sourceKey !== 'analytics' || href.href !== rawMatch.analyticsHref
                    || data.matchId !== rawMatch.matchId || data.timestamp !== rawMatch.timestamp
                    || !Array.isArray(data.teams) || data.teams.length !== 2
                    || data.teams.some((name, i) => normalisedName(name) !== normalisedName(rawMatch.teams[i].name))
                    || !Array.isArray(data.maps) || data.maps.length > CONFIG.maximumMaps
                    || !Array.isArray(data.bookmakers) || data.bookmakers.length > CONFIG.maximumProviders) return false;
            } else if (source.kind === 'team-players') {
                const index = rawMatch.teams.findIndex((team) => team.id === source.teamId);
                if (index < 0 || source.sourceKey !== `team-players-${index}`
                    || /^\/stats\/teams\/players\/(\d{1,20})(?:\/|$)/.exec(href.pathname)?.[1] !== source.teamId
                    || data.teamId !== source.teamId || data.ratingVersion !== '3.0'
                    || !isRecord(source.window) || data.startDate !== source.window.startDate || data.endDate !== source.window.endDate
                    || href.searchParams.get('csVersion') !== 'CS2'
                    || href.searchParams.get('startDate') !== data.startDate || href.searchParams.get('endDate') !== data.endDate
                    || parameterEntries(href.searchParams).map(([name]) => name).sort().join(',') !== 'csVersion,endDate,startDate'
                    || !Array.isArray(data.players) || data.players.length > 30
                    || data.players.some((player) => !isRecord(player) || !/^\d{1,20}$/.test(player.playerId)
                        || player.ratingVersion !== '3.0' || !Number.isFinite(player.rating) || player.rating < 0 || player.rating > 5
                        || !Number.isSafeInteger(player.maps) || player.maps < 1 || !Number.isSafeInteger(player.rounds) || player.rounds < 1)) return false;
            } else return false;
            return true;
        });
    }

    function validLivePrediction(value, mode = value?.mode, bestOf = null) {
        if (!isRecord(value) || value.modelVersion !== CONFIG.predictionModelVersion
            || !CONFIG.modes.includes(mode) || value.mode !== mode
            || typeof value.insufficient !== 'boolean' || !isRecord(value.structural)
            || !isRecord(value.market) || !isRecord(value.coverage)
            || !isRecord(value.scorelineDistribution) || typeof value.likelyScoreline !== 'string'
            || !validPredictionTree(value) || !validLiveRenderShape(value)) return false;
        if (value.probabilityA === null || value.probabilityB === null) {
            return value.probabilityA === null && value.probabilityB === null && value.winnerIndex === null
                && (value.insufficient || (mode === 'market' && !value.market.available))
                && Object.keys(value.scorelineDistribution || {}).length === 0;
        }
        if (!Number.isFinite(value.probabilityA) || value.probabilityA < 0 || value.probabilityA > 1
            || !Number.isFinite(value.probabilityB) || value.probabilityB < 0 || value.probabilityB > 1
            || Math.abs(value.probabilityA + value.probabilityB - 1) > 1e-6
            || value.winnerIndex !== (Math.abs(value.probabilityA - 0.5) <= 1e-12 ? null : value.probabilityA > 0.5 ? 0 : 1)) return false;
        if (mode === 'market') return value.market.available
            && Math.abs(value.probabilityA - value.market.probability) <= 1e-6
            && Object.keys(value.scorelineDistribution).length === 0 && value.likelyScoreline === '';
        if (Math.abs(value.probabilityA - value.structural.probability) > 1e-6) return false;
        const scores = value.scorelineDistribution;
        if (!isRecord(scores) || !Object.keys(scores).length) return value.insufficient;
        if (bestOf && Object.keys(scores).some((score) => !legalScorelines(bestOf).includes(score))) return false;
        if (Object.entries(scores).some(([score, probability]) => !/^[0-3]-[0-3]$/.test(score)
            || !Number.isFinite(probability) || probability < 0 || probability > 1)) return false;
        return Math.abs(Object.values(scores).reduce((a, b) => a + b, 0) - 1) <= 1e-6
            && Math.abs(distributionWinProbability(scores) - value.probabilityA) <= 1e-6
            && value.likelyScoreline === Object.entries(scores).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))[0]?.[0];
    }

    function validLiveArchive(entry, currentIdentity, now) {
        if (!hasExactKeys(entry, ['version', 'modelVersion', 'identity', 'calculatedAt', 'sourceFetchedAt',
            'renderInputs', 'predictions', 'explanations', 'fingerprint'])
            || entry.version !== 2 || entry.modelVersion !== CONFIG.predictionModelVersion
            || !validPredictionTree(entry) || JSON.stringify(entry).length > CONFIG.maximumArchiveEntryCharacters
            || !hasExactKeys(entry.identity, ['matchId', 'teamIds', 'scheduledAt'])
            || !/^\d{1,20}$/.test(entry.identity.matchId)
            || !Array.isArray(entry.identity.teamIds) || entry.identity.teamIds.length !== 2
            || entry.identity.teamIds.some((id) => typeof id !== 'string' || !/^\d{1,20}$/.test(id))
            || new Set(entry.identity.teamIds).size !== 2
            || !Number.isSafeInteger(entry.identity.scheduledAt) || entry.identity.scheduledAt <= 0
            || !Number.isSafeInteger(entry.calculatedAt) || entry.calculatedAt <= 0
            || entry.calculatedAt >= entry.identity.scheduledAt || entry.calculatedAt > now + CONFIG.timestampToleranceMs
            || !Number.isSafeInteger(entry.sourceFetchedAt) || entry.sourceFetchedAt <= 0
            || entry.sourceFetchedAt > entry.calculatedAt || entry.sourceFetchedAt >= entry.identity.scheduledAt
            || !isRecord(entry.renderInputs) || entry.renderInputs.modelVersion !== CONFIG.predictionModelVersion
            || ![null, 1, 3, 5].includes(entry.renderInputs.bestOf)
            || entry.renderInputs.timestamp !== entry.identity.scheduledAt
            || !Array.isArray(entry.renderInputs.teams) || entry.renderInputs.teams.length !== 2
            || entry.renderInputs.teams.some((team, i) => !isRecord(team) || team.id !== entry.identity.teamIds[i]
                || !team.name || boundedText(team.name) !== team.name)
            || !hasExactKeys(entry.predictions, CONFIG.modes)
            || !CONFIG.modes.every((mode) => validLivePrediction(entry.predictions[mode], mode, entry.renderInputs.bestOf))
            || fingerprint(entry.predictions.stats.structural) !== fingerprint(entry.predictions.market.structural)
            || fingerprint(entry.predictions.stats.market) !== fingerprint(entry.predictions.market.market)
            || !hasExactKeys(entry.explanations, CONFIG.modes)
            || !CONFIG.modes.every((mode) => hasExactKeys(entry.explanations[mode], mode === 'market'
                ? ['mode', 'quality'] : ['mode', 'lineup', 'maps', 'veto', 'strength', 'scoreline', 'coverage', 'updated'])
                && Object.values(entry.explanations[mode]).every(validExplanationEntry))
            || entry.fingerprint !== fingerprint(archivePayload(entry))) return false;
        return !currentIdentity || currentIdentity.matchId === entry.identity.matchId
            && currentIdentity.teams?.length === 2
            && currentIdentity.teams.every((team, i) => team.id === entry.identity.teamIds[i]);
    }

    function validCachedPrediction(value) {
        if (value?.modelVersion === CONFIG.predictionModelVersion) return validLivePrediction(value);
        const marketUnavailable = value?.mode === 'market'
            && value?.market?.available === false;
        return value
            && typeof value === 'object'
            && (marketUnavailable
                ? value.probabilityA === null
                    && value.probabilityB === null
                    && value.winnerIndex === null
                : Number.isFinite(value.probabilityA)
                    && value.probabilityA >= 0
                    && value.probabilityA <= 1
                    && Number.isFinite(value.probabilityB)
                    && value.probabilityB >= 0
                    && value.probabilityB <= 1
                    && Math.abs(value.probabilityA + value.probabilityB - 1)
                        <= CONFIG.probability.epsilon
                    && (value.winnerIndex === 0 || value.winnerIndex === 1))
            && CONFIG.modes.includes(value.mode)
            && typeof value.insufficient === 'boolean'
            && Number.isFinite(value.structuralShare)
            && (value.likelyScoreline === '' || /^\d-\d$/.test(value.likelyScoreline))
            && Number.isFinite(value.quality?.score)
            && value.quality.score >= 0
            && value.quality.score <= 100
            && ['High', 'Medium', 'Low'].includes(value.quality?.label)
            && typeof value.market?.available === 'boolean'
            && (value.market.available
                ? Number.isFinite(value.market.probability)
                : value.market.probability === null)
            && Number.isSafeInteger(value.market?.providerCount)
            && value.market.providerCount >= 0
            && Number.isSafeInteger(value.market?.rejectedCount)
            && value.market.rejectedCount >= 0
            && Number.isFinite(value.market?.reliability)
            && Number.isFinite(value.structural?.probability)
            && Number.isFinite(value.structural?.reliability)
            && Number.isFinite(value.structural?.strength?.ratio)
            && Number.isFinite(value.structural?.lineup?.z)
            && Number.isFinite(value.structural?.form?.z)
            && Number.isFinite(value.structural?.margin?.z)
            && typeof value.structural?.mapSeries?.mode === 'string';
    }

    function isRecord(value) {
        return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
    }

    function hasExactKeys(value, expectedKeys) {
        if (!isRecord(value)) return false;
        const actualKeys = Object.keys(value).sort();
        const sortedExpectedKeys = [...expectedKeys].sort();
        return actualKeys.length === sortedExpectedKeys.length
            && actualKeys.every((key, index) => key === sortedExpectedKeys[index]);
    }

    function archiveRenderInputs(inputs) {
        if (inputs.modelVersion === CONFIG.predictionModelVersion) return {
            modelVersion: CONFIG.predictionModelVersion,
            teams: inputs.teams.map(({ id, name }) => ({ id, name })),
            timestamp: inputs.timestamp, bestOf: inputs.bestOf,
            officialMaps: [...(inputs.officialMaps || [])],
        };
        return {
            teams: inputs.teams.map((team) => ({ id: team.id, name: team.name })),
            timestamp: inputs.timestamp,
            bestOf: inputs.bestOf,
            officialMaps: [...inputs.officialMaps],
        };
    }

    function calculatePredictionModes(inputs) {
        return liveModel.calculatePredictionModes(inputs, calculateMarketProbability);
    }

    function archivedUpdatedExplanation(calculatedAt, scheduledAt) {
        return {
            summary: 'This is when the saved pre-match estimate was calculated.',
            details: `This frozen estimate was calculated at ${new Date(calculatedAt).toLocaleString()} `
                + `for a match scheduled at ${new Date(scheduledAt).toLocaleString()}. It was `
                + 'restored from extension-local storage without using live or final-match data.',
            formula: 'Require calculatedAt < scheduledAt. Once the page is live, finished, or past '
                + 'its scheduled start, load this stored snapshot without requesting analytics or '
                + 'running either prediction model again.',
            equations: [],
        };
    }

    function copyExplanationEntry(value) {
        return {
            summary: value.summary,
            details: value.details,
            formula: value.formula,
            equations: [...value.equations],
        };
    }

    function frozenPredictionExplanations(
        predictions,
        inputs,
        sourceFetchedAt,
        calculatedAt,
    ) {
        if (predictions.stats.modelVersion === CONFIG.predictionModelVersion) {
            return Object.fromEntries(CONFIG.modes.map((mode) => [mode,
                predictionExplanations(predictions[mode], inputs, calculatedAt)]));
        }
        return Object.fromEntries(CONFIG.modes.map((mode) => {
            const generated = predictionExplanations(
                predictions[mode],
                inputs,
                sourceFetchedAt,
            );
            const selected = Object.fromEntries(
                CONFIG.archiveExplanationKeys[mode].map((key) => [
                    key,
                    copyExplanationEntry(generated[key]),
                ]),
            );
            if (mode === 'stats') {
                selected.updated = archivedUpdatedExplanation(calculatedAt, inputs.timestamp);
            }
            return [mode, selected];
        }));
    }

    function legalScorelines(bestOf) {
        if (![1, 3, 5].includes(bestOf)) return [];
        const winsRequired = Math.floor(bestOf / 2) + 1;
        const scores = [];
        for (let losingScore = 0; losingScore < winsRequired; losingScore += 1) {
            scores.push(`${winsRequired}-${losingScore}`, `${losingScore}-${winsRequired}`);
        }
        return scores;
    }

    function validArchivedScorelineDistribution(value, prediction, bestOf) {
        if (!isRecord(value)) return false;
        if (prediction.mode === 'market') {
            return Object.keys(value).length === 0 && prediction.likelyScoreline === '';
        }
        const expected = legalScorelines(bestOf).sort();
        const keys = Object.keys(value).sort();
        if (keys.length !== expected.length
            || keys.some((key, index) => key !== expected[index])) return false;
        const probabilities = keys.map((key) => value[key]);
        if (probabilities.some((probability) => (
            !Number.isFinite(probability) || probability < 0 || probability > 1
        ))) return false;
        const total = probabilities.reduce((sum, probability) => sum + probability, 0);
        const probabilityA = distributionWinProbability(value);
        if (Math.abs(total - 1) > CONFIG.probability.epsilon
            || Math.abs(probabilityA - prediction.probabilityA) > CONFIG.probability.epsilon
            || Math.abs((1 - probabilityA) - prediction.probabilityB)
                > CONFIG.probability.epsilon) return false;
        const modalScoreline = sortedScorelineEntries(value)[0]?.[0] || '';
        const expectedLikelyScoreline = scorelineWinnerIndex(modalScoreline) === prediction.winnerIndex
            ? modalScoreline
            : '';
        return prediction.likelyScoreline === expectedLikelyScoreline;
    }

    function archivedModelProbability(structural, rules) {
        const probability = clip(
            structural.probability,
            rules.probabilityEpsilon,
            1 - rules.probabilityEpsilon,
        );
        return clip(
            sigmoid(structural.reliability * Math.log(probability / (1 - probability))),
            rules.displayMinimum,
            rules.displayMaximum,
        );
    }

    function validArchivedPrediction(value, expectedMode, bestOf, rules) {
        if (!hasExactKeys(value, [
            'probabilityA', 'probabilityB', 'winnerIndex', 'mode', 'insufficient',
            'structuralShare', 'likelyScoreline', 'scorelineDistribution', 'quality',
            'market', 'structural',
        ])
            || !hasExactKeys(value.quality, ['score', 'label'])
            || !hasExactKeys(value.market, [
                'available', 'probability', 'providerCount', 'rejectedCount', 'reliability',
            ])
            || !hasExactKeys(value.structural, [
                'probability', 'reliability', 'strength', 'lineup', 'form', 'margin',
                'mapSeries',
            ])
            || !hasExactKeys(value.structural.strength, ['ratio'])
            || !hasExactKeys(value.structural.lineup, ['z'])
            || !hasExactKeys(value.structural.form, ['z'])
            || !hasExactKeys(value.structural.margin, ['z'])
            || !hasExactKeys(value.structural.mapSeries, ['mode'])
            || !validCachedPrediction(value)
            || !rules
            || value.mode !== expectedMode
            || !isRecord(value.scorelineDistribution)
            || value.market.reliability < 0
            || value.market.reliability > 1
            || value.structural.probability < 0
            || value.structural.probability > 1
            || value.structural.reliability < 0
            || value.structural.reliability > 1
            || !['official-maps', 'partial-maps', 'pre-veto', 'generic-maps']
                .includes(value.structural.mapSeries.mode)) return false;
        if (value.market.available !== (value.market.providerCount > 0)) return false;
        if (value.market.available && (
            value.market.probability < 0 || value.market.probability > 1
        )) return false;
        if (!value.market.available && value.market.reliability !== 0) return false;
        const activeReliability = expectedMode === 'market'
            ? value.market.reliability
            : value.structural.reliability;
        const qualityScale = expectedMode === 'market'
            ? rules.marketQualityScale
            : rules.statsOnlyQualityScale;
        const expectedQualityScore = clip(qualityScale * activeReliability, 0, 100);
        const expectedQualityLabel = expectedQualityScore >= rules.qualityHigh
            ? 'High'
            : expectedQualityScore >= rules.qualityMedium ? 'Medium' : 'Low';
        if (Math.abs(value.quality.score - expectedQualityScore) > CONFIG.probability.epsilon
            || value.quality.label !== expectedQualityLabel) return false;
        if (expectedMode === 'market') {
            if (value.structuralShare !== 0 || value.insufficient) return false;
            if (value.market.available) {
                if (Math.abs(value.probabilityA - value.market.probability)
                        > CONFIG.probability.epsilon
                    || value.winnerIndex !== (value.probabilityA >= 0.5 ? 0 : 1)) return false;
            } else if (value.probabilityA !== null
                || value.probabilityB !== null
                || value.winnerIndex !== null) return false;
        } else {
            if (value.structuralShare !== 1
                || !Number.isFinite(value.probabilityA)
                || value.insufficient !== (
                    value.structural.reliability < rules.minimumStatsOnlyReliability
                )
                || Math.abs(value.probabilityA - archivedModelProbability(value.structural, rules))
                    > CONFIG.probability.epsilon
                || value.winnerIndex !== (value.probabilityA >= 0.5 ? 0 : 1)) return false;
        }
        return validArchivedScorelineDistribution(value.scorelineDistribution, value, bestOf);
    }

    function validExplanationEntry(value) {
        return hasExactKeys(value, ['summary', 'details', 'formula', 'equations'])
            && ['summary', 'details', 'formula'].every((key) => (
                typeof value[key] === 'string'
                && value[key].length > 0
                && value[key].length <= CONFIG.maximumExplanationTextCharacters
            ))
            && Array.isArray(value.equations)
            && value.equations.length <= CONFIG.maximumExplanationEquations
            && value.equations.every((equation) => (
                typeof equation === 'string'
                && equation.length > 0
                && equation.length <= CONFIG.maximumExplanationEquationCharacters
            ));
    }

    function validFrozenExplanations(value) {
        if (!hasExactKeys(value, CONFIG.modes)) return false;
        return CONFIG.modes.every((mode) => {
            const explanations = value[mode];
            if (!isRecord(explanations)) return false;
            const expectedKeys = [...CONFIG.archiveExplanationKeys[mode]].sort();
            const actualKeys = Object.keys(explanations).sort();
            return actualKeys.length === expectedKeys.length
                && actualKeys.every((key, index) => key === expectedKeys[index])
                && actualKeys.every((key) => validExplanationEntry(explanations[key]));
        });
    }

    function validArchiveRenderInputs(value, identity) {
        if (!hasExactKeys(value, ['teams', 'timestamp', 'bestOf', 'officialMaps'])
            || !Array.isArray(value.teams)
            || value.teams.length !== 2
            || value.teams.some((team, index) => (
                !hasExactKeys(team, ['id', 'name'])
                || !/^\d{1,20}$/.test(team.id)
                || !team.name
                || boundedText(team.name) !== team.name
                || team.id !== identity.teamIds[index]
            ))
            || value.timestamp !== identity.scheduledAt
            || ![1, 3, 5].includes(value.bestOf)
            || !Array.isArray(value.officialMaps)
            || value.officialMaps.length > value.bestOf
            || value.officialMaps.some((name) => !name || boundedText(name) !== name)) return false;
        const mapKeys = value.officialMaps.map(normalisedMapName);
        return mapKeys.every(Boolean) && new Set(mapKeys).size === mapKeys.length;
    }

    function archivePayload(entry) {
        return {
            version: entry.version,
            modelVersion: entry.modelVersion,
            identity: entry.identity,
            calculatedAt: entry.calculatedAt,
            sourceFetchedAt: entry.sourceFetchedAt,
            renderInputs: entry.renderInputs,
            predictions: entry.predictions,
            explanations: entry.explanations,
        };
    }

    function validPredictionArchiveEntry(entry, currentIdentity = null, now = Date.now()) {
        if (entry?.version === 2) {
            try { return validLiveArchive(entry, currentIdentity, now); } catch { return false; }
        }
        let serialised = '';
        try {
            serialised = JSON.stringify(entry);
        } catch {
            return false;
        }
        const modelRules = CONFIG.archiveModelRules[entry?.modelVersion];
        if (!hasExactKeys(entry, [
            'version', 'modelVersion', 'identity', 'calculatedAt', 'sourceFetchedAt',
            'renderInputs', 'predictions', 'explanations', 'fingerprint',
        ])
            || !serialised
            || serialised.length > CONFIG.maximumArchiveEntryCharacters
            || entry.version !== 1
            || typeof entry.modelVersion !== 'string'
            || !/^[a-z0-9._-]{1,80}$/i.test(entry.modelVersion)
            || !modelRules
            || !hasExactKeys(entry.identity, ['matchId', 'teamIds', 'scheduledAt'])
            || !/^\d{1,20}$/.test(entry.identity.matchId)
            || !Array.isArray(entry.identity.teamIds)
            || entry.identity.teamIds.length !== 2
            || entry.identity.teamIds.some((id) => !/^\d{1,20}$/.test(id))
            || new Set(entry.identity.teamIds).size !== 2
            || !Number.isSafeInteger(entry.identity.scheduledAt)
            || entry.identity.scheduledAt <= 0
            || !Number.isSafeInteger(entry.calculatedAt)
            || entry.calculatedAt <= 0
            || entry.calculatedAt >= entry.identity.scheduledAt
            || entry.calculatedAt > now + CONFIG.timestampToleranceMs
            || !Number.isSafeInteger(entry.sourceFetchedAt)
            || entry.sourceFetchedAt <= 0
            || entry.sourceFetchedAt >= entry.identity.scheduledAt
            || entry.sourceFetchedAt > entry.calculatedAt + CONFIG.timestampToleranceMs
            || !validArchiveRenderInputs(entry.renderInputs, entry.identity)
            || !hasExactKeys(entry.predictions, CONFIG.modes)
            || !CONFIG.modes.every((mode) => (
                validArchivedPrediction(
                    entry.predictions[mode],
                    mode,
                    entry.renderInputs.bestOf,
                    modelRules,
                )
            ))
            || fingerprint(entry.predictions.stats.market)
                !== fingerprint(entry.predictions.market.market)
            || fingerprint(entry.predictions.stats.structural)
                !== fingerprint(entry.predictions.market.structural)
            || !validFrozenExplanations(entry.explanations)
            || typeof entry.fingerprint !== 'string'
            || entry.fingerprint !== fingerprint(archivePayload(entry))) return false;
        if (!currentIdentity) return true;
        return currentIdentity.matchId === entry.identity.matchId
            && Array.isArray(currentIdentity.teams)
            && currentIdentity.teams.length === 2
            && currentIdentity.teams.every((team, index) => (
                team?.id === entry.identity.teamIds[index]
            ));
    }

    function createPredictionArchiveEntry(
        inputs,
        predictions,
        sourceFetchedAt,
        calculatedAt = Date.now(),
    ) {
        try {
            const snapshots = Object.fromEntries(CONFIG.modes.map((mode) => [
                mode,
                predictionSnapshot(predictions[mode]),
            ]));
            const entry = {
                version: CONFIG.archiveSchemaVersion,
                modelVersion: CONFIG.predictionModelVersion,
                identity: {
                    matchId: inputs.matchId,
                    teamIds: inputs.teams.map((team) => team.id),
                    scheduledAt: inputs.timestamp,
                },
                calculatedAt,
                sourceFetchedAt,
                renderInputs: archiveRenderInputs(inputs),
                predictions: snapshots,
                explanations: frozenPredictionExplanations(
                    snapshots,
                    archiveRenderInputs(inputs),
                    sourceFetchedAt,
                    calculatedAt,
                ),
            };
            entry.fingerprint = fingerprint(archivePayload(entry));
            return validPredictionArchiveEntry(entry, null, calculatedAt) ? entry : null;
        } catch {
            return null;
        }
    }

    function predictionArchiveEntryKey(entry) {
        if (!isRecord(entry?.identity)) return '';
        return `${entry.identity.matchId}:${entry.identity.teamIds?.join(':') || ''}`;
    }

    function predictionArchiveStorageKey(matchId, teams, version = 2) {
        const teamIds = Array.isArray(teams) ? teams.map((team) => (
            typeof team === 'string' ? team : team?.id
        )) : [];
        if (!/^\d{1,20}$/.test(matchId)
            || teamIds.length !== 2
            || teamIds.some((id) => !/^\d{1,20}$/.test(id))) return '';
        return `${version === 1 ? CONFIG.legacyArchiveKeyPrefix : CONFIG.archiveKeyPrefix}${encodeURIComponent(`${matchId}:${teamIds.join(':')}`)}`;
    }

    function predictionArchiveEntryStorageKey(entry) {
        return predictionArchiveStorageKey(
            entry?.identity?.matchId,
            entry?.identity?.teamIds,
            entry?.version,
        );
    }

    function prunePredictionArchive(rawStorage, now = Date.now()) {
        if (!isRecord(rawStorage)) return {};
        const entries = Object.entries(rawStorage).filter(([key, entry]) => (
            (key.startsWith(CONFIG.archiveKeyPrefix) || key.startsWith(CONFIG.legacyArchiveKeyPrefix))
            && key === predictionArchiveEntryStorageKey(entry)
            && validPredictionArchiveEntry(entry, null, now)
        ));
        entries.sort((first, second) => {
            const timestampDifference = second[1].calculatedAt - first[1].calculatedAt;
            if (timestampDifference) return timestampDifference;
            return first[0] < second[0] ? -1 : first[0] > second[0] ? 1 : 0;
        });
        const retainedMatches = new Set();
        for (const [, entry] of entries) {
            const identity = predictionArchiveEntryKey(entry);
            if (retainedMatches.size < CONFIG.maximumArchiveEntries) retainedMatches.add(identity);
        }
        return Object.fromEntries(entries.filter(([, entry]) => retainedMatches.has(predictionArchiveEntryKey(entry))));
    }

    async function loadPredictionArchive(identity, now = Date.now()) {
        if (!identity) return null;
        try {
            const keys = [2, 1].map((version) => predictionArchiveStorageKey(identity.matchId, identity.teams, version));
            if (keys.some((key) => !key)) return null;
            const stored = await extensionApi.storage.local.get(keys);
            return keys.map((key) => stored?.[key]).filter((entry) => validPredictionArchiveEntry(entry, identity, now))
                .sort((a, b) => b.calculatedAt - a.calculatedAt || b.version - a.version)[0] || null;
        } catch { return null; }
    }

    function storePredictionArchive(
        inputs,
        predictions,
        sourceFetchedAt,
        calculatedAt = Date.now(),
    ) {
        const candidate = createPredictionArchiveEntry(
            inputs,
            predictions,
            sourceFetchedAt,
            calculatedAt,
        );
        if (!candidate) return Promise.resolve(null);
        const storageKey = predictionArchiveEntryStorageKey(candidate);
        const operation = archiveWriteQueue.then(async () => {
            try {
                const stored = await extensionApi.storage.local.get(storageKey);
                const existing = stored?.[storageKey];
                if (validPredictionArchiveEntry(existing)
                    && predictionArchiveEntryStorageKey(existing) === storageKey
                    && existing.calculatedAt > candidate.calculatedAt) {
                    return existing;
                }
                await extensionApi.storage.local.set({ [storageKey]: candidate });
                const allStored = await extensionApi.storage.local.get(null);
                const retained = prunePredictionArchive(allStored);
                const removeKeys = Object.keys(allStored || {}).filter((key) => (
                    (key.startsWith(CONFIG.archiveKeyPrefix) || key.startsWith(CONFIG.legacyArchiveKeyPrefix))
                    && validPredictionArchiveEntry(allStored[key]) && !hasOwn(retained, key)
                ));
                if (removeKeys.length) await extensionApi.storage.local.remove(removeKeys);
                return retained[storageKey] || null;
            } catch {
                return null;
            }
        });
        archiveWriteQueue = operation.then(() => undefined, () => undefined);
        return operation;
    }

    async function loadPredictionCache(
        rawMatch,
        requestedModeOrNow = CONFIG.defaultMode,
        now = Date.now(),
    ) {
        const validationNow = Number.isFinite(requestedModeOrNow) ? requestedModeOrNow : now;
        try {
            const stored = await extensionApi.storage.local.get({ [CONFIG.cacheKey]: {} });
            const cache = stored?.[CONFIG.cacheKey];
            const entry = cache?.[cacheEntryKey(rawMatch.matchId, rawMatch.teams)];
            let serialisedInputs = '';
            try {
                serialisedInputs = JSON.stringify(entry?.inputs);
            } catch {
                return null;
            }
            if (!entry || typeof entry !== 'object'
                || !Number.isFinite(entry.timestamp)
                || !Number.isFinite(entry.expiresAt)
                || entry.timestamp > validationNow
                || entry.expiresAt <= validationNow
                || entry.expiresAt > rawMatch.timestamp + CONFIG.refresh.minimumTimerMs
                || entry.matchFingerprint !== rawMatchFingerprint(rawMatch)
                || entry.inputs?.modelVersion !== CONFIG.predictionModelVersion
                || !validPredictionTree(entry.inputs)
                || !validCachedSources(entry.inputs.sourceData, rawMatch, validationNow)
                || entry.inputs?.matchId !== rawMatch.matchId
                || entry.inputs?.timestamp !== rawMatch.timestamp
                || !serialisedInputs
                || serialisedInputs.length > CONFIG.maximumCachedInputCharacters
                || !Array.isArray(entry.inputs?.teams)
                || entry.inputs.teams.length !== 2
                || entry.inputs.teams.some((team, index) => (
                    team?.id !== rawMatch.teams[index].id
                ))
                || entry.fingerprint !== fingerprint(entry.inputs)) return null;
            return {
                inputs: entry.inputs,
                fetchedAt: entry.timestamp,
                matchFingerprint: entry.matchFingerprint,
            };
        } catch {
            return null;
        }
    }

    async function storePredictionCache(
        inputs,
        prediction,
        fetchedAt,
        matchFingerprint,
    ) {
        const key = `${inputs.matchId}:${inputs.teams.map((team) => team.id).join(':')}`;
        try {
            const stored = await extensionApi.storage.local.get({ [CONFIG.cacheKey]: {} });
            const rawCache = stored?.[CONFIG.cacheKey];
            const cache = rawCache && typeof rawCache === 'object' && !Array.isArray(rawCache)
                ? { ...rawCache }
                : {};
            cache[key] = {
                inputs,
                timestamp: fetchedAt,
                expiresAt: fetchedAt + refreshInterval(inputs.timestamp, fetchedAt),
                matchFingerprint,
                fingerprint: fingerprint(inputs),
                prediction: predictionSnapshot(prediction),
            };
            const entries = Object.entries(cache)
                .sort((first, second) => (
                    Number(second[1]?.timestamp || 0) - Number(first[1]?.timestamp || 0)
                ))
                .slice(0, CONFIG.maximumCacheEntries);
            await extensionApi.storage.local.set({ [CONFIG.cacheKey]: Object.fromEntries(entries) });
        } catch {
            // Caching is optional; calculation and rendering remain available.
        }
    }

    function stopRefresh() {
        if (state.refreshTimer) globalThis.clearTimeout(state.refreshTimer);
        state.refreshTimer = 0;
    }

    function sameOrderedMatchIdentity(first, second) {
        return Boolean(first && second)
            && first.matchId === second.matchId
            && first.timestamp === second.timestamp
            && Array.isArray(first.teams)
            && Array.isArray(second.teams)
            && first.teams.length === 2
            && second.teams.length === 2
            && first.teams.every((team, index) => team.id === second.teams[index]?.id);
    }

    async function showSavedPrediction(identity, generation) {
        stopRefresh();
        const archived = await loadPredictionArchive(identity);
        if (state.destroyed || generation !== state.requestGeneration) return;
        clearCurrentPredictionState();
        state.currentPhase = identity.phase;
        if (!archived) {
            renderStatus(
                'No saved pre-match estimate is available for this match.',
                false,
                true,
            );
            return;
        }
        state.currentRenderInputs = archived.renderInputs;
        state.currentPredictions = archived.predictions;
        state.currentExplanations = archived.explanations;
        state.currentFetchedAt = archived.sourceFetchedAt;
        state.currentCalculatedAt = archived.calculatedAt;
        state.currentArchived = true;
        renderCurrentPrediction();
    }

    async function sync() {
        const generation = ++state.requestGeneration;
        if (state.destroyed || state.suspended || !state.enabled) {
            sourceTransport?.cancel();
            stopRefresh();
            clearCurrentPredictionState();
            removeUi();
            return;
        }
        const identity = extractMatchIdentity(document);
        if (!identity) {
            sourceTransport?.cancel();
            stopRefresh();
            clearCurrentPredictionState();
            removeUi();
            return;
        }
        state.currentPhase = identity.phase;
        if (identity.phase !== 'scheduled') {
            sourceTransport?.cancel();
            await showSavedPrediction(identity, generation);
            return;
        }
        const rawMatch = extractMatchPageData(document, identity);
        if (!rawMatch) return;
        if (!sourceTransport) {
            sourceTransport = globalThis.HLTV_MATCH_PREDICTION_TRANSPORT_V23.create({
                getIdentity: () => extractMatchIdentity(document),
                onDiagnostic: (entry) => globalThis.HLTV_SP_DIAGNOSTICS?.record(
                    'warn', 'match prediction source', entry,
                ),
            });
        }
        if (sourcePlanIdentity && !sameOrderedMatchIdentity(sourcePlanIdentity, identity)) {
            sourceTransport.cancel();
            sourceResults.clear();
            clearCurrentPredictionState();
            renderStatus('Reload this match page to load its prediction sources.', false, true);
            return;
        }
        sourcePlanIdentity ||= identity;
        sourceTransport.resume();
        sourcePlan ||= sourceTransport.plan(rawMatch);
        scheduleRefresh(identity.timestamp);
        // A cache is only a source snapshot. Always recalculate from the current local DOM.
        if (!sourceResults.size && !sourceLoads.size) {
            const cached = await loadPredictionCache(rawMatch);
            if (state.destroyed || generation !== state.requestGeneration) return;
            for (const item of cached?.inputs?.sourceData || []) {
                const source = sourcePlan.find((candidate) => candidate.sourceKey === item.source?.sourceKey
                    && candidate.href === item.source.href);
                if (source && item.fetchedAt > 0 && item.fetchedAt < identity.timestamp) {
                    sourceResults.set(source.sourceKey, { ...item, source });
                    sourceTransport.settle?.(source);
                }
            }
        }
        await publishSourceSnapshot(rawMatch, generation);
        // Serialized starts keep traffic bounded and retain a useful local estimate throughout.
        for (const source of sourcePlan) {
            if (state.destroyed || state.suspended || !state.enabled
                || generation !== state.requestGeneration) return;
            if (sourceResults.has(source.sourceKey)) continue;
            let promise = sourceLoads.get(source.sourceKey);
            if (!promise) {
                promise = sourceTransport.load(source).then((response) => {
                    const current = extractMatchIdentity(document);
                    if (state.destroyed || state.suspended || !state.enabled
                        || !sameOrderedMatchIdentity(source, current) || current.phase !== 'scheduled'
                        || Date.now() >= source.timestamp) return;
                    const parsed = parseInertAnalyticsDocument(response.html);
                    const data = source.kind === 'analytics'
                        ? extractAnalyticsPageData(parsed)
                        : liveModel.extractTeamPlayerPageData(parsed, source);
                    if (!data) throw new Error('The prediction source has no usable data.');
                    sourceResults.set(source.sourceKey, {
                        source, data, fetchedAt: response.fetchedAt, status: 'loaded',
                    });
                }).catch((error) => {
                    const current = extractMatchIdentity(document);
                    if (error.pausedBeforeFetch || state.destroyed || state.suspended || !state.enabled
                        || !sameOrderedMatchIdentity(source, current) || current.phase !== 'scheduled') return;
                    sourceResults.set(source.sourceKey, {
                        source, status: 'unavailable', code: error.code || 'SOURCE_INVALID',
                        fetchedAt: 0,
                    });
                    globalThis.HLTV_SP_DIAGNOSTICS?.record('warn', 'match prediction source', error);
                }).finally(() => sourceLoads.delete(source.sourceKey));
                sourceLoads.set(source.sourceKey, promise);
            }
            await promise;
            if (state.destroyed || generation !== state.requestGeneration) return;
            const currentIdentity = extractMatchIdentity(document);
            if (!sameOrderedMatchIdentity(identity, currentIdentity)) return;
            if (currentIdentity.phase !== 'scheduled') {
                await showSavedPrediction(currentIdentity, generation);
                return;
            }
            const currentMatch = extractMatchPageData(document, currentIdentity);
            if (currentMatch) await publishSourceSnapshot(currentMatch, generation);
        }
    }

    async function publishSourceSnapshot(rawMatch, generation) {
        if (state.destroyed || state.suspended || !state.enabled
            || generation !== state.requestGeneration) return;
        const now = Date.now();
        const identity = extractMatchIdentity(document);
        if (!sameOrderedMatchIdentity(rawMatch, identity)
            || identity.phase !== 'scheduled' || now >= rawMatch.timestamp) return;
        const results = [...sourceResults.values()].sort((a, b) => (
            a.source.sourceKey.localeCompare(b.source.sourceKey)
        ));
        const analytics = results.find((item) => item.source.kind === 'analytics' && item.data)?.data || null;
        const teamPlayers = results.filter((item) => item.source.kind === 'team-players' && item.data)
            .map((item) => item.data);
        const records = (sourcePlan || []).map((source) => {
            const result = sourceResults.get(source.sourceKey);
            return { ...source, fetchedAt: result?.fetchedAt || 0,
                status: result?.status || 'pending', code: result?.code || '' };
        });
        try {
            const inputs = { ...normalizePredictionInputs(rawMatch, analytics, teamPlayers, records),
                sourceData: results.filter((item) => item.data) };
            const predictions = calculatePredictionModes(inputs);
            if (!CONFIG.modes.every((mode) => validCachedPrediction(predictions[mode]))) {
                throw new Error('Prediction result failed validation.');
            }
            // CPU work can cross the cutoff even when every HTTP response arrived earlier.
            if (Date.now() >= rawMatch.timestamp || generation !== state.requestGeneration) return;
            state.currentInputs = inputs;
            state.currentRenderInputs = inputs;
            state.currentPredictions = predictions;
            state.currentExplanations = null;
            state.currentFetchedAt = now;
            state.currentCalculatedAt = now;
            state.currentArchived = false;
            state.currentPhase = 'scheduled';
            state.currentRawMatchFingerprint = rawMatchFingerprint(rawMatch);
            renderCurrentPrediction();
            void storePredictionCache(inputs, predictions[state.mode], now, state.currentRawMatchFingerprint);
            await storePredictionArchive(inputs, predictions, now, now);
        } catch (error) {
            globalThis.HLTV_SP_DIAGNOSTICS?.record('warn', 'match prediction calculation', error);
            if (!state.currentPredictions) renderStatus('Prediction is unavailable for this match.', true, true);
        }
    }

    function handleStorageChanges(changes, areaName) {
        if (areaName !== 'local' || !changes || typeof changes !== 'object') return;
        let resync = false;
        if (hasOwn(changes, CONFIG.enableKey)) {
            const value = changes[CONFIG.enableKey]?.newValue;
            state.enabled = typeof value === 'boolean' ? value : CONFIG.defaultEnabled;
            resync = true;
        }
        if (hasOwn(changes, CONFIG.modeKey)) {
            const value = changes[CONFIG.modeKey]?.newValue;
            const nextMode = CONFIG.modes.includes(value) ? value : CONFIG.defaultMode;
            if (nextMode !== state.mode) {
                state.mode = nextMode;
                if (state.currentPredictions && state.currentRenderInputs) {
                    renderCurrentPrediction();
                }
            }
        }
        if (resync) void sync();
    }

    function mutationTouchesPredictionInput(mutation) {
        if (['live', 'finished', 'started'].includes(state.currentPhase)) return false;
        const selector = [
            '.teamsBox:not(.teamsBoxDropdown) .countdown',
            '.teamsBox:not(.teamsBoxDropdown) [data-time-countdown]',
            '.teamsBox:not(.teamsBoxDropdown) [data-unix]',
            '.teamsBox:not(.teamsBoxDropdown) a[href*="/team/"]',
            '.teamsBox:not(.teamsBoxDropdown) .won',
            '.teamsBox:not(.teamsBoxDropdown) .lost',
            '.maps .mapholder',
            '.lineups-compare-container',
            '.lineups',
            '.map-stats-infobox',
            '.veto-box',
            '.vrs-forecast-container',
            '.matchpage-analytics-section',
        ].join(',');
        const target = mutation.target instanceof Element ? mutation.target : mutation.target?.parentElement;
        const countdown = target?.closest?.(
            '.teamsBox:not(.teamsBoxDropdown) .countdown',
        );
        if (countdown) {
            const statusText = boundedText(countdown.textContent, 60);
            return countdown.classList.contains('countdown-live')
                || /^(?:live|match over|finished)$/i.test(statusText);
        }
        if (target?.closest?.(selector)) return true;
        return [...mutation.addedNodes, ...mutation.removedNodes].some((node) => (
            node instanceof Element
            && (node.matches(selector) || node.querySelector(selector))
        ));
    }

    function domPredictionInputsChanged() {
        const identity = extractMatchIdentity(document);
        if (!identity || identity.phase !== state.currentPhase) return true;
        if (identity.phase !== 'scheduled') return false;
        const rawMatch = extractMatchPageData(document, identity);
        if (!rawMatch) return true;
        return rawMatchFingerprint(rawMatch) !== state.currentRawMatchFingerprint;
    }

    function scheduleDomSync() {
        if (state.destroyed || state.domSyncTimer) return;
        state.domSyncTimer = globalThis.setTimeout(() => {
            state.domSyncTimer = 0;
            if (!domPredictionInputsChanged()) return;
            void sync();
        }, 0);
    }

    function observePredictionInputs() {
        if (state.domObserver || !document.body || typeof MutationObserver !== 'function') return;
        state.domObserver = new MutationObserver((mutations) => {
            if (mutations.some(mutationTouchesPredictionInput)) scheduleDomSync();
        });
        state.domObserver.observe(document.body, {
            attributes: true,
            characterData: true,
            childList: true,
            subtree: true,
        });
    }

    function whenReady() {
        if (document.readyState !== 'loading') return Promise.resolve();
        return new Promise((resolve) => document.addEventListener('DOMContentLoaded', resolve, {
            once: true,
        }));
    }

    async function initialise() {
        await whenReady();
        if (state.destroyed || !extensionApi?.storage?.local || !extensionApi?.runtime
            || !liveModel || !globalThis.HLTV_MATCH_PREDICTION_TRANSPORT_V23) return;
        try {
            const stored = await extensionApi.storage.local.get({
                [CONFIG.enableKey]: CONFIG.defaultEnabled,
                [CONFIG.modeKey]: CONFIG.defaultMode,
            });
            state.enabled = typeof stored?.[CONFIG.enableKey] === 'boolean'
                ? stored[CONFIG.enableKey]
                : CONFIG.defaultEnabled;
            state.mode = CONFIG.modes.includes(stored?.[CONFIG.modeKey])
                ? stored[CONFIG.modeKey]
                : CONFIG.defaultMode;
        } catch {
            state.enabled = CONFIG.defaultEnabled;
            state.mode = CONFIG.defaultMode;
        }
        state.storageListener = handleStorageChanges;
        extensionApi.storage.onChanged?.addListener?.(state.storageListener);
        observePredictionInputs();
        await sync();
    }

    function destroy() {
        if (state.destroyed) return;
        state.destroyed = true;
        sourceTransport?.destroy();
        state.requestGeneration += 1;
        if (state.refreshTimer) globalThis.clearTimeout(state.refreshTimer);
        state.refreshTimer = 0;
        if (state.domSyncTimer) globalThis.clearTimeout(state.domSyncTimer);
        state.domSyncTimer = 0;
        state.domObserver?.disconnect();
        state.domObserver = null;
        if (state.storageListener) {
            extensionApi.storage.onChanged?.removeListener?.(state.storageListener);
            state.storageListener = null;
        }
        removeUi();
    }

    const ready = initialise();
    const api = Object.freeze({
        ready,
        destroy,
        sync,
        config: CONFIG,
        testing: Object.freeze({
            clip,
            sigmoid,
            logit,
            median,
            medianAbsoluteDeviation,
            weightedMean,
            solveByBisection,
            parseNumber,
            parsePercent,
            extractBookmakers,
            extractMatchIdentity,
            extractMatchPageData,
            extractAnalyticsPageData,
            parseInertAnalyticsDocument,
            normalizePredictionInputs,
            calculateMarketProbability,
            calculateStructuralProbability,
            calculateFinalPrediction,
            calculateDataQuality,
            qualityBandDescription,
            mapSeriesLabel,
            predictionExplanations,
            renderPrediction,
            seriesDistribution,
            distributionWinProbability,
            scorelineWinnerIndex,
            constantMapProbabilityFromSeries,
            fingerprint,
            refreshInterval,
            rawMatchFingerprint,
            predictionSnapshot,
            calculatePredictionModes,
            archiveRenderInputs,
            frozenPredictionExplanations,
            validArchivedPrediction,
            validPredictionArchiveEntry,
            createPredictionArchiveEntry,
            predictionArchiveEntryKey,
            predictionArchiveStorageKey,
            predictionArchiveEntryStorageKey,
            prunePredictionArchive,
            loadPredictionArchive,
            storePredictionArchive,
            loadPredictionCache,
        }),
    });
    Object.defineProperty(globalThis, CONFIG.globalName, {
        configurable: true,
        enumerable: false,
        writable: false,
        value: api,
    });
    globalThis.addEventListener('pagehide', (event) => {
        if (!event.persisted) { destroy(); return; }
        state.suspended = true;
        state.requestGeneration += 1;
        sourceTransport?.suspend();
        stopRefresh();
    });
    globalThis.addEventListener('pageshow', (event) => {
        if (!event.persisted || state.destroyed) return;
        state.suspended = false;
        sourceTransport?.resume();
        void sync();
    });
})();
