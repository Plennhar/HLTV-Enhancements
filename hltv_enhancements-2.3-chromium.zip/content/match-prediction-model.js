// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Plennhar

// Pure, bounded parsers and deterministic inference. This module performs no I/O.
(() => {
    'use strict';

    const MODEL_VERSION = 'lineup-map-1';
    const CONFIG = Object.freeze({
        modelVersion: MODEL_VERSION,
        lineupWeight: 0.60,
        mapWeight: 0.30,
        vrsWeight: 0.10,
        ratingSlope: Math.log(1.5) / 0.10,
        recentShare: 5 / 12,
        recentPriorMaps: 10,
        mapPriorWins: 4,
        mapPriorMaps: 8,
        minimumPlayers: 3,
        minimumMapSamples: 5,
        habitPriorOpportunities: 8,
        firstHabitUniformShare: 0.20,
        habitWeight: 0.60,
        utilityTemperature: 0.75,
        maximumPlayers: 30,
        maximumMaps: 9,
        maximumScenarios: 3,
    });
    const clip = (value, low, high) => Math.min(high, Math.max(low, value));
    const finite = (value) => typeof value === 'number' && Number.isFinite(value) ? value : null;
    const number = (value) => {
        if (typeof value === 'number') return finite(value);
        let numericText = String(value ?? '').trim().replace(/(?<=\d)[\s\u00a0\u202f]+(?=\d)/g, '');
        if (!numericText || /^(?:-|—|n\/?a)$/i.test(numericText)) return null;
        // HLTV points use three-digit grouping; decimal odds can use a comma.
        if (!numericText.includes('.')) numericText = numericText.replace(/,(\d{1,2})(?!\d)/g, '.$1');
        numericText = numericText.replace(/,/g, '');
        const match = /[-+]?\d+(?:\.\d+)?/.exec(numericText);
        return match ? finite(Number(match[0])) : null;
    };
    const text = (value, limit = 100) => String(value ?? '').replace(/\s+/g, ' ').trim().slice(0, limit);
    const key = (value) => text(value).toLowerCase().replace(/[^a-z0-9]/g, '');
    const id = (value) => /^\d{1,20}$/.test(String(value ?? '')) ? String(value) : '';
    const sigmoid = (value) => 1 / (1 + Math.exp(-value));
    const logit = (value) => Math.log(clip(value, 1e-9, 1 - 1e-9) / (1 - clip(value, 1e-9, 1 - 1e-9)));
    const percent = (value) => {
        const parsed = number(value);
        if (parsed === null) return null;
        const result = typeof value === 'string' && value.includes('%') ? parsed / 100 : parsed;
        return result >= 0 && result <= 1 ? result : null;
    };
    const count = (value) => {
        const result = number(value);
        return Number.isSafeInteger(result) && result >= 0 && result <= 100000 ? result : null;
    };
    const rating = (value) => {
        const result = number(value);
        return result !== null && result >= 0 && result <= 5 ? result : null;
    };
    const url = (value) => {
        try {
            const result = new URL(String(value ?? ''), 'https://www.hltv.org/');
            return result.protocol === 'https:' && result.hostname === 'www.hltv.org'
                && !result.username && !result.password ? result : null;
        } catch { return null; }
    };
    const plain = (value) => JSON.parse(JSON.stringify(value));

    function parameterEntries(searchParams) {
        const entries = [];
        searchParams.forEach((value, key) => entries.push([key, value]));
        return entries;
    }

    function playerDataset(raw, teamId, declaredVersion) {
        if (typeof raw !== 'string' || raw.length > 128 * 1024) return [];
        try {
            const parsed = JSON.parse(raw);
            if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return [];
            const seen = new Set();
            return Object.entries(parsed).slice(0, CONFIG.maximumPlayers).flatMap(([entryId, player]) => {
                if (!player || typeof player !== 'object') return [];
                const playerId = id(player.playerId ?? entryId);
                if (!playerId || seen.has(playerId) || (id(player.teamId) && id(player.teamId) !== teamId)) return [];
                seen.add(playerId);
                // The recognized current widget has both Rating 3 components. A generic
                // "Rating" label alone never establishes version compatibility.
                const currentAdapter = Object.hasOwn(player, 'numericRoundSwing')
                    && Object.hasOwn(player, 'numericMultiKillRating');
                const explicitVersion = text(player.ratingVersion || declaredVersion);
                const ratingVersion = explicitVersion || (currentAdapter ? '3.0' : null);
                return [{ playerId, nickname: text(player.nickname), rating: rating(player.numericRating),
                    ratingVersion, ratingAdapter: explicitVersion ? 'explicit' : currentAdapter ? 'match-widget-r3' : 'unknown' }];
            });
        } catch { return []; }
    }

    function extractCoreMaps(document, lineups, observedAt) {
        const headers = [...document.querySelectorAll('.map-stats-infobox-header .team a[href]')];
        const coreSources = [0, 1].map((index) => {
            const source = url(headers[index]?.getAttribute('href'));
            return source ? { href: source.href, startDate: source.searchParams.get('startDate'),
                endDate: source.searchParams.get('endDate'), minimumPlayers: Number(source.searchParams.get('minLineupMatch')),
                playerIds: source.searchParams.getAll('lineup') } : null;
        });
        const today = new Date(observedAt).toISOString().slice(0, 10);
        const validDate = (value) => /^\d{4}-\d{2}-\d{2}$/.test(value || '') && Number.isFinite(Date.parse(value))
            && new Date(value).toISOString().slice(0, 10) === value;
        const sameWindow = coreSources.every((source) => source && validDate(source.startDate) && validDate(source.endDate)
            && source.startDate < source.endDate && source.endDate <= today)
            && coreSources[0].startDate === coreSources[1].startDate && coreSources[0].endDate === coreSources[1].endDate;
        const coreVerified = [0, 1].map((index) => {
            const source = url(headers[index]?.getAttribute('href'));
            const ids = source?.searchParams.getAll('lineup') || [];
            const current = (lineups[index] || []).map((player) => player.playerId);
            return sameWindow && source?.pathname === '/stats/lineup/maps' && source.searchParams.get('minLineupMatch') === '3'
                && current.length === 5 && ids.length === 5 && new Set(ids).size === 5
                && current.every((playerId) => ids.includes(playerId));
        });
        const chartNames = (document.querySelector('svg[data-spider-chart]')?.getAttribute('data-spider-chart') || '').split(',').map((name) => key(name));
        const result = new Map();
        for (const row of [...document.querySelectorAll('.map-stats-infobox-maps[data-mapname]')].slice(0, 90)) {
            const name = text(row.querySelector('.mapname')?.textContent || row.dataset.mapname);
            const mapKey = key(name);
            if (!mapKey) continue;
            const entry = result.get(mapKey) || { name, teams: [{}, {}], coreMinimumPlayers: 3 };
            const type = row.closest('[map-stats-infobox]')?.getAttribute('map-stats-infobox') || 'wins';
            const sides = [...row.querySelectorAll('.map-stats-infobox-stats')].slice(0, 2);
            sides.forEach((side, index) => {
                const sideText = text(side.textContent + ' ' + [...side.querySelectorAll('[title]')].map((node) => node.getAttribute('title')).join(' '), 1000);
                let value = percent(side.querySelector('.map-stats-infobox-winpercentage')?.textContent);
                const maps = count(/(\d+)\s+maps?\b/i.exec(sideText)?.[1]);
                const opportunities = count(/(\d+)\s+(?:possibilit(?:y|ies)|opportunities)\b/i.exec(sideText)?.[1]);
                if (/win/i.test(type)) {
                    const overlay = document.querySelector('[data-spider-tab-toggle-value="wins"]');
                    const precisionValues = (overlay?.getAttribute(`data-spider-overlay${index + 1}`) || '').split(',').map(number);
                    const precision = precisionValues[chartNames.indexOf(mapKey)];
                    // Overlay percentages use the chart's 0..1 scale. Do not let an
                    // overlay zero fabricate a rate hidden by the native minimum sample.
                    if (value !== null && precision !== null && Number.isFinite(precision)
                        && precision >= 0 && precision <= 1 && Math.abs(precision - value) <= 0.00501) value = precision;
                    entry.teams[index].winRate = coreVerified[index] ? value : null;
                    entry.teams[index].coreVerified = coreVerified[index];
                    entry.teams[index].sourceRecord = coreSources[index];
                    entry.teams[index].maps = maps;
                } else if (/pick/i.test(type)) {
                    entry.teams[index].pick = value;
                    entry.teams[index].pickOpportunities = opportunities;
                } else if (/ban/i.test(type)) {
                    entry.teams[index].ban = value;
                    entry.teams[index].banOpportunities = opportunities;
                }
            });
            result.set(mapKey, entry);
        }
        return [...result.values()].sort((a, b) => Number(chartNames.includes(key(b.name))) - Number(chartNames.includes(key(a.name)))).slice(0, CONFIG.maximumMaps);
    }

    function extractVeto(document, teams) {
        const actions = [];
        const boxes = [...document.querySelectorAll('.veto-box .preformatted-text')];
        for (const box of boxes) {
            const lines = [...box.childNodes].map((node) => node.nodeName === 'BR' ? '\n' : node.textContent).join('').split('\n');
            for (const line of lines) {
                const match = /^\s*(\d+)\.\s+(.+?)\s+(removed|picked)\s+([a-z0-9 _-]+)\s*$/i.exec(line);
                if (!match) continue;
                const actor = teams.findIndex((team) => key(team.name) === key(match[2]));
                if (actor < 0) continue;
                actions.push({ step: Number(match[1]) - 1, actor, type: match[3].toLowerCase() === 'picked' ? 'pick' : 'ban', map: text(match[4]) });
            }
        }
        return actions.slice(0, 6);
    }

    function extractMatchPageData(document, identity) {
        const root = document.querySelector('.match-page');
        if (!root || !identity || identity.teams?.length !== 2) return null;
        const formatText = text([...root.querySelectorAll('.veto-box .preformatted-text')].map((node) => node.textContent).join(' '), 1000);
        const bestOf = Number(/\bBest of\s+([135])\b/i.exec(formatText)?.[1]) || null;
        const lineupsRoot = root.querySelector('.lineups-compare-container');
        const rosterBoxes = [...root.querySelectorAll('.lineups .lineup')].slice(0, 2);
        const lineups = [0, 1].map((index) => {
            const dataset = playerDataset(lineupsRoot?.dataset[`team${index + 1}PlayersData`], identity.teams[index].id, lineupsRoot?.dataset.ratingVersion);
            const announcedIds = [...(rosterBoxes[index]?.querySelectorAll('.player-image .player-compare[data-player-id]') || [])]
                .map((node) => id(node.getAttribute('data-player-id'))).filter(Boolean);
            const uniqueIds = [...new Set(announcedIds)];
            if (uniqueIds.length === 5) return uniqueIds.map((playerId) => dataset.find((player) => player.playerId === playerId)
                || { playerId, nickname: '', rating: null, ratingVersion: null, ratingAdapter: 'missing' });
            // The current widget's exact five-entry dataset is an alternate roster
            // source. Never choose the first five out of a historical/mixed dataset.
            return uniqueIds.length === 0 && dataset.length === 5 ? dataset : [];
        });
        const vrsRoot = root.querySelector('.vrs-forecast-container .vrs-forecast-left-numbers');
        const vrs = [...(vrsRoot?.querySelectorAll(':scope > .vrs-forecast-numbers-wrapper') || [])].slice(0, 2).map((node) => ({
            points: number(node.querySelector('.vrs-forecast-points')?.textContent),
            rank: number(node.querySelector('.vrs-forecast-ranking')?.textContent),
        }));
        const advantage = [0, 0];
        for (let index = 0; index < 2; index += 1) {
            const teamName = identity.teams[index].name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            const advantageMatch = new RegExp(`${teamName}\\s+(?:has|have|starts? with|will have)\\s+(?:a\\s+)?([12])(?:[-:]0)?\\s+map advantage`, 'i').exec(formatText);
            if (advantageMatch) advantage[index] = Number(advantageMatch[1]);
        }
        // Keep one bounded overflow holder so a sixth named map cannot disappear
        // before validation. Default holders represent awarded, rather than played, maps.
        const mapNames = [...root.querySelectorAll('.maps .mapholder .mapname')].slice(0, 6)
            .map((node) => text(node.textContent));
        const actualSlots = (advantage.some(Boolean) ? mapNames.filter((name) => !/^default$/i.test(name)) : mapNames)
            .map((name) => /^(?:tba|tbd|-|default|unknown)$/i.test(name) ? null : name);
        const maps = extractCoreMaps(root, lineups, Number.isFinite(identity.observedAt) ? identity.observedAt : Date.now());
        const chartPool = (root.querySelector('svg[data-spider-chart]')?.getAttribute('data-spider-chart') || '')
            .split(',').map((name) => text(name)).filter(Boolean);
        const verifiedPool = chartPool.length === 7 && new Set(chartPool.map(key)).size === 7
            && chartPool.every((name) => maps.some((map) => key(map.name) === key(name)));
        const analytics = url(root.querySelector('a.matchpage-analytics-center-container[href]')?.getAttribute('href'));
        return { ...plain(identity), bestOf, formatText, isLive: identity.phase !== 'scheduled',
            analyticsHref: analytics?.href || '', vrs, lineups, maps,
            mapPool: verifiedPool ? chartPool : [],
            mapPoolSource: verifiedPool ? 'match-core-widget' : 'unknown',
            mapSlots: actualSlots, officialMaps: actualSlots.filter(Boolean),
            vetoActions: extractVeto(root, identity.teams), advantage, bookmakers: [] };
    }

    function extractAnalyticsPageData(document) {
        const header = document.querySelector('.analytics-header');
        if (!header) return null;
        const back = [...header.querySelectorAll('a[href]')].map((anchor) => url(anchor.getAttribute('href')))
            .find((entry) => /^\/matches\/\d+(?:\/|$)/.test(entry?.pathname || ''));
        const teams = [...header.querySelectorAll('.team .team-name')].slice(0, 2)
            .map((node) => text(node.querySelector('.name')?.textContent || node.textContent));
        const timestamps = [...header.querySelectorAll('[data-unix]')].map((node) => number(node.getAttribute('data-unix'))).filter(Number.isSafeInteger);
        const maps = [];
        const rows = [...document.querySelectorAll('#maps > table.table-container.gtSmartphone-only tbody tr')];
        for (let index = 0; index + 1 < rows.length && maps.length < CONFIG.maximumMaps; index += 1) {
            const mapCell = rows[index].querySelector('td[rowspan="2"]');
            const name = text(mapCell?.querySelector('.analytics-map-name')?.textContent);
            if (!name) continue;
            maps.push({ name, teams: [rows[index], rows[index + 1]].map((row) => ({
                teamName: text(row.querySelector('.maps-team-name')?.textContent),
                firstPick: percent(row.querySelector('.analytics-map-stats-pick-percentage')?.textContent),
                firstBan: percent(row.querySelector('.analytics-map-stats-ban-percentage')?.textContent),
                winRate: percent(row.querySelector('.analytics-map-stats-win-percentage')?.textContent),
                maps: count(row.querySelector('.analytics-map-stats-played')?.textContent),
            })) });
            index += 1;
        }
        return { matchId: /^\/matches\/(\d+)/.exec(back?.pathname || '')?.[1] || '', teams,
            timestamp: timestamps[0] ?? null, maps, bookmakers: [] };
    }

    function extractTeamPlayerPageData(document, source = {}) {
        const context = [...document.querySelectorAll('.context-item-name[href]')].map((node) => url(node.getAttribute('href')))
            .find((entry) => /^\/stats\/teams\/\d+(?:\/|$)/.test(entry?.pathname || ''));
        const selectedTeam = [...document.querySelectorAll('a.stats-top-menu-item-link.selected[href]')]
            .map((node) => url(node.getAttribute('href'))).find((entry) => /^\/stats\/teams\/players\/\d+(?:\/|$)/.test(entry?.pathname || ''));
        const teamId = /^\/stats\/teams\/(\d+)/.exec(context?.pathname || '')?.[1]
            || /^\/stats\/teams\/players\/(\d+)/.exec(selectedTeam?.pathname || '')?.[1] || '';
        if (!teamId || teamId !== id(source.teamId)) throw new Error('Team player statistics identity does not match.');
        const startDate = text(source.window?.startDate || source.startDate);
        const endDate = text(source.window?.endDate || source.endDate);
        const selectedFilter = (selector) => {
            const selected = document.querySelector(`${selector} option[selected]`);
            return url(selected?.getAttribute('data-link'));
        };
        const timeFilter = selectedFilter('.stats-sub-navigation-simple-filter-time');
        const versionFilter = selectedFilter('.stats-sub-navigation-simple-filter-version');
        const expectedPath = url(source.href)?.pathname || selectedTeam?.pathname;
        const matchesSource = (candidate) => candidate && candidate.pathname === expectedPath
            && /^\/stats\/teams\/players\/(\d+)(?:\/|$)/.exec(candidate.pathname)?.[1] === teamId
            && candidate.searchParams.get('startDate') === startDate
            && candidate.searchParams.get('endDate') === endDate
            && candidate.searchParams.get('csVersion') === 'CS2'
            && parameterEntries(candidate.searchParams).every(([name]) => ['startDate', 'endDate', 'csVersion'].includes(name))
            && ['startDate', 'endDate', 'csVersion'].every((name) => candidate.searchParams.getAll(name).length === 1);
        const conflictingForm = [...document.querySelectorAll('input[name], select[name]')].some((node) => {
            const name = node.getAttribute('name');
            // Native blank date editors are unapplied; selected links still prove the active window.
            if (node.matches('input.filter-date') && ['startDate', 'endDate'].includes(name)
                && node.type === 'text' && node.value === '' && node.form === null) return false;
            const expected = { startDate, endDate, csVersion: 'CS2' }[name];
            return expected !== undefined && node.value !== expected;
        });
        const conflictingFilter = [...document.querySelectorAll('select[class*="stats-sub-navigation-simple-filter-"] option[selected][data-link]')]
            .some((node) => !matchesSource(url(node.getAttribute('data-link'))));
        if (conflictingForm || conflictingFilter || !/^\d{4}-\d{2}-\d{2}$/.test(startDate) || !/^\d{4}-\d{2}-\d{2}$/.test(endDate)
            || !matchesSource(timeFilter) || !matchesSource(versionFilter) || !matchesSource(selectedTeam)) {
            throw new Error('Team player statistics date or CS2 filters do not match.');
        }
        const tables = [...document.querySelectorAll('table.stats-table')].filter((candidate) => {
            const headers = [...candidate.querySelectorAll('thead th')].map((node) => text(node.textContent));
            return headers.some((value) => /^Player$/i.test(value)) && headers.some((value) => /Rating\s*3\.0/i.test(value))
                && headers.some((value) => /^Maps?$/i.test(value))
                && headers.some((value) => /^Rounds?$/i.test(value));
        });
        if (!tables.length) throw new Error('Rating 3.0 player table is unavailable.');
        const seen = new Set();
        const players = [];
        let remainingRows = CONFIG.maximumPlayers;
        // Announced stand-ins may appear under Historical players. Each compatible
        // table has its own column layout; all tables share one bounded row budget.
        for (const table of tables) {
            if (remainingRows <= 0) break;
            const headers = [...table.querySelectorAll('thead th')].map((node) => text(node.textContent));
            const mapsColumn = headers.findIndex((value) => /^Maps?$/i.test(value));
            const roundsColumn = headers.findIndex((value) => /^Rounds?$/i.test(value));
            const ratingColumn = headers.findIndex((value) => /Rating\s*3\.0/i.test(value));
            for (const row of [...table.querySelectorAll('tbody tr')].slice(0, remainingRows)) {
                remainingRows -= 1;
                const anchor = [...row.querySelectorAll('a[href]')].find((node) => /^\/stats\/players\/\d+(?:\/|$)/.test(url(node.getAttribute('href'))?.pathname || ''));
                const playerId = /^\/stats\/players\/(\d+)/.exec(url(anchor?.getAttribute('href'))?.pathname || '')?.[1] || '';
                const cells = [...row.querySelectorAll(':scope > td')];
                const value = rating(cells[ratingColumn]?.textContent);
                const maps = count(cells[mapsColumn]?.textContent);
                const rounds = count(cells[roundsColumn]?.textContent);
                if (!playerId || seen.has(playerId) || value === null || !maps || !rounds) continue;
                seen.add(playerId);
                players.push({ playerId, nickname: text(anchor.textContent), rating: value, maps, rounds, ratingVersion: '3.0' });
            }
        }
        return { teamId, ratingVersion: '3.0', startDate, endDate,
            window: 'last-calendar-month', players };
    }

    function normalizePredictionInputs(rawMatch, rawAnalytics, rawTeamPlayers = [], sourceRecords = []) {
        if (!rawMatch || rawMatch.teams?.length !== 2) throw new Error('Prediction match data is incomplete.');
        if (rawAnalytics) {
            if (String(rawAnalytics.matchId) !== String(rawMatch.matchId)
                || rawAnalytics.teams?.length !== 2
                || rawAnalytics.teams.some((team, index) => key(typeof team === 'string' ? team : team.name) !== key(rawMatch.teams[index].name))
                || !Number.isFinite(rawAnalytics.timestamp)
                || Math.abs(rawAnalytics.timestamp - rawMatch.timestamp) > 60000) {
                throw new Error('Analytics match identity does not match.');
            }
        }
        const lineups = [0, 1].map((index) => {
            const teamId = id(rawMatch.teams[index].id);
            const month = (Array.isArray(rawTeamPlayers) ? rawTeamPlayers : []).find((entry) => entry && id(entry.teamId) === teamId);
            const seen = new Set();
            return (rawMatch.lineups?.[index] || []).slice(0, CONFIG.maximumPlayers).flatMap((player) => {
                const playerId = id(player.playerId);
                if (!playerId || seen.has(playerId)) return [];
                seen.add(playerId);
                const monthly = month?.players?.find((entry) => id(entry.playerId) === playerId);
                return [{ playerId, nickname: text(player.nickname || monthly?.nickname || `Player ${playerId}`), rating: rating(player.rating),
                    ratingVersion: text(player.ratingVersion) || null, ratingAdapter: text(player.ratingAdapter),
                    monthRating: rating(monthly?.rating), monthMaps: count(monthly?.maps), monthRounds: count(monthly?.rounds),
                    monthRatingVersion: text(monthly?.ratingVersion || month?.ratingVersion) || null }];
            }).slice(0, 5);
        });
        const seenMaps = new Set();
        const rawMaps = [...(rawMatch.maps || [])];
        for (const analyticsMap of rawAnalytics?.maps || []) {
            if (!rawMaps.some((entry) => key(entry.name) === key(analyticsMap.name))) rawMaps.push({ name: analyticsMap.name, teams: [{}, {}] });
        }
        const eligibleNames = new Set([...(rawMatch.mapPool || []), ...(rawMatch.mapSlots || rawMatch.officialMaps || [])].filter(Boolean).map(key));
        rawMaps.sort((a, b) => Number(eligibleNames.has(key(b.name))) - Number(eligibleNames.has(key(a.name))));
        const maps = rawMaps.slice(0, CONFIG.maximumMaps).flatMap((entry) => {
            const name = text(entry.name);
            if (!key(name) || seenMaps.has(key(name))) return [];
            seenMaps.add(key(name));
            const analyticsMap = rawAnalytics?.maps?.find((candidate) => key(candidate.name) === key(name));
            return [{ name, coreMinimumPlayers: 3, teams: [0, 1].map((index) => {
                const core = entry.teams?.[index] || {};
                const candidate = analyticsMap?.teams?.[index] || {};
                const first = key(candidate.teamName) === key(rawMatch.teams[index].name) ? candidate : {};
                const useCore = mapRate(core).available;
                const sample = useCore ? core : mapRate(first).available ? first : core;
                return { source: useCore ? 'lineup-core' : sample === first ? 'analytics-team' : 'unknown',
                    sourceRecord: useCore ? plain(core.sourceRecord || null) : sample === first
                        ? { kind: 'analytics-team', matchId: String(rawMatch.matchId) } : null,
                    maps: count(sample.maps), wins: count(sample.wins), draws: count(sample.draws) ?? 0,
                    winRate: percent(sample.winRate), pick: percent(core.pick), ban: percent(core.ban),
                    pickOpportunities: count(core.pickOpportunities), banOpportunities: count(core.banOpportunities),
                    firstPick: percent(first.firstPick ?? first.pick), firstBan: percent(first.firstBan ?? first.ban) };
            }) }];
        });
        const mapPool = [...new Set((rawMatch.mapPool || []).map((name) => text(name)).filter(Boolean))].slice(0, CONFIG.maximumMaps);
        const bestOf = [1, 3, 5].includes(rawMatch.bestOf) ? rawMatch.bestOf : null;
        const advantage = [0, 1].map((index) => rawMatch.advantage?.[index] == null ? 0 : count(rawMatch.advantage[index]));
        const slots = rawMatch.mapSlots || rawMatch.officialMaps || [];
        return { modelVersion: MODEL_VERSION, matchId: String(rawMatch.matchId), teams: plain(rawMatch.teams),
            timestamp: rawMatch.timestamp, bestOf, formatText: text(rawMatch.formatText, 1000),
            vrs: [0, 1].map((index) => ({ points: number(rawMatch.vrs?.[index]?.points), rank: number(rawMatch.vrs?.[index]?.rank) })),
            lineups, maps, mapPool, mapPoolSource: text(rawMatch.mapPoolSource) || 'unknown',
            mapSlots: slots.slice(0, 5).map((name) => name ? text(name) : null),
            officialMaps: slots.filter(Boolean).map((name) => text(name)), advantage,
            vetoActions: (rawMatch.vetoActions || []).slice(0, 6).map((action) => ({ step: count(action.step), actor: action.actor, type: action.type, map: text(action.map) })),
            bookmakers: plain(rawAnalytics?.bookmakers?.length ? rawAnalytics.bookmakers : rawMatch.bookmakers || []),
            bookmakerSource: rawAnalytics?.bookmakers?.length ? 'analytics' : 'match',
            sourceRecords: plain(Array.isArray(sourceRecords) ? sourceRecords : []).slice(0, 3) };
    }

    function lineupExpert(inputs) {
        const players = [0, 1].map((index) => Array.from({ length: 5 }, (_, playerIndex) => {
            const player = inputs.lineups?.[index]?.[playerIndex] || {};
            const baseline = player.ratingVersion === '3.0' ? rating(player.rating) : null;
            const monthly = player.monthRatingVersion === '3.0' ? rating(player.monthRating) : null;
            const sample = count(player.monthMaps) || 0;
            const shrink = sample / (sample + CONFIG.recentPriorMaps);
            const monthlyUsable = monthly !== null && sample > 0;
            const effective = baseline !== null
                ? baseline + (monthlyUsable ? CONFIG.recentShare * shrink * (monthly - baseline) : 0)
                : monthlyUsable ? 1 + shrink * (monthly - 1) : 1;
            return { playerId: id(player.playerId), nickname: text(player.nickname), baselineRating: baseline,
                monthlyRating: monthlyUsable ? monthly : null, monthlyMaps: sample,
                monthlyRounds: count(player.monthRounds), shrink, effectiveRating: effective,
                available: baseline !== null || monthlyUsable, baselineSampleUnknown: baseline !== null };
        }));
        const observed = players.map((team) => team.filter((player) => player.available).length);
        const available = observed.every((value) => value >= CONFIG.minimumPlayers);
        const means = players.map((team) => team.reduce((sum, player) => sum + player.effectiveRating, 0) / 5);
        const z = available ? CONFIG.ratingSlope * (means[0] - means[1]) : 0;
        return { available, probability: sigmoid(z), z, means, observed, players,
            monthlyObserved: players.map((team) => team.filter((player) => player.monthlyRating !== null).length) };
    }

    function vrsExpert(inputs) {
        const points = [0, 1].map((index) => number(inputs.vrs?.[index]?.points));
        const available = points.every((value) => value !== null && value > 0);
        if (!available) return { available: false, probability: 0.5, referenceSeriesProbability: 0.5, z: 0 };
        const q = Math.log(10) / 400;
        const g = 1 / Math.sqrt(1 + 3 * q * q * 75 * 75 / (Math.PI * Math.PI));
        const target = sigmoid(g * q * (points[0] - points[1]));
        let low = 0; let high = 1;
        for (let iteration = 0; iteration < 60; iteration += 1) {
            const middle = (low + high) / 2;
            if (3 * middle * middle - 2 * middle * middle * middle < target) low = middle;
            else high = middle;
        }
        const probability = (low + high) / 2;
        return { available, probability, referenceSeriesProbability: target, z: logit(probability), referenceBestOf: 3 };
    }

    function mapRate(team = {}) {
        const maps = count(team.maps);
        const wins = count(team.wins);
        const draws = count(team.draws) || 0;
        const winRate = percent(team.winRate);
        const available = maps !== null && maps >= 3 && draws <= maps
            && (wins !== null ? wins + draws <= maps : winRate !== null);
        if (!available) return { available: false, rate: 0.5, maps: maps || 0, effectiveWins: null, approximate: false };
        const effectiveWins = wins !== null ? wins + draws / 2 : winRate * maps;
        return { available, rate: (effectiveWins + CONFIG.mapPriorWins) / (maps + CONFIG.mapPriorMaps),
            maps, effectiveWins, approximate: wins === null };
    }

    function seriesDistribution(probabilities, bestOf, advantage = [0, 0]) {
        if (![1, 3, 5].includes(bestOf)) return {};
        const needed = Math.floor(bestOf / 2) + 1;
        const result = {};
        const walk = (index, a, b, mass) => {
            if (a >= needed || b >= needed) {
                const score = `${a}-${b}`;
                result[score] = (result[score] || 0) + mass;
                return;
            }
            if (index >= probabilities.length) return;
            const p = finite(probabilities[index]) === null ? 0.5 : clip(probabilities[index], 0, 1);
            walk(index + 1, a + 1, b, mass * p);
            walk(index + 1, a, b + 1, mass * (1 - p));
        };
        walk(0, advantage[0] || 0, advantage[1] || 0, 1);
        return result;
    }
    const distributionProbability = (distribution) => Object.entries(distribution).reduce((sum, [score, value]) => {
        const [a, b] = score.split('-').map(Number);
        return sum + (a > b ? value : 0);
    }, 0);

    function vetoMixture(inputs, mapModels, baseMapProbability) {
        const bestOf = inputs.bestOf;
        const advantage = inputs.advantage || [0, 0];
        const needed = Math.floor(bestOf / 2) + 1;
        if (![1, 3, 5].includes(bestOf) || advantage.some((value) => !Number.isSafeInteger(value) || value < 0 || value >= needed)
            || advantage.every((value) => value > 0)) return { available: false, reason: 'unsupported-format', distribution: {}, scenarios: [] };
        const actualCount = bestOf - advantage[0] - advantage[1];
        if ((inputs.mapSlots || []).slice(actualCount).some(Boolean) || inputs.officialMaps?.length > actualCount) {
            return { available: false, reason: 'excess-official-map', distribution: {}, scenarios: [] };
        }
        const slots = Array.from({ length: actualCount }, (_, index) => inputs.mapSlots?.[index] || null);
        const known = slots.filter(Boolean).map(key);
        if (new Set(known).size !== known.length) return { available: false, reason: 'duplicate-official-map', distribution: {}, scenarios: [] };
        const pool = inputs.mapPool || [];
        const poolKnown = pool.length === 7 && new Set(pool.map(key)).size === 7;
        const types = bestOf === 1 ? ['ban', 'ban', 'ban', 'ban', 'ban', 'ban']
            : bestOf === 3 ? ['ban', 'ban', 'pick', 'pick', 'ban', 'ban']
                : ['ban', 'ban', 'pick', 'pick', 'pick', 'pick'];
        const observed = inputs.vetoActions || [];
        if (observed.some((action) => ![0, 1].includes(action.actor) || !Number.isInteger(action.step)
            || action.step < 0 || action.step >= 6 || !['ban', 'pick'].includes(action.type) || !key(action.map))) {
            return { available: false, reason: 'unsupported-veto', distribution: {}, scenarios: [] };
        }
        const observedSteps = new Map();
        const observedMaps = new Map();
        const contradictoryVeto = observed.some((action) => {
            const mapKey = key(action.map);
            const previous = observedSteps.get(action.step);
            const previousStep = observedMaps.get(mapKey);
            observedSteps.set(action.step, action);
            observedMaps.set(mapKey, action.step);
            const pickSlot = types.slice(0, action.step).filter((type) => type === 'pick').length;
            return types[action.step] !== action.type
                || (previous && (previous.actor !== action.actor || key(previous.map) !== mapKey))
                || (previousStep !== undefined && previousStep !== action.step)
                || (poolKnown && !pool.some((name) => key(name) === mapKey))
                || (action.type === 'ban' && known.includes(mapKey))
                || (action.type === 'pick' && !advantage.some(Boolean)
                    && ((slots[pickSlot] && key(slots[pickSlot]) !== mapKey)
                        || slots.some((name, index) => index !== pickSlot && name && key(name) === mapKey)))
                || (action.type === 'pick' && known.length === actualCount && !known.includes(mapKey));
        });
        const compatibleActors = [0, 1].filter((firstActor) => observed.every((action) => action.actor === (firstActor + action.step) % 2));
        if (contradictoryVeto || !compatibleActors.length
            || (poolKnown && known.some((name) => !pool.some((map) => key(map) === name)))) {
            return { available: false, reason: 'inconsistent-veto', distribution: {}, scenarios: [] };
        }
        const probabilityFor = (name) => mapModels.find((map) => key(map.name) === key(name))?.probability ?? baseMapProbability;
        const direct = (method, reason = '') => {
            const probabilities = slots.map((name) => name ? probabilityFor(name) : baseMapProbability);
            const distribution = seriesDistribution(probabilities, bestOf, advantage);
            return { available: true, method, reason, distribution, probability: distributionProbability(distribution),
                scenarios: [{ maps: slots, probability: 1, probabilityA: distributionProbability(distribution) }],
                selectedMaps: slots.map((name, index) => ({ name, slot: index, selectionProbability: 1, probabilityA: probabilities[index] })) };
        };
        if (known.length === actualCount) return direct('official');
        if (advantage.some(Boolean)) return { available: false, reason: 'unknown-advantage-veto', distribution: {}, scenarios: [] };
        if (!poolKnown) {
            return direct('known-slots-baseline', 'map-pool-unavailable');
        }
        const leaves = [];
        function walk(remaining, picks, actions, firstActor) {
            const step = actions.length;
            if (step === 6) {
                const maps = [...picks, ...remaining];
                const distribution = seriesDistribution(maps.map(probabilityFor), bestOf);
                return { probability: distributionProbability(distribution), leaves: [{ maps, actions, distribution, mass: 1 }] };
            }
            const actor = (firstActor + step) % 2;
            const type = types[step];
            const firstForActor = !actions.some((action) => action.actor === actor && action.type === type);
            const habits = remaining.map((name) => {
                const team = mapModels.find((map) => key(map.name) === key(name))?.teams?.[actor] || {};
                if (firstForActor && finite(team[type === 'pick' ? 'firstPick' : 'firstBan']) !== null) {
                    return (1 - CONFIG.firstHabitUniformShare) * team[type === 'pick' ? 'firstPick' : 'firstBan'] + CONFIG.firstHabitUniformShare / remaining.length;
                }
                const n = count(team[`${type}Opportunities`]) || 0;
                const rate = percent(team[type]);
                return rate !== null && n > 0 ? (n * rate + CONFIG.habitPriorOpportunities / remaining.length) / (n + CONFIG.habitPriorOpportunities) : 1 / remaining.length;
            });
            const habitSum = habits.reduce((sum, value) => sum + value, 0);
            const children = remaining.map((name, index) => {
                const child = walk(remaining.filter((_, i) => i !== index), type === 'pick' ? [...picks, name] : picks,
                    [...actions, { step, actor, type, map: name }], firstActor);
                const actorUtility = (actor === 0 ? 1 : -1) * clip(logit(child.probability), -4, 4);
                const weight = Math.exp((CONFIG.habitWeight * Math.log(habits[index] / habitSum)
                    + (1 - CONFIG.habitWeight) * actorUtility) / CONFIG.utilityTemperature);
                return { child, weight };
            });
            const total = children.reduce((sum, entry) => sum + entry.weight, 0);
            return { probability: children.reduce((sum, entry) => sum + entry.child.probability * entry.weight / total, 0),
                leaves: children.flatMap(({ child, weight }) => child.leaves.map((leaf) => ({ ...leaf, mass: leaf.mass * weight / total }))) };
        }
        for (const firstActor of [0, 1]) {
            const tree = walk(pool, [], [], firstActor);
            for (const leaf of tree.leaves) {
                const compatible = slots.every((name, index) => !name || key(name) === key(leaf.maps[index]))
                    && observed.every((action) => {
                        const actual = leaf.actions[action.step];
                        return actual && actual.actor === action.actor && actual.type === action.type && key(actual.map) === key(action.map);
                    });
                if (compatible) leaves.push({ ...leaf, mass: leaf.mass / 2 });
            }
        }
        const total = leaves.reduce((sum, leaf) => sum + leaf.mass, 0);
        if (!(total > 0)) return { available: false, reason: 'inconsistent-veto', distribution: {}, scenarios: [] };
        const distribution = {}; const scenarioMap = new Map(); const selections = new Map();
        for (const leaf of leaves) {
            const mass = leaf.mass / total;
            for (const [score, value] of Object.entries(leaf.distribution)) distribution[score] = (distribution[score] || 0) + mass * value;
            const scenarioKey = leaf.maps.map(key).join('|');
            const scenario = scenarioMap.get(scenarioKey) || { maps: leaf.maps, probability: 0, probabilityA: distributionProbability(leaf.distribution) };
            scenario.probability += mass; scenarioMap.set(scenarioKey, scenario);
            leaf.maps.forEach((name, slot) => {
                const selectionKey = `${slot}:${key(name)}`;
                const selection = selections.get(selectionKey) || { name, slot, selectionProbability: 0, probabilityA: probabilityFor(name) };
                selection.selectionProbability += mass; selections.set(selectionKey, selection);
            });
        }
        const distributionMass = Object.values(distribution).reduce((sum, value) => sum + value, 0);
        for (const score of Object.keys(distribution)) distribution[score] /= distributionMass;
        const scenarios = [...scenarioMap.values()].map((entry) => ({ ...entry, probability: clip(entry.probability, 0, 1) })).sort((a, b) => b.probability - a.probability || a.maps.join('|').localeCompare(b.maps.join('|'))).slice(0, CONFIG.maximumScenarios);
        return { available: true, method: 'veto-mixture', distribution, probability: clip(distributionProbability(distribution), 0, 1),
            scenarios, selectedMaps: [...selections.values()].map((entry) => ({ ...entry, selectionProbability: clip(entry.selectionProbability, 0, 1) })), scenarioCount: scenarioMap.size, conditionedMass: total };
    }

    function calculateStructuralProbability(inputs) {
        const lineup = lineupExpert(inputs);
        const strength = vrsExpert(inputs);
        const baseZ = CONFIG.lineupWeight * lineup.z + CONFIG.vrsWeight * strength.z;
        const baseProbability = sigmoid(baseZ);
        const maps = (inputs.maps || []).slice(0, CONFIG.maximumMaps).map((entry) => {
            const rates = [0, 1].map((index) => mapRate(entry.teams?.[index]));
            const available = rates.every((rate) => rate.available);
            const mapZ = available ? logit(rates[0].rate) - logit(rates[1].rate) : 0;
            return { name: entry.name, teams: entry.teams, rates, available, mapProbability: sigmoid(mapZ),
                probability: sigmoid(baseZ + CONFIG.mapWeight * mapZ), z: mapZ };
        });
        const eligible = inputs.mapPool?.length === 7 ? new Set(inputs.mapPool.map(key))
            : new Set((inputs.mapSlots || []).filter(Boolean).map(key));
        const mapSamples = [0, 1].map((index) => maps.reduce((sum, map) => sum + (eligible.has(key(map.name)) && map.available ? map.rates[index].maps - (count(map.teams?.[index]?.draws) || 0) : 0), 0));
        const mapAvailable = mapSamples.every((sample) => sample >= CONFIG.minimumMapSamples);
        const mapSeries = vetoMixture(inputs, maps, baseProbability);
        const available = mapSeries.available && (lineup.available || mapAvailable);
        for (const map of maps) {
            map.selectionProbability = (mapSeries.selectedMaps || []).reduce((sum, selection) => sum
                + (key(selection.name) === key(map.name) ? selection.selectionProbability : 0), 0);
            map.selectionProbability = clip(map.selectionProbability, 0, 1);
        }
        const missing = [];
        if (!lineup.available) missing.push('At least three current-player ratings per team are unavailable.');
        if (!strength.available) missing.push('Opponent-strength ranking points unavailable.');
        if (!mapAvailable) missing.push('Insufficient eligible core-map samples.');
        if (lineup.monthlyObserved.some((n) => n < 5)) missing.push('Some current players lack usable last-month ratings.');
        if (mapSeries.method === 'known-slots-baseline') missing.push('Current map pool unavailable; unknown slots use the baseline.');
        const coverage = { missing, lineup: lineup.observed, monthly: lineup.monthlyObserved,
            vrs: strength.available, maps: mapSamples, coreMinimumPlayers: 3,
            mapPoolKnown: inputs.mapPool?.length === 7, vetoMethod: mapSeries.method || 'unavailable',
            limited: !strength.available || !lineup.available || !mapAvailable || mapSeries.method === 'known-slots-baseline' || lineup.monthlyObserved.some((n) => n < 5),
            sourceRecords: inputs.sourceRecords || [] };
        const diagnostics = { modelVersion: MODEL_VERSION, weights: { lineup: 0.60, map: 0.30, vrs: 0.10 },
            assumptions: ['Heuristic coefficients; no calibrated accuracy claim.', 'Player and map evidence can overlap and differ in opponent strength.',
                'Monthly team statistics and three-month player ratings can cover different team contexts.', 'VRS series-to-map conversion assumes a reference BO3.'],
            reason: !mapSeries.available ? mapSeries.reason : !available ? 'insufficient-player-and-map-samples' : '' };
        return { available, probability: available ? mapSeries.probability : null, baseProbability, baseZ,
            reliability: available ? 1 : 0, reliabilityParts: {}, strength, lineup,
            mapSeries: { ...mapSeries, maps, mapReliability: mapAvailable ? 1 : 0, vetoReliability: mapSeries.method === 'veto-mixture' || mapSeries.method === 'official' ? 1 : 0 },
            coverage, diagnostics, players: lineup.players, maps, scenarios: mapSeries.scenarios || [] };
    }

    function calculateFinalPrediction(inputs, mode = 'stats', marketCalculator = null) {
        mode = mode === 'market' ? 'market' : 'stats';
        const market = typeof marketCalculator === 'function' ? marketCalculator(inputs)
            : { available: false, probability: null, reliability: 0, accepted: [], rejected: [] };
        const structural = calculateStructuralProbability(inputs);
        return buildFinalPrediction(structural, market, mode);
    }

    function buildFinalPrediction(structural, market, mode) {
        const probability = mode === 'market' ? market.available ? market.probability : null : structural.probability;
        const winnerIndex = Number.isFinite(probability) && Math.abs(probability - 0.5) > 1e-12 ? probability > 0.5 ? 0 : 1 : null;
        const scorelineDistribution = mode === 'stats' && structural.available ? structural.mapSeries.distribution : {};
        const scores = Object.entries(scorelineDistribution).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
        const likely = scores[0];
        return { modelVersion: MODEL_VERSION, probabilityA: probability, probabilityB: Number.isFinite(probability) ? 1 - probability : null,
            winnerIndex, mode, insufficient: !Number.isFinite(probability), structuralShare: mode === 'market' ? 0 : 1,
            scorelineDistribution, likelyScoreline: likely?.[0] || '',
            quality: { score: mode === 'market' ? (market.reliability || 0) * 100 : null,
                label: mode === 'market' ? 'Market coverage' : !structural.available ? 'Unavailable' : structural.coverage.limited ? 'Limited stats' : 'Stats coverage' },
            market, structural, coverage: structural.coverage, diagnostics: structural.diagnostics,
            players: structural.players, maps: structural.maps, scenarios: structural.scenarios };
    }

    function calculatePredictionModes(inputs, marketCalculator = null) {
        const structural = calculateStructuralProbability(inputs);
        const market = typeof marketCalculator === 'function' ? marketCalculator(inputs)
            : { available: false, probability: null, reliability: 0, accepted: [], rejected: [] };
        return { stats: buildFinalPrediction(structural, market, 'stats'), market: buildFinalPrediction(structural, market, 'market') };
    }

    globalThis.HLTV_MATCH_PREDICTION_MODEL_V23 = Object.freeze({ config: CONFIG, modelVersion: MODEL_VERSION,
        extractMatchPageData, extractAnalyticsPageData, extractTeamPlayerPageData, normalizePredictionInputs,
        calculateStructuralProbability, calculateFinalPrediction, calculatePredictionModes, seriesDistribution, parseNumber: number });
})();
