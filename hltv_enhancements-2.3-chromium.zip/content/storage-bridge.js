// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Plennhar

(() => {
    'use strict';

    const extensionApi = globalThis.browser;
    const ACTION_LOCK_PORT_NAME = 'hltv-sp:action-lock';
    const ACTION_LOCK_REQUEST_PATTERN = /^[A-Za-z0-9_-]{1,64}$/;
    const ACTION_LOCK_TOKEN_PATTERN = /^[A-Za-z0-9_-]{43}$/;
    const ACTION_LOCK_REACTION_KEY_PATTERN = /^(?:thread|reply):\d{1,20}$/;
    const ACTION_LOCK_THREAD_ID_PATTERN = /^\d{1,20}$/;
    const ACTION_LOCK_USER_ID_PATTERN = /^\d{1,20}$/;
    const ACTION_LOCK_DRAFT_ACCOUNT_ID_PATTERN = /^\d{1,20}$/;
    const SAVED_DRAFT_ACCOUNT_PREFIX_PATTERN = /^hltvForumSidebarPlus\.savedDraftV1\.\d{1,20}\.$/;
    const ACTION_LOCK_ACQUIRE_TIMEOUT_MS = 5000;
    const STORAGE_READY_RETRY_DELAYS_MS = Object.freeze([0, 50, 250]);
    const BATCH_WRITE_KEYS = new Set([
        'activitySourcesV2',
        'displayedForumsV1',
        'selectedForums',
        'hideMatches',
        'hideNews',
        'forumThreadLimits',
        'activitySourceColorsV1',
        'enableCustomThreadFetching',
        'enableCustomThreadColors',
        'layoutWidthPreset',
        'largeSidebarText',
        'movePostNewTopicToTop',
        'showRelativeAges',
        'enableExtendedMatchFilter',
        'strictSelectedTeamMatches',
        'enableThreadPreviews',
        'enableOriginalPosterHighlight',
        'enableReadStatus',
        'replyComposerAfterOriginalPost',
        'enableSavedDrafts',
        'enableUserTags',
        'hiddenUserTags',
        'enableLocalUserScores',
        'enableLocalDownvotes',
        'changeUpvoteStyle',
        'enableSignedOutLocalVoting',
        'enableUsernameBlocking',
        'enableWinAdjustedRatings',
        'enableKprMatchHistory',
        'showFullMapNames',
        'enableDiagnosticLogging',
        'enableStickyMatchHeader',
        'enableMatchPlayerFormOverlays',
        'enableMatchPrediction',
        'matchPredictionMode',
        'enableTeamPerformanceDifference',
        'matchPlayerPrimaryMetrics',
        'matchPlayerPrimaryMetric1',
        'matchPlayerPrimaryMetric2',
        'enableStatsColumnChooser',
        'enableStatsMultiSort',
        'enableStatsCsvExport',
        'enablePlayerMatchSparklines',
        'enableExtendedMatchHistoryLoading',
        'playerMatchTrendMetric',
        'enablePlayerMapMatrix',
        'enablePlayerComparisonEnhancements',
        'enablePlayerConsistencyScore',
        'enableStatsTablePeriodComparison',
        'enablePlayerPagePeriodComparison',
        'previousPeriodMetric',
        'statsOptionalColumnsV2',
        'extendedMatchTeamsV1',
        'sortOrder',
        'winAdjustedAutoRun',
        'statsColumnLayoutV2',
        'statsMatchHistoryRowsV2',
        'statsMultiSortV2',
        'userAnnotationsV1',
        'readStateV1',
        'localReactionsV1',
        'provisionalLocalUpvotesV1',
        'syncPulseV1',
    ]);
    if (!extensionApi?.storage?.local
        || typeof extensionApi.storage.local.get !== 'function'
        || typeof extensionApi.storage.local.set !== 'function'
        || typeof extensionApi.storage.local.remove !== 'function'
        || !extensionApi?.storage?.onChanged
        || !extensionApi?.runtime) {
        throw new Error('HLTV Enhancements requires browser extension APIs.');
    }

    const listeners = new Map();
    const pendingLocalWrites = new Map();
    const valueCache = new Map();
    const cacheRevisions = new Map();
    const changesBeforeCacheReady = new Map();
    let nextListenerId = 1;
    let cacheReady = false;
    let storageReadyPromise = null;

    function delay(milliseconds) {
        return new Promise((resolve) => globalThis.setTimeout(resolve, milliseconds));
    }

    function initialiseStorageCache(stored) {
        valueCache.clear();
        for (const [key, value] of Object.entries(stored || {})) {
            valueCache.set(key, value);
        }
        for (const [key, change] of changesBeforeCacheReady) {
            if (change.deleted) {
                valueCache.delete(key);
            } else {
                valueCache.set(key, change.value);
            }
        }
        changesBeforeCacheReady.clear();
        cacheReady = true;
    }

    async function loadStorageCacheWithRetry() {
        let lastError = null;
        for (const retryDelay of STORAGE_READY_RETRY_DELAYS_MS) {
            if (retryDelay) await delay(retryDelay);
            try {
                initialiseStorageCache(await extensionApi.storage.local.get(null));
                return;
            } catch (error) {
                lastError = error instanceof Error ? error : new Error(String(error));
            }
        }
        throw lastError || new Error('Extension-private storage could not be loaded.');
    }

    function ensureStorageReady() {
        if (cacheReady) return Promise.resolve();
        if (storageReadyPromise) return storageReadyPromise;
        const pending = loadStorageCacheWithRetry();
        storageReadyPromise = pending;
        pending.then(
            () => undefined,
            () => {
                if (!cacheReady && storageReadyPromise === pending) {
                    storageReadyPromise = null;
                }
            },
        );
        return pending;
    }

    function hasOwn(object, key) {
        return Object.prototype.hasOwnProperty.call(object, key);
    }

    function cloneValue(value) {
        if (value === undefined || value === null || typeof value !== 'object') return value;
        if (typeof globalThis.structuredClone === 'function') {
            return globalThis.structuredClone(value);
        }
        return JSON.parse(JSON.stringify(value));
    }

    function bumpCacheRevision(key) {
        const revision = (cacheRevisions.get(key) || 0) + 1;
        cacheRevisions.set(key, revision);
        return revision;
    }

    function valueSignature(value) {
        if (value === undefined) return 'undefined';
        try {
            return JSON.stringify(value);
        } catch {
            return String(value);
        }
    }

    function addPendingLocalWrite(key, value, hadPrevious, previousValue) {
        const normalisedKey = String(key);
        const queue = pendingLocalWrites.get(normalisedKey) || [];
        const inheritedFallback = queue[0];
        const marker = {
            signature: valueSignature(value),
            expiresAt: Date.now() + 5000,
            fallbackHadValue: inheritedFallback
                ? inheritedFallback.fallbackHadValue
                : Boolean(hadPrevious),
            fallbackValue: cloneValue(inheritedFallback
                ? inheritedFallback.fallbackValue
                : previousValue),
        };
        queue.push(marker);
        pendingLocalWrites.set(normalisedKey, queue);
        globalThis.setTimeout(() => {
            const current = pendingLocalWrites.get(normalisedKey);
            if (!current) return;
            const index = current.indexOf(marker);
            if (index >= 0) current.splice(index, 1);
            if (!current.length) pendingLocalWrites.delete(normalisedKey);
        }, 5100);
        return marker;
    }

    function removePendingLocalWrite(key, marker) {
        const normalisedKey = String(key);
        const queue = pendingLocalWrites.get(normalisedKey);
        if (!queue) return;
        const index = queue.indexOf(marker);
        if (index >= 0) queue.splice(index, 1);
        if (!queue.length) pendingLocalWrites.delete(normalisedKey);
    }

    function consumePendingLocalWrite(key, value) {
        const normalisedKey = String(key);
        const queue = pendingLocalWrites.get(normalisedKey);
        if (!queue?.length) return false;
        const signature = valueSignature(value);
        const now = Date.now();
        const index = queue.findIndex((marker) => (
            marker.expiresAt >= now && marker.signature === signature
        ));
        if (index < 0) return false;
        queue.splice(index, 1);
        if (!queue.length) pendingLocalWrites.delete(normalisedKey);
        return true;
    }

    async function getValue(key, fallbackValue) {
        await ensureStorageReady();
        const normalisedKey = String(key);
        return valueCache.has(normalisedKey)
            ? cloneValue(valueCache.get(normalisedKey))
            : cloneValue(fallbackValue);
    }

    function requireReadyCache() {
        if (!cacheReady) {
            throw new Error('Extension-private storage is not ready.');
        }
    }

    function restoreCachedFallback(key, revision, hadPrevious, previousValue) {
        if (cacheRevisions.get(key) !== revision) return;
        bumpCacheRevision(key);
        if (hadPrevious) {
            valueCache.set(key, cloneValue(previousValue));
        } else {
            valueCache.delete(key);
        }
    }

    async function reconcileFailedMutation(
        key,
        revision,
        hadPrevious,
        previousValue,
    ) {
        let stored;
        try {
            stored = await extensionApi.storage.local.get(key);
        } catch {
            restoreCachedFallback(key, revision, hadPrevious, previousValue);
            return;
        }
        if (cacheRevisions.get(key) !== revision) return;
        bumpCacheRevision(key);
        if (stored && typeof stored === 'object' && hasOwn(stored, key)) {
            valueCache.set(key, cloneValue(stored[key]));
        } else {
            valueCache.delete(key);
        }
    }

    function persistValue(key, value) {
        const normalisedKey = String(key);
        requireReadyCache();
        const hadPrevious = valueCache.has(normalisedKey);
        const previousValue = valueCache.get(normalisedKey);
        const revision = bumpCacheRevision(normalisedKey);
        valueCache.set(normalisedKey, cloneValue(value));
        const marker = addPendingLocalWrite(
            normalisedKey,
            value,
            hadPrevious,
            previousValue,
        );
        return extensionApi.storage.local.set({ [normalisedKey]: value }).catch(async (error) => {
            removePendingLocalWrite(normalisedKey, marker);
            await reconcileFailedMutation(
                normalisedKey,
                revision,
                marker.fallbackHadValue,
                marker.fallbackValue,
            );
            throw error;
        });
    }

    async function setValue(key, value) {
        await ensureStorageReady();
        await persistValue(key, value);
    }

    async function setValues(values) {
        if (!values || typeof values !== 'object' || Array.isArray(values)) {
            throw new TypeError('A batch storage write must be an object.');
        }
        const entries = Object.entries(values);
        if (!entries.length || entries.length > BATCH_WRITE_KEYS.size) {
            throw new TypeError('A batch storage write has an invalid number of keys.');
        }
        const payload = {};
        for (const [key, value] of entries) {
            if (!BATCH_WRITE_KEYS.has(key) || value === undefined) {
                throw new TypeError(`Batch storage key is not allowed: ${key}`);
            }
            payload[key] = cloneValue(value);
        }

        await ensureStorageReady();
        const markers = new Map();
        const revisions = new Map();
        for (const [key, value] of Object.entries(payload)) {
            const hadPrevious = valueCache.has(key);
            const previousValue = valueCache.get(key);
            revisions.set(key, bumpCacheRevision(key));
            valueCache.set(key, cloneValue(value));
            markers.set(key, addPendingLocalWrite(
                key,
                value,
                hadPrevious,
                previousValue,
            ));
        }
        try {
            await extensionApi.storage.local.set(payload);
        } catch (error) {
            for (const [key, marker] of markers) removePendingLocalWrite(key, marker);
            await Promise.all([...revisions].map(([key, revision]) => {
                const marker = markers.get(key);
                return reconcileFailedMutation(
                    key,
                    revision,
                    marker.fallbackHadValue,
                    marker.fallbackValue,
                );
            }));
            throw error;
        }
    }

    function setCachedValue(key, value) {
        return persistValue(key, value);
    }

    function getCachedValue(key, fallbackValue) {
        requireReadyCache();
        const normalisedKey = String(key);
        return valueCache.has(normalisedKey)
            ? cloneValue(valueCache.get(normalisedKey))
            : cloneValue(fallbackValue);
    }

    function removeCachedValue(key) {
        requireReadyCache();
        const normalisedKey = String(key);
        const hadPrevious = valueCache.has(normalisedKey);
        const previousValue = valueCache.get(normalisedKey);
        const revision = bumpCacheRevision(normalisedKey);
        valueCache.delete(normalisedKey);
        const marker = addPendingLocalWrite(
            normalisedKey,
            undefined,
            hadPrevious,
            previousValue,
        );
        return extensionApi.storage.local.remove(normalisedKey).catch(async (error) => {
            removePendingLocalWrite(normalisedKey, marker);
            await reconcileFailedMutation(
                normalisedKey,
                revision,
                marker.fallbackHadValue,
                marker.fallbackValue,
            );
            throw error;
        });
    }

    function getCachedEntriesByPrefix(prefix) {
        requireReadyCache();
        const normalisedPrefix = String(prefix);
        return [...valueCache.entries()]
            .filter(([key]) => key.startsWith(normalisedPrefix))
            .map(([key, value]) => [key, cloneValue(value)]);
    }

    async function getAuthoritativeEntriesByPrefix(prefix) {
        const normalisedPrefix = String(prefix);
        if (!SAVED_DRAFT_ACCOUNT_PREFIX_PATTERN.test(normalisedPrefix)) {
            throw new TypeError('An authoritative storage prefix is not allowed.');
        }
        await ensureStorageReady();
        const stored = await extensionApi.storage.local.get(null);
        if (!stored || typeof stored !== 'object' || Array.isArray(stored)) {
            throw new Error('Extension-private storage returned an invalid record.');
        }

        const authoritative = Object.entries(stored)
            .filter(([key]) => key.startsWith(normalisedPrefix));
        const authoritativeKeys = new Set(authoritative.map(([key]) => key));
        for (const key of [...valueCache.keys()]) {
            if (!key.startsWith(normalisedPrefix) || authoritativeKeys.has(key)) continue;
            bumpCacheRevision(key);
            valueCache.delete(key);
        }
        for (const [key, value] of authoritative) {
            if (!valueCache.has(key)
                || valueSignature(valueCache.get(key)) !== valueSignature(value)) {
                bumpCacheRevision(key);
                valueCache.set(key, cloneValue(value));
            }
        }
        return authoritative.map(([key, value]) => [key, cloneValue(value)]);
    }

    async function removeValues(keys) {
        await ensureStorageReady();
        const normalisedKeys = [...new Set(
            (Array.isArray(keys) ? keys : [keys])
                .map((key) => String(key))
                .filter(Boolean),
        )];
        if (!normalisedKeys.length) return;

        const previousValues = new Map();
        const markers = new Map();
        const revisions = new Map();
        for (const key of normalisedKeys) {
            const hadPrevious = valueCache.has(key);
            const previousValue = valueCache.get(key);
            if (hadPrevious) previousValues.set(key, previousValue);
            revisions.set(key, bumpCacheRevision(key));
            valueCache.delete(key);
            markers.set(key, addPendingLocalWrite(
                key,
                undefined,
                hadPrevious,
                previousValue,
            ));
        }
        try {
            await extensionApi.storage.local.remove(normalisedKeys);
        } catch (error) {
            for (const [key, marker] of markers) removePendingLocalWrite(key, marker);
            await Promise.all([...revisions].map(([key, revision]) => {
                const marker = markers.get(key);
                return reconcileFailedMutation(
                    key,
                    revision,
                    marker?.fallbackHadValue ?? previousValues.has(key),
                    marker?.fallbackValue ?? previousValues.get(key),
                );
            }));
            throw error;
        }
    }

    function addValueChangeListener(key, callback) {
        if (typeof callback !== 'function') {
            throw new TypeError('A storage change listener must be a function.');
        }
        const id = nextListenerId;
        nextListenerId += 1;
        listeners.set(id, {
            key: String(key),
            prefix: '',
            callback,
        });
        return id;
    }

    function addPrefixChangeListener(prefix, callback) {
        if (typeof callback !== 'function') {
            throw new TypeError('A storage change listener must be a function.');
        }
        const normalisedPrefix = String(prefix);
        if (!normalisedPrefix) {
            throw new TypeError('A storage change prefix must not be empty.');
        }
        const id = nextListenerId;
        nextListenerId += 1;
        listeners.set(id, {
            key: '',
            prefix: normalisedPrefix,
            callback,
        });
        return id;
    }

    function removeValueChangeListener(id) {
        return listeners.delete(Number(id));
    }

    function actionLockError(code) {
        const normalisedCode = code === 'contended' ? 'contended' : 'unavailable';
        const error = new Error(normalisedCode === 'contended'
            ? 'Another tab already holds this action lock.'
            : 'The private action-lock broker is unavailable.');
        error.code = normalisedCode;
        return error;
    }

    function normaliseActionLockTarget(kind, target) {
        if (kind === 'vote' && typeof target === 'string'
            && ACTION_LOCK_REACTION_KEY_PATTERN.test(target)) return target;
        if (kind === 'reply' && typeof target === 'string'
            && ACTION_LOCK_THREAD_ID_PATTERN.test(target)) return target;
        if (kind === 'block' && typeof target === 'string'
            && ACTION_LOCK_USER_ID_PATTERN.test(target)) return target;
        if (kind === 'draft' && typeof target === 'string'
            && ACTION_LOCK_DRAFT_ACCOUNT_ID_PATTERN.test(target)) return target;
        return '';
    }

    let nextActionLockRequest = 0;

    function releaseActionLock(kind, target, token) {
        if (!ACTION_LOCK_TOKEN_PATTERN.test(String(token || ''))) return;
        let port;
        try {
            port = extensionApi.runtime.connect({ name: ACTION_LOCK_PORT_NAME });
        } catch {
            // The durable broker lease expires automatically if release is unavailable.
            return;
        }

        let disconnected = false;
        let timeout = 0;
        const disconnect = () => {
            if (disconnected) return;
            disconnected = true;
            globalThis.clearTimeout(timeout);
            try {
                port.disconnect();
            } catch {
                // The broker may already have disconnected the release port.
            }
        };
        timeout = globalThis.setTimeout(disconnect, ACTION_LOCK_ACQUIRE_TIMEOUT_MS);
        port.onMessage.addListener((message) => {
            if (message?.type === 'released' && message.token === token) disconnect();
        });
        port.onDisconnect.addListener(() => {
            disconnected = true;
            globalThis.clearTimeout(timeout);
        });
        try {
            port.postMessage({
                type: 'release',
                kind,
                target,
                token,
            });
        } catch {
            disconnect();
        }
    }

    function acquireActionLock(kind, target) {
        const normalisedTarget = normaliseActionLockTarget(kind, target);
        if (!normalisedTarget || typeof extensionApi.runtime.connect !== 'function') {
            return Promise.reject(actionLockError('unavailable'));
        }

        let port;
        try {
            port = extensionApi.runtime.connect({ name: ACTION_LOCK_PORT_NAME });
        } catch {
            return Promise.reject(actionLockError('unavailable'));
        }

        nextActionLockRequest += 1;
        const requestId = `a${nextActionLockRequest.toString(36)}`;
        if (!ACTION_LOCK_REQUEST_PATTERN.test(requestId)) {
            try {
                port.disconnect();
            } catch {
                // The broker port may already be closed.
            }
            return Promise.reject(actionLockError('unavailable'));
        }

        return new Promise((resolve, reject) => {
            let settled = false;
            let activeToken = '';

            const disconnect = () => {
                try {
                    port.disconnect();
                } catch {
                    // The broker port may already be closed.
                }
            };

            const timeout = globalThis.setTimeout(() => {
                if (settled) return;
                settled = true;
                disconnect();
                reject(actionLockError('unavailable'));
            }, ACTION_LOCK_ACQUIRE_TIMEOUT_MS);

            port.onMessage.addListener((message) => {
                if (message?.type === 'expired'
                    && message.token === activeToken
                    && ACTION_LOCK_TOKEN_PATTERN.test(activeToken)) {
                    activeToken = '';
                    disconnect();
                    return;
                }
                if (settled || message?.requestId !== requestId) return;
                if (message.type === 'rejected') {
                    settled = true;
                    globalThis.clearTimeout(timeout);
                    disconnect();
                    reject(actionLockError(message.code));
                    return;
                }
                if (message.type !== 'acquired'
                    || message.kind !== kind
                    || message.target !== normalisedTarget
                    || typeof message.token !== 'string'
                    || !ACTION_LOCK_TOKEN_PATTERN.test(message.token)) {
                    settled = true;
                    globalThis.clearTimeout(timeout);
                    disconnect();
                    reject(actionLockError('unavailable'));
                    return;
                }

                settled = true;
                globalThis.clearTimeout(timeout);
                activeToken = message.token;
                resolve(Object.freeze({
                    release() {
                        if (!activeToken) return;
                        const token = activeToken;
                        activeToken = '';
                        disconnect();
                        releaseActionLock(kind, normalisedTarget, token);
                    },
                }));
            });

            port.onDisconnect.addListener(() => {
                if (settled) return;
                settled = true;
                globalThis.clearTimeout(timeout);
                reject(actionLockError('unavailable'));
            });

            try {
                port.postMessage({
                    type: 'acquire',
                    requestId,
                    kind,
                    target: normalisedTarget,
                });
            } catch {
                if (!settled) {
                    settled = true;
                    globalThis.clearTimeout(timeout);
                    disconnect();
                    reject(actionLockError('unavailable'));
                }
            }
        });
    }

    function randomReplyFieldToken() {
        const bytes = new Uint8Array(32);
        globalThis.crypto.getRandomValues(bytes);
        let binary = '';
        for (const byte of bytes) binary += String.fromCharCode(byte);
        return globalThis.btoa(binary)
            .replace(/\+/g, '-')
            .replace(/\//g, '_')
            .replace(/=+$/g, '');
    }

    function replyFieldUrl(token) {
        return `${extensionApi.runtime.getURL('ui/reply-field.html')}#${token}`;
    }

    function createReplyField({
        placeholder = '',
        label = 'Reply text',
        onDraftState = null,
        onPrefixRequest = null,
        onClick = null,
    } = {}) {
        if (typeof extensionApi.runtime.connect !== 'function'
            || typeof extensionApi.runtime.getURL !== 'function'
            || typeof globalThis.crypto?.getRandomValues !== 'function') {
            throw new Error('Private reply-field APIs are unavailable.');
        }

        const token = randomReplyFieldToken();
        const reconnectDelays = [0, 50, 250, 1_000, 3_000];
        const pendingTextRequests = new Map();
        const pendingRestoreRequests = new Map();
        let port = null;
        let reconnectTimer = 0;
        let reconnectAttempt = 0;
        let connectionGeneration = 0;
        let ready = false;
        let disposed = false;
        let hasDraft = false;
        let requestSequence = 0;
        let disabled = false;
        let focusRequested = false;
        let clearRequested = false;

        function post(message) {
            if (disposed) throw new Error('Private reply field is closed.');
            if (!port) throw new Error('Private reply field is disconnected.');
            port.postMessage({ ...message, token });
        }

        function configure() {
            post({
                type: 'configure',
                placeholder: String(placeholder).slice(0, 500),
                label: String(label || 'Reply text').slice(0, 200),
            });
            post({ type: 'set-disabled', disabled });
            if (clearRequested) {
                clearRequested = false;
                post({ type: 'clear' });
            }
            if (focusRequested) {
                focusRequested = false;
                post({ type: 'focus' });
            }
        }

        function rejectPending(error) {
            for (const pending of pendingTextRequests.values()) {
                globalThis.clearTimeout(pending.timeout);
                pending.reject(error);
            }
            pendingTextRequests.clear();
            for (const pending of pendingRestoreRequests.values()) {
                globalThis.clearTimeout(pending.timeout);
                pending.reject(error);
            }
            pendingRestoreRequests.clear();
        }

        function stopReconnectTimer() {
            if (!reconnectTimer) return;
            globalThis.clearTimeout(reconnectTimer);
            reconnectTimer = 0;
        }

        function scheduleReconnect() {
            if (disposed
                || reconnectTimer
                || reconnectAttempt >= reconnectDelays.length) return;
            const delay = reconnectDelays[reconnectAttempt];
            reconnectAttempt += 1;
            reconnectTimer = globalThis.setTimeout(() => {
                reconnectTimer = 0;
                connect();
            }, delay);
        }

        function handleMessage(message, activePort, generation) {
            if (disposed
                || port !== activePort
                || generation !== connectionGeneration
                || message?.token !== token) return;
            if (message.type === 'ready') {
                ready = true;
                reconnectAttempt = 0;
                try {
                    configure();
                } catch {
                    handleDisconnect(activePort, generation);
                }
                return;
            }
            if (message.type === 'closed') {
                disposed = true;
                ready = false;
                stopReconnectTimer();
                rejectPending(new Error('Private reply field was closed.'));
                try {
                    activePort.disconnect();
                } catch {
                    // The router may already have disconnected the Port.
                }
                if (port === activePort) port = null;
                return;
            }
            if (message.type === 'click') {
                if (ready && typeof onClick === 'function') onClick();
                return;
            }
            if (message.type === 'state' && typeof message.hasDraft === 'boolean') {
                hasDraft = message.hasDraft;
                if (typeof onDraftState === 'function') onDraftState(hasDraft);
                return;
            }
            if (message.type === 'text-response'
                && typeof message.requestId === 'string'
                && typeof message.text === 'string') {
                const pending = pendingTextRequests.get(message.requestId);
                if (!pending) return;
                pendingTextRequests.delete(message.requestId);
                globalThis.clearTimeout(pending.timeout);
                pending.resolve(message.text);
                return;
            }
            if (message.type === 'restore-response'
                && typeof message.requestId === 'string'
                && typeof message.restored === 'boolean'
                && message.reason === (message.restored ? '' : 'not-empty')) {
                const pending = pendingRestoreRequests.get(message.requestId);
                if (!pending) return;
                pendingRestoreRequests.delete(message.requestId);
                globalThis.clearTimeout(pending.timeout);
                pending.resolve(message.restored);
                return;
            }
            if (message.type === 'prefix-request'
                && typeof message.requestId === 'string'
                && typeof message.prefix === 'string'
                && typeof onPrefixRequest === 'function') {
                Promise.resolve(onPrefixRequest(message.prefix))
                    .then((value) => {
                        if (disposed || !ready || port !== activePort) return;
                        const names = (Array.isArray(value) ? value : [])
                            .filter((name) => typeof name === 'string')
                            .slice(0, 10)
                            .map((name) => name.slice(0, 100));
                        try {
                            post({
                                type: 'suggestions-response',
                                requestId: message.requestId,
                                names,
                            });
                        } catch {
                            // A reconnect will restore the field if the Port was lost.
                        }
                    })
                    .catch(() => {
                        if (!disposed && ready && port === activePort) {
                            try {
                                post({
                                    type: 'suggestions-response',
                                    requestId: message.requestId,
                                    names: [],
                                });
                            } catch {
                                // A reconnect will restore the field if the Port was lost.
                            }
                        }
                    });
                return;
            }
            if (message.type === 'child-disconnected') {
                ready = false;
                rejectPending(new Error('Private reply field disconnected.'));
            }
        }

        function handleDisconnect(activePort, generation) {
            if (disposed
                || port !== activePort
                || generation !== connectionGeneration) return;
            port = null;
            ready = false;
            rejectPending(new Error('Private reply field disconnected.'));
            try {
                activePort.disconnect();
            } catch {
                // The failed Port may already be disconnected.
            }
            scheduleReconnect();
        }

        function connect() {
            if (disposed || port) return;
            const generation = ++connectionGeneration;
            let nextPort;
            try {
                nextPort = extensionApi.runtime.connect({
                    name: 'hltv-sp:reply-field',
                });
            } catch {
                scheduleReconnect();
                return;
            }
            port = nextPort;
            nextPort.onMessage.addListener((message) => {
                handleMessage(message, nextPort, generation);
            });
            nextPort.onDisconnect.addListener(() => {
                handleDisconnect(nextPort, generation);
            });
            try {
                post({ type: 'register', role: 'parent' });
            } catch {
                handleDisconnect(nextPort, generation);
            }
        }

        connect();

        return Object.freeze({
            url: replyFieldUrl(token),
            get hasDraft() {
                return hasDraft;
            },
            get ready() {
                return ready;
            },
            focus() {
                if (ready) post({ type: 'focus' });
                else focusRequested = true;
            },
            clear() {
                hasDraft = false;
                if (typeof onDraftState === 'function') onDraftState(false);
                if (ready) post({ type: 'clear' });
                else clearRequested = true;
            },
            setDisabled(value) {
                disabled = Boolean(value);
                if (ready) post({ type: 'set-disabled', disabled });
            },
            requestText() {
                if (!ready) {
                    return Promise.reject(new Error('Private reply field is still loading.'));
                }
                const requestId = `t${++requestSequence}`;
                return new Promise((resolve, reject) => {
                    const timeout = globalThis.setTimeout(() => {
                        pendingTextRequests.delete(requestId);
                        reject(new Error('Private reply field did not respond.'));
                    }, 3000);
                    pendingTextRequests.set(requestId, { resolve, reject, timeout });
                    try {
                        post({ type: 'request-text', requestId });
                    } catch (error) {
                        globalThis.clearTimeout(timeout);
                        pendingTextRequests.delete(requestId);
                        reject(error);
                    }
                });
            },
            restoreText(value) {
                const text = String(value ?? '');
                if (text.length > 50_000) {
                    return Promise.reject(new Error('Saved reply exceeds the private field limit.'));
                }
                if (!ready) {
                    return Promise.reject(new Error('Private reply field is still loading.'));
                }
                const requestId = `r${++requestSequence}`;
                return new Promise((resolve, reject) => {
                    const timeout = globalThis.setTimeout(() => {
                        pendingRestoreRequests.delete(requestId);
                        reject(new Error('Private reply field did not respond.'));
                    }, 3000);
                    pendingRestoreRequests.set(requestId, { resolve, reject, timeout });
                    try {
                        post({ type: 'restore-text', requestId, text });
                    } catch (error) {
                        globalThis.clearTimeout(timeout);
                        pendingRestoreRequests.delete(requestId);
                        reject(error);
                    }
                });
            },
            dispose() {
                if (disposed) return;
                if (port) {
                    try {
                        post({ type: 'close' });
                    } catch {
                        // The router may already have disconnected the Port.
                    }
                }
                disposed = true;
                ready = false;
                stopReconnectTimer();
                rejectPending(new Error('Private reply field was closed.'));
                try {
                    port?.disconnect();
                } catch {
                    // The router may already have disconnected the port.
                }
                port = null;
            },
        });
    }

    extensionApi.storage.onChanged.addListener((changes, areaName) => {
        if (areaName !== 'local' || !changes || typeof changes !== 'object') return;
        for (const [key, change] of Object.entries(changes)) {
            if (cacheReady) {
                bumpCacheRevision(key);
                if (change && hasOwn(change, 'newValue')) {
                    valueCache.set(key, cloneValue(change.newValue));
                } else {
                    valueCache.delete(key);
                }
            } else {
                changesBeforeCacheReady.set(key, change && hasOwn(change, 'newValue')
                    ? { deleted: false, value: change.newValue }
                    : { deleted: true });
            }
            const remote = !consumePendingLocalWrite(key, change?.newValue);
            for (const listener of listeners.values()) {
                if (listener.key !== key && !(
                    listener.prefix && key.startsWith(listener.prefix)
                )) continue;
                try {
                    listener.callback(
                        key,
                        cloneValue(change?.oldValue),
                        cloneValue(change?.newValue),
                        remote,
                    );
                } catch (error) {
                    console.warn(
                        '[HLTV Enhancements] Storage listener failed.',
                        error,
                    );
                }
            }
        }
    });

    const gmApi = Object.freeze({
        getValue,
        setValue,
        addValueChangeListener,
        removeValueChangeListener,
    });
    const privateStorageApi = Object.freeze({
        ready: ensureStorageReady,
        getCachedValue,
        setCachedValue,
        setValues,
        removeCachedValue,
        getCachedEntriesByPrefix,
        getAuthoritativeEntriesByPrefix,
        removeValues,
        addPrefixChangeListener,
        removeChangeListener: removeValueChangeListener,
    });
    const replyFieldsApi = typeof extensionApi.runtime.connect === 'function'
        && typeof extensionApi.runtime.getURL === 'function'
        ? Object.freeze({ create: createReplyField })
        : null;
    const actionLocksApi = Object.freeze({
        acquire: acquireActionLock,
    });
    const extensionInfo = Object.freeze({
        environment: 'firefox-extension',
        version: '2.3',
        storage: privateStorageApi,
        actionLocks: actionLocksApi,
        replyFields: replyFieldsApi,
    });

    Object.defineProperties(globalThis, {
        GM: {
            value: gmApi,
            configurable: false,
            enumerable: false,
            writable: false,
        },
        GM_getValue: {
            value: getValue,
            configurable: false,
            enumerable: false,
            writable: false,
        },
        GM_setValue: {
            value: setValue,
            configurable: false,
            enumerable: false,
            writable: false,
        },
        GM_addValueChangeListener: {
            value: addValueChangeListener,
            configurable: false,
            enumerable: false,
            writable: false,
        },
        GM_removeValueChangeListener: {
            value: removeValueChangeListener,
            configurable: false,
            enumerable: false,
            writable: false,
        },
        HLTV_SP_EXTENSION: {
            value: extensionInfo,
            configurable: false,
            enumerable: false,
            writable: false,
        },
    });
})();
