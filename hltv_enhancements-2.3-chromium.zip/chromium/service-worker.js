// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Plennhar

'use strict';

// All listeners are registered synchronously during service-worker evaluation.
importScripts(
    '../background/prediction-parser.js',
    'offscreen-parser.js',
    '../background/screenshot-loader.js',
    '../background/match-prediction-fetch.js',
    '../background/reply-field-router.js',
    '../background/action-lock-router.js',
);
