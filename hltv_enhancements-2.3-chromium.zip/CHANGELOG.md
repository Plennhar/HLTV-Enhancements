# HLTV Enhancements changelog

## Version 2.3 - 2026-09-06

- Added **Last comment** navigation with a temporary comment highlight to thread and notification previews.
- Fixed missing author flags on later comments in long previews.
- Fixed match predictions failing to load with HTTP 403 errors.
- Rebuilt **HLTV stats** predictions around current players, monthly form,
  map performance, and exact veto/series math, with clear source coverage and
  at most three additional fetch attempts per match page.
- Reject contradictory official-map and veto evidence instead of displaying
  a prediction based on inconsistent inputs.
- Fixed monthly player sources being rejected by unused native date editors
  and Firefox content-script URL-parameter iteration.
- Added an expandable version notice above the HLTV header. Closing it is
  remembered for that version.
- Retired the standalone userscript distribution; development continues on
  the Firefox add-on.

## Version 2.2.1 - 2026-08-16

### [ FIXES ]

- Fixed affected Firefox profiles returning the extension to **Permission
  needed to read and change data** after reloading HLTV.org by adding a one-time
  **Always allow on HLTV.org** recovery action to the toolbar settings.
- Added **Report a bug or submit feedback** to the settings opened from the
  extension icon.

## Version 2.2 - 2026-08-16

### [ FORUMS ]

- Added saved drafts for topics and replies, with a draft manager in settings.
- Added optional original-poster highlighting.
- Improved thread previews with embedded images, flags, flairs, independent
  reply text, clearer reply trees, and better notification and locked-thread
  handling.
- Fixed draft-button placement and several preview state and voting issues.

### [ MATCHES ]

- Redesigned match predictions with clearer results, explanations, exact-score
  chances, and up to 50 saved recent predictions.
- Made **Page stats only** the default and replaced **Market-assisted** with the
  simpler odds-only **Market-estimated** mode.
- Added more configurable statistics to match-lineup player cards.
- Fixed prediction behavior around match start times and live countdowns.

### [ STATISTICS ]

- Added a remembered 100-500/**ALL** row selector to player match history.
- Recalibrated Overperformance Score from the active filtered data.
- Improved comparison graphs, Consistency, baseline deltas, KPR/DPR headers,
  player navigation, and match filters.

### [ SETTINGS AND GENERAL ]

- Added opt-out settings for drafts, original-poster highlighting, and extended
  match-history loading.
- Added screenshots to feature help and a **Report a bug or submit feedback**
  link.
- Fixed the header search and settings-cog layout.
- Improved request reliability and reduced redundant site permissions.
- Removed the moderation-risk and writing-assistance feature.

## Version 2.1 - 2026-08-08

### [ GENERAL ]

- Kept Save and Cancel visible while scrolling through settings.
- Added **Try it on HLTV** links to help panels where a feature has a useful
  place to try it. Stats links open with a trailing three-month date filter.
- Simplified settings text, improved spacing, and made every extension button
  show a pointing-hand cursor.

### [ FORUMS ]

- Added thread previews to forum notifications, including a highlight for the
  relevant reply.
- Preserved HLTV's reply nesting and indentation inside thread previews.
- Added an immediate **Blocked** indicator after blocking a user.
- Moved additional match teams into HLTV's native Team list and extended the
  native **Search team...** field beyond five selections.
- Prevented thread-preview scrolling from carrying over to the page.
- Kept previews open when right-clicking inside them.
- Fixed successful thread replies getting stuck on **Posted. Redirecting...**.

### [ MATCHES ]

- Added deterministic pre-match predictions with **Market-assisted** and
  **Page stats only** modes.
- Positioned predictions directly below HLTV's Analytics/Pick a winner block.
- Fixed the sticky match bar covering HLTV navigation menus.

### [ STATS ]

- Added **Overperformance Score (OS)** to team FTU pages. It compares T-side
  results with an expectation based on CT opening-duel success and can act as
  a rough IGL/team-system signal, not a direct measure of IGL impact.
- Fixed OS values remaining blank on live filtered FTU pages.
- Made the Map matrix available from every player-stats page that has the
  player navigation bar.
- Kept the column chooser open when columns are removed.
- Improved narrow-layout spacing and fixed several calculated-column colors
  and borders.

### [ WRITING ASSISTANCE ]

- Split likely House Rules concerns from softer writing and link checks.
- Rebuilt local moderation analysis around objective checks, licensed public
  word lists, a compact statistical classifier, and clause-level context
  rules, with no remote service or feedback upload.
- Added clearer status names, actionable revision guidance, and click-open
  details.
- Improved external-link checks and added the evaluation corpus to regression
  testing.

## Version 2.0 - 2026-08-03

### [ GENERAL ]

- Added a new borderless logo showing a magic wand enhancing the HLTV mark.
- Redesigned all extension interfaces to better match HLTV's colors and style.
- Reorganized settings into clearer groups.
- Enabled all main features by default except diagnostic logging.
- Kept Off-Topic and Counter-Strike as the only default recent-activity sources.

### [ FORUMS ]

- Added separate switches for custom recent-activity fetching and custom colors.
- Added local moderation-risk hints while writing posts and replies.
- Expanded reply-box placement support to forum, News, and match pages.
- Improved thread previews, read tracking, vote feedback, and local reactions.
- Made the native minus sign bolder without bolding its count.
- Improved settings help and reduced background page observation.

### [ MATCHES ]

- Added an optional sticky match header for desktop match pages.
- Added player form overlays using HLTV's Past 3 months data.
- Added Rating, KPR, DPR, KAST, ADR, multi-kill rating, and Round Swing choices.
- Made HLTV's native match-filter star and dropdown control extension filtering too.
- Disabling HLTV's match filter now immediately restores extension-hidden matches.

### [ STATS TABLES ]

- Added column visibility and ordering controls to player stats tables.
- Added saved multi-column sorting.  Shift-click adds a secondary sort.
- Added automatic column sizing and horizontal scrolling when needed.
- Added CSV export for the currently displayed table.
- Added selectable estimated KPR, DPR, and kills-per-map columns.
- Added selectable exact KPR and DPR columns to player match history.
- Moved WAR into the column selector and made it visible by default.
- Added detailed calculation help for estimated and calculated columns.
- Added selectable Baseline delta columns for date-period comparisons.
- Added full map names for known map abbreviations.

### [ PLAYER STATS ]

- Added match-history graphs for the latest 100 loaded maps.
- Added an orange five-map average line to match-history graphs.
- Added match details while graph points are hovered or focused.
- Added a sortable map-by-stat matrix that follows the active player filters.
- Changed matrix DPR colors so lower values are green and higher values are red.
- Added a 0-100 consistency score based on all maps matching the active filters.
- Added separate date-period comparisons for ranking tables and player pages.
- Improved baseline loading when switching comparison metrics.

### [ PLAYER COMPARISON ]

- Added absolute and percentage differences with better-value highlighting.
- Added a lead summary, player swapping, filter syncing, and CSV export.
- Added complete-history graphs for one or two comparison players.
- Added raw, trailing 10-map average, and trailing daily average graph modes.
- Added adjustable daily windows from 1 to 365 days, defaulting to 30.
- Added optional graph points and per-player linear trend lines.
- Added immediate match details while points are hovered or focused.
- Made graph details disappear as soon as the point is no longer active.
- Changed the second player graph color to blue.
- Fixed daily graph gaps so they appear only when the full window has no data.

### [ DATA & RELIABILITY ]

- Added local settings export and import.
- Added local user-data export and import.
- Added optional redacted diagnostic logging, disabled by default.
- Improved fetch retry handling for player histories and WAR.
- Added clearer progress, partial-result, and error states.
- Improved handling of large histories, replaced tables, and changed HLTV markup.
- Added stricter request validation and response-size limits.

### [ INSTALLATION ]

- Version 2.0 uses the permanent Firefox ID `hltv-enhancements@plennhar`.
- Version 1.0 used a temporary ID, so Firefox treats 2.0 as a separate add-on.
- Disable or remove version 1.0 before installing version 2.0.
- Version 1.0 settings cannot transfer automatically to the new extension ID.

## Version 1.0 - 2026-07-29

- Initial Firefox release of HLTV Enhancements.
