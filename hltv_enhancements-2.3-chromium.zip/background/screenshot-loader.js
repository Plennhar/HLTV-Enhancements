// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Plennhar

(() => {
    'use strict';

    const REQUEST_TYPE = 'hltv-sp:get-screenshot';
    const MAX_SCREENSHOT_BYTES = 2 * 1024 * 1024;
    const SCREENSHOTS = new Map([
        ['add_a_map-by-stat_matrix_to_player_pages.png', 'assets/screenshots/add_a_map-by-stat_matrix_to_player_pages.png'],
        ['add_more_teams_to_the_match_filter.png', 'assets/screenshots/add_more_teams_to_the_match_filter.png'],
        ['bug_comparison_page_graph_color.png', 'assets/screenshots/bug_comparison_page_graph_color.png'],
        ['change-upvoted-comments-to-green.png', 'assets/screenshots/change-upvoted-comments-to-green.png'],
        ['compare_player-page_statistics_with_another_date_period.png', 'assets/screenshots/compare_player-page_statistics_with_another_date_period.png'],
        ['compare_stats-table_data_with_another_date_period.png', 'assets/screenshots/compare_stats-table_data_with_another_date_period.png'],
        ['enable_local_user_tags.png', 'assets/screenshots/enable_local_user_tags.png'],
        ['enable_multi-column_sorting.png', 'assets/screenshots/enable_multi-column_sorting.png'],
        ['enable_right-lcikc_username_actions.png', 'assets/screenshots/enable_right-lcikc_username_actions.png'],
        ['enable_stats-table_column_controls.png', 'assets/screenshots/enable_stats-table_column_controls.png'],
        ['enhance_player_comparison_pages.png', 'assets/screenshots/enhance_player_comparison_pages.png'],
        ['kpr-match-history.png', 'assets/screenshots/kpr-match-history.png'],
        ['kpr-ranking-table.png', 'assets/screenshots/kpr-ranking-table.png'],
        ['local-downvote-button.png', 'assets/screenshots/local-downvote-button.png'],
        ['local-user-reaction-counter.png', 'assets/screenshots/local-user-reaction-counter.png'],
        ['move_post_new_topic_to_the_top_of_the_sidebar.png', 'assets/screenshots/move_post_new_topic_to_the_top_of_the_sidebar.png'],
        ['reply-composer-below-original-post.png', 'assets/screenshots/reply-composer-below-original-post.png'],
        ['show_a_player_consistency_score.png', 'assets/screenshots/show_a_player_consistency_score.png'],
        ['show_a_sticky_match_header_while_scrolling.png', 'assets/screenshots/show_a_sticky_match_header_while_scrolling.png'],
        ['show_full_map_names_on_player_match_history_pages.png', 'assets/screenshots/show_full_map_names_on_player_match_history_pages.png'],
        ['show_match_result_predictions.png', 'assets/screenshots/show_match_result_predictions.png'],
        ['show_recent-form_statistics_on_match_lineups.png', 'assets/screenshots/show_recent-form_statistics_on_match_lineups.png'],
        ['show_relative_post_ages_in_threads_and_previews.png', 'assets/screenshots/show_relative_post_ages_in_threads_and_previews.png'],
        ['show_selectable_player_match-history_trends.png', 'assets/screenshots/show_selectable_player_match-history_trends.png'],
        ['show_team_overperformance_score.png', 'assets/screenshots/show_team_overperformance_score.png'],
        ['thread-preview.png', 'assets/screenshots/thread-preview.png'],
        ['thread-read-status.png', 'assets/screenshots/thread-read-status.png'],
        ['win-adjusted-ratings.png', 'assets/screenshots/win-adjusted-ratings.png'],
    ]);
    const PNG_SIGNATURE = Object.freeze([137, 80, 78, 71, 13, 10, 26, 10]);

    function isAllowedSender(sender) {
        if (sender?.id !== browser.runtime.id) return false;
        if (sender?.frameId !== 0) return false;
        try {
            return new URL(sender.url).origin === 'https://www.hltv.org';
        } catch {
            return false;
        }
    }

    function isPng(bytes) {
        return bytes.length >= PNG_SIGNATURE.length
            && PNG_SIGNATURE.every((value, index) => bytes[index] === value);
    }

    function bytesToBase64(bytes) {
        const chunks = [];
        const chunkSize = 0x8000;
        for (let offset = 0; offset < bytes.length; offset += chunkSize) {
            chunks.push(String.fromCharCode(...bytes.subarray(offset, offset + chunkSize)));
        }
        return btoa(chunks.join(''));
    }

    async function loadScreenshot(file) {
        const path = SCREENSHOTS.get(file);
        if (!path) throw new Error('Unknown screenshot.');
        const response = await fetch(browser.runtime.getURL(path), {
            cache: 'force-cache',
            credentials: 'omit',
        });
        if (!response.ok) throw new Error(`Screenshot request failed (${response.status}).`);
        const contentType = String(response.headers.get('content-type') || '')
            .split(';', 1)[0]
            .trim()
            .toLowerCase();
        if (contentType && contentType !== 'image/png') {
            throw new Error('Unexpected screenshot media type.');
        }
        const bytes = new Uint8Array(await response.arrayBuffer());
        if (!bytes.length || bytes.length > MAX_SCREENSHOT_BYTES || !isPng(bytes)) {
            throw new Error('Invalid screenshot data.');
        }
        return `data:image/png;base64,${bytesToBase64(bytes)}`;
    }

    browser.runtime.onMessage.addListener((message, sender) => {
        if (message?.type !== REQUEST_TYPE || !isAllowedSender(sender)) return undefined;
        const file = typeof message.file === 'string' ? message.file : '';
        if (!SCREENSHOTS.has(file)) {
            return Promise.resolve({ ok: false, error: 'Unknown screenshot.' });
        }
        return loadScreenshot(file)
            .then((dataUrl) => ({ ok: true, dataUrl }))
            .catch(() => ({ ok: false, error: 'Screenshot could not be loaded.' }));
    });
})();
