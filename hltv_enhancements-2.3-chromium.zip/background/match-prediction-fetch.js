// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Plennhar

(() => {
    'use strict';

    const CONFIG = Object.freeze({
        sourceRequestType: 'hltv-sp:get-prediction-source',
        sourceFetchType: 'hltv-sp:fetch-prediction-source',
        sourceCancelType: 'hltv-sp:cancel-prediction-source',
        sourceReleaseType: 'hltv-sp:release-prediction-source',
        origin: 'https://www.hltv.org',
        matchPath: /^\/matches\/(\d{1,20})(?:\/|$)/,
        analyticsPath: /^\/betting\/analytics\/(\d{1,20})(?:\/|$)/,
        teamNameMaxLength: 80,
        initialRequestDelayMs: 500,
        retryDelaysMs: Object.freeze([]),
        timeoutMs: 12_000,
        maximumResponseBytes: 4 * 1024 * 1024,
        minimumCacheMs: 60_000,
        maximumCacheMs: 30 * 60_000,
        timestampToleranceMs: 60_000,
        maximumCacheEntries: 8,
        maximumPendingRequests: 8,
        maximumRequesters: 8,
        maximumErrorCharacters: 180,
    });

    const cache = new Map();
    const pending = new Map();
    const parser = globalThis.HLTV_PREDICTION_PARSER;
    const {
        safeUrl, boundedName, matchesSourceFilters,
        validateTeamPlayerDocument, validateAnalyticsDocument, parseInertAnalyticsHtml,
    } = parser;
    // Fixed identifiers only: never derive diagnostic fields from HTML, URLs or exception messages.
    const DIAGNOSTIC_CODES = new Set([
        'ANALYTICS_STAGE_RESPONSE_URL', 'ANALYTICS_STAGE_RESPONSE_MIME',
        'ANALYTICS_STAGE_RESPONSE_LENGTH', 'ANALYTICS_STAGE_RESPONSE_BODY', 'ANALYTICS_STAGE_RESPONSE_STREAM',
        'ANALYTICS_STAGE_SANITIZER_UNAVAILABLE', 'ANALYTICS_STAGE_SANITIZE', 'ANALYTICS_STAGE_PARSE',
        'ANALYTICS_STAGE_TEAM_TIME_FILTER', 'ANALYTICS_STAGE_TEAM_VERSION_FILTER',
        'ANALYTICS_STAGE_TEAM_FORM_FILTER', 'ANALYTICS_STAGE_TEAM_EXTRA_FILTER',
        'ANALYTICS_STAGE_TEAM_IDENTITY', 'ANALYTICS_STAGE_TEAM_TABLE', 'ANALYTICS_STAGE_TEAM_TITLE',
        'ANALYTICS_STAGE_ANALYTICS_DOCUMENT',
    ]);
    let attemptSequence = 0;

    function scheduledStartError() {
        return analyticsError('ANALYTICS_STARTED', 'Analytics request stopped at the scheduled match start.');
    }

    function ensureBeforeScheduledStart(request, now = Date.now()) {
        if (!Number.isSafeInteger(request?.timestamp) || now >= request.timestamp) {
            throw scheduledStartError();
        }
        return request.timestamp - now;
    }

    function senderMatchId(sender) {
        if (sender?.id !== browser.runtime.id || sender?.frameId !== 0) return '';
        const url = safeUrl(sender?.url);
        if (url?.origin !== CONFIG.origin || url.protocol !== 'https:') return '';
        return CONFIG.matchPath.exec(url.pathname)?.[1] || '';
    }

    function normaliseRequest(message, sender) {
        if (message?.type !== CONFIG.sourceRequestType) return null;
        const requestedSource = normaliseSource(message.source);
        if (!requestedSource) return null;
        message = {
            ...message, matchId: requestedSource.matchId, href: requestedSource.href,
            teamNames: requestedSource.teams.map((team) => team.name), timestamp: requestedSource.timestamp,
        };
        if (!Number.isInteger(sender?.tab?.id) || sender.tab.id < 0
            || !validId(message.documentId) || !validId(message.requestId)) return null;
        const matchId = typeof message.matchId === 'string' ? message.matchId : '';
        if (!/^\d{1,20}$/.test(matchId) || senderMatchId(sender) !== matchId) return null;
        const url = safeUrl(message.href);
        if (url?.origin !== CONFIG.origin || url.protocol !== 'https:'
            || url.username || url.password) return null;
        const teamNames = Array.isArray(message.teamNames)
            ? message.teamNames.map(boundedName)
            : [];
        if (teamNames.length !== 2 || teamNames.some((name) => !name)) return null;
        const timestamp = Number(message.timestamp);
        if (!Number.isSafeInteger(timestamp) || timestamp <= Date.now()) return null;
        const requestedCacheMs = Number(message.cacheTtlMs);
        const cacheTtlMs = Math.min(
            CONFIG.maximumCacheMs,
            Math.max(
                CONFIG.minimumCacheMs,
                Number.isFinite(requestedCacheMs)
                    ? Math.trunc(requestedCacheMs)
                    : CONFIG.minimumCacheMs,
            ),
        );
        return Object.freeze({
            matchId,
            requestedSource,
            source: {
                tabId: sender.tab.id, documentId: message.documentId,
                requestId: message.requestId, href: url.href, released: false, onRelease: null,
            },
            url,
            teamNames,
            timestamp,
            cacheTtlMs,
            key: `v23:${requestedSource.kind}:${url.href}:${matchId}:${requestedSource.teams.map((team) => team.id).join(':')}:${timestamp}`,
        });
    }

    function normaliseSource(source) {
        if (!source || typeof source !== 'object' || !/^\d{1,20}$/.test(source.matchId || '')
            || !Number.isSafeInteger(source.timestamp) || source.timestamp <= Date.now()
            || !Array.isArray(source.teams) || source.teams.length !== 2
            || source.teams.some((team) => !/^\d{1,20}$/.test(team?.id || '') || !boundedName(team.name))
            || source.teams[0].id === source.teams[1].id) return null;
        const url = safeUrl(source.href);
        if (url?.origin !== CONFIG.origin || url.username || url.password || url.hash) return null;
        if (source.kind === 'analytics') {
            if (source.sourceKey !== 'analytics' || source.teamId !== '' || source.window !== null
                || url.search || CONFIG.analyticsPath.exec(url.pathname)?.[1] !== source.matchId) return null;
        } else if (source.kind === 'team-players') {
            const index = /^team-players-([01])$/.exec(source.sourceKey || '')?.[1];
            if (index === undefined || source.teams[Number(index)].id !== source.teamId
                || /^\/stats\/teams\/players\/(\d{1,20})\/[a-zA-Z0-9_-]+\/?$/.exec(url.pathname)?.[1] !== source.teamId
                || !validWindow(source.window) || !matchesSourceFilters(url, source)) return null;
        } else return null;
        return source;
    }

    function validWindow(window) {
        if (!window || !/^\d{4}-\d{2}-\d{2}$/.test(window.startDate || '')
            || !/^\d{4}-\d{2}-\d{2}$/.test(window.endDate || '')) return false;
        const end = new Date(`${window.endDate}T00:00:00Z`);
        if (!Number.isFinite(end.getTime()) || end.toISOString().slice(0, 10) !== window.endDate
            || end.getTime() > Date.now()) return false;
        const start = new Date(Date.UTC(end.getUTCFullYear(), end.getUTCMonth() - 1, 1));
        const last = new Date(Date.UTC(start.getUTCFullYear(), start.getUTCMonth() + 1, 0)).getUTCDate();
        start.setUTCDate(Math.min(end.getUTCDate(), last));
        return window.startDate === start.toISOString().slice(0, 10);
    }

    function pruneCache(now = Date.now()) {
        for (const [key, entry] of cache) {
            if (entry.expiresAt <= now) cache.delete(key);
        }
        while (cache.size > CONFIG.maximumCacheEntries) {
            cache.delete(cache.keys().next().value);
        }
    }

    function delay(milliseconds) {
        return new Promise((resolve) => {
            globalThis.setTimeout(resolve, milliseconds);
        });
    }

    async function delayBeforeScheduledStart(milliseconds, request) {
        ensureBeforeScheduledStart(request);
        await delay(milliseconds);
        ensureBeforeScheduledStart(request);
    }

    function validId(value) {
        return typeof value === 'string' && /^[A-Za-z0-9_-]{1,80}$/.test(value);
    }

    function diagnosticFields(value) {
        return DIAGNOSTIC_CODES.has(value) ? { diagnosticCode: value } : {};
    }

    function analyticsError(code, message, diagnosticCode) {
        return Object.assign(new Error(message), { code }, diagnosticFields(diagnosticCode));
    }

    function cancelAttempt(source, message) {
        try {
            void browser.tabs.sendMessage(source.tabId, {
                type: CONFIG.sourceCancelType,
                documentId: message.documentId,
                requestId: message.requestId,
                attemptId: message.attemptId,
                source: message.source,
            }, { frameId: 0 }).catch(() => {});
        } catch {
            // The document or extension context may already be gone.
        }
    }

    async function fetchFromSource(request, source) {
        const remaining = ensureBeforeScheduledStart(request);
        const deadline = Date.now() + Math.min(CONFIG.timeoutMs, remaining);
        const message = {
            type: CONFIG.sourceFetchType,
            documentId: source.documentId,
            requestId: source.requestId,
            attemptId: `a${++attemptSequence}`,
            href: source.href,
            matchId: request.matchId,
            timestamp: request.timestamp,
            deadline,
            source: request.requestedSource,
        };
        let timer;
        try {
            const response = await new Promise((resolve, reject) => {
                source.onRelease = () => {
                    cancelAttempt(source, message);
                    reject(analyticsError('ANALYTICS_CONTEXT_UNAVAILABLE', 'The requesting match page is no longer available.'));
                };
                if (source.released) { source.onRelease(); return; }
                timer = globalThis.setTimeout(() => {
                    cancelAttempt(source, message);
                    reject(Date.now() >= request.timestamp ? scheduledStartError()
                        : analyticsError('ANALYTICS_TIMEOUT', 'Analytics request timed out.'));
                }, Math.max(0, deadline - Date.now()));
                Promise.resolve().then(() => browser.tabs.sendMessage(
                    source.tabId, message, { frameId: 0 },
                )).then(resolve, () => reject(analyticsError(
                    'ANALYTICS_CONTEXT_UNAVAILABLE', 'The requesting match page is no longer available.',
                )));
            });
            ensureBeforeScheduledStart(request);
            if (Date.now() >= deadline) {
                cancelAttempt(source, message);
                throw analyticsError('ANALYTICS_TIMEOUT', 'Analytics request timed out.');
            }
            if (!response || response.documentId !== message.documentId
                || response.requestId !== message.requestId || response.attemptId !== message.attemptId) {
                throw analyticsError('ANALYTICS_CONTEXT_UNAVAILABLE', 'The requesting match page is no longer available.');
            }
            if (!response.ok) {
                const code = /^(?:ANALYTICS_(?:HTTP_[1-5]\d\d|NETWORK|TIMEOUT|CONTEXT_UNAVAILABLE|STARTED|INVALID_RESPONSE|BUDGET_EXHAUSTED))$/.test(response.code || '')
                    ? response.code : 'ANALYTICS_INVALID_RESPONSE';
                const error = analyticsError(code, typeof response.error === 'string'
                    ? response.error.slice(0, CONFIG.maximumErrorCharacters) : 'Analytics request failed.', response.diagnosticCode);
                error.attemptStarted = response.attemptStarted !== false;
                throw error;
            }
            const finalUrl = safeUrl(response.url);
            if (finalUrl?.origin !== CONFIG.origin || finalUrl.username || finalUrl.password
                || finalUrl.href !== request.requestedSource.href) {
                throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Analytics request was redirected away from this match.', 'ANALYTICS_STAGE_RESPONSE_URL');
            }
            if (response.contentType !== '' && response.contentType !== 'text/html'
                && response.contentType !== 'application/xhtml+xml') {
                throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Analytics response is not HTML.', 'ANALYTICS_STAGE_RESPONSE_MIME');
            }
            if (typeof response.html !== 'string' || !response.html
                || response.html.length > CONFIG.maximumResponseBytes
                || !Number.isSafeInteger(response.byteLength) || response.byteLength <= 0
                || response.byteLength > CONFIG.maximumResponseBytes) {
                throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Analytics response is empty or exceeds its size limit.', 'ANALYTICS_STAGE_RESPONSE_BODY');
            }
            const parsing = globalThis.HLTV_PREDICTION_OFFSCREEN || parser;
            const parsed = await parsing.parseAndValidate(response.html, {
                requestedSource: request.requestedSource,
                matchId: request.matchId, teamNames: request.teamNames, timestamp: request.timestamp,
            });
            const fetchedAt = Date.now();
            ensureBeforeScheduledStart(request, fetchedAt);
            const entry = Object.freeze({
                html: parsed.html, fetchedAt, expiresAt: fetchedAt + request.cacheTtlMs,
            });
            cache.set(request.key, entry);
            pruneCache(fetchedAt);
            return entry;
        } finally {
            globalThis.clearTimeout(timer);
            source.onRelease = null;
        }
    }

    async function fetchAnalyticsOnce(request, job) {
        for (const [key, source] of job.sources) {
            try {
                return await fetchFromSource(request, source);
            } catch (error) {
                if (error.code !== 'ANALYTICS_CONTEXT_UNAVAILABLE') throw error;
                if (job.sources.get(key) === source) job.sources.delete(key);
                // A waiting document can serve its own original source once. Its
                // document-owned ledger remains authoritative, including after failover.
            }
        }
        throw analyticsError('ANALYTICS_CONTEXT_UNAVAILABLE', 'The requesting match page is no longer available.');
    }

    async function fetchAnalytics(request, job) {
        await delayBeforeScheduledStart(CONFIG.initialRequestDelayMs, request);
        ensureBeforeScheduledStart(request);
        return fetchAnalyticsOnce(request, job);
    }

    function loadAnalytics(request) {
        const now = Date.now();
        if (now >= request.timestamp) return Promise.reject(scheduledStartError());
        pruneCache(now);
        const cached = cache.get(request.key);
        if (cached?.expiresAt > now) return Promise.resolve({ ...cached, fromCache: true });
        const sourceKey = `${request.source.tabId}:${request.source.documentId}`;
        const existing = pending.get(request.key);
        if (existing) {
            if (existing.sources.has(sourceKey) || existing.sources.size < CONFIG.maximumRequesters) {
                existing.sources.set(sourceKey, request.source);
            }
            return existing.promise;
        }
        if (pending.size >= CONFIG.maximumPendingRequests) {
            return Promise.reject(new Error('Too many analytics requests are active.'));
        }
        const job = { sources: new Map([[sourceKey, request.source]]), promise: null };
        job.promise = fetchAnalytics(request, job).finally(() => pending.delete(request.key));
        pending.set(request.key, job);
        return job.promise;
    }

    browser.runtime.onMessage.addListener((message, sender) => {
        if (message?.type === CONFIG.sourceReleaseType) {
            const request = normaliseRequest({ ...message, type: CONFIG.sourceRequestType }, sender);
            if (!request) return Promise.resolve({ ok: false });
            const job = pending.get(request.key);
            const sourceKey = `${request.source.tabId}:${request.source.documentId}`;
            const source = job?.sources.get(sourceKey);
            if (source?.requestId === request.source.requestId) {
                source.released = true;
                source.onRelease?.();
                job.sources.delete(sourceKey);
            }
            return Promise.resolve({ ok: true });
        }
        if (message?.type !== CONFIG.sourceRequestType) return undefined;
        const request = normaliseRequest(message, sender);
        if (!request) return Promise.resolve({ ok: false, code: 'ANALYTICS_INVALID_REQUEST', error: 'Invalid analytics request.' });
        return loadAnalytics(request)
            .then((entry) => {
                ensureBeforeScheduledStart(request);
                return {
                    ok: true,
                    html: entry.html,
                    fetchedAt: entry.fetchedAt,
                    fromCache: entry.fromCache === true,
                };
            })
            .catch((error) => ({
                ok: false,
                code: error?.code || 'ANALYTICS_INVALID_RESPONSE',
                ...diagnosticFields(error?.diagnosticCode),
                error: String(error instanceof Error ? error.message : 'Analytics request failed.')
                    .replace(/\s+/g, ' ')
                    .trim()
                    .slice(0, CONFIG.maximumErrorCharacters),
            }));
    });

    Object.defineProperty(globalThis, 'HLTV_MATCH_PREDICTION_FETCH_TESTING', {
        configurable: true,
        enumerable: false,
        value: Object.freeze({
            config: CONFIG,
            normaliseRequest,
            normaliseSource,
            validateTeamPlayerDocument,
            ensureBeforeScheduledStart,
            validateAnalyticsDocument,
            parseInertAnalyticsHtml,
            cacheSize: () => cache.size,
        }),
    });
})();
