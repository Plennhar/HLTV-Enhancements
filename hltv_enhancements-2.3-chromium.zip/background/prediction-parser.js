// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Plennhar

(() => {
    'use strict';

    const CONFIG = Object.freeze({
        origin: 'https://www.hltv.org',
        matchPath: /^\/matches\/(\d{1,20})(?:\/|$)/,
        teamNameMaxLength: 80,
        timestampToleranceMs: 60_000,
        sanitizerRemoveElements: Object.freeze([
            'applet', 'audio', 'base', 'embed', 'frame', 'frameset', 'iframe',
            'img', 'link', 'meta', 'noscript', 'object', 'picture', 'portal',
            'script', 'source', 'style', 'track', 'video',
            { name: 'svg', namespace: 'http://www.w3.org/2000/svg' },
            { name: 'math', namespace: 'http://www.w3.org/1998/Math/MathML' },
        ]),
        sanitizerRemoveAttributes: Object.freeze([
            'background', 'data', 'imagesizes', 'imagesrcset', 'manifest',
            'ping', 'poster', 'src', 'srcset', 'style',
        ]),
    });

    let inertSanitizer = null;

    function safeUrl(value, base = CONFIG.origin) {
        try {
            return new URL(String(value || ''), base);
        } catch {
            return null;
        }
    }

    function boundedName(value) {
        const text = String(value ?? '').normalize('NFKC').replace(/\s+/g, ' ').trim();
        return text && text.length <= CONFIG.teamNameMaxLength ? text : '';
    }

    function normalisedName(value) {
        return boundedName(value).toLocaleLowerCase();
    }

    function matchesSourceFilters(url, source) {
        const keys = [...url.searchParams.keys()].sort();
        return keys.join(',') === 'csVersion,endDate,startDate'
            && url.searchParams.get('csVersion') === 'CS2'
            && url.searchParams.get('startDate') === source.window.startDate
            && url.searchParams.get('endDate') === source.window.endDate;
    }

    function validateTeamPlayerDocument(document, source) {
        const expected = safeUrl(source.href);
        const selectors = [
            ['.stats-sub-navigation-simple-filter-time option[selected]', 'ANALYTICS_STAGE_TEAM_TIME_FILTER'],
            ['.stats-sub-navigation-simple-filter-version option[selected]', 'ANALYTICS_STAGE_TEAM_VERSION_FILTER'],
        ];
        for (const [selector, diagnosticCode] of selectors) {
            const selected = document.querySelector(selector);
            const url = safeUrl(selected?.getAttribute('data-link'));
            if (!selected || url?.origin !== CONFIG.origin || url.username || url.password || url.hash
                || url.pathname !== expected.pathname || !matchesSourceFilters(url, source)) {
                throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Team-player filters do not match the request.', diagnosticCode);
            }
        }
        for (const [name, expectedValue] of Object.entries({
            startDate: source.window.startDate, endDate: source.window.endDate, csVersion: 'CS2',
        })) {
            for (const control of document.querySelectorAll(`input[name="${name}"], select[name="${name}"]`)) {
                // Native blank date editors are unapplied; selected links above prove the active window.
                if (control.matches('input.filter-date') && ['startDate', 'endDate'].includes(name)
                    && control.type === 'text' && control.value === '' && control.form === null) continue;
                if (control.value !== expectedValue) throw analyticsError(
                    'ANALYTICS_INVALID_RESPONSE', 'Team-player form filters do not match the request.', 'ANALYTICS_STAGE_TEAM_FORM_FILTER',
                );
            }
        }
        for (const selected of document.querySelectorAll('select[class*="stats-sub-navigation-simple-filter-"] option[selected]')) {
            const url = safeUrl(selected.getAttribute('data-link'));
            if (!url || url.origin !== CONFIG.origin || url.pathname !== expected.pathname
                || url.username || url.password || url.hash || !matchesSourceFilters(url, source)) {
                throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Team-player data has additional or inconsistent filters.', 'ANALYTICS_STAGE_TEAM_EXTRA_FILTER');
            }
        }
        const selectedTab = document.querySelector('a.stats-top-menu-item-link.selected');
        const selectedUrl = safeUrl(selectedTab?.getAttribute('href'));
        if (!selectedTab || selectedUrl?.origin !== CONFIG.origin || selectedUrl.pathname !== expected.pathname
            || !matchesSourceFilters(selectedUrl, source)) {
            throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Team-player identity does not match the request.', 'ANALYTICS_STAGE_TEAM_IDENTITY');
        }
        const tables = [...document.querySelectorAll('table.stats-table')];
        const table = tables.find((candidate) => {
            const headers = [...candidate.querySelectorAll('thead th')].map((cell) => boundedName(cell.textContent));
            return headers.some((header) => /^player$/i.test(header))
                && headers.some((header) => /^maps$/i.test(header))
                && headers.some((header) => /^rounds$/i.test(header))
                && headers.some((header) => /^rating\s*3\.0$/i.test(header));
        });
        if (!table || /\b(?:access denied|captcha|log[ -]?in|error)\b/i.test(document.title || '')) {
            throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Team-player data table is missing.',
                !table ? 'ANALYTICS_STAGE_TEAM_TABLE' : 'ANALYTICS_STAGE_TEAM_TITLE');
        }
    }

    function validateAnalyticsDocument(document, request) {
        const header = document.querySelector('.analytics-header');
        if (!header) throw new Error('Analytics header is missing.');

        const backLink = [...header.querySelectorAll('a[href]')].find((anchor) => {
            const url = safeUrl(anchor.getAttribute('href'));
            return url?.origin === CONFIG.origin
                && CONFIG.matchPath.exec(url.pathname)?.[1] === request.matchId;
        });
        if (!backLink) throw new Error('Analytics back-link does not match this match.');

        const analyticsNames = [...header.querySelectorAll('.team .team-name .name')]
            .map((element) => boundedName(element.textContent));
        const fallbackNames = [...header.querySelectorAll('.team .team-name')]
            .map((element) => boundedName(element.textContent));
        const names = (analyticsNames.length === 2 ? analyticsNames : fallbackNames)
            .slice(0, 2)
            .map(normalisedName);
        if (names.length !== 2
            || names[0] !== normalisedName(request.teamNames[0])
            || names[1] !== normalisedName(request.teamNames[1])) {
            throw new Error('Analytics teams do not match this match.');
        }

        const timestamps = [...header.querySelectorAll('[data-unix]')]
            .map((element) => Number(element.getAttribute('data-unix')))
            .filter(Number.isSafeInteger);
        if (!timestamps.some((value) => (
            Math.abs(value - request.timestamp) <= CONFIG.timestampToleranceMs
        ))) {
            throw new Error('Analytics timestamp does not match this match.');
        }

        if (!document.querySelector('#bookmakers, #maps, .analytics-player-container, #form')) {
            throw new Error('Analytics data sections are missing.');
        }
        const title = String(document.title || '').toLocaleLowerCase();
        if (/\b(?:access denied|captcha|log[ -]?in|error)\b/.test(title)) {
            throw new Error('Analytics response is not a data page.');
        }
    }

    function getInertSanitizer() {
        if (inertSanitizer) return inertSanitizer;
        if (typeof globalThis.Sanitizer !== 'function') {
            throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Secure analytics parsing is unavailable.', 'ANALYTICS_STAGE_SANITIZER_UNAVAILABLE');
        }
        inertSanitizer = new globalThis.Sanitizer({
            removeElements: CONFIG.sanitizerRemoveElements,
            removeAttributes: CONFIG.sanitizerRemoveAttributes,
            comments: false,
        });
        return inertSanitizer;
    }

    function parseInertAnalyticsHtml(value) {
        const template = globalThis.document?.createElement?.('template');
        if (!template || typeof template.setHTML !== 'function') {
            throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Secure analytics parsing is unavailable.', 'ANALYTICS_STAGE_SANITIZER_UNAVAILABLE');
        }
        try {
            template.setHTML(String(value ?? ''), { sanitizer: getInertSanitizer() });
        } catch (error) {
            throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Analytics response could not be sanitized.',
                error?.diagnosticCode === 'ANALYTICS_STAGE_SANITIZER_UNAVAILABLE'
                    ? error.diagnosticCode : 'ANALYTICS_STAGE_SANITIZE');
        }
        const html = template.innerHTML;
        let document;
        try { document = new DOMParser().parseFromString(html, 'text/html'); } catch {
            throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Analytics response could not be parsed.', 'ANALYTICS_STAGE_PARSE');
        }
        if (!document?.documentElement || document.querySelector('parsererror')) {
            throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Analytics response could not be parsed.', 'ANALYTICS_STAGE_PARSE');
        }
        return { document, html };
    }

    function analyticsError(code, message, diagnosticCode) {
        return Object.assign(new Error(message), { code }, diagnosticCode ? { diagnosticCode } : {});
    }

    function parseAndValidate(value, request) {
        const parsed = parseInertAnalyticsHtml(value);
        if (request.requestedSource?.kind === 'team-players') {
            validateTeamPlayerDocument(parsed.document, request.requestedSource);
        } else {
            try { validateAnalyticsDocument(parsed.document, request); } catch {
                throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Analytics document validation failed.', 'ANALYTICS_STAGE_ANALYTICS_DOCUMENT');
            }
        }
        return { html: parsed.html };
    }

    Object.defineProperty(globalThis, 'HLTV_PREDICTION_PARSER', {
        value: Object.freeze({
            safeUrl, boundedName, matchesSourceFilters,
            parseInertAnalyticsHtml, validateTeamPlayerDocument, validateAnalyticsDocument, parseAndValidate,
        }),
        configurable: false, writable: false,
    });
})();
