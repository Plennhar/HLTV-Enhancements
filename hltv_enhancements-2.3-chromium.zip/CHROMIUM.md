# Chromium desktop edition

HLTV Enhancements uses one shared feature implementation for Firefox and
Chromium. The Chromium build targets current desktop Chrome, Microsoft Edge,
Brave, Opera (including Opera GX), Vivaldi, and Chromium on Windows, macOS,
and Linux. It requires a Chromium engine version of **148 or newer**; vendor
version numbers can differ. Android and iOS are outside this edition's scope.

These browsers share extension APIs, but a target is not a claim that every
browser/OS combination has been tested. See the validation section below.

## Build

With Node.js 24.x, npm 11.x, and `unzip` on PATH (on Windows, build
in WSL or an environment providing `unzip`; the resulting ZIP installs
natively in Windows browsers):

```sh
npm ci --ignore-scripts --no-audit --no-fund
npm run build:chromium
```

Outputs:

- `chromium-dist/hltv_enhancements-2.3-chromium.zip`: distributable ZIP with
  `manifest.json` at its root.
- `chromium-dist/hltv_enhancements-2.3-chromium.zip.sha256`: archive checksum.
- `chromium-dist/hltv-enhancements/`: ready-to-load unpacked extension.

The build derives its name, version, content scripts, icons, and feature UI
from the Firefox source. It replaces the Firefox background declaration with
a Chromium service worker and omits Mozilla-specific manifest settings. The
Firefox build and permanent Gecko ID remain available through their existing
commands. No store account, signing key, or publishing service is needed.

## Install without a store

1. Extract the Chromium ZIP to a permanent folder. If building locally, use
   the ready-to-load folder listed above.
2. Open the browser's extensions manager:

   | Browser | Extensions manager |
   | --- | --- |
   | Chrome / Chromium | `chrome://extensions` |
   | Microsoft Edge | `edge://extensions` |
   | Brave | `brave://extensions` |
   | Opera / Opera GX | `opera://extensions` |
   | Vivaldi | `vivaldi://extensions` |

3. Enable **Developer mode**.
4. Choose **Load unpacked** (Opera may label it **Load extension**) and select
   the folder containing `manifest.json`.
5. Reload existing HLTV.org tabs, then open the toolbar settings.

Keep that folder in place. The browser reads the extension from it. Browser
or organization policies can disable Developer mode or unpacked extensions.
Chromium may display a Developer mode warning. A downloaded ZIP or CRX does
not provide universal one-click installation in Chrome.

## Update without losing settings

Export local data from the extension settings before updating. Extract the
new release over the **same folder**, replacing its files, then click **Reload**
on the existing extension card and reload HLTV tabs. For a local build, rerun
`npm run build:chromium` and reload the existing extension card.

Keep the existing extension installed and keep the folder path stable. Moving
the folder or removing/reinstalling the extension can change its identity or
delete its local storage. Unpacked copies do not receive automatic store
updates. Each browser/profile has its own local settings and data. A later
store installation may have a different identity; use export/import to migrate.

## Permissions and privacy

The Chromium edition requests `storage` and `offscreen`. The latter lets an
extension-owned hidden document sanitize and validate prediction HTML using
the same parser as Firefox; service workers cannot use DOM APIs. That document
does not fetch prediction pages. Prediction requests remain in the requesting
HLTV match tab with the existing attempt, size, origin, and pre-match limits.

Site access remains exactly `https://www.hltv.org/*` through static content
scripts. There are no additional host permissions, telemetry, or developer
servers. If the browser withholds site access, use its extension details to
allow access on HLTV.org, then reload the page. The Firefox-specific popup
permission-repair panel is hidden in Chromium.

The packaged `PRIVACY.md` describes the shared feature data inventory.

## Distribution choices

The owner excludes Chrome Web Store publication. Direct ZIP distribution is
the supported account-free route. No store submission or account registration
is performed by the build or CI.

The owner's limit for another store is **no fee and no personal contact
information beyond an email address**. On 2026-10-18:

- [Microsoft Edge registration](https://learn.microsoft.com/en-us/microsoft-edge/extensions/publish/create-dev-account)
  documents no registration fee, but requests country/region and contact
  information. Its [published contact-form example](https://learn.microsoft.com/en-us/microsoft-edge/extensions/publish/create-dev-account-images/contact-info.png)
  includes required name, phone, and postal-address fields, so the documented
  process exceeds the owner's email-only limit. This is documentation evidence,
  not a completed registration or a claim about every individual-account flow.
- [Opera publication guidance](https://help.opera.com/en/extensions/publishing-guidelines/)
  requires a signed-in account and review. The public guide does not establish
  all current account/contact/verification requirements, so eligibility under
  the owner's limit is unconfirmed.

Store availability is browser-specific. Publishing in Edge or Opera does not
give Chrome users a universal install/update channel. Store enrollment and
publication require a separate owner decision after the actual requirements
are verified.

## Validation

Run `npm run ci` for the complete shared suite, Firefox lint, Chromium package
checks, Chromium runtime detection, and worker/offscreen parser regression
tests. Package checks verify ZIP integrity, inventory, byte parity, and the
unchanged Firefox manifest.

On 2026-10-18, `npm run ci` passed **640/640 tests**, with zero errors,
notices, or warnings from canonical Firefox lint. Chromium ZIP and unpacked
files passed integrity, inventory, manifest, and byte-parity checks.

Native browser evidence on 2026-10-18: **Chrome 154.0.8037.92 on Linux**,
loaded from the unpacked package into an isolated profile. Checks passed for
popup version and save/reopen, content-script startup, private in-page settings,
thread previews, packaged screenshots, private reply-frame restore/readback,
native sanitizer resource removal and mismatched-team rejection. After forcibly
stopping the service worker through DevTools, the reply field reconnected with
its unsent text intact and the single offscreen document was reused. No page
errors occurred. HLTV pages and preview responses were synthetic intercepted
fixtures; no real account was used and no posts or votes were sent.

| Browser | Current evidence |
| --- | --- |
| Chrome | Linux smoke checks above; Windows/macOS not individually checked |
| Edge, Brave, Opera/GX, Vivaldi, Chromium | Shared-engine compatibility targets; individual browser/OS checks pending |

Before declaring a browser/OS combination fully verified, load the unpacked
package there and check popup save/reopen, site access, thread previews,
private reply fields and reconnect, local draft save/restore, screenshots,
prediction HTML validation, and recovery after the worker becomes idle.
Use synthetic pages for posting/voting checks to avoid sending real actions.

Platform background documentation:
[service workers](https://developer.chrome.com/docs/extensions/develop/migrate/to-service-workers),
[native browser namespace and Promise messaging from Chromium 148](https://developer.chrome.com/docs/extensions/develop/concepts/browser-namespace),
[offscreen documents](https://developer.chrome.com/docs/extensions/reference/api/offscreen),
[distribution restrictions](https://developer.chrome.com/docs/extensions/how-to/distribute).
