# Third-Party Notices

HLTV Enhancements is distributed under the GNU General Public License,
version 3 or, at the recipient's option, any later version. See `LICENSE`.

Extension developer and maintainer: Plennhar  
Copyright (C) 2026 Plennhar

## Integrated GPL-licensed userscripts

This extension contains modified and integrated portions of the following
userscripts:

### HLTV: Win-adjusted player ratings

- Original author: Plennhar
- Referenced original version: 1.0, dated 2026-05-03
- Original source:
  <https://greasyfork.org/en/scripts/576401-hltv-win-adjusted-player-ratings>
- Original license: GNU General Public License v3.0 or later

### HLTV: Add KPR estimate to player stats pages

- Original author: Plennhar
- Referenced original version: 1.1, dated 2026-01-24
- Original source:
  <https://greasyfork.org/en/scripts/563839-hltv-add-kpr-estimate-to-player-stats-pages>
- Original license: GNU General Public License v3.0 or later

The versions included here are not unmodified copies. Changes made during
integration include adaptation to the combined extension lifecycle, settings
and help UI, Firefox extension-private storage, same-origin request validation,
bounded caches and parsing, error handling, retry and rate controls, styling,
sorting, and compatibility with other features in this extension. The
integrated code remains available under GPL-3.0-or-later.

These features were first modified and integrated into this project on
2026-07-28. That date records the original integration work rather than the
current package version.

No third-party executable JavaScript library is bundled with this extension.

## HLTV logo incorporated in the extension icon

- Work: HLTV logo 2017
- Author identified by the source: Better Collective
- Source: <https://commons.wikimedia.org/wiki/File:HLTV_logo_2017.svg>
- Copyright status stated by the source: public domain because the logo is
  considered too simple to qualify for copyright protection

The logo geometry is incorporated into an original borderless dark-square
composition with a classic magic wand, contact burst, and separate sparkle.
Wikimedia Commons warns that the logo can still be protected as a trademark.
Its copyright classification does not grant trademark rights or permission,
and rights in the HLTV name and marks remain with their respective owners.

The icon is used only to identify the site this independent extension works
with. HLTV Enhancements is unofficial and is not affiliated with, sponsored
by, endorsed by, or approved by HLTV.org or its owners.

## Documentation screenshots

Files under `assets/screenshots/` are documentation images supplied for this
extension. They show HLTV.org pages with the extension active and can contain
HLTV interface elements, flags, team or event marks, statistics, player
likenesses, usernames, and forum text. Rights in third-party material remain
with the respective owners. The screenshots are included only to explain
extension features and do not imply endorsement.
