// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Plennhar

(() => {
    'use strict';

    const TYPE = 'hltv-sp:parse-prediction-html';
    const MAXIMUM_CHARACTERS = 4 * 1024 * 1024;
    const workerUrl = browser.runtime.getURL('chromium/service-worker.js');

    browser.runtime.onMessage.addListener((message, sender) => {
        // Neither an HLTV content script nor another extension page may invoke this sink.
        if (message?.type !== TYPE || sender?.id !== browser.runtime.id
            || sender?.tab || sender?.url !== workerUrl) return undefined;
        const requestId = message.requestId;
        const failure = (diagnosticCode) => ({
            requestId, ok: false, code: 'ANALYTICS_INVALID_RESPONSE',
            ...(typeof diagnosticCode === 'string' && /^ANALYTICS_STAGE_[A-Z_]+$/.test(diagnosticCode)
                ? { diagnosticCode } : {}),
            error: 'Prediction response validation failed.',
        });
        if (typeof requestId !== 'string' || !/^[A-Za-z0-9_-]{1,80}$/.test(requestId)
            || typeof message.html !== 'string' || !message.html || message.html.length > MAXIMUM_CHARACTERS
            || !message.request || typeof message.request !== 'object'
            || !/^\d{1,20}$/.test(message.request.matchId || '')
            || !Number.isSafeInteger(message.request.timestamp)
            || !Array.isArray(message.request.teamNames) || message.request.teamNames.length !== 2
            || message.request.teamNames.some((name) => typeof name !== 'string' || !name || name.length > 80)
            || !['analytics', 'team-players', 'team-history'].includes(message.request.requestedSource?.kind)) {
            return Promise.resolve(failure());
        }
        try {
            const parsed = globalThis.HLTV_PREDICTION_PARSER.parseAndValidate(message.html, message.request);
            return Promise.resolve({ requestId, ok: true, html: parsed.html });
        } catch (error) {
            return Promise.resolve(failure(error?.diagnosticCode));
        }
    });
})();
