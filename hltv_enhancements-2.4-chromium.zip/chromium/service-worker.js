// Generated from the canonical background scripts.
'use strict';
importScripts(...["offscreen-parser.js","../background/runtime-gate.js","../background/screenshot-loader.js","../content/ranking-snapshots.js","../background/ranking-cache.js","../background/match-prediction-fetch.js","../background/reply-field-router.js","../background/action-lock-router.js"]);
