// Generated at build time from background/match-prediction-fetch.js.
(() => {
'use strict';
    const CONFIG = Object.freeze({
        sourceRequestType: 'hltv-sp:get-prediction-source',
        sourceFetchType: 'hltv-sp:fetch-prediction-source',
        sourceCancelType: 'hltv-sp:cancel-prediction-source',
        sourceReleaseType: 'hltv-sp:release-prediction-source',
        origin: 'https://www.hltv.org',
        matchPath: /^\/matches\/(\d{1,20})(?:\/|$)/,
        analyticsPath: /^\/betting\/analytics\/(\d{1,20})(?:\/|$)/,
        teamNameMaxLength: 80,
        initialRequestDelayMs: 500,
        retryDelaysMs: Object.freeze([]),
        timeoutMs: 12_000,
        maximumResponseBytes: 4 * 1024 * 1024,
        minimumCacheMs: 60_000,
        maximumCacheMs: 30 * 60_000,
        timestampToleranceMs: 60_000,
        maximumCacheEntries: 8,
        maximumPendingRequests: 8,
        maximumRequesters: 8,
        maximumErrorCharacters: 180,
        sanitizerRemoveElements: Object.freeze([
            'applet', 'audio', 'base', 'embed', 'frame', 'frameset', 'iframe',
            'img', 'link', 'meta', 'noscript', 'object', 'picture', 'portal',
            'script', 'source', 'style', 'track', 'video',
            { name: 'svg', namespace: 'http://www.w3.org/2000/svg' },
            { name: 'math', namespace: 'http://www.w3.org/1998/Math/MathML' },
        ]),
        sanitizerRemoveAttributes: Object.freeze([
            'background', 'data', 'imagesizes', 'imagesrcset', 'manifest',
            'ping', 'poster', 'src', 'srcset', 'style',
        ]),
    });


    const DIAGNOSTIC_CODES = new Set([
        'ANALYTICS_STAGE_RESPONSE_URL', 'ANALYTICS_STAGE_RESPONSE_MIME',
        'ANALYTICS_STAGE_RESPONSE_LENGTH', 'ANALYTICS_STAGE_RESPONSE_BODY', 'ANALYTICS_STAGE_RESPONSE_STREAM',
        'ANALYTICS_STAGE_SANITIZER_UNAVAILABLE', 'ANALYTICS_STAGE_SANITIZE', 'ANALYTICS_STAGE_PARSE',
        'ANALYTICS_STAGE_TEAM_TIME_FILTER', 'ANALYTICS_STAGE_TEAM_VERSION_FILTER',
        'ANALYTICS_STAGE_TEAM_FORM_FILTER', 'ANALYTICS_STAGE_TEAM_EXTRA_FILTER',
        'ANALYTICS_STAGE_TEAM_IDENTITY', 'ANALYTICS_STAGE_TEAM_TABLE', 'ANALYTICS_STAGE_TEAM_TITLE',
        'ANALYTICS_STAGE_ANALYTICS_DOCUMENT',
    ]);
    let inertSanitizer = null;

    function safeUrl(value, base = CONFIG.origin) {
        try {
            return new URL(String(value || ''), base);
        } catch {
            return null;
        }
    }

    function boundedName(value) {
        const text = String(value ?? '').normalize('NFKC').replace(/\s+/g, ' ').trim();
        return text && text.length <= CONFIG.teamNameMaxLength ? text : '';
    }

    function normalisedName(value) {
        return boundedName(value).toLocaleLowerCase();
    }


    function matchesSourceFilters(url, source) {
        const keys = [...url.searchParams.keys()].sort();
        return keys.join(',') === 'csVersion,endDate,startDate'
            && url.searchParams.get('csVersion') === 'CS2'
            && url.searchParams.get('startDate') === source.window.startDate
            && url.searchParams.get('endDate') === source.window.endDate;
    }

    function validateTeamPlayerDocument(document, source) {
        const expected = safeUrl(source.href);
        const selectors = [
            ['.stats-sub-navigation-simple-filter-time option[selected]', 'ANALYTICS_STAGE_TEAM_TIME_FILTER'],
            ['.stats-sub-navigation-simple-filter-version option[selected]', 'ANALYTICS_STAGE_TEAM_VERSION_FILTER'],
        ];
        for (const [selector, diagnosticCode] of selectors) {
            const selected = document.querySelector(selector);
            const url = safeUrl(selected?.getAttribute('data-link'));
            if (!selected || url?.origin !== CONFIG.origin || url.username || url.password || url.hash
                || url.pathname !== expected.pathname || !matchesSourceFilters(url, source)) {
                throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Team-player filters do not match the request.', diagnosticCode);
            }
        }
        for (const [name, expectedValue] of Object.entries({
            startDate: source.window.startDate, endDate: source.window.endDate, csVersion: 'CS2',
        })) {
            for (const control of document.querySelectorAll(`input[name="${name}"], select[name="${name}"]`)) {
                // Native blank date editors are unapplied; selected links above prove the active window.
                if (control.matches('input.filter-date') && ['startDate', 'endDate'].includes(name)
                    && control.type === 'text' && control.value === '' && control.form === null) continue;
                if (control.value !== expectedValue) throw analyticsError(
                    'ANALYTICS_INVALID_RESPONSE', 'Team-player form filters do not match the request.', 'ANALYTICS_STAGE_TEAM_FORM_FILTER',
                );
            }
        }
        for (const selected of document.querySelectorAll('select[class*="stats-sub-navigation-simple-filter-"] option[selected]')) {
            const url = safeUrl(selected.getAttribute('data-link'));
            if (!url || url.origin !== CONFIG.origin || url.pathname !== expected.pathname
                || url.username || url.password || url.hash || !matchesSourceFilters(url, source)) {
                throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Team-player data has additional or inconsistent filters.', 'ANALYTICS_STAGE_TEAM_EXTRA_FILTER');
            }
        }
        const selectedTab = document.querySelector('a.stats-top-menu-item-link.selected');
        const selectedUrl = safeUrl(selectedTab?.getAttribute('href'));
        if (!selectedTab || selectedUrl?.origin !== CONFIG.origin || selectedUrl.pathname !== expected.pathname
            || !matchesSourceFilters(selectedUrl, source)) {
            throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Team-player identity does not match the request.', 'ANALYTICS_STAGE_TEAM_IDENTITY');
        }
        const tables = [...document.querySelectorAll('table.stats-table')];
        const table = tables.find((candidate) => {
            const headers = [...candidate.querySelectorAll('thead th')].map((cell) => boundedName(cell.textContent));
            return headers.some((header) => /^player$/i.test(header))
                && headers.some((header) => /^maps$/i.test(header))
                && headers.some((header) => /^rounds$/i.test(header))
                && headers.some((header) => /^rating\s*3\.0$/i.test(header));
        });
        if (!table || /\b(?:access denied|captcha|log[ -]?in|error)\b/i.test(document.title || '')) {
            throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Team-player data table is missing.',
                !table ? 'ANALYTICS_STAGE_TEAM_TABLE' : 'ANALYTICS_STAGE_TEAM_TITLE');
        }
    }

    function validateTeamHistoryDocument(document, source) {
        const expected = safeUrl(source.href);
        const timeOptions = [...document.querySelectorAll('.stats-sub-navigation-simple-filter-time option[selected]')];
        const timeOption = timeOptions.length === 1 ? timeOptions[0] : null;
        // Native custom-date selection has no link. Only this exact option can
        // instead use one active text date editor per bound as its date proof.
        const nativeCustomTime = timeOption && !timeOption.hasAttribute('data-link')
            && timeOption.parentElement?.matches('select.stats-sub-navigation-simple-filter-time')
            && ['startDate', 'endDate'].every((name) => {
                const controls = [...document.querySelectorAll(`input[name="${name}"], select[name="${name}"]`)];
                return controls.length === 1 && controls[0].matches('input.filter-date')
                    && controls[0].type === 'text' && !controls[0].disabled && controls[0].value === source.window[name];
            });
        const matchesHistorySource = (url) => url?.origin === CONFIG.origin && url.pathname === expected.pathname
            && !url.username && !url.password && !url.hash && matchesSourceFilters(url, source);
        if (!timeOption || (!nativeCustomTime && !matchesHistorySource(safeUrl(timeOption.getAttribute('data-link'))))) {
            throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Team history time filters do not match.', 'ANALYTICS_STAGE_TEAM_IDENTITY');
        }
        for (const selector of ['.stats-sub-navigation-simple-filter-version option[selected]', 'a.stats-top-menu-item-link.selected']) {
            const nodes = [...document.querySelectorAll(selector)];
            const node = nodes.length === 1 ? nodes[0] : null;
            if (!node || !matchesHistorySource(safeUrl(node.getAttribute(node.matches('a') ? 'href' : 'data-link')))
                || (!node.matches('a') && boundedName(node.textContent) !== 'CS2')) {
                throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Team history identity or filters do not match.', 'ANALYTICS_STAGE_TEAM_IDENTITY');
            }
        }
        for (const selected of document.querySelectorAll('select[class*="stats-sub-navigation-simple-filter-"] option[selected]')) {
            if (nativeCustomTime && selected === timeOption) continue;
            if (!matchesHistorySource(safeUrl(selected.getAttribute('data-link')))) {
                throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Team history has extra filters.', 'ANALYTICS_STAGE_TEAM_EXTRA_FILTER');
            }
        }
        for (const [name, expectedValue] of Object.entries({ ...source.window, csVersion: 'CS2' })) {
            for (const control of document.querySelectorAll(`input[name="${name}"], select[name="${name}"]`)) {
                // Linked time controls retain their existing unapplied-editor rule.
                if (!nativeCustomTime && control.matches('input.filter-date') && ['startDate', 'endDate'].includes(name)
                    && control.type === 'text' && control.value === '' && control.form === null) continue;
                if (control.value !== expectedValue) throw analyticsError('ANALYTICS_INVALID_RESPONSE',
                    'Team history form filters do not match.', 'ANALYTICS_STAGE_TEAM_FORM_FILTER');
            }
        }
        if (!document.querySelector('table.stats-table')
            || /\b(?:access denied|captcha|log[ -]?in|error)\b/i.test(document.title || '')
            || document.querySelector('.pagination-next:not(.disabled), a[rel="next"]')) {
            throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Complete team history is unavailable.', 'ANALYTICS_STAGE_TEAM_TABLE');
        }
    }

    function validateAnalyticsDocument(document, request) {
        const header = document.querySelector('.analytics-header');
        if (!header) throw new Error('Analytics header is missing.');

        const backLink = [...header.querySelectorAll('a[href]')].find((anchor) => {
            const url = safeUrl(anchor.getAttribute('href'));
            return url?.origin === CONFIG.origin
                && CONFIG.matchPath.exec(url.pathname)?.[1] === request.matchId;
        });
        if (!backLink) throw new Error('Analytics back-link does not match this match.');

        const analyticsNames = [...header.querySelectorAll('.team .team-name .name')]
            .map((element) => boundedName(element.textContent));
        const fallbackNames = [...header.querySelectorAll('.team .team-name')]
            .map((element) => boundedName(element.textContent));
        const names = (analyticsNames.length === 2 ? analyticsNames : fallbackNames)
            .slice(0, 2)
            .map(normalisedName);
        if (names.length !== 2
            || names[0] !== normalisedName(request.teamNames[0])
            || names[1] !== normalisedName(request.teamNames[1])) {
            throw new Error('Analytics teams do not match this match.');
        }

        const timestamps = [...header.querySelectorAll('[data-unix]')]
            .map((element) => Number(element.getAttribute('data-unix')))
            .filter(Number.isSafeInteger);
        if (!timestamps.some((value) => (
            Math.abs(value - request.timestamp) <= CONFIG.timestampToleranceMs
        ))) {
            throw new Error('Analytics timestamp does not match this match.');
        }

        if (!document.querySelector('#bookmakers, #maps, .analytics-player-container, #form')) {
            throw new Error('Analytics data sections are missing.');
        }
        const title = String(document.title || '').toLocaleLowerCase();
        if (/\b(?:access denied|captcha|log[ -]?in|error)\b/.test(title)) {
            throw new Error('Analytics response is not a data page.');
        }
    }

    function getInertSanitizer() {
        if (inertSanitizer) return inertSanitizer;
        if (typeof globalThis.Sanitizer !== 'function') {
            throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Secure analytics parsing is unavailable.', 'ANALYTICS_STAGE_SANITIZER_UNAVAILABLE');
        }
        inertSanitizer = new globalThis.Sanitizer({
            removeElements: CONFIG.sanitizerRemoveElements,
            removeAttributes: CONFIG.sanitizerRemoveAttributes,
            comments: false,
        });
        return inertSanitizer;
    }

    function parseInertAnalyticsHtml(value) {
        const template = globalThis.document?.createElement?.('template');
        if (!template || typeof template.setHTML !== 'function') {
            throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Secure analytics parsing is unavailable.', 'ANALYTICS_STAGE_SANITIZER_UNAVAILABLE');
        }
        try {
            template.setHTML(String(value ?? ''), { sanitizer: getInertSanitizer() });
        } catch (error) {
            throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Analytics response could not be sanitized.',
                error?.diagnosticCode === 'ANALYTICS_STAGE_SANITIZER_UNAVAILABLE'
                    ? error.diagnosticCode : 'ANALYTICS_STAGE_SANITIZE');
        }
        const html = template.innerHTML;
        let document;
        try { document = new DOMParser().parseFromString(html, 'text/html'); } catch {
            throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Analytics response could not be parsed.', 'ANALYTICS_STAGE_PARSE');
        }
        if (!document?.documentElement || document.querySelector('parsererror')) {
            throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Analytics response could not be parsed.', 'ANALYTICS_STAGE_PARSE');
        }
        return { document, html };
    }


    function diagnosticFields(value) {
        return DIAGNOSTIC_CODES.has(value) ? { diagnosticCode: value } : {};
    }

    function analyticsError(code, message, diagnosticCode) {
        return Object.assign(new Error(message), { code }, diagnosticFields(diagnosticCode));
    }


    function parseAndValidate(value, request) {
        const parsed = parseInertAnalyticsHtml(value);
        if (request.requestedSource?.kind === 'team-players') validateTeamPlayerDocument(parsed.document, request.requestedSource);
        else if (request.requestedSource?.kind === 'team-history') validateTeamHistoryDocument(parsed.document, request.requestedSource);
        else {
            try { validateAnalyticsDocument(parsed.document, request); } catch {
                throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Analytics document validation failed.', 'ANALYTICS_STAGE_ANALYTICS_DOCUMENT');
            }
        }
        return { html: parsed.html };
    }
    Object.defineProperty(globalThis, 'HLTV_PREDICTION_PARSER', {
        value: Object.freeze({ parseAndValidate }), configurable: false, writable: false,
    });
})();
