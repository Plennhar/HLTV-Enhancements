// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Plennhar

(() => {
    'use strict';

    const DOCUMENT_PATH = 'chromium/offscreen.html';
    const TYPE = 'hltv-sp:parse-prediction-html';
    const MAXIMUM_CHARACTERS = 4 * 1024 * 1024;
    let creatingDocument = null;

    async function documentExists() {
        const contexts = await browser.runtime.getContexts({
            contextTypes: ['OFFSCREEN_DOCUMENT'],
            documentUrls: [browser.runtime.getURL(DOCUMENT_PATH)],
        });
        return contexts.length > 0;
    }

    async function ensureDocument() {
        if (creatingDocument) return creatingDocument;
        creatingDocument = (async () => {
            if (await documentExists()) return;
            try {
                await browser.offscreen.createDocument({
                    url: DOCUMENT_PATH,
                    reasons: ['DOM_PARSER'],
                    justification: 'Sanitize and validate bounded HLTV prediction responses without loading their resources.',
                });
            } catch (error) {
                // A previous worker may have completed creation during this worker's startup.
                if (!await documentExists()) throw error;
            }
        })();
        try { await creatingDocument; } finally { creatingDocument = null; }
    }

    function invalidResponse(diagnosticCode) {
        return Object.assign(new Error('Prediction response validation failed.'), {
            code: 'ANALYTICS_INVALID_RESPONSE',
            ...(typeof diagnosticCode === 'string' && /^ANALYTICS_STAGE_[A-Z_]+$/.test(diagnosticCode)
                ? { diagnosticCode } : {}),
        });
    }

    async function parseAndValidate(html, request) {
        if (typeof html !== 'string' || !html || html.length > MAXIMUM_CHARACTERS) throw invalidResponse();
        await ensureDocument();
        const requestId = globalThis.crypto.randomUUID();
        const result = await browser.runtime.sendMessage({ type: TYPE, requestId, html, request });
        if (!result || result.requestId !== requestId || result.ok !== true
            || typeof result.html !== 'string' || !result.html || result.html.length > MAXIMUM_CHARACTERS) {
            throw invalidResponse(result?.diagnosticCode);
        }
        return { html: result.html };
    }

    Object.defineProperty(globalThis, 'HLTV_PREDICTION_OFFSCREEN', {
        value: Object.freeze({ parseAndValidate }), configurable: false, writable: false,
    });
})();
