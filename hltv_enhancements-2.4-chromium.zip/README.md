# HLTV Enhancements

HLTV Enhancements is a free, unofficial Firefox extension that adds optional
forum, match, player, comparison, and statistics tools to HLTV.org.

It is not affiliated with, sponsored by, endorsed by, or approved by HLTV.org
or its owners.

- Version: 2.4 (under integrated validation)
- Developer: Plennhar
- Support: `plenhar@proton.me`
- Firefox: 148 or newer
- License: GPL-3.0-or-later

See [CHANGELOG.md](CHANGELOG.md) for the user-facing version 2.4 release notes
and the extension-ID change made in version 2.0.

## Features

The version notice above the HLTV header expands when clicked to show the
current release's changes. Close it with **×** to dismiss it for that version;
it stays dismissed across page visits and browser restarts.

The **Disable HLTV Enhancements** master switch preserves saved configuration and local
data. Save a change, then manually reload each HLTV tab for it to take effect.
When disabled, newly loaded HLTV pages use native behavior without extension
feature requests. The header settings cog and toolbar settings remain available.
Re-enable through either settings menu and reload to restore saved features.

### Forums, recent activity, and local user tools

- Choose which forum sections, News, and Matches appear in recent activity,
  set per-source limits, fetch older forum pages, and choose a separate color
  for each source. Separate master switches can return fetching and source
  coloring to HLTV's native behavior without erasing the saved configuration.
- Use wider page layouts, larger recent-activity text, relative ages, and an
  optional relocated **Post new topic** control.
- Preview threads on title hover, including the original post, comments,
  replies, votes, tags, read state, first-unread and **Last comment** navigation, allowlisted HLTV
  gallery images, user flags, and player or team flairs. The same preview is
  available for forum-thread notifications and gives the exact target reply a
  distinct highlight after expanding its ancestors.
- Keep local user tags, exact tag-based comment hiding, local reaction scores,
  local minus controls, and provisional local +1 state. Scores belong beside
  actual nicknames; profile sort links and other navigation do not receive them.
- Search **Authored threads** and **Forum posts** independently on profiles.
  Each section automatically loads up to 100 entries, including native loaded
  entries. **Continue loading** follows that section's native pagination to
  exhaustion with progress, **Cancel**, and resumable loading. Search updates
  as entries arrive; clearing it restores native loaded order. Counts explain
  partial/complete/error states. Posts search available title/comment excerpts,
  which may be truncated. Native upvote counts and comment links are preserved.
- Add optional right-click actions for validated HLTV profile links. Blocking
  and unblocking use HLTV's own account action and do not create a separate
  extension block list. After a successful block, a page-local **Blocked**
  marker appears immediately and remains until the page is refreshed.
- Extend HLTV's match filter with up to 50 extension-local teams and
  optionally hide loaded match and result rows that involve none of the
  combined selections. The native **Search team...** field remains usable
  after HLTV's five built-in slots are filled, and added teams appear directly
  in the same Team list. They remain extension-local if a native slot later
  opens, are reapplied after navigation, and never change the user's HLTV
  account filter. HLTV's own star and settings-dropdown switch remain the
  master control: turning the native filter off immediately restores HLTV's
  unfiltered view without deleting extension selections.

Thread previews contain their own scroll area. Continuous ancestor rails and
branch elbows show reply relationships. A rail can be clicked or activated
from the keyboard to hide that branch's descendants while keeping its parent
visible; a count reports hidden replies. Hidden replies remain unread until
expanded, notification targets expand their ancestors, and collapsed state
resets when the preview closes. **Last comment** jumps to the highest-numbered
comment whose author is not hidden, opening only its ancestor branches and
scrolling only the preview. It also works with read tracking disabled and
preserves open reply drafts. The target stays highlighted until a click outside
that comment, including another comment or reply field in the preview.
Scrolling or interacting inside the highlighted comment keeps it highlighted.
Reaching the preview's top or bottom no longer
scrolls the page, and opening the browser context menu inside it does not close
the preview.

Each reply target has its own private draft composer, so switching to another
reply does not discard text already entered for either target. A preview keeps
at most 20 extension-origin composer sessions in memory; clearing a draft lets
an unused session be replaced, and closing the preview disposes its sessions.

Forum composers also provide an explicit **Save as draft** action for signed-in
users. Nothing is saved merely because text was typed. A saved entry is scoped
to the current HLTV account and its exact top-level reply, threaded-reply, or
new-topic context. Returning to that context offers **Restore**, but restoration
never replaces a nonempty title or message field. Failed posting attempts leave
the composer and any saved revision intact. The extension does not classify a
failure as a posting limit, highlight **Save as draft** after failures, or
schedule draft reminders or notifications.

Saved drafts can be reviewed from **Saved drafts** in the in-page settings.
The manager shows bounded context, title, and last-updated information and can
revisit a target, restore it when the matching empty composer is available, or
delete one entry or all entries with confirmation. A confirmed reply posted
through the extension removes a saved draft only when both its revision and
stored body still match the revision and body captured for that post, so a
newer edit from another tab is preserved. Because a new topic uses HLTV's
native form rather than the extension reply broker, its saved draft remains
until the user explicitly deletes it from the manager.

### Match pages

Each match-page feature can be disabled independently:

- A desktop sticky match header for scheduled, TBD, live, and finished
  matches. Live state includes the series score and current-map information
  when HLTV exposes it. Native mobile layout is left unchanged.
- Player form overlays built from HLTV's inline past-three-month data. The
  user chooses any non-empty combination of Rating, KPR, DPR, KAST, ADR,
  multi-kill rating, and Round Swing. The full chooser appears inside the
  setting's expanded help, and a compact **Lineup stats** button on match pages
  makes the same selection available in context.
- **Show match result predictions** adds a deterministic pre-match card.
  **Market + stats** is selected by default and retains the saved `stats` mode
  value. Its market percentage defaults to 50% and accepts values from 0 to 100,
  including fractions. The remaining share uses map results adjusted by each
  historical opponent's strictly prior weekly HLTV points, without a direct
  own-ranking baseline. Historical team identity does not prove current-roster
  continuity.
- Market series probability is converted to an equivalent constant per-map
  probability, blended with each statistics map probability, and passed through
  exact BO1/BO3/BO5 series/veto math. The selected and effective shares,
  single-source fallbacks, ranking dates, samples and missing coverage are
  disclosed. The most probable individual score can favor a different winner
  from the summed team win probability; both remain visible.
- **Market-estimated** stays independent and odds-only. It reports retained
  median de-vigged consensus directly. The blend setting does not change it,
  and missing odds keep its selected mode with an unavailable explanation.
  Its market-quality chip describes provider coverage/agreement, does not
  change probability, and has no statistics breakdown or exact-score line.

**Stats only** uses opponent-adjusted map analysis with no bookmaker input,
regardless of the saved blend percentage. Missing statistics remain unavailable
without a market fallback. Both statistics modes show the calculation breakdown
and exact scores; Market-estimated remains odds-only. The blend percentage is
retained and is editable only in Market + stats. All three choices are saved
and available in the card, toolbar popup and on-site settings cog.

The sticky header and player overlays use the loaded page. Prediction fetches
Analytics and two CS2 team histories once, plus every required weekly world
ranking sequentially: current week first, then historical weeks newest first.
The separate ranking ledger allows at most 15 distinct weeks per document;
cache hits and joining in-flight downloads consume no new attempt. Failures
are shown and never cause automatic repeated downloads in that document.

Both histories cover the 90 days before the current observation UTC day, ending
on the previous day. Same-day and future results are excluded. Responses are
bounded to 600 maps, 4 MiB and 12 seconds, stopping sooner at scheduled start.
There are no monthly player requests, opponent crawls, history pagination,
redirects, alternate sources or periodic refresh. Mode changes do not reset
request ledgers. Complete weekly snapshots persist locally without expiry and
are shared across teams and tabs. No extra permission or prediction service
is required.

The `opponent-map-1` model adjusts each team's map wins and losses using only
its opponents' dated HLTV points. Its own ranking has no direct contribution.
The ranking must precede each historical result's UTC day; Monday results use
the previous Monday. Zero points are valid; an opponent absent from a complete
ranking is excluded and counted. Missing required weeks or incomplete team
histories leave statistics pending while rankings load. A missing current
ranking cannot disable otherwise usable historical evidence.

Sparse maps borrow from the same team's overall map results; unplayed maps
are labeled as pooled estimates. The card shows raw samples and regularized
win-rate estimates against common reference opposition, as well as actual
matchup chances and the selected market blend. Historical team records do not
establish current-roster continuity. See [model equations](../specs/prediction_model_opponent_map_1.md)
and the [evaluation report](../data/prediction/opponent-evaluation.json).
The corpus is partial and the later assessment was reused; improved predictive
accuracy is not established.

At or after scheduled start, fetching and calculation stop. Keep the newest
50 match identities' frozen pre-match results without age expiry. New results
use V6 storage; valid V1/V2/V3/V4/V5 records keep their original models, values,
explanations and calculation times. Live/final odds, maps and scores cannot
recompute those saved estimates.

### Player ranking and match-history tables

The following tools can be enabled independently on supported player-ranking
and player match-history pages:

- Column visibility and order, stored separately by table type.
- Multi-column sorting that survives reloads: click replaces the sort, while Shift-click
  adds or changes a secondary key.
- Automatic content-based column widths whenever an extension column is
  visible, with safe horizontal scrolling when the selected columns cannot
  fit the available page width. There is no separate auto-fit setting.
- Individually selectable estimated KPR, DPR, and kills-per-map columns on
  ranking tables. Estimates appear as ranges when HLTV's rounded K/D prevents
  an exact result. Supported match-history tables can show exact KPR and an
  individually selectable exact DPR column.
- An individually selectable WAR column, shown by default on fresh installs.
  Selecting WAR reveals its fetch, cache, and automatic-refresh controls;
  hiding it removes both the column and those controls. The chooser explains
  the complete team-win adjustment and formula.
- An individually selectable baseline-delta column. Showing the column enables
  table date-period comparison; hiding it disables that table feature without
  changing the separate player-overview comparison setting.
- CSV export of currently loaded rows using visible columns, displayed order,
  extension columns, player/team countries, and the current sort. Formula-like
  spreadsheet prefixes are escaped.
- An in-page **Rows to show** selector after the bottom match-history pager.
  It offers 100, 200, 300, 400, 500, and **ALL**, remembers one global choice,
  and defaults to 100. Larger choices follow HLTV's native next-page links from
  the current offset, merge the additional rows into the same column, sorting,
  reset, and CSV model, and rewrite Previous/Next for the selected window.
  **ALL** means every remaining result from the current offset within the
  safety caps and returns to the first result window through Previous.
- A selectable numeric trend for the latest 100 loaded maps with locked labeled
  axes, an orange five-map rolling line, and points that show match details immediately
  while hovered or keyboard-focused. The detail popup disappears on pointer
  exit or blur.

The column chooser owns WAR, estimated ranking-table KPR, and exact KPR on
supported match-history tables. Every selectable column starts visible and can
then be hidden independently. Calculated and estimated columns have inline
explanations beside their ordering controls. Unknown map abbreviations remain
unchanged.

### Player analytics and comparison pages

Each feature can be disabled independently:

- A sortable map-by-stat matrix that follows the current player filters. It is
  available from every supported player-stats route that contains HLTV's
  player navigation bar. At the default/narrow width, navigation wraps into
  two clean rows so **Map matrix** stays separated from **Opponents**. When the
  user opens its tab, the extension fetches matching history pages sequentially,
  aggregates Rating, KPR, DPR, and K/D by map, shows progress and
  partial-result warnings, detects pagination loops, and reuses a short
  in-memory cache. Column headers toggle stable sorting; Map starts ascending, numeric
  columns start descending, and lower DPR is colored as better.
- A 0-100 consistency score over every fetched rating under the active player
  filters, requiring at least 10 values:
  `round(100 * max(0, 1 - population_SD))`. Rating SD 0 maps
  to 100, while Rating SD 1.00 or greater maps to 0. Scores of 60 or more are
  Good and green, 40-59 are Mixed, and scores below 40 are Poor and red. It
  appears at native metric width in the center of the final player-summary
  row, grows the summary downward without covering native controls, and loads
  automatically when enabled. Its bar and hover/focus description use HLTV's
  native presentation. It uses the bounded sequential history loader,
  its short in-memory
  cache, retry policy, and partial-result warnings.
- Separately switchable user-selected comparison date ranges for ranking
  tables and individual player overviews. The current page remains the primary
  period. The comparison dates are stored in the page URL, preserve compatible
  filters, and default to the preceding equal period. Its five-minute page
  cache is limited to 16 entries and 8 MiB of serialized content. Comparison
  is disabled when a specific-event filter would make it misleading. Individual
  overviews offer numeric metrics present in both periods. Ranking pages offer
  native numeric comparison metrics, estimated KPR/DPR range midpoints, and
  exact net K/R as a date-period comparison metric; net K/R is not an optional
  table column. ADR and KAST are not available from the ranking table.
- Comparison pages automatically fetch one filtered overview per player and
  add all 32 raw role metrics and seven category scores in expandable groups.
  Shared Both/CT/T and Everyone/role-baseline controls reuse embedded data;
  Sniping remains explicitly compared with Everyone. Duration values use
  seconds for differences, with human-readable display. Playstyle frequencies
  have neutral differences rather than universal better/worse coloring.
  Expanded CSV rows include side, baseline, units and source-filter metadata.
  All seven groups start expanded and share aligned metric/value columns.
  Player differences are right minus left
  (98 on the left versus 97 on the right gives -1.00); percentage differences
  use the right value as their denominator.
- Other comparison-page additions: absolute and percentage deltas, direction-aware
  highlighting, a lead summary, player swapping, one-way filter
  synchronization, and local CSV export. An explicit button can fetch every
  filtered match-history page for each available player and draw one or both
  available players on a shared calendar-date graph. The graph retains raw
  per-match and **10-map average** views and can instead plot one trailing mean
  per UTC calendar day. **10-map average** and **Trailing daily mean** are
  mutually exclusive transient controls; leaving both unchecked selects raw
  per-match data. Daily mode reveals a **Window (days)** field that accepts
  1-365 in one-day steps and defaults invalid or untouched values to 30. Each
  daily value is the mean of finite selected-metric map values in the inclusive
  trailing N-day UTC period ending that date. A zero-map window is a gap, and
  lines do not bridge it. A **Show points** switch controls markers. An optional
  **Linear trend line** draws a separate least-squares line for each displayed
  player over the points in the current raw, 10-map, or daily view.
  Raw-point details identify the
  player, matchup, date, map, K-D when available, and value without displaying
  an ID or URL.
  Adding the second player through the native picker copies the left filters
  once; later independent filter choices remain available.
  Daily-point details show the UTC date range, contributing map count, and
  mean. Point details appear immediately only while the point is hovered or
  keyboard-focused, then disappear on pointer exit or blur.

Player-history pagination, including the match-history row selector, is capped
at 100 pages and 10,000 unique rows. It starts requests at least 500 ms apart.
A failed page is retried after three seconds and, if needed, once more after
five seconds; failure of the final retry stops that operation. The row selector
preserves the rows already loaded and offers a manual retry. Daily rendering
rejects a shared span
above 20,000 UTC days. Visible, keyboard-focusable comparison markers are
evenly sampled to at most 600 per player without removing data from the plotted
lines. In daily mode, bounded SVG-level nearest-point hit testing keeps every
finite daily value immediately mouse-inspectable without adding one DOM node
per date.

### Team FTU pages

On `/stats/teams/ftu` pages, **Show team Overperformance Score** adds a
sortable OS column comparing a team's actual T-side round-win percentage with
the expectation fitted from CT-side opening-duel success across the active
filtered team cohort. The cohort's mean T RW, mean CT OpK, and least-squares
slope are calculated locally each time; no historical fixed coefficient or
intercept is used. Positive and negative values indicate performance above or
below that cohort-relative expectation, so scores from different filter sets
are not directly comparable. Calibration requires at least three paired teams
and variation in CT OpK. OS can be a rough signal of IGL or team-system
strength, but it does not isolate or prove an IGL's individual impact. The
feature reuses the current side when possible and loads only the missing
matching T-side or CT-side view.

## Version 2.4 defaults

All global settings appear in both the Firefox toolbar popup and the in-page
settings dialog, including master disable, prediction mode and market percentage.
Version 2.4 features can be controlled separately. Every feature toggle except local diagnostic
logging is enabled on a fresh install. Only Off-Topic and Counter-Strike are
selected as recent-activity sources by default. Table-width fitting activates
automatically only while a custom column is visible. Existing stored choices
are preserved during an upgrade.

Save and Cancel stay visible at the top while the settings list scrolls.
Expanded help panels include **Try it on HLTV** where there is a useful
HLTV page on which to try the feature. Stats actions add rolling three-calendar-
month native date filters, while non-stats actions open plain routes. Player
role comparison overviews load automatically when two players are present.
History graphs load when requested. **Report a bug or submit feedback** is available in both
the toolbar popup and the in-page dialog and opens the fixed
`plenhar@proton.me` email address in the user's configured mail application.

Firefox profiles that lack ongoing HLTV access see a one-time
**Always allow on HLTV.org** action in the toolbar popup. Accepting it stores
the required content-script origin grant and reloads the active HLTV tab. The
recovery action stays hidden when access is already granted and does not add a
duplicate optional host permission to the canonical manifest.

## Local data, exports, and diagnostics

Settings, colors, tags, read state, local reactions, provisional votes,
additional match teams, table layouts and sort definitions, match-prediction
choices, downloaded full weekly rankings, the newest 50 saved pre-match predictions, explicitly saved forum
drafts, and bounded feature caches are kept in Firefox extension-private
storage. Draft storage uses schema 1 and accepts at most 50 entries, 50,000
characters per message body, and 2 MiB in aggregate across that signed-in
account's valid draft records. Drafts have no age expiry and are never silently
evicted: if either capacity limit is reached, saving is refused while the
existing records remain available in the manager. Saved predictions remain
until newer matches evict them, the user clears extension data, or the extension
is removed. Short-lived page-analysis caches can also exist only in memory.
Weekly rankings have no age expiry. **Clear cached rankings** is available in
both the toolbar popup and on-site settings; it removes ranking downloads while
preserving archived forecasts and saved settings.

The settings UI can create three user-requested local JSON downloads:

- saved settings;
- user data, including tags, read state, reactions and scores, provisional
  local +1 records, and additional match teams;
- the optional diagnostic log.

Saved drafts are intentionally excluded from all three downloads and from
settings or user-data imports. They can be inspected and deleted only through
the on-page draft manager or by clearing Firefox extension data.

Separate Import settings and Import user data controls accept the corresponding
local export type. Settings replace recognized settings while preserving
unrelated storage. User records are merged by identity, with the newer valid
timestamp winning where both files contain the same record. Imports are
size-bounded, validated before one atomic storage update, and never uploaded.

Diagnostic logging is off by default. When enabled, the log is redacted and
limited to 500 entries, 256 KiB, and seven days. It does not record draft
titles or bodies, post text, usernames, tags, cookies, credentials, raw HTML, response bodies,
full URLs, query strings, fragments, or numeric profile/thread identifiers.
It is never sent automatically. Export occurs only when the user presses the
export button.

The extension has no developer-operated server, analytics, advertising, or
telemetry. See [PRIVACY.md](PRIVACY.md) for the complete data-flow and
retention details.

## Network boundaries

Extension-initiated requests are HTTPS requests restricted to
`https://www.hltv.org`. They support enabled forum/news/match sources, thread
previews, profile-history pagination, team-name suggestions, match Analytics,
bounded team match histories and weekly world rankings for prediction, paired FTU
statistics, user-selected date-period comparisons, player-history
aggregation, comparison trend graphs, username suggestions, and
user-requested HLTV actions such as posting, +1, block, or unblock.

Thread-preview rendering can also load validated image resources from
allowlisted HLTV origins: `https://www.hltv.org` and
`https://img-cdn.hltv.org`. Gallery and flag URLs must match their expected
path families, and team logos must use a supported image filename. Gallery
embeds are limited to four per post and 20 per preview, and team-flair images
are limited to 100 per preview. Each rendered author retains their validated
flag independently of these budgets. Images load lazily
with a `no-referrer` policy. Fetched markup cannot activate arbitrary image
URLs.

Match-page overlays, loaded-row table tools, local CSV generation, and
comparison-page deltas use already loaded data and do not make an additional
request. The comparison trend graph
makes bounded same-origin HLTV match-history requests only after the user
presses its fetch button. Prediction may attempt only the linked same-match
Analytics page and each team's bounded match history (three source attempts),
plus all required weekly world rankings (at most 15 distinct weeks per document), with
no periodic network refresh. Shared cache hits and in-flight requests do not
spend additional download attempts.

No data is sent to the developer or to an analytics or advertising service.
Firefox can attach the user's existing HLTV cookies to same-origin requests;
the extension does not read or store cookie contents.

## Migration from the retired userscript

The standalone userscript distribution is retired. Firefox extensions cannot
read private Violentmonkey or Tampermonkey storage,
so userscript settings and local data do not transfer automatically. Disable
the userscript before installing this extension to avoid duplicate controls,
observers, and requests.

## Temporary development installation

1. Extract the source archive.
2. Open `about:debugging#/runtime/this-firefox` in Firefox.
3. Select **Load Temporary Add-on**.
4. Select this directory's `manifest.json`.
5. Open or reload HLTV.org.

### Isolated host-permission diagnostic

If that fresh load shows Firefox's yellow **Permission needed to read and
change data** indicator while `extensions.originControls.grantByDefault` is
`true`, run this from the repository root:

```bash
npm run build:firefox:temporary
```

It creates
`firefox-dist/hltv_enhancements-2.4-unsigned-temporary-autogrant.zip`, named
**HLTV Enhancements (Temporary Test)** and identified as
`hltv-enhancements-temporary-autogrant@plennhar`. The staged manifest preserves
the exact `https://www.hltv.org/*` content-script scope, keeps
`host_permissions` and `optional_host_permissions` absent, and adds Firefox's
temporary-only `granted_host_permissions: true` flag. Apart from that flag, the
diagnostic name, and the separate ID, its packaged files match the ordinary
extension.

First remove any previous **HLTV Enhancements (Temporary Test)** entry in
`about:debugging`; then choose **Load Temporary Add-on**, select the diagnostic
ZIP, and open or reload HLTV.org. If access is granted, the result points to
Firefox's ordinary temporary-load permission-grant path. If the yellow
indicator remains, forced temporary autogrant did not resolve the symptom.
Neither result predicts the behavior of a normally signed installation by
itself.

The diagnostic build produces the expected `MANIFEST_FIELD_PRIVILEGEDONLY`
lint warning because `granted_host_permissions` is unavailable to ordinary
signed extensions. Never upload this ZIP to AMO or ship it to users. The
canonical `manifest.json` and normal `npm run build:firefox` package omit the
flag, `host_permissions`, and `optional_host_permissions`, and keep the
permanent `hltv-enhancements@plennhar` ID.

## Validate and build

Run from the extension directory:

```bash
npx --yes web-ext@10.6.0 lint --source-dir . --ignore-files amo 'amo/**'

npx --yes web-ext@10.6.0 build \
  --source-dir . \
  --artifacts-dir ../firefox-dist \
  --ignore-files amo 'amo/**'
```

The installable archive must have `manifest.json` at its root. The `amo/`
directory contains submission notes and is not part of the extension package.
These commands create a development archive. From the repository root,
`npm run build-for-amo` creates and validates the canonical
`amo-dist/hltv_enhancements-2.4-amo.zip`. The repository's
`amo/release-validation-2.3.md` document is historical evidence for 2.3;
fresh source, browser and package measurements are required for 2.4. AMO upload, signing, review,
and publication remain pending. The separately documented temporary autogrant ZIP
is diagnostic-only and is never an AMO input.

## Licensing and third-party material

The extension is distributed under GPL-3.0-or-later. See
[LICENSE](LICENSE), [CHANGELOG.md](CHANGELOG.md),
[THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md), and
[TRADEMARKS.md](TRADEMARKS.md).
