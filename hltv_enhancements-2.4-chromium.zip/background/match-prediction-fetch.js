// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Plennhar

(() => {
    'use strict';

    const CONFIG = Object.freeze({
        sourceRequestType: 'hltv-sp:get-prediction-source',
        sourceFetchType: 'hltv-sp:fetch-prediction-source',
        sourceCancelType: 'hltv-sp:cancel-prediction-source',
        sourceReleaseType: 'hltv-sp:release-prediction-source',
        origin: 'https://www.hltv.org',
        matchPath: /^\/matches\/(\d{1,20})(?:\/|$)/,
        analyticsPath: /^\/betting\/analytics\/(\d{1,20})(?:\/|$)/,
        teamNameMaxLength: 80,
        initialRequestDelayMs: 500,
        retryDelaysMs: Object.freeze([]),
        timeoutMs: 12_000,
        maximumResponseBytes: 4 * 1024 * 1024,
        minimumCacheMs: 60_000,
        maximumCacheMs: 30 * 60_000,
        timestampToleranceMs: 60_000,
        maximumCacheEntries: 8,
        maximumPendingRequests: 8,
        maximumRequesters: 8,
        maximumErrorCharacters: 180,
        sanitizerRemoveElements: Object.freeze([
            'applet', 'audio', 'base', 'embed', 'frame', 'frameset', 'iframe',
            'img', 'link', 'meta', 'noscript', 'object', 'picture', 'portal',
            'script', 'source', 'style', 'track', 'video',
            { name: 'svg', namespace: 'http://www.w3.org/2000/svg' },
            { name: 'math', namespace: 'http://www.w3.org/1998/Math/MathML' },
        ]),
        sanitizerRemoveAttributes: Object.freeze([
            'background', 'data', 'imagesizes', 'imagesrcset', 'manifest',
            'ping', 'poster', 'src', 'srcset', 'style',
        ]),
    });

    const cache = new Map();
    const pending = new Map();
    // Fixed identifiers only: never derive diagnostic fields from HTML, URLs or exception messages.
    const DIAGNOSTIC_CODES = new Set([
        'ANALYTICS_STAGE_RESPONSE_URL', 'ANALYTICS_STAGE_RESPONSE_MIME',
        'ANALYTICS_STAGE_RESPONSE_LENGTH', 'ANALYTICS_STAGE_RESPONSE_BODY', 'ANALYTICS_STAGE_RESPONSE_STREAM',
        'ANALYTICS_STAGE_SANITIZER_UNAVAILABLE', 'ANALYTICS_STAGE_SANITIZE', 'ANALYTICS_STAGE_PARSE',
        'ANALYTICS_STAGE_TEAM_TIME_FILTER', 'ANALYTICS_STAGE_TEAM_VERSION_FILTER',
        'ANALYTICS_STAGE_TEAM_FORM_FILTER', 'ANALYTICS_STAGE_TEAM_EXTRA_FILTER',
        'ANALYTICS_STAGE_TEAM_IDENTITY', 'ANALYTICS_STAGE_TEAM_TABLE', 'ANALYTICS_STAGE_TEAM_TITLE',
        'ANALYTICS_STAGE_ANALYTICS_DOCUMENT',
    ]);
    let inertSanitizer = null;
    let attemptSequence = 0;

    function safeUrl(value, base = CONFIG.origin) {
        try {
            return new URL(String(value || ''), base);
        } catch {
            return null;
        }
    }

    function boundedName(value) {
        const text = String(value ?? '').normalize('NFKC').replace(/\s+/g, ' ').trim();
        return text && text.length <= CONFIG.teamNameMaxLength ? text : '';
    }

    function normalisedName(value) {
        return boundedName(value).toLocaleLowerCase();
    }

    function scheduledStartError() {
        return analyticsError('ANALYTICS_STARTED', 'Analytics request stopped at the scheduled match start.');
    }

    function ensureBeforeScheduledStart(request, now = Date.now()) {
        if (!Number.isSafeInteger(request?.timestamp) || now >= request.timestamp) {
            throw scheduledStartError();
        }
        return request.timestamp - now;
    }

    function senderMatchId(sender) {
        if (sender?.id !== browser.runtime.id || sender?.frameId !== 0) return '';
        const url = safeUrl(sender?.url);
        if (url?.origin !== CONFIG.origin || url.protocol !== 'https:') return '';
        return CONFIG.matchPath.exec(url.pathname)?.[1] || '';
    }

    function normaliseRequest(message, sender) {
        if (message?.type !== CONFIG.sourceRequestType) return null;
        const requestedSource = normaliseSource(message.source);
        if (!requestedSource) return null;
        message = {
            ...message, matchId: requestedSource.matchId, href: requestedSource.href,
            teamNames: requestedSource.teams.map((team) => team.name), timestamp: requestedSource.timestamp,
        };
        if (!Number.isInteger(sender?.tab?.id) || sender.tab.id < 0
            || !validId(message.documentId) || !validId(message.requestId)) return null;
        const matchId = typeof message.matchId === 'string' ? message.matchId : '';
        if (!/^\d{1,20}$/.test(matchId) || senderMatchId(sender) !== matchId) return null;
        const url = safeUrl(message.href);
        if (url?.origin !== CONFIG.origin || url.protocol !== 'https:'
            || url.username || url.password) return null;
        const teamNames = Array.isArray(message.teamNames)
            ? message.teamNames.map(boundedName)
            : [];
        if (teamNames.length !== 2 || teamNames.some((name) => !name)) return null;
        const timestamp = Number(message.timestamp);
        if (!Number.isSafeInteger(timestamp) || timestamp <= Date.now()) return null;
        const requestedCacheMs = Number(message.cacheTtlMs);
        const cacheTtlMs = Math.min(
            CONFIG.maximumCacheMs,
            Math.max(
                CONFIG.minimumCacheMs,
                Number.isFinite(requestedCacheMs)
                    ? Math.trunc(requestedCacheMs)
                    : CONFIG.minimumCacheMs,
            ),
        );
        return Object.freeze({
            matchId,
            requestedSource,
            source: {
                tabId: sender.tab.id, documentId: message.documentId,
                requestId: message.requestId, href: url.href, released: false, onRelease: null,
            },
            url,
            teamNames,
            timestamp,
            cacheTtlMs,
            key: `v23:${requestedSource.kind}:${url.href}:${matchId}:${requestedSource.teams.map((team) => team.id).join(':')}:${timestamp}`,
        });
    }

    function normaliseSource(source) {
        if (!source || typeof source !== 'object' || !/^\d{1,20}$/.test(source.matchId || '')
            || !Number.isSafeInteger(source.timestamp) || source.timestamp <= Date.now()
            || !Array.isArray(source.teams) || source.teams.length !== 2
            || source.teams.some((team) => !/^\d{1,20}$/.test(team?.id || '') || !boundedName(team.name))
            || source.teams[0].id === source.teams[1].id) return null;
        const url = safeUrl(source.href);
        if (url?.origin !== CONFIG.origin || url.username || url.password || url.hash) return null;
        if (source.kind === 'analytics') {
            if (source.sourceKey !== 'analytics' || source.teamId !== '' || source.window !== null
                || url.search || CONFIG.analyticsPath.exec(url.pathname)?.[1] !== source.matchId) return null;
        } else if (source.kind === 'team-players') {
            const index = /^team-players-([01])$/.exec(source.sourceKey || '')?.[1];
            if (index === undefined || source.teams[Number(index)].id !== source.teamId
                || /^\/stats\/teams\/players\/(\d{1,20})\/[a-zA-Z0-9_-]+\/?$/.exec(url.pathname)?.[1] !== source.teamId
                || !validWindow(source.window) || !matchesSourceFilters(url, source)) return null;
        } else if (source.kind === 'team-history') {
            const index = /^team-history-([01])$/.exec(source.sourceKey || '')?.[1];
            if (index === undefined || source.teams[Number(index)].id !== source.teamId
                || /^\/stats\/teams\/matches\/(\d{1,20})\/[a-zA-Z0-9_-]+\/?$/.exec(url.pathname)?.[1] !== source.teamId
                || !validHistoryWindow(source.window) || !matchesSourceFilters(url, source)) return null;
        } else return null;
        return source;
    }

    function validWindow(window) {
        if (!window || !/^\d{4}-\d{2}-\d{2}$/.test(window.startDate || '')
            || !/^\d{4}-\d{2}-\d{2}$/.test(window.endDate || '')) return false;
        const end = new Date(`${window.endDate}T00:00:00Z`);
        if (!Number.isFinite(end.getTime()) || end.toISOString().slice(0, 10) !== window.endDate
            || end.getTime() > Date.now()) return false;
        const start = new Date(Date.UTC(end.getUTCFullYear(), end.getUTCMonth() - 1, 1));
        const last = new Date(Date.UTC(start.getUTCFullYear(), start.getUTCMonth() + 1, 0)).getUTCDate();
        start.setUTCDate(Math.min(end.getUTCDate(), last));
        return window.startDate === start.toISOString().slice(0, 10);
    }
    function validHistoryWindow(window) {
        if (!window || !/^\d{4}-\d{2}-\d{2}$/.test(window.startDate || '')
            || !/^\d{4}-\d{2}-\d{2}$/.test(window.endDate || '')) return false;
        const end = Date.parse(`${window.endDate}T00:00:00Z`);
        const start = Date.parse(`${window.startDate}T00:00:00Z`);
        const today = new Date(Date.now()); today.setUTCHours(0, 0, 0, 0);
        return Number.isFinite(end) && Number.isFinite(start)
            && new Date(end).toISOString().slice(0, 10) === window.endDate
            && new Date(start).toISOString().slice(0, 10) === window.startDate
            && today.getTime() - end >= 86_400_000 && today.getTime() - end <= 2 * 86_400_000
            && end - start === 89 * 86_400_000;
    }

    function matchesSourceFilters(url, source) {
        const keys = [...url.searchParams.keys()].sort();
        return keys.join(',') === 'csVersion,endDate,startDate'
            && url.searchParams.get('csVersion') === 'CS2'
            && url.searchParams.get('startDate') === source.window.startDate
            && url.searchParams.get('endDate') === source.window.endDate;
    }

    function validateTeamPlayerDocument(document, source) {
        const expected = safeUrl(source.href);
        const selectors = [
            ['.stats-sub-navigation-simple-filter-time option[selected]', 'ANALYTICS_STAGE_TEAM_TIME_FILTER'],
            ['.stats-sub-navigation-simple-filter-version option[selected]', 'ANALYTICS_STAGE_TEAM_VERSION_FILTER'],
        ];
        for (const [selector, diagnosticCode] of selectors) {
            const selected = document.querySelector(selector);
            const url = safeUrl(selected?.getAttribute('data-link'));
            if (!selected || url?.origin !== CONFIG.origin || url.username || url.password || url.hash
                || url.pathname !== expected.pathname || !matchesSourceFilters(url, source)) {
                throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Team-player filters do not match the request.', diagnosticCode);
            }
        }
        for (const [name, expectedValue] of Object.entries({
            startDate: source.window.startDate, endDate: source.window.endDate, csVersion: 'CS2',
        })) {
            for (const control of document.querySelectorAll(`input[name="${name}"], select[name="${name}"]`)) {
                // Native blank date editors are unapplied; selected links above prove the active window.
                if (control.matches('input.filter-date') && ['startDate', 'endDate'].includes(name)
                    && control.type === 'text' && control.value === '' && control.form === null) continue;
                if (control.value !== expectedValue) throw analyticsError(
                    'ANALYTICS_INVALID_RESPONSE', 'Team-player form filters do not match the request.', 'ANALYTICS_STAGE_TEAM_FORM_FILTER',
                );
            }
        }
        for (const selected of document.querySelectorAll('select[class*="stats-sub-navigation-simple-filter-"] option[selected]')) {
            const url = safeUrl(selected.getAttribute('data-link'));
            if (!url || url.origin !== CONFIG.origin || url.pathname !== expected.pathname
                || url.username || url.password || url.hash || !matchesSourceFilters(url, source)) {
                throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Team-player data has additional or inconsistent filters.', 'ANALYTICS_STAGE_TEAM_EXTRA_FILTER');
            }
        }
        const selectedTab = document.querySelector('a.stats-top-menu-item-link.selected');
        const selectedUrl = safeUrl(selectedTab?.getAttribute('href'));
        if (!selectedTab || selectedUrl?.origin !== CONFIG.origin || selectedUrl.pathname !== expected.pathname
            || !matchesSourceFilters(selectedUrl, source)) {
            throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Team-player identity does not match the request.', 'ANALYTICS_STAGE_TEAM_IDENTITY');
        }
        const tables = [...document.querySelectorAll('table.stats-table')];
        const table = tables.find((candidate) => {
            const headers = [...candidate.querySelectorAll('thead th')].map((cell) => boundedName(cell.textContent));
            return headers.some((header) => /^player$/i.test(header))
                && headers.some((header) => /^maps$/i.test(header))
                && headers.some((header) => /^rounds$/i.test(header))
                && headers.some((header) => /^rating\s*3\.0$/i.test(header));
        });
        if (!table || /\b(?:access denied|captcha|log[ -]?in|error)\b/i.test(document.title || '')) {
            throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Team-player data table is missing.',
                !table ? 'ANALYTICS_STAGE_TEAM_TABLE' : 'ANALYTICS_STAGE_TEAM_TITLE');
        }
    }

    function validateTeamHistoryDocument(document, source) {
        const expected = safeUrl(source.href);
        const timeOptions = [...document.querySelectorAll('.stats-sub-navigation-simple-filter-time option[selected]')];
        const timeOption = timeOptions.length === 1 ? timeOptions[0] : null;
        // Native custom-date selection has no link. Only this exact option can
        // instead use one active text date editor per bound as its date proof.
        const nativeCustomTime = timeOption && !timeOption.hasAttribute('data-link')
            && timeOption.parentElement?.matches('select.stats-sub-navigation-simple-filter-time')
            && ['startDate', 'endDate'].every((name) => {
                const controls = [...document.querySelectorAll(`input[name="${name}"], select[name="${name}"]`)];
                return controls.length === 1 && controls[0].matches('input.filter-date')
                    && controls[0].type === 'text' && !controls[0].disabled && controls[0].value === source.window[name];
            });
        const matchesHistorySource = (url) => url?.origin === CONFIG.origin && url.pathname === expected.pathname
            && !url.username && !url.password && !url.hash && matchesSourceFilters(url, source);
        if (!timeOption || (!nativeCustomTime && !matchesHistorySource(safeUrl(timeOption.getAttribute('data-link'))))) {
            throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Team history time filters do not match.', 'ANALYTICS_STAGE_TEAM_IDENTITY');
        }
        for (const selector of ['.stats-sub-navigation-simple-filter-version option[selected]', 'a.stats-top-menu-item-link.selected']) {
            const nodes = [...document.querySelectorAll(selector)];
            const node = nodes.length === 1 ? nodes[0] : null;
            if (!node || !matchesHistorySource(safeUrl(node.getAttribute(node.matches('a') ? 'href' : 'data-link')))
                || (!node.matches('a') && boundedName(node.textContent) !== 'CS2')) {
                throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Team history identity or filters do not match.', 'ANALYTICS_STAGE_TEAM_IDENTITY');
            }
        }
        for (const selected of document.querySelectorAll('select[class*="stats-sub-navigation-simple-filter-"] option[selected]')) {
            if (nativeCustomTime && selected === timeOption) continue;
            if (!matchesHistorySource(safeUrl(selected.getAttribute('data-link')))) {
                throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Team history has extra filters.', 'ANALYTICS_STAGE_TEAM_EXTRA_FILTER');
            }
        }
        for (const [name, expectedValue] of Object.entries({ ...source.window, csVersion: 'CS2' })) {
            for (const control of document.querySelectorAll(`input[name="${name}"], select[name="${name}"]`)) {
                // Linked time controls retain their existing unapplied-editor rule.
                if (!nativeCustomTime && control.matches('input.filter-date') && ['startDate', 'endDate'].includes(name)
                    && control.type === 'text' && control.value === '' && control.form === null) continue;
                if (control.value !== expectedValue) throw analyticsError('ANALYTICS_INVALID_RESPONSE',
                    'Team history form filters do not match.', 'ANALYTICS_STAGE_TEAM_FORM_FILTER');
            }
        }
        if (!document.querySelector('table.stats-table')
            || /\b(?:access denied|captcha|log[ -]?in|error)\b/i.test(document.title || '')
            || document.querySelector('.pagination-next:not(.disabled), a[rel="next"]')) {
            throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Complete team history is unavailable.', 'ANALYTICS_STAGE_TEAM_TABLE');
        }
    }

    function validateAnalyticsDocument(document, request) {
        const header = document.querySelector('.analytics-header');
        if (!header) throw new Error('Analytics header is missing.');

        const backLink = [...header.querySelectorAll('a[href]')].find((anchor) => {
            const url = safeUrl(anchor.getAttribute('href'));
            return url?.origin === CONFIG.origin
                && CONFIG.matchPath.exec(url.pathname)?.[1] === request.matchId;
        });
        if (!backLink) throw new Error('Analytics back-link does not match this match.');

        const analyticsNames = [...header.querySelectorAll('.team .team-name .name')]
            .map((element) => boundedName(element.textContent));
        const fallbackNames = [...header.querySelectorAll('.team .team-name')]
            .map((element) => boundedName(element.textContent));
        const names = (analyticsNames.length === 2 ? analyticsNames : fallbackNames)
            .slice(0, 2)
            .map(normalisedName);
        if (names.length !== 2
            || names[0] !== normalisedName(request.teamNames[0])
            || names[1] !== normalisedName(request.teamNames[1])) {
            throw new Error('Analytics teams do not match this match.');
        }

        const timestamps = [...header.querySelectorAll('[data-unix]')]
            .map((element) => Number(element.getAttribute('data-unix')))
            .filter(Number.isSafeInteger);
        if (!timestamps.some((value) => (
            Math.abs(value - request.timestamp) <= CONFIG.timestampToleranceMs
        ))) {
            throw new Error('Analytics timestamp does not match this match.');
        }

        if (!document.querySelector('#bookmakers, #maps, .analytics-player-container, #form')) {
            throw new Error('Analytics data sections are missing.');
        }
        const title = String(document.title || '').toLocaleLowerCase();
        if (/\b(?:access denied|captcha|log[ -]?in|error)\b/.test(title)) {
            throw new Error('Analytics response is not a data page.');
        }
    }

    function getInertSanitizer() {
        if (inertSanitizer) return inertSanitizer;
        if (typeof globalThis.Sanitizer !== 'function') {
            throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Secure analytics parsing is unavailable.', 'ANALYTICS_STAGE_SANITIZER_UNAVAILABLE');
        }
        inertSanitizer = new globalThis.Sanitizer({
            removeElements: CONFIG.sanitizerRemoveElements,
            removeAttributes: CONFIG.sanitizerRemoveAttributes,
            comments: false,
        });
        return inertSanitizer;
    }

    function parseInertAnalyticsHtml(value) {
        const template = globalThis.document?.createElement?.('template');
        if (!template || typeof template.setHTML !== 'function') {
            throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Secure analytics parsing is unavailable.', 'ANALYTICS_STAGE_SANITIZER_UNAVAILABLE');
        }
        try {
            template.setHTML(String(value ?? ''), { sanitizer: getInertSanitizer() });
        } catch (error) {
            throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Analytics response could not be sanitized.',
                error?.diagnosticCode === 'ANALYTICS_STAGE_SANITIZER_UNAVAILABLE'
                    ? error.diagnosticCode : 'ANALYTICS_STAGE_SANITIZE');
        }
        const html = template.innerHTML;
        let document;
        try { document = new DOMParser().parseFromString(html, 'text/html'); } catch {
            throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Analytics response could not be parsed.', 'ANALYTICS_STAGE_PARSE');
        }
        if (!document?.documentElement || document.querySelector('parsererror')) {
            throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Analytics response could not be parsed.', 'ANALYTICS_STAGE_PARSE');
        }
        return { document, html };
    }

    function pruneCache(now = Date.now()) {
        for (const [key, entry] of cache) {
            if (entry.expiresAt <= now) cache.delete(key);
        }
        while (cache.size > CONFIG.maximumCacheEntries) {
            cache.delete(cache.keys().next().value);
        }
    }

    function delay(milliseconds) {
        return new Promise((resolve) => {
            globalThis.setTimeout(resolve, milliseconds);
        });
    }

    async function delayBeforeScheduledStart(milliseconds, request) {
        ensureBeforeScheduledStart(request);
        await delay(milliseconds);
        ensureBeforeScheduledStart(request);
    }

    function validId(value) {
        return typeof value === 'string' && /^[A-Za-z0-9_-]{1,80}$/.test(value);
    }

    function diagnosticFields(value) {
        return DIAGNOSTIC_CODES.has(value) ? { diagnosticCode: value } : {};
    }

    function analyticsError(code, message, diagnosticCode) {
        return Object.assign(new Error(message), { code }, diagnosticFields(diagnosticCode));
    }

    function cancelAttempt(source, message) {
        try {
            void browser.tabs.sendMessage(source.tabId, {
                type: CONFIG.sourceCancelType,
                documentId: message.documentId,
                requestId: message.requestId,
                attemptId: message.attemptId,
                source: message.source,
            }, { frameId: 0 }).catch(() => {});
        } catch {
            // The document or extension context may already be gone.
        }
    }

    async function fetchFromSource(request, source) {
        if (browser.storage?.local) {
            const setting = await browser.storage.local.get({ extensionDisabled: false });
            if (setting.extensionDisabled === true) throw analyticsError('ANALYTICS_CONTEXT_UNAVAILABLE', 'Extension disabled.');
        }
        const remaining = ensureBeforeScheduledStart(request);
        const deadline = Date.now() + Math.min(CONFIG.timeoutMs, remaining);
        const message = {
            type: CONFIG.sourceFetchType,
            documentId: source.documentId,
            requestId: source.requestId,
            attemptId: `a${++attemptSequence}`,
            href: source.href,
            matchId: request.matchId,
            timestamp: request.timestamp,
            deadline,
            source: request.requestedSource,
        };
        let timer;
        try {
            const response = await new Promise((resolve, reject) => {
                source.onRelease = () => {
                    cancelAttempt(source, message);
                    reject(analyticsError('ANALYTICS_CONTEXT_UNAVAILABLE', 'The requesting match page is no longer available.'));
                };
                if (source.released) { source.onRelease(); return; }
                timer = globalThis.setTimeout(() => {
                    cancelAttempt(source, message);
                    reject(Date.now() >= request.timestamp ? scheduledStartError()
                        : analyticsError('ANALYTICS_TIMEOUT', 'Analytics request timed out.'));
                }, Math.max(0, deadline - Date.now()));
                Promise.resolve().then(() => browser.tabs.sendMessage(
                    source.tabId, message, { frameId: 0 },
                )).then(resolve, () => reject(analyticsError(
                    'ANALYTICS_CONTEXT_UNAVAILABLE', 'The requesting match page is no longer available.',
                )));
            });
            ensureBeforeScheduledStart(request);
            if (Date.now() >= deadline) {
                cancelAttempt(source, message);
                throw analyticsError('ANALYTICS_TIMEOUT', 'Analytics request timed out.');
            }
            if (!response || response.documentId !== message.documentId
                || response.requestId !== message.requestId || response.attemptId !== message.attemptId) {
                throw analyticsError('ANALYTICS_CONTEXT_UNAVAILABLE', 'The requesting match page is no longer available.');
            }
            if (!response.ok) {
                const code = /^(?:ANALYTICS_(?:HTTP_[1-5]\d\d|NETWORK|TIMEOUT|CONTEXT_UNAVAILABLE|STARTED|INVALID_RESPONSE|BUDGET_EXHAUSTED))$/.test(response.code || '')
                    ? response.code : 'ANALYTICS_INVALID_RESPONSE';
                const error = analyticsError(code, typeof response.error === 'string'
                    ? response.error.slice(0, CONFIG.maximumErrorCharacters) : 'Analytics request failed.', response.diagnosticCode);
                error.attemptStarted = response.attemptStarted !== false;
                throw error;
            }
            const finalUrl = safeUrl(response.url);
            if (finalUrl?.origin !== CONFIG.origin || finalUrl.username || finalUrl.password
                || finalUrl.href !== request.requestedSource.href) {
                throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Analytics request was redirected away from this match.', 'ANALYTICS_STAGE_RESPONSE_URL');
            }
            if (response.contentType !== '' && response.contentType !== 'text/html'
                && response.contentType !== 'application/xhtml+xml') {
                throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Analytics response is not HTML.', 'ANALYTICS_STAGE_RESPONSE_MIME');
            }
            if (typeof response.html !== 'string' || !response.html
                || response.html.length > CONFIG.maximumResponseBytes
                || !Number.isSafeInteger(response.byteLength) || response.byteLength <= 0
                || response.byteLength > CONFIG.maximumResponseBytes) {
                throw analyticsError('ANALYTICS_INVALID_RESPONSE', 'Analytics response is empty or exceeds its size limit.', 'ANALYTICS_STAGE_RESPONSE_BODY');
            }
            const parsed = await globalThis.HLTV_PREDICTION_OFFSCREEN.parseAndValidate(response.html, {
                matchId: request.matchId, teamNames: request.teamNames, timestamp: request.timestamp,
                requestedSource: request.requestedSource,
            });
            const fetchedAt = Date.now();
            ensureBeforeScheduledStart(request, fetchedAt);
            const entry = Object.freeze({
                html: parsed.html, fetchedAt, expiresAt: fetchedAt + request.cacheTtlMs,
            });
            cache.set(request.key, entry);
            pruneCache(fetchedAt);
            return entry;
        } finally {
            globalThis.clearTimeout(timer);
            source.onRelease = null;
        }
    }

    async function fetchAnalyticsOnce(request, job) {
        for (const [key, source] of job.sources) {
            try {
                return await fetchFromSource(request, source);
            } catch (error) {
                if (error.code !== 'ANALYTICS_CONTEXT_UNAVAILABLE') throw error;
                if (job.sources.get(key) === source) job.sources.delete(key);
                // A waiting document can serve its own original source once. Its
                // document-owned ledger remains authoritative, including after failover.
            }
        }
        throw analyticsError('ANALYTICS_CONTEXT_UNAVAILABLE', 'The requesting match page is no longer available.');
    }

    async function fetchAnalytics(request, job) {
        await delayBeforeScheduledStart(CONFIG.initialRequestDelayMs, request);
        ensureBeforeScheduledStart(request);
        return fetchAnalyticsOnce(request, job);
    }

    function loadAnalytics(request) {
        const now = Date.now();
        if (now >= request.timestamp) return Promise.reject(scheduledStartError());
        pruneCache(now);
        const cached = cache.get(request.key);
        if (cached?.expiresAt > now) return Promise.resolve({ ...cached, fromCache: true });
        const sourceKey = `${request.source.tabId}:${request.source.documentId}`;
        const existing = pending.get(request.key);
        if (existing) {
            if (existing.sources.has(sourceKey) || existing.sources.size < CONFIG.maximumRequesters) {
                existing.sources.set(sourceKey, request.source);
            }
            return existing.promise;
        }
        if (pending.size >= CONFIG.maximumPendingRequests) {
            return Promise.reject(new Error('Too many analytics requests are active.'));
        }
        const job = { sources: new Map([[sourceKey, request.source]]), promise: null };
        job.promise = fetchAnalytics(request, job).finally(() => pending.delete(request.key));
        pending.set(request.key, job);
        return job.promise;
    }

    browser.runtime.onMessage.addListener((message, sender) => {
        if (message?.type === CONFIG.sourceReleaseType) {
            const request = normaliseRequest({ ...message, type: CONFIG.sourceRequestType }, sender);
            if (!request) return Promise.resolve({ ok: false });
            const job = pending.get(request.key);
            const sourceKey = `${request.source.tabId}:${request.source.documentId}`;
            const source = job?.sources.get(sourceKey);
            if (source?.requestId === request.source.requestId) {
                source.released = true;
                source.onRelease?.();
                job.sources.delete(sourceKey);
            }
            return Promise.resolve({ ok: true });
        }
        if (message?.type !== CONFIG.sourceRequestType) return undefined;
        const request = normaliseRequest(message, sender);
        if (!request) return Promise.resolve({ ok: false, code: 'ANALYTICS_INVALID_REQUEST', error: 'Invalid analytics request.' });
        return Promise.resolve().then(async () => {
            if (browser.storage?.local) {
                const setting = await browser.storage.local.get({ extensionDisabled: false });
                if (setting.extensionDisabled === true) throw analyticsError('ANALYTICS_CONTEXT_UNAVAILABLE', 'Extension disabled. Reload to apply settings.');
            }
            return loadAnalytics(request);
        })
            .then((entry) => {
                ensureBeforeScheduledStart(request);
                return {
                    ok: true,
                    html: entry.html,
                    fetchedAt: entry.fetchedAt,
                    fromCache: entry.fromCache === true,
                };
            })
            .catch((error) => ({
                ok: false,
                code: error?.code || 'ANALYTICS_INVALID_RESPONSE',
                ...diagnosticFields(error?.diagnosticCode),
                error: String(error instanceof Error ? error.message : 'Analytics request failed.')
                    .replace(/\s+/g, ' ')
                    .trim()
                    .slice(0, CONFIG.maximumErrorCharacters),
            }));
    });

    Object.defineProperty(globalThis, 'HLTV_MATCH_PREDICTION_FETCH_TESTING', {
        configurable: true,
        enumerable: false,
        value: Object.freeze({
            config: CONFIG,
            normaliseRequest,
            normaliseSource,
            validateTeamPlayerDocument,
            validateTeamHistoryDocument,
            ensureBeforeScheduledStart,
            validateAnalyticsDocument,
            parseInertAnalyticsHtml,
            cacheSize: () => cache.size,
        }),
    });
})();
