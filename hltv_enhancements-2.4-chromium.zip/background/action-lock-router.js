// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Plennhar

(() => {
    'use strict';

    const PORT_NAME = 'hltv-sp:action-lock';
    const HLTV_ORIGIN = 'https://www.hltv.org';
    const SESSION_STORAGE_KEY = 'hltvSpActionLocksV1';
    const SESSION_SCHEMA = 1;
    const REQUEST_PATTERN = /^[A-Za-z0-9_-]{1,64}$/;
    const TOKEN_PATTERN = /^[A-Za-z0-9_-]{43}$/;
    const REACTION_KEY_PATTERN = /^(?:thread|reply):\d{1,20}$/;
    const THREAD_ID_PATTERN = /^\d{1,20}$/;
    const USER_ID_PATTERN = /^\d{1,20}$/;
    const DRAFT_ACCOUNT_ID_PATTERN = /^\d{1,20}$/;
    const MAX_ACTIVE_LOCKS_PER_TAB = 10;
    const MAX_STORED_LOCKS = 500;
    const LOCK_TIMEOUT_MS = 2 * 60 * 1000;
    const MAX_FUTURE_SKEW_MS = 30 * 1000;
    const portStates = new Map();
    const liveLocksByToken = new Map();
    let storageMutationQueue = Promise.resolve();

    function safeUrl(value) {
        try {
            return new URL(String(value || ''));
        } catch {
            return null;
        }
    }

    function senderTabId(sender) {
        return Number.isInteger(sender?.tab?.id) && sender.tab.id >= 0
            ? sender.tab.id
            : null;
    }

    function isAllowedSender(sender) {
        const url = safeUrl(sender?.url);
        return sender?.id === browser.runtime.id
            && sender?.frameId === 0
            && senderTabId(sender) !== null
            && url?.origin === HLTV_ORIGIN;
    }

    function isRequestId(value) {
        return typeof value === 'string' && REQUEST_PATTERN.test(value);
    }

    function isToken(value) {
        return typeof value === 'string' && TOKEN_PATTERN.test(value);
    }

    function normaliseTarget(kind, target) {
        if (kind === 'vote' && typeof target === 'string'
            && REACTION_KEY_PATTERN.test(target)) return target;
        if (kind === 'reply' && typeof target === 'string'
            && THREAD_ID_PATTERN.test(target)) return target;
        if (kind === 'block' && typeof target === 'string'
            && USER_ID_PATTERN.test(target)) return target;
        if (kind === 'draft' && typeof target === 'string'
            && DRAFT_ACCOUNT_ID_PATTERN.test(target)) return target;
        return '';
    }

    function lockKey(kind, target) {
        const normalisedTarget = normaliseTarget(kind, target);
        return normalisedTarget ? `${kind}:${normalisedTarget}` : '';
    }

    function randomToken() {
        const bytes = new Uint8Array(32);
        globalThis.crypto.getRandomValues(bytes);
        let binary = '';
        for (const byte of bytes) binary += String.fromCharCode(byte);
        return globalThis.btoa(binary)
            .replace(/\+/g, '-')
            .replace(/\//g, '_')
            .replace(/=+$/g, '');
    }

    function createUniqueToken(locks) {
        const existingTokens = new Set(
            [...locks.values()].map((lock) => lock.token),
        );
        for (let attempt = 0; attempt < 4; attempt += 1) {
            const token = randomToken();
            if (isToken(token) && !existingTokens.has(token)) return token;
        }
        return '';
    }

    function safePost(port, message) {
        try {
            port.postMessage(message);
            return true;
        } catch {
            return false;
        }
    }

    function disconnect(port) {
        try {
            port.disconnect();
        } catch {
            // The port may already be disconnected.
        }
    }

    function enqueueStorageMutation(operation) {
        const pending = storageMutationQueue.then(operation, operation);
        storageMutationQueue = pending.catch(() => undefined);
        return pending;
    }

    function sessionStorageApi() {
        const storage = browser.storage?.session;
        return storage
            && typeof storage.get === 'function'
            && typeof storage.set === 'function'
            && typeof storage.remove === 'function'
            ? storage
            : null;
    }

    function normaliseStoredLocks(value, now = Date.now()) {
        if (value === undefined || value === null) return new Map();
        if (!value
            || typeof value !== 'object'
            || Array.isArray(value)
            || value.schema !== SESSION_SCHEMA
            || !value.locks
            || typeof value.locks !== 'object'
            || Array.isArray(value.locks)) {
            throw new Error('Invalid action-lock session record.');
        }

        const entries = Object.entries(value.locks);
        if (entries.length > MAX_STORED_LOCKS) {
            throw new Error('Action-lock session record exceeds its safety limit.');
        }

        const locks = new Map();
        const tokens = new Set();
        for (const [storedKey, rawLock] of entries) {
            const kind = rawLock?.kind;
            const target = normaliseTarget(kind, rawLock?.target);
            const key = target ? lockKey(kind, target) : '';
            const token = rawLock?.token;
            const tabId = rawLock?.tabId;
            const expiresAt = Number(rawLock?.expiresAt);
            if (!key
                || key !== storedKey
                || !isToken(token)
                || !Number.isInteger(tabId)
                || tabId < 0
                || !Number.isFinite(expiresAt)
                || expiresAt > now + LOCK_TIMEOUT_MS + MAX_FUTURE_SKEW_MS
                || tokens.has(token)) {
                throw new Error('Invalid action-lock entry.');
            }
            if (expiresAt <= now) continue;
            tokens.add(token);
            locks.set(key, {
                key,
                kind,
                target,
                token,
                tabId,
                expiresAt,
            });
        }
        return locks;
    }

    async function readStoredLocks() {
        const storage = sessionStorageApi();
        if (!storage) throw new Error('Session storage is unavailable.');
        const result = await storage.get(SESSION_STORAGE_KEY);
        return normaliseStoredLocks(result?.[SESSION_STORAGE_KEY]);
    }

    function serialiseStoredLocks(locks) {
        return {
            schema: SESSION_SCHEMA,
            updatedAt: Date.now(),
            locks: Object.fromEntries(
                [...locks.entries()].map(([key, lock]) => [key, {
                    kind: lock.kind,
                    target: lock.target,
                    token: lock.token,
                    tabId: lock.tabId,
                    expiresAt: lock.expiresAt,
                }]),
            ),
        };
    }

    async function writeStoredLocks(locks) {
        const storage = sessionStorageApi();
        if (!storage) throw new Error('Session storage is unavailable.');
        if (!locks.size) {
            await storage.remove(SESSION_STORAGE_KEY);
            return;
        }
        await storage.set({
            [SESSION_STORAGE_KEY]: serialiseStoredLocks(locks),
        });
    }

    function lockMatches(first, second) {
        return Boolean(first
            && second
            && first.key === second.key
            && first.kind === second.kind
            && first.target === second.target
            && first.token === second.token
            && first.tabId === second.tabId
            && first.expiresAt === second.expiresAt);
    }

    function activeLockCountForTab(locks, tabId) {
        let count = 0;
        for (const lock of locks.values()) {
            if (lock.tabId === tabId) count += 1;
        }
        return count;
    }

    function forgetLiveLock(token) {
        const live = liveLocksByToken.get(token);
        if (!live) return null;
        liveLocksByToken.delete(token);
        globalThis.clearTimeout(live.timeout);
        live.state?.tokens.delete(token);
        return live;
    }

    async function expireStoredLock(expectedLock) {
        const locks = await readStoredLocks();
        const current = locks.get(expectedLock.key);
        if (!lockMatches(current, expectedLock)) return false;
        locks.delete(expectedLock.key);
        await writeStoredLocks(locks);
        const live = forgetLiveLock(expectedLock.token);
        if (live?.port) {
            safePost(live.port, {
                type: 'expired',
                token: expectedLock.token,
            });
            disconnect(live.port);
        }
        return true;
    }

    function scheduleExpiry(lock, port, state) {
        const delay = Math.max(0, lock.expiresAt - Date.now());
        const live = {
            ...lock,
            port,
            state,
            timeout: 0,
        };
        live.timeout = globalThis.setTimeout(() => {
            enqueueStorageMutation(() => expireStoredLock(lock))
                .catch(() => {
                    // Keeping an unverifiable lease until its stored expiry fails closed.
                });
        }, delay);
        liveLocksByToken.set(lock.token, live);
        state.tokens.add(lock.token);
    }

    function rejectAcquire(port, requestId, code) {
        if (!safePost(port, {
            type: 'rejected',
            requestId,
            code: code === 'contended' ? 'contended' : 'unavailable',
        })) disconnect(port);
    }

    async function acquireLock(port, state, message) {
        if (globalThis.HLTV_EXTENSION_BACKGROUND_GATE
            && !await globalThis.HLTV_EXTENSION_BACKGROUND_GATE.isEnabled()) {
            rejectAcquire(port, message?.requestId, 'disabled');
            return;
        }
        const requestId = message?.requestId;
        const kind = message?.kind;
        const target = normaliseTarget(kind, message?.target);
        const key = target ? lockKey(kind, target) : '';
        if (!isRequestId(requestId) || !key) {
            disconnect(port);
            return;
        }
        if (portStates.get(port) !== state) return;

        let locks;
        try {
            locks = await readStoredLocks();
        } catch {
            rejectAcquire(port, requestId, 'unavailable');
            return;
        }
        if (portStates.get(port) !== state) return;
        if (locks.has(key)) {
            rejectAcquire(port, requestId, 'contended');
            return;
        }
        if (activeLockCountForTab(locks, state.tabId) >= MAX_ACTIVE_LOCKS_PER_TAB) {
            rejectAcquire(port, requestId, 'unavailable');
            return;
        }
        if (locks.size >= MAX_STORED_LOCKS) {
            rejectAcquire(port, requestId, 'unavailable');
            return;
        }

        let token = '';
        try {
            token = createUniqueToken(locks);
        } catch {
            // Cryptographic token generation must fail closed.
        }
        if (!token) {
            rejectAcquire(port, requestId, 'unavailable');
            return;
        }

        const lock = {
            key,
            kind,
            target,
            token,
            tabId: state.tabId,
            expiresAt: Date.now() + LOCK_TIMEOUT_MS,
        };
        locks.set(key, lock);
        try {
            await writeStoredLocks(locks);
            const confirmedLocks = await readStoredLocks();
            if (!lockMatches(confirmedLocks.get(key), lock)) {
                rejectAcquire(port, requestId, 'unavailable');
                return;
            }
        } catch {
            rejectAcquire(port, requestId, 'unavailable');
            return;
        }

        if (portStates.get(port) !== state || !safePost(port, {
            type: 'acquired',
            requestId,
            kind,
            target,
            token,
        })) {
            try {
                const latest = await readStoredLocks();
                if (lockMatches(latest.get(key), lock)) {
                    latest.delete(key);
                    await writeStoredLocks(latest);
                }
            } catch {
                // The unclaimed lease remains fail-closed until expiry.
            }
            disconnect(port);
            return;
        }
        scheduleExpiry(lock, port, state);
    }

    async function releaseOwnedLock(port, state, message) {
        const token = message?.token;
        const kind = message?.kind;
        const target = normaliseTarget(kind, message?.target);
        const key = target ? lockKey(kind, target) : '';
        if (!isToken(token) || !key) {
            disconnect(port);
            return;
        }

        let locks;
        try {
            locks = await readStoredLocks();
            const lock = locks.get(key);
            if (!lock || lock.token !== token || lock.tabId !== state.tabId) {
                disconnect(port);
                return;
            }
            locks.delete(key);
            await writeStoredLocks(locks);
            const confirmed = await readStoredLocks();
            if (confirmed.has(key)) {
                disconnect(port);
                return;
            }
        } catch {
            // An unverifiable release must leave the lease fail-closed.
            disconnect(port);
            return;
        }

        forgetLiveLock(token);
        safePost(port, { type: 'released', token });
        disconnect(port);
    }

    browser.runtime.onConnect.addListener((port) => {
        if (port?.name !== PORT_NAME) return;
        if (!isAllowedSender(port.sender)) {
            disconnect(port);
            return;
        }

        const state = {
            tabId: senderTabId(port.sender),
            tokens: new Set(),
        };
        portStates.set(port, state);

        port.onMessage.addListener((message) => {
            if (portStates.get(port) !== state) return;
            if (message?.type === 'acquire') {
                enqueueStorageMutation(() => acquireLock(port, state, message))
                    .catch(() => rejectAcquire(port, message?.requestId, 'unavailable'));
                return;
            }
            if (message?.type === 'release') {
                enqueueStorageMutation(() => releaseOwnedLock(port, state, message))
                    .catch(() => disconnect(port));
                return;
            }
            disconnect(port);
        });

        port.onDisconnect.addListener(() => {
            if (portStates.get(port) !== state) return;
            portStates.delete(port);
            for (const token of state.tokens) {
                const live = liveLocksByToken.get(token);
                if (live?.port === port) {
                    live.port = null;
                    live.state = null;
                }
            }
            state.tokens.clear();
        });
    });
})();
