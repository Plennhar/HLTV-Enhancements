// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Plennhar

(() => {
    'use strict';

    const PORT_NAME = 'hltv-sp:reply-field';
    const HLTV_ORIGIN = 'https://www.hltv.org';
    const FIELD_URL = browser.runtime.getURL('ui/reply-field.html');
    const TOKEN_PATTERN = /^[A-Za-z0-9_-]{43}$/;
    const REQUEST_PATTERN = /^[A-Za-z0-9_-]{1,64}$/;
    const MAX_SESSIONS_PER_TAB = 20;
    const MAX_REPLY_CHARS = 50_000;
    const HALF_SESSION_TTL_MS = 10_000;
    const sessions = new Map();

    function safeUrl(value) {
        try {
            return new URL(String(value || ''));
        } catch {
            return null;
        }
    }

    function senderTabId(sender) {
        return Number.isInteger(sender?.tab?.id) && sender.tab.id >= 0
            ? sender.tab.id
            : null;
    }

    function isParentSender(sender) {
        const url = safeUrl(sender?.url);
        return sender?.id === browser.runtime.id
            && sender?.frameId === 0
            && senderTabId(sender) !== null
            && url?.origin === HLTV_ORIGIN;
    }

    function isChildSender(sender) {
        const url = safeUrl(sender?.url);
        const expected = safeUrl(FIELD_URL);
        return sender?.id === browser.runtime.id
            && Number.isInteger(sender?.frameId)
            && sender.frameId > 0
            && senderTabId(sender) !== null
            && url?.protocol === expected?.protocol
            && url?.host === expected?.host
            && url?.pathname === expected?.pathname
            && !url.search;
    }

    function isToken(value) {
        return typeof value === 'string' && TOKEN_PATTERN.test(value);
    }

    function isRequestId(value) {
        return typeof value === 'string' && REQUEST_PATTERN.test(value);
    }

    function isBoundedString(value, maximum, allowEmpty = true) {
        return typeof value === 'string'
            && value.length <= maximum
            && (allowEmpty || Boolean(value));
    }

    function cleanSuggestions(value) {
        if (!Array.isArray(value) || value.length > 10) return null;
        const names = [];
        const seen = new Set();
        for (const name of value) {
            if (!isBoundedString(name, 100, false)
                || /[\u0000-\u001f\u007f]/.test(name)
                || seen.has(name)) return null;
            seen.add(name);
            names.push(name);
        }
        return names;
    }

    function safePost(port, message) {
        try {
            port?.postMessage(message);
            return true;
        } catch {
            return false;
        }
    }

    function clearHalfSessionTimer(session) {
        if (!session?.expiryTimer) return;
        clearTimeout(session.expiryTimer);
        session.expiryTimer = 0;
    }

    function disconnectPort(port) {
        try {
            port?.disconnect();
        } catch {
            // The endpoint may already be disconnected.
        }
    }

    function disposeSession(token, notifyClosed = false) {
        const session = sessions.get(token);
        if (!session) return;
        sessions.delete(token);
        clearHalfSessionTimer(session);
        if (notifyClosed) {
            safePost(session.parentPort, { type: 'closed', token });
            safePost(session.childPort, { type: 'closed', token });
        }
        disconnectPort(session.parentPort);
        disconnectPort(session.childPort);
        session.parentPort = null;
        session.childPort = null;
    }

    function armHalfSessionExpiry(session) {
        clearHalfSessionTimer(session);
        if (session.parentPort && session.childPort) return;
        session.expiryTimer = setTimeout(() => {
            if (sessions.get(session.token) !== session
                || (session.parentPort && session.childPort)) return;
            disposeSession(session.token, true);
        }, HALF_SESSION_TTL_MS);
    }

    function notifyReady(session) {
        if (!session?.parentPort || !session.childPort) {
            armHalfSessionExpiry(session);
            return;
        }
        clearHalfSessionTimer(session);
        safePost(session.parentPort, {
            type: 'ready',
            token: session.token,
        });
        safePost(session.childPort, {
            type: 'ready',
            token: session.token,
        });
    }

    function getOrCreateSession(port, token) {
        const tabId = senderTabId(port.sender);
        const existing = sessions.get(token);
        if (existing) {
            return existing.tabId === tabId ? existing : null;
        }
        const sessionCount = [...sessions.values()]
            .filter((session) => session.tabId === tabId).length;
        if (sessionCount >= MAX_SESSIONS_PER_TAB) return null;
        const session = {
            token,
            tabId,
            parentPort: null,
            childPort: null,
            expiryTimer: 0,
        };
        sessions.set(token, session);
        armHalfSessionExpiry(session);
        return session;
    }

    function registerParent(port, token) {
        if (!isParentSender(port.sender) || !isToken(token)) {
            port.disconnect();
            return null;
        }
        const session = getOrCreateSession(port, token);
        if (!session || session.parentPort) {
            port.disconnect();
            return null;
        }
        session.parentPort = port;
        safePost(port, { type: 'registered', token, role: 'parent' });
        notifyReady(session);
        return session;
    }

    function registerChild(port, token) {
        const childUrl = safeUrl(port.sender?.url);
        if (!isToken(token)
            || !isChildSender(port.sender)
            || childUrl?.hash !== `#${token}`) {
            port.disconnect();
            return null;
        }
        const session = getOrCreateSession(port, token);
        if (!session || session.childPort) {
            port.disconnect();
            return null;
        }
        session.childPort = port;
        safePost(port, { type: 'registered', token, role: 'child' });
        notifyReady(session);
        return session;
    }

    function relayParentMessage(session, message) {
        if (message?.token !== session.token) return;
        switch (message.type) {
            case 'configure':
                if (!session.childPort
                    || !isBoundedString(message.placeholder, 500)
                    || !isBoundedString(message.label, 200, false)) return;
                safePost(session.childPort, {
                    type: 'configure',
                    token: session.token,
                    placeholder: message.placeholder,
                    label: message.label,
                });
                break;
            case 'focus':
            case 'clear':
                if (!session.childPort) return;
                safePost(session.childPort, {
                    type: message.type,
                    token: session.token,
                });
                break;
            case 'set-disabled':
                if (!session.childPort || typeof message.disabled !== 'boolean') return;
                safePost(session.childPort, {
                    type: 'set-disabled',
                    token: session.token,
                    disabled: message.disabled,
                });
                break;
            case 'request-text':
                if (!session.childPort || !isRequestId(message.requestId)) return;
                safePost(session.childPort, {
                    type: 'request-text',
                    token: session.token,
                    requestId: message.requestId,
                });
                break;
            case 'restore-text':
                if (!session.childPort
                    || !isRequestId(message.requestId)
                    || !isBoundedString(message.text, MAX_REPLY_CHARS)) return;
                safePost(session.childPort, {
                    type: 'restore-text',
                    token: session.token,
                    requestId: message.requestId,
                    text: message.text,
                });
                break;
            case 'suggestions-response': {
                if (!session.childPort || !isRequestId(message.requestId)) return;
                const names = cleanSuggestions(message.names);
                if (!names) return;
                safePost(session.childPort, {
                    type: 'suggestions-response',
                    token: session.token,
                    requestId: message.requestId,
                    names,
                });
                break;
            }
            case 'close':
                disposeSession(session.token, true);
                break;
            default:
                break;
        }
    }

    function relayChildMessage(session, message) {
        if (message?.token !== session.token) return;
        switch (message.type) {
            case 'click':
                if (!session.parentPort) return;
                safePost(session.parentPort, { type: 'click', token: session.token });
                break;
            case 'state':
                if (!session.parentPort || typeof message.hasDraft !== 'boolean') return;
                safePost(session.parentPort, {
                    type: 'state',
                    token: session.token,
                    hasDraft: message.hasDraft,
                });
                break;
            case 'text-response':
                if (!session.parentPort
                    || !isRequestId(message.requestId)
                    || !isBoundedString(message.text, MAX_REPLY_CHARS)) return;
                safePost(session.parentPort, {
                    type: 'text-response',
                    token: session.token,
                    requestId: message.requestId,
                    text: message.text,
                });
                break;
            case 'restore-response':
                if (!session.parentPort
                    || !isRequestId(message.requestId)
                    || typeof message.restored !== 'boolean'
                    || message.reason !== (message.restored ? '' : 'not-empty')) return;
                safePost(session.parentPort, {
                    type: 'restore-response',
                    token: session.token,
                    requestId: message.requestId,
                    restored: message.restored,
                    reason: message.reason,
                });
                break;
            case 'prefix-request':
                if (!session.parentPort
                    || !isRequestId(message.requestId)
                    || !isBoundedString(message.prefix, 100, false)
                    || /[\u0000-\u001f\u007f\u2063]/.test(message.prefix)) return;
                safePost(session.parentPort, {
                    type: 'prefix-request',
                    token: session.token,
                    requestId: message.requestId,
                    prefix: message.prefix,
                });
                break;
            case 'close':
                disposeSession(session.token, true);
                break;
            default:
                break;
        }
    }

    browser.runtime.onConnect.addListener((port) => {
        if (port?.name !== PORT_NAME) return;
        let role = '';
        let session = null;
        let closed = false;

        port.onMessage.addListener(async (message) => {
            if (!role) {
                if (globalThis.HLTV_EXTENSION_BACKGROUND_GATE
                    && !await globalThis.HLTV_EXTENSION_BACKGROUND_GATE.isEnabled()) {
                    disconnectPort(port);
                    return;
                }
                if (closed || role) return;
                if (message?.type !== 'register' || !isToken(message.token)) {
                    port.disconnect();
                    return;
                }
                if (message.role === 'parent') {
                    session = registerParent(port, message.token);
                } else if (message.role === 'child') {
                    session = registerChild(port, message.token);
                } else {
                    port.disconnect();
                }
                if (session) role = message.role;
                return;
            }
            if (!session || sessions.get(session.token) !== session) return;
            if (role === 'parent' && session.parentPort === port) relayParentMessage(session, message);
            else if (role === 'child' && session.childPort === port) relayChildMessage(session, message);
        });

        port.onDisconnect.addListener(() => {
            closed = true;
            if (!session || sessions.get(session.token) !== session) return;
            if (role === 'parent' && session.parentPort === port) {
                session.parentPort = null;
                safePost(session.childPort, {
                    type: 'parent-disconnected',
                    token: session.token,
                });
                armHalfSessionExpiry(session);
            } else if (role === 'child' && session.childPort === port) {
                session.childPort = null;
                safePost(session.parentPort, {
                    type: 'child-disconnected',
                    token: session.token,
                });
                armHalfSessionExpiry(session);
            }
        });
    });
})();
