// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Plennhar

(() => {
    'use strict';
    const api = globalThis.HLTV_RANKING_SNAPSHOTS;
    const PREFIX = 'hltvRankingSnapshot:v1:';
    const pending = new Map();
    const cache = new Map();
    let generation = 0;
    let attemptSequence = 0;
    let mutation = Promise.resolve();
    const validToken = (value) => typeof value === 'string' && /^[A-Za-z0-9_-]{1,80}$/.test(value);
    const failure = (code) => Object.assign(new Error(code), { code });
    const safeUrl = (value) => { try { return new URL(value); } catch { return null; } };
    function extensionSender(sender) {
        const url = safeUrl(sender?.url);
        const ownUrl = typeof browser.runtime.getURL === 'function' ? safeUrl(browser.runtime.getURL('')) : null;
        const extensionPage = ['moz-extension:', 'chrome-extension:'].includes(url?.protocol)
            && !url.username && !url.password
            && (ownUrl ? url.protocol === ownUrl.protocol && url.host === ownUrl.host
                : typeof browser.runtime.getURL !== 'function');
        return sender?.id === browser.runtime.id && (extensionPage
            || (Number.isInteger(sender.tab?.id) && sender.tab.id >= 0 && sender.frameId === 0
                && url?.origin === 'https://www.hltv.org' && !url.username && !url.password));
    }
    function normalize(message, sender) {
        const source = message?.source;
        const route = safeUrl(sender?.url);
        try {
            if (!api || sender?.id !== browser.runtime.id || sender?.frameId !== 0
                || !Number.isInteger(sender?.tab?.id) || sender.tab.id < 0
                || route?.origin !== 'https://www.hltv.org' || route.username || route.password
                || !validToken(message.documentId) || !validToken(message.requestId)
                || !/^[1-9]\d{0,19}$/.test(source?.matchId || '')
                || /^\/matches\/(\d{1,20})(?:\/|$)/.exec(route.pathname)?.[1] !== source.matchId
                || !Number.isSafeInteger(source.timestamp) || source.timestamp <= Date.now()
                || !Array.isArray(source.teams) || source.teams.length !== 2
                || source.teams.some((team) => !/^[1-9]\d{0,19}$/.test(team?.id || ''))
                || source.teams[0].id === source.teams[1].id
                || source.href !== api.sourceUrl(source.date) || source.date > api.weekBefore(source.timestamp)) return null;
            return { source, documentId: message.documentId, requestId: message.requestId, tabId: sender.tab.id,
                key: `${sender.tab.id}:${message.documentId}:${message.requestId}`, released: false, cancel: null };
        } catch { return null; }
    }
    async function enabled(request, job) {
        if (request.released || job?.generation !== generation || Date.now() >= request.source.timestamp) throw failure('RANKING_CONTEXT_UNAVAILABLE');
        const setting = await browser.storage.local.get({ extensionDisabled: false });
        if (setting.extensionDisabled === true || request.released || job?.generation !== generation
            || Date.now() >= request.source.timestamp) throw failure('RANKING_CONTEXT_UNAVAILABLE');
    }
    function serialize(operation) {
        const result = mutation.then(operation);
        mutation = result.catch(() => {});
        return result;
    }
    async function fetchFromDocument(request, job) {
        await enabled(request, job);
        // Same short pre-request throttle as the existing prediction transport.
        await new Promise((resolve) => globalThis.setTimeout(resolve, 500));
        await enabled(request, job);
        const binding = { documentId: request.documentId, requestId: request.requestId, attemptId: `a${++attemptSequence}` };
        const deadline = Math.min(Date.now() + 12000, request.source.timestamp);
        let timer;
        const cancel = () => {
            try { void browser.tabs.sendMessage(request.tabId, { type: 'hltv-sp:cancel-ranking-snapshot', ...binding, source: request.source }, { frameId: 0 }).catch(() => {}); } catch { /* Departed document. */ }
        };
        let response;
        try {
            response = await new Promise((resolve, reject) => {
                request.cancel = () => { cancel(); reject(failure('RANKING_CONTEXT_UNAVAILABLE')); };
                if (request.released) { request.cancel(); return; }
                timer = globalThis.setTimeout(() => { cancel(); reject(failure('RANKING_TIMEOUT')); }, Math.max(0, deadline - Date.now()));
                Promise.resolve().then(() => browser.tabs.sendMessage(request.tabId, {
                    type: 'hltv-sp:fetch-ranking-snapshot', ...binding, source: request.source, deadline,
                }, { frameId: 0 })).then(resolve, () => reject(failure('RANKING_CONTEXT_UNAVAILABLE')));
            });
        } finally {
            globalThis.clearTimeout(timer);
            request.cancel = null;
        }
        await enabled(request, job);
        if (Date.now() >= deadline || !response || Object.keys(binding).some((key) => response[key] !== binding[key])) throw failure('RANKING_INVALID_RESPONSE');
        if (!response.ok) throw failure(/^RANKING_[A-Z_0-9]+$/.test(response.code || '') ? response.code : 'RANKING_INVALID_RESPONSE');
        const snapshot = response.snapshot;
        if (!api.validateSnapshot(snapshot) || snapshot.date !== request.source.date
            || snapshot.fetchedAt >= request.source.timestamp || snapshot.fetchedAt > Date.now() + 60000) throw failure('RANKING_INVALID_RESPONSE');
        let storageError;
        await serialize(async () => {
            await enabled(request, job);
            try {
                // Separate keys prevent concurrent weeks from overwriting one another.
                await browser.storage.local.set({ [`${PREFIX}${snapshot.date}`]: snapshot });
                if (job.generation === generation) cache.set(snapshot.date, snapshot);
            } catch { storageError = 'Downloaded ranking snapshot could not be retained in local storage.'; }
        });
        await enabled(request, job);
        return { snapshot, storageError };
    }
    async function fetchShared(job) {
        for (const request of job.sources.values()) {
            try { return await fetchFromDocument(request, job); } catch (error) {
                if (!['RANKING_CONTEXT_UNAVAILABLE', 'RANKING_BUDGET_EXHAUSTED', 'RANKING_ALREADY_ATTEMPTED'].includes(error.code)) throw error;
            }
        }
        throw failure('RANKING_CONTEXT_UNAVAILABLE');
    }
    async function load(request) {
        const epoch = generation;
        // Reads wait for an already queued clear/write so old storage cannot
        // repopulate the in-memory cache while deletion is still pending.
        await mutation;
        await enabled(request, { generation: epoch });
        const remembered = cache.get(request.source.date);
        if (remembered && api.validateSnapshot(remembered)) return { snapshot: remembered, fromCache: true };
        let readError;
        try {
            const key = `${PREFIX}${request.source.date}`;
            const stored = (await browser.storage.local.get([key]))[key];
            await enabled(request, { generation: epoch });
            if (stored && stored.date === request.source.date && stored.fetchedAt < request.source.timestamp
                && stored.fetchedAt <= Date.now() + 60000 && api.validateSnapshot(stored)) { cache.set(request.source.date, stored); return { snapshot: stored, fromCache: true }; }
        } catch (error) {
            if (error.code === 'RANKING_CONTEXT_UNAVAILABLE') throw error;
            readError = 'Saved ranking snapshots could not be read from local storage.';
        }
        if (epoch !== generation) throw failure('RANKING_CONTEXT_UNAVAILABLE');
        let job = pending.get(request.source.date);
        if (!job) {
            if (pending.size >= 16) throw failure('RANKING_BUSY');
            job = { generation: epoch, sources: new Map(), promise: null };
            job.sources.set(request.key, request);
            pending.set(request.source.date, job);
            job.promise = Promise.resolve().then(() => fetchShared(job)).finally(() => {
                if (pending.get(request.source.date) === job) pending.delete(request.source.date);
            });
        } else {
            if (job.sources.size >= 32) throw failure('RANKING_BUSY');
            job.sources.set(request.key, request);
        }
        const result = await job.promise;
        await enabled(request, job);
        return { ...result, storageError: result.storageError || readError };
    }
    async function metadata() {
        const values = await browser.storage.local.get(null);
        const snapshots = Object.entries(values).filter(([key, value]) => key.startsWith(PREFIX) && api.validateSnapshot(value)
            && key === `${PREFIX}${value.date}`).map(([, value]) => ({ date: value.date, fetchedAt: value.fetchedAt, teams: Object.keys(value.teamsById).length, checksum: value.checksum }));
        snapshots.sort((a, b) => b.date.localeCompare(a.date));
        return { ok: true, count: snapshots.length, snapshots };
    }
    function clear() {
        generation += 1;
        cache.clear();
        for (const job of pending.values()) for (const request of job.sources.values()) { request.released = true; request.cancel?.(); }
        pending.clear();
        return serialize(async () => {
            const values = await browser.storage.local.get(null);
            const keys = Object.keys(values).filter((key) => key.startsWith(PREFIX));
            if (keys.length) await browser.storage.local.remove(keys);
            return { ok: true, cleared: keys.length };
        });
    }
    browser.runtime.onMessage.addListener((message, sender) => {
        if (['hltv-sp:clear-cached-rankings', 'hltv-sp:ranking-cache-metadata'].includes(message?.type)) {
            if (!extensionSender(sender)) return Promise.resolve({ ok: false, error: 'Invalid ranking cache request.' });
            return Promise.resolve().then(() => message.type === 'hltv-sp:clear-cached-rankings' ? clear() : metadata())
                .catch(() => ({ ok: false, error: 'Local ranking cache storage is unavailable.' }));
        }
        if (!['hltv-sp:get-ranking-snapshot', 'hltv-sp:release-ranking-snapshot'].includes(message?.type)) return undefined;
        const request = normalize(message, sender);
        if (!request) return Promise.resolve({ ok: false, code: 'RANKING_INVALID_REQUEST' });
        if (message.type === 'hltv-sp:release-ranking-snapshot') {
            const existing = pending.get(request.source.date)?.sources.get(request.key);
            if (existing) { existing.released = true; existing.cancel?.(); }
            return Promise.resolve({ ok: true });
        }
        return load(request).then((result) => ({ ok: true, ...result }))
            .catch((error) => ({ ok: false, code: error.code || 'RANKING_STORAGE_UNAVAILABLE', error: 'Ranking snapshot is unavailable.' }));
    });
})();
