// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Plennhar

(() => {
    'use strict';

    async function isEnabled() {
        try {
            const stored = await browser.storage.local.get(['extensionDisabled']);
            return stored?.extensionDisabled !== true;
        } catch {
            return false;
        }
    }
    Object.defineProperty(globalThis, 'HLTV_EXTENSION_BACKGROUND_GATE', {
        value: Object.freeze({ isEnabled }),
        configurable: false,
        writable: false,
        enumerable: false,
    });
})();
