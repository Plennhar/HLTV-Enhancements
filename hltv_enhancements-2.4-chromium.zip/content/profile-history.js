// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Plennhar
(() => {
    'use strict';
    if (globalThis.HLTV_PROFILE_HISTORY) return;
    const api = { sections: [], ready: null };
    globalThis.HLTV_PROFILE_HISTORY = api;
    const AUTO_LIMIT = 100;
    const MAX_BYTES = 2 * 1024 * 1024;
    const PAUSE_MS = 350;
    const profile = location.pathname.match(/^\/profile\/(\d+)\/([^/]+)\/?$/);
    const base = profile ? `/profile/${profile[1]}/${profile[2]}` : '';
    let pageHidden = false;
    let lastRequest = 0;
    let requestQueue = Promise.resolve();
    const text = node => (node?.textContent || '').replace(/\s+/g, ' ').trim();

    function route(raw, kind) {
        const url = new URL(raw, location.href);
        const activeSort = new URL(location.href).searchParams.get(kind === 'posts' ? 'postSort' : 'threadSort');
        const sorts = url.searchParams.getAll('sort');
        const validSort = activeSort === 'upvotes' ? sorts.length === 1 && sorts[0] === 'upvotes' : sorts.length === 0;
        let unsupportedParameter = false;
        url.searchParams.forEach((_value, name) => { if (name !== 'offset' && name !== 'sort') unsupportedParameter = true; });
        if (!validSort || unsupportedParameter || url.searchParams.getAll('offset').length !== 1 || url.origin !== location.origin || url.username || url.password || url.hash
            || url.pathname !== `${base}/${kind}`
            || !/^\d+$/.test(url.searchParams.get('offset') || '')
            || Number(url.searchParams.get('offset')) <= 0) {
            throw new Error('Invalid pagination route; loading stopped.');
        }
        return url.href;
    }

    // Use the same safe HTML sink as core. Core's parser is closure-private.
    function parse(html) {
        if (typeof Sanitizer !== 'function' || typeof Element.prototype.setHTML !== 'function') {
            throw new Error('Secure history loading requires Firefox 148 or newer.');
        }
        const template = document.createElement('template');
        template.setHTML(html, { sanitizer: new Sanitizer({
            removeElements: ['script', 'style', 'iframe', 'frame', 'frameset', 'object', 'embed',
                'link', 'meta', 'base', 'audio', 'video', 'source', 'track', 'img', 'picture',
                'applet', 'portal', 'noscript', { name: 'svg', namespace: 'http://www.w3.org/2000/svg' },
                { name: 'math', namespace: 'http://www.w3.org/1998/Math/MathML' }],
            removeAttributes: ['src', 'srcset', 'imagesrcset', 'imagesizes', 'style', 'background',
                'data', 'poster', 'ping', 'manifest'], comments: false,
        }) });
        // Pagination is interpreted as data only; imported rows never execute HTMX.
        for (const element of template.content.querySelectorAll('*')) {
            for (const attribute of [...element.attributes]) {
                if (/^(?:on|data-hx-|hx-)/i.test(attribute.name) && attribute.name !== 'hx-get') {
                    element.removeAttribute(attribute.name);
                }
            }
        }
        return template.content;
    }

    async function read(response) {
        if (!response.ok) throw new Error(`History request failed (${response.status}).`);
        if (!/text\/html|application\/xhtml\+xml/i.test(response.headers.get('content-type') || 'text/html')) {
            throw new Error('Unexpected history response type.');
        }
        if (Number(response.headers.get('content-length')) > MAX_BYTES) throw new Error('History response is too large.');
        if (!response.body?.getReader) throw new Error('Bounded history streaming is unavailable.');
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let bytes = 0;
        let html = '';
        try {
            while (true) {
                const part = await reader.read();
                if (part.done) break;
                bytes += part.value.byteLength;
                if (bytes > MAX_BYTES) throw new Error('History response is too large.');
                html += decoder.decode(part.value, { stream: true });
            }
            return html + decoder.decode();
        } finally {
            try { await reader.cancel(); } catch { /* Response may already be closed. */ }
            reader.releaseLock();
        }
    }

    function rowsIn(root, kind) {
        return kind === 'posts'
            ? [...root.querySelectorAll('.post')].map(node => node.closest('a')).filter(Boolean)
            : [...root.querySelectorAll('.box-item.plus-row')];
    }
    function allowedLink(url, kind) {
        return url.origin === location.origin && (kind === 'threads'
            ? /^\/forums\/threads\/\d+\//.test(url.pathname)
            : /^\/(?:forums\/threads|news|matches)\/\d+\//.test(url.pathname));
    }
    function key(row, kind) {
        const anchor = row.matches('a') ? row : row.querySelector('a');
        if (!anchor) return null;
        try {
            const url = new URL(anchor.getAttribute('href'), location.href);
            if (!allowedLink(url, kind)) return null;
            return url.href;
        } catch { return null; }
    }
    function searchText(row, kind) {
        if (kind === 'threads') return text(row.querySelector('a')).toLocaleLowerCase();
        const title = row.querySelector('.headline')?.cloneNode(true);
        title?.querySelectorAll('.plus-count').forEach(node => node.remove());
        return `${text(title)} ${text(row.querySelector('.content'))}`.toLocaleLowerCase();
    }
    function update(section) {
        const query = section.input.value.trim().toLocaleLowerCase();
        let matches = 0;
        for (const row of section.rows) {
            row.hidden = !!query && !searchText(row, section.kind).includes(query);
            row.toggleAttribute('data-hltv-history-hidden', row.hidden);
            if (!row.hidden) matches++;
        }
        const state = section.error ? `Error: ${section.error}` : section.loading ? 'Loading…'
            : section.cancelled ? 'Cancelled — partial history.'
                : section.next || section.pending.length ? 'Partial history.' : 'Complete history.';
        section.status.textContent = `${matches} of ${section.rows.length} loaded entries match. ${state}${section.kind === 'posts' ? ' Searches titles and available comment excerpts; excerpts may be truncated.' : ' Searches thread titles.'}`;
        section.button.textContent = section.loading ? 'Cancel' : section.cancelled || section.error ? 'Resume loading' : 'Continue loading';
        section.button.disabled = !section.loading && !section.next && !section.pending.length;
    }
    function suppressLoader(section) {
        for (const loader of section.container.querySelectorAll('.load-more')) {
            if (loader.hasAttribute('hx-get')) {
                const raw = loader.getAttribute('hx-get');
                try { section.next = route(raw, section.kind); }
                catch (error) { section.error = error.message; section.next = null; }
                loader.removeAttribute('hx-get');
                loader.removeAttribute('hx-trigger');
                loader.removeAttribute('hx-swap');
                loader.hidden = true;
            }
        }
    }
    function collect(section) {
        for (const row of rowsIn(section.container, section.kind)) {
            if (section.rows.includes(row)) continue;
            const identity = key(row, section.kind);
            if (!identity || section.keys.has(identity)) {
                row.hidden = true;
                row.setAttribute('data-hltv-history-hidden', '');
                continue;
            }
            section.keys.add(identity);
            section.rows.push(row);
        }
        suppressLoader(section);
        update(section);
    }
    function flush(section, limit) {
        let remaining = limit - section.rows.length;
        while (section.pending.length && remaining > 0) {
            remaining--;
            const row = section.pending.shift();
            // Rebuild as data-only links and text; preserve row markup and upvote labels.
            for (const node of [row, ...row.querySelectorAll('*')]) {
                for (const attribute of [...node.attributes]) {
                    if (/^(?:on|data-hx-|hx-)/i.test(attribute.name)) node.removeAttribute(attribute.name);
                }
                if (node.matches('a')) {
                    const href = node.getAttribute('href');
                    try {
                        const url = new URL(href, location.href);
                        if (!allowedLink(url, section.kind)) node.removeAttribute('href');
                    } catch { node.removeAttribute('href'); }
                }
            }
            section.container.append(document.importNode(row, true));
        }
        collect(section);
    }
    async function fetchPage(section, signal) {
        // Share a queue between columns so continuing both cannot burst requests.
        let release;
        const prior = requestQueue;
        requestQueue = new Promise(resolve => { release = resolve; });
        await prior;
        try {
            const delay = Math.max(0, lastRequest + PAUSE_MS - Date.now());
            if (delay) await new Promise(resolve => setTimeout(resolve, delay));
            if (signal.aborted) throw new DOMException('Cancelled', 'AbortError');
            lastRequest = Date.now();
            const response = await fetch(section.next, { credentials: 'same-origin', redirect: 'error', signal,
                headers: { 'HX-Request': 'true', Accept: 'text/html' } });
            return parse(await read(response));
        } finally { release(); }
    }
    async function load(section, limit) {
        if (section.loading || pageHidden) return;
        section.loading = true;
        section.cancelled = false;
        section.error = '';
        section.controller = new AbortController();
        update(section);
        try {
            flush(section, limit);
            while (!pageHidden && section.next && section.rows.length < limit) {
                const current = section.next;
                if (section.visited.has(current)) throw new Error('Pagination loop detected.');
                const fragment = await fetchPage(section, section.controller.signal);
                if (section.controller.signal.aborted) throw new DOMException('Cancelled', 'AbortError');
                let scope = fragment;
                if (fragment.querySelector('.userprofile')) {
                    scope = [...fragment.querySelectorAll('.userprofile .box-items')].find(column =>
                        text(column.querySelector('.sort-headline')?.firstChild).startsWith(section.label));
                    if (!scope) throw new Error('History response did not contain the requested section.');
                }
                const loaders = [...scope.querySelectorAll('.load-more[hx-get]')];
                if (loaders.length > 1) throw new Error('Ambiguous history pagination.');
                const next = loaders.length ? route(loaders[0].getAttribute('hx-get'), section.kind) : null;
                if (next && (next === current || section.visited.has(next)
                    || Number(new URL(next).searchParams.get('offset')) <= Number(new URL(current).searchParams.get('offset')))) {
                    throw new Error('Pagination loop detected.');
                }
                const batchKeys = new Set(section.keys);
                const rawRows = rowsIn(scope, section.kind);
                if (!rawRows.length && !loaders.length && (scope.querySelector('*') || text(scope))) {
                    throw new Error('Unexpected history response; loaded entries remain searchable.');
                }
                const rows = rawRows.filter(row => {
                    const identity = key(row, section.kind);
                    if (!identity || batchKeys.has(identity)) return false;
                    batchKeys.add(identity); return true;
                });
                if (!rows.length && next) throw new Error('History pagination made no progress.');
                section.visited.add(current);
                section.next = next;
                section.pending.push(...rows);
                flush(section, limit);
            }
        } catch (error) {
            if (error.name === 'AbortError') section.cancelled = true;
            else section.error = error.message || 'History could not be loaded.';
        } finally {
            section.loading = false;
            update(section);
        }
    }
    function setup(column, kind, label) {
        const container = column.querySelector(kind === 'posts' ? '.posts' : '.standard-box');
        if (!container) return;
        const controls = document.createElement('div');
        controls.dataset.hltvHistoryControls = kind;
        controls.style.cssText = 'display:flex;flex-wrap:wrap;gap:6px;padding:8px 0;align-items:center';
        const input = document.createElement('input');
        input.type = 'search'; input.placeholder = `Search ${label.toLowerCase()}`;
        input.setAttribute('aria-label', `Search ${label.toLowerCase()}`);
        input.style.cssText = 'min-width:100px;flex:1;color:inherit;background:transparent;border:1px solid #888;padding:5px';
        const button = document.createElement('button'); button.type = 'button';
        const status = document.createElement('div'); status.setAttribute('role', 'status'); status.style.flexBasis = '100%';
        controls.append(input, button, status); container.before(controls);
        const section = { kind, label, container, input, button, status, rows: [], keys: new Set(),
            visited: new Set(), pending: [], next: null, loading: false, error: '', cancelled: false };
        api.sections.push(section);
        input.addEventListener('input', () => update(section));
        button.addEventListener('click', () => {
            if (section.loading) { section.cancelled = true; section.controller.abort(); update(section); }
            else void load(section, Infinity);
        });
        collect(section);
        const observer = new MutationObserver(() => collect(section));
        observer.observe(container, { childList: true, subtree: true });
        section.observer = observer;
    }
    function installPageLifecycleListeners() {
        globalThis.addEventListener('pagehide', () => {
            pageHidden = true;
            for (const section of api.sections) {
                section.observer.disconnect();
                if (section.loading) {
                    section.cancelled = true;
                    section.controller.abort();
                }
                update(section);
            }
        });
        globalThis.addEventListener('pageshow', event => {
            if (!event.persisted) return;
            pageHidden = false;
            for (const section of api.sections) {
                // Restoring a document never restarts network work without a click.
                section.observer.observe(section.container, { childList: true, subtree: true });
                collect(section);
            }
        });
    }
    api.ready = (async () => {
        try {
            if (!profile || (globalThis.HLTV_EXTENSION_GATE?.ready && !await globalThis.HLTV_EXTENSION_GATE.ready)) return;
            installPageLifecycleListeners();
            if (document.readyState === 'loading') await new Promise(resolve => document.addEventListener('DOMContentLoaded', resolve, { once: true }));
            const style = document.createElement('style');
            style.textContent = `
                .userprofile [data-hltv-history-hidden] { display: none !important; }
                .userprofile [data-hltv-history-controls] button {
                    background: #435365;
                    border: 1px solid #596f84;
                    border-radius: 2px;
                    color: #aeb5b9;
                    cursor: pointer;
                    font: inherit;
                    min-height: 28px;
                    padding: 5px 9px;
                }
                .userprofile [data-hltv-history-controls] button:hover:not(:disabled) {
                    background: #50647a;
                    color: #fff;
                }
                .userprofile [data-hltv-history-controls] button:focus-visible {
                    outline: 2px solid #5f89b3;
                    outline-offset: 2px;
                }
                .userprofile [data-hltv-history-controls] button:disabled {
                    cursor: default;
                    opacity: .55;
                }
            `;
            document.head.append(style);
            for (const column of document.querySelectorAll('.userprofile .box-items')) {
                const heading = column.querySelector('.sort-headline, :scope > .headline');
                const title = [...(heading?.childNodes || [])].filter(node => node.nodeType === Node.TEXT_NODE).map(text).join(' ').trim();
                if (title === 'Authored threads') setup(column, 'threads', title);
                if (title === 'Forum posts') setup(column, 'posts', title);
            }
            for (const eventName of ['htmx:beforeRequest', 'htmx:beforeSwap']) {
                document.addEventListener(eventName, event => {
                    const target = event.detail?.elt || event.detail?.target || event.target;
                    if (api.sections.some(section => section.container.contains(target))) event.preventDefault();
                }, true);
            }
            for (const section of api.sections) if (!section.error) void load(section, AUTO_LIMIT);
        } catch { /* Core gate failures leave the native profile untouched. */ }
    })();
})();
