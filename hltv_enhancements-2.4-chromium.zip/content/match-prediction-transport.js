// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Plennhar

(async () => {
    'use strict';
    if (globalThis.HLTV_EXTENSION_GATE && !await globalThis.HLTV_EXTENSION_GATE.ready) return;
    const GLOBAL = 'HLTV_MATCH_PREDICTION_TRANSPORT_V23';
    if (globalThis[GLOBAL]) return;
    const CONFIG = Object.freeze({
        requestType: 'hltv-sp:get-prediction-source',
        fetchType: 'hltv-sp:fetch-prediction-source',
        cancelType: 'hltv-sp:cancel-prediction-source',
        releaseType: 'hltv-sp:release-prediction-source',
        maximumAttempts: 3,
        timeoutMs: 12_000,
        maximumBytes: 4 * 1024 * 1024,
        origin: 'https://www.hltv.org',
    });
    const browser = globalThis.browser;
    // Match the coordinator's finite diagnostic vocabulary; message data cannot extend it.
    const DIAGNOSTIC_CODES = new Set([
        'ANALYTICS_STAGE_RESPONSE_URL', 'ANALYTICS_STAGE_RESPONSE_MIME',
        'ANALYTICS_STAGE_RESPONSE_LENGTH', 'ANALYTICS_STAGE_RESPONSE_BODY', 'ANALYTICS_STAGE_RESPONSE_STREAM',
        'ANALYTICS_STAGE_SANITIZER_UNAVAILABLE', 'ANALYTICS_STAGE_SANITIZE', 'ANALYTICS_STAGE_PARSE',
        'ANALYTICS_STAGE_TEAM_TIME_FILTER', 'ANALYTICS_STAGE_TEAM_VERSION_FILTER',
        'ANALYTICS_STAGE_TEAM_FORM_FILTER', 'ANALYTICS_STAGE_TEAM_EXTRA_FILTER',
        'ANALYTICS_STAGE_TEAM_IDENTITY', 'ANALYTICS_STAGE_TEAM_TABLE', 'ANALYTICS_STAGE_TEAM_TITLE',
        'ANALYTICS_STAGE_ANALYTICS_DOCUMENT',
    ]);
    const ledger = {
        documentId: globalThis.crypto.randomUUID(),
        attemptsStarted: 0,
        sequence: 0,
        sources: null,
        slots: new Map(),
    };
    let owner = null;
    let listenerInstalled = false;

    function diagnosticFields(value) {
        return DIAGNOSTIC_CODES.has(value) ? { diagnosticCode: value } : {};
    }
    function failure(code, message = 'Prediction source is unavailable.', diagnosticCode) {
        return Object.assign(new Error(message), { code }, diagnosticFields(diagnosticCode));
    }
    function safeUrl(value) {
        try { return new URL(String(value || ''), CONFIG.origin); } catch { return null; }
    }
    function validUrl(url) {
        return url?.origin === CONFIG.origin && !url.username && !url.password && !url.hash;
    }
    function freeze(value) {
        if (value && typeof value === 'object') {
            Object.values(value).forEach(freeze);
            Object.freeze(value);
        }
        return value;
    }
    function monthWindow(now) {
        const end = new Date(now);
        const start = new Date(Date.UTC(end.getUTCFullYear(), end.getUTCMonth() - 1, 1));
        const lastDay = new Date(Date.UTC(start.getUTCFullYear(), start.getUTCMonth() + 1, 0)).getUTCDate();
        start.setUTCDate(Math.min(end.getUTCDate(), lastDay));
        return { startDate: start.toISOString().slice(0, 10), endDate: end.toISOString().slice(0, 10) };
    }
    function historyWindow(now) {
        // Team history exposes calendar dates, so exclude the current day entirely.
        const end = new Date(now);
        end.setUTCHours(0, 0, 0, 0);
        end.setUTCDate(end.getUTCDate() - 1);
        const start = new Date(end);
        start.setUTCDate(start.getUTCDate() - 89);
        return { startDate: start.toISOString().slice(0, 10), endDate: end.toISOString().slice(0, 10) };
    }
    function active(source, currentOwner = owner) {
        if (!currentOwner || currentOwner !== owner || currentOwner.destroyed || currentOwner.paused
            || Date.now() >= source.timestamp) return false;
        let identity;
        try { identity = currentOwner.getIdentity(); } catch { return false; }
        const route = /^\/matches\/(\d{1,20})(?:\/|$)/.exec(location.pathname)?.[1];
        return route === source.matchId && identity?.phase === 'scheduled'
            && identity.matchId === source.matchId && identity.timestamp === source.timestamp
            && source.teams.every((team, index) => team.id === identity.teams?.[index]?.id);
    }
    function findSlot(source) {
        const slot = ledger.slots.get(source?.sourceKey);
        return slot && slot.source === source ? slot : null;
    }
    function buildPlan(rawMatch) {
        if (ledger.sources) return ledger.sources;
        if (!/^\d{1,20}$/.test(rawMatch?.matchId || '')
            || !Number.isSafeInteger(rawMatch.timestamp) || rawMatch.timestamp <= Date.now()
            || !Array.isArray(rawMatch.teams) || rawMatch.teams.length !== 2
            || rawMatch.teams.some((team) => !/^\d{1,20}$/.test(team?.id || '')
                || typeof team.name !== 'string' || !team.name.trim() || team.name.length > 80)
            || rawMatch.teams[0].id === rawMatch.teams[1].id) return Object.freeze([]);
        const teams = rawMatch.teams.map(({ id, name }) => ({ id, name: name.trim() }));
        const common = { matchId: rawMatch.matchId, teams, timestamp: rawMatch.timestamp };
        const sources = [];
        const analytics = safeUrl(rawMatch.analyticsHref);
        if (validUrl(analytics) && !analytics.search
            && /^\/betting\/analytics\/(\d{1,20})(?:\/|$)/.exec(analytics.pathname)?.[1] === rawMatch.matchId) {
            sources.push({ ...common, sourceKey: 'analytics', kind: 'analytics', teamId: '', window: null, href: analytics.href });
        }
        const window = owner.history ? historyWindow(Date.now()) : monthWindow(Date.now());
        rawMatch.teams.forEach((team, index) => {
            const teamUrl = safeUrl(team.href);
            const match = /^\/team\/(\d{1,20})\/([a-zA-Z0-9_-]+)\/?$/.exec(teamUrl?.pathname || '');
            if (!validUrl(teamUrl) || teamUrl.search || match?.[1] !== team.id) return;
            const kind = owner.history ? 'team-history' : 'team-players';
            const href = new URL(`/stats/teams/${owner.history ? 'matches' : 'players'}/${team.id}/${match[2]}`, CONFIG.origin);
            href.searchParams.set('csVersion', 'CS2');
            href.searchParams.set('endDate', window.endDate);
            href.searchParams.set('startDate', window.startDate);
            sources.push({ ...common, sourceKey: `${kind}-${index}`, kind, teamId: team.id, window, href: href.href });
        });
        ledger.sources = freeze(sources);
        for (const source of sources) ledger.slots.set(source.sourceKey, {
            source, state: 'idle', attempted: false, requestId: '', attemptId: '',
            controller: null, promise: null, result: null, error: null, reject: null,
        });
        return ledger.sources;
    }
    async function cancelBody(body, reason) {
        try { await body?.cancel?.(reason); } catch { /* A locked or failed stream may reject. */ }
    }
    async function readBoundedHtml(response, signal) {
        const rawLength = response.headers.get('content-length');
        if (rawLength !== null && (!/^(?:0|[1-9]\d*)$/.test(rawLength)
            || !Number.isSafeInteger(Number(rawLength)) || Number(rawLength) > CONFIG.maximumBytes)) {
            await cancelBody(response.body);
            throw failure('ANALYTICS_INVALID_RESPONSE', 'Prediction response exceeds its size limit.', 'ANALYTICS_STAGE_RESPONSE_LENGTH');
        }
        if (!response.body?.getReader || typeof globalThis.TextDecoder !== 'function') {
            throw failure('ANALYTICS_INVALID_RESPONSE', 'Prediction response stream is unavailable.', 'ANALYTICS_STAGE_RESPONSE_STREAM');
        }
        const reader = response.body.getReader();
        const abort = () => { void reader.cancel(signal.reason).catch(() => {}); };
        signal.addEventListener('abort', abort, { once: true });
        const decoder = new TextDecoder('utf-8');
        let html = '';
        let byteLength = 0;
        try {
            while (true) {
                if (signal.aborted) throw signal.reason;
                const chunk = await reader.read();
                if (signal.aborted) throw signal.reason;
                if (chunk.done) break;
                if (!ArrayBuffer.isView(chunk.value)) throw failure('ANALYTICS_INVALID_RESPONSE', undefined, 'ANALYTICS_STAGE_RESPONSE_STREAM');
                byteLength += chunk.value.byteLength;
                if (byteLength > CONFIG.maximumBytes) throw failure('ANALYTICS_INVALID_RESPONSE', 'Prediction response exceeds its size limit.', 'ANALYTICS_STAGE_RESPONSE_BODY');
                html += decoder.decode(chunk.value, { stream: true });
            }
            html += decoder.decode();
            if (!byteLength || html.length > CONFIG.maximumBytes) throw failure('ANALYTICS_INVALID_RESPONSE', undefined, 'ANALYTICS_STAGE_RESPONSE_BODY');
            return { html, byteLength };
        } catch (error) {
            try { await reader.cancel(error); } catch { /* Already cancelled. */ }
            throw error;
        } finally {
            signal.removeEventListener('abort', abort);
            try { reader.releaseLock(); } catch { /* Already released. */ }
        }
    }
    function handleMessage(message, sender) {
        if (![CONFIG.fetchType, CONFIG.cancelType].includes(message?.type)) return undefined;
        const senderUrl = safeUrl(sender?.url);
        const extensionUrl = safeUrl(browser.runtime.getURL(''));
        if (sender?.id !== browser.runtime.id || sender?.tab
            || senderUrl?.protocol !== extensionUrl?.protocol || senderUrl?.host !== extensionUrl?.host
            || message.documentId !== ledger.documentId
            || !/^a\d{1,20}$/.test(message.attemptId || '')) return undefined;
        const slot = ledger.slots.get(message.source?.sourceKey);
        const binding = { documentId: ledger.documentId, requestId: message.requestId, attemptId: message.attemptId };
        if (message.type === CONFIG.cancelType) {
            if (slot?.requestId === message.requestId && slot.attemptId === message.attemptId) {
                slot.controller?.abort(failure('ANALYTICS_TIMEOUT'));
            }
            return Promise.resolve({ ...binding, ok: true });
        }
        const unavailable = (code = 'ANALYTICS_CONTEXT_UNAVAILABLE') => Promise.resolve({
            ...binding, ok: false, attemptStarted: false, code, error: 'Prediction source is unavailable.',
        });
        if (!slot || slot.state !== 'pending' || slot.attempted || slot.requestId !== message.requestId
            || JSON.stringify(message.source) !== JSON.stringify(slot.source)
            || slot.epoch !== owner?.epoch || !active(slot.source) || !Number.isSafeInteger(message.deadline)
            || message.deadline <= Date.now()
            || message.deadline > Math.min(slot.source.timestamp, Date.now() + CONFIG.timeoutMs)) return unavailable();
        if (ledger.attemptsStarted >= CONFIG.maximumAttempts) return unavailable('ANALYTICS_BUDGET_EXHAUSTED');
        const currentOwner = owner;
        const controller = new AbortController();
        slot.controller = controller;
        slot.attemptId = message.attemptId;
        const timer = globalThis.setTimeout(() => controller.abort(failure(
            Date.now() >= slot.source.timestamp ? 'ANALYTICS_STARTED' : 'ANALYTICS_TIMEOUT',
        )), Math.max(0, message.deadline - Date.now()));
        const aborted = new Promise((resolve, reject) => {
            controller.signal.addEventListener('abort', () => reject(controller.signal.reason), { once: true });
        });
        const operation = (async () => {
            // No await may separate this document-owned debit from its one fetch call.
            slot.attempted = true;
            ledger.attemptsStarted += 1;
            let response;
            try {
                response = await globalThis.fetch(slot.source.href, {
                    method: 'GET', credentials: 'include', headers: { Accept: 'text/html' },
                    cache: 'no-store', redirect: 'error', signal: controller.signal,
                });
            } catch {
                throw controller.signal.aborted ? controller.signal.reason : failure('ANALYTICS_NETWORK');
            }
            if (controller.signal.aborted) {
                await cancelBody(response.body, controller.signal.reason);
                throw controller.signal.reason;
            }
            if (!response.ok || response.redirected || response.url !== slot.source.href) {
                await cancelBody(response.body);
                throw failure(!response.ok ? `ANALYTICS_HTTP_${response.status}` : 'ANALYTICS_INVALID_RESPONSE',
                    undefined, !response.ok ? undefined : 'ANALYTICS_STAGE_RESPONSE_URL');
            }
            const contentType = String(response.headers.get('content-type') || '').split(';', 1)[0].trim().toLowerCase();
            if (contentType && !['text/html', 'application/xhtml+xml'].includes(contentType)) {
                await cancelBody(response.body);
                throw failure('ANALYTICS_INVALID_RESPONSE', undefined, 'ANALYTICS_STAGE_RESPONSE_MIME');
            }
            const payload = await readBoundedHtml(response, controller.signal);
            if (!active(slot.source, currentOwner) || Date.now() >= message.deadline) throw failure(
                Date.now() >= slot.source.timestamp ? 'ANALYTICS_STARTED' : 'ANALYTICS_CONTEXT_UNAVAILABLE',
            );
            return { ...binding, ...payload, ok: true, url: response.url, contentType };
        })();
        return Promise.race([operation, aborted]).catch((error) => ({
            ...binding, ok: false, attemptStarted: true,
            code: error?.code || 'ANALYTICS_INVALID_RESPONSE', error: 'Prediction source request failed.',
            ...diagnosticFields(error?.diagnosticCode),
        })).finally(() => {
            globalThis.clearTimeout(timer);
            if (slot.attemptId === message.attemptId) slot.controller = null;
        });
    }
    function release(slot) {
        if (!slot.requestId) return;
        try {
            void browser.runtime.sendMessage({
                type: CONFIG.releaseType, documentId: ledger.documentId, requestId: slot.requestId,
                source: slot.source,
            }).catch(() => {});
        } catch { /* Extension context may have disappeared. */ }
    }
    function pause(currentOwner) {
        currentOwner.paused = true;
        currentOwner.epoch += 1;
        for (const slot of ledger.slots.values()) {
            if (slot.state !== 'pending') continue;
            release(slot);
            const error = failure(Date.now() >= slot.source.timestamp ? 'ANALYTICS_STARTED' : 'ANALYTICS_CONTEXT_UNAVAILABLE');
            error.pausedBeforeFetch = !slot.attempted;
            slot.controller?.abort(error);
            slot.reject?.(error);
        }
    }
    function create({ getIdentity, onDiagnostic = () => {}, history = false }) {
        if (typeof getIdentity !== 'function') throw new TypeError('Prediction identity reader is required.');
        if (owner && !owner.destroyed) pause(owner);
        const currentOwner = { getIdentity, onDiagnostic, history: history === true, paused: false, destroyed: false, epoch: 0 };
        owner = currentOwner;
        if (!listenerInstalled) {
            browser.runtime.onMessage.addListener(handleMessage);
            listenerInstalled = true;
        }
        const api = {
            plan: buildPlan,
            settle(source) {
                const slot = findSlot(source);
                if (!slot || slot.state !== 'idle' || slot.attempted) return false;
                slot.state = 'cached';
                return true;
            },
            load(source) {
                const slot = findSlot(source);
                if (!slot || !active(source, currentOwner)) return Promise.reject(failure('ANALYTICS_CONTEXT_UNAVAILABLE'));
                if (slot.result) return Promise.resolve(slot.result);
                if (slot.promise) return slot.promise;
                if (slot.state !== 'idle') return Promise.reject(slot.error || failure('ANALYTICS_ALREADY_SETTLED'));
                slot.state = 'pending';
                slot.epoch = currentOwner.epoch;
                slot.requestId = `r${++ledger.sequence}`;
                const requestId = slot.requestId;
                const epoch = currentOwner.epoch;
                let timer;
                const cancelled = new Promise((resolve, reject) => { slot.reject = reject; });
                const operation = Promise.resolve().then(() => {
                    if (!active(source, currentOwner) || currentOwner.epoch !== epoch || slot.requestId !== requestId) throw failure('ANALYTICS_CONTEXT_UNAVAILABLE');
                    return browser.runtime.sendMessage({
                        type: CONFIG.requestType, documentId: ledger.documentId, requestId, source,
                    });
                }).then((response) => {
                    if (!active(source, currentOwner) || currentOwner.epoch !== epoch || slot.requestId !== requestId) throw failure('ANALYTICS_CONTEXT_UNAVAILABLE');
                    if (!response?.ok) throw failure(response?.code || 'ANALYTICS_INVALID_RESPONSE', undefined, response?.diagnosticCode);
                    if (typeof response.html !== 'string' || !response.html || response.html.length > CONFIG.maximumBytes
                        || !Number.isSafeInteger(response.fetchedAt) || response.fetchedAt >= source.timestamp
                        || response.fetchedAt > Date.now() + 60_000) throw failure('ANALYTICS_INVALID_RESPONSE');
                    return Object.freeze({ html: response.html, fetchedAt: response.fetchedAt, source, fromCache: response.fromCache === true });
                });
                timer = globalThis.setTimeout(() => {
                    release(slot);
                    slot.controller?.abort(failure('ANALYTICS_TIMEOUT'));
                    slot.reject?.(failure(Date.now() >= source.timestamp ? 'ANALYTICS_STARTED' : 'ANALYTICS_TIMEOUT'));
                }, Math.max(0, Math.min(CONFIG.timeoutMs + 1000, source.timestamp - Date.now())));
                slot.promise = Promise.race([operation, cancelled]).then((result) => {
                    slot.result = result;
                    slot.state = result.fromCache ? 'cached' : 'ready';
                    return result;
                }).catch((error) => {
                    const pausedBeforeFetch = !slot.attempted && error.pausedBeforeFetch
                        && error.code === 'ANALYTICS_CONTEXT_UNAVAILABLE';
                    slot.error = pausedBeforeFetch ? null : error;
                    slot.state = pausedBeforeFetch ? 'idle' : 'failed';
                    try { currentOwner.onDiagnostic({ code: error.diagnosticCode || error.code || 'ANALYTICS_INVALID_RESPONSE' }); } catch { /* Optional diagnostics. */ }
                    throw error;
                }).finally(() => {
                    globalThis.clearTimeout(timer);
                    slot.reject = null;
                    slot.promise = null;
                });
                return slot.promise;
            },
            cancel() { pause(currentOwner); },
            suspend() { pause(currentOwner); },
            resume() { if (!currentOwner.destroyed && owner === currentOwner) currentOwner.paused = false; },
            destroy() { pause(currentOwner); currentOwner.destroyed = true; },
            snapshot() {
                return freeze({ documentId: ledger.documentId, used: ledger.attemptsStarted,
                    remaining: CONFIG.maximumAttempts - ledger.attemptsStarted,
                    sources: [...ledger.slots.values()].map((slot) => ({ sourceKey: slot.source.sourceKey, state: slot.state, attempted: slot.attempted })) });
            },
        };
        return Object.freeze(api);
    }
    globalThis.addEventListener('pagehide', () => { if (owner) pause(owner); });
    Object.defineProperty(globalThis, GLOBAL, {
        configurable: false, enumerable: false, writable: false,
        value: Object.freeze({ create, config: CONFIG }),
    });
})();
