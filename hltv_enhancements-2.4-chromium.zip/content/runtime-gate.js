// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Plennhar

(() => {
    'use strict';

    // Snapshot once per document. Changing the master setting takes effect only
    // after reload, so running pages never enter a partially disabled state.
    const ready = (async () => {
        try {
            const stored = await globalThis.browser.storage.local.get(['extensionDisabled']);
            return stored?.extensionDisabled !== true;
        } catch {
            return false;
        }
    })();
    Object.defineProperty(globalThis, 'HLTV_EXTENSION_GATE', {
        value: Object.freeze({ ready }),
        configurable: false,
        writable: false,
        enumerable: false,
    });
})();
