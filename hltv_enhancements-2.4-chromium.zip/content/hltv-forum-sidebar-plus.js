// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Plennhar

(async () => {
    'use strict';

    // Keep settings available while disabled. Feature activation stays fixed to
    // this document's startup snapshot, even when the master setting is saved.
    const featureRuntimeEnabled = !globalThis.HLTV_EXTENSION_GATE
        || await globalThis.HLTV_EXTENSION_GATE.ready;

    const SCRIPT_VERSION = '2.4';
    const UI_COMPAT_VERSION = '1.7.0';
    const HLTV_ORIGIN = 'https://www.hltv.org';
    const FEEDBACK_MAILTO = 'mailto:plenhar@proton.me';
    const FEATURE_PAGE_PATH_BY_HELP_ID = Object.freeze({
        'hltv-sp-custom-thread-fetching-help': '/',
        'hltv-sp-custom-thread-colors-help': '/',
        'hltv-sp-forum-offtopic-help': '/forums/offtopic',
        'hltv-sp-forum-counterstrike-help': '/forums/counterstrike',
        'hltv-sp-forum-fantasy-help': '/forums/fantasy',
        'hltv-sp-forum-betting-help': '/forums/betting',
        'hltv-sp-forum-hardware-help': '/forums/hardware',
        'hltv-sp-forum-bugs-help': '/forums/bugs',
        'hltv-sp-forum-news-help': '/',
        'hltv-sp-forum-matches-help': '/matches',
        'hltv-sp-layout-width-help': '/',
        'hltv-sp-large-sidebar-text-help': '/',
        'hltv-sp-move-post-new-topic-help': '/',
        'hltv-sp-extended-match-filter-help': '/matches',
        'hltv-sp-strict-selected-teams-help': '/matches',
        'hltv-sp-thread-previews-help': '/forums',
        'hltv-sp-read-status-help': '/forums',
        'hltv-sp-relative-ages-help': '/forums',
        'hltv-sp-reply-composer-after-op-help': '/forums',
        'hltv-sp-user-tags-help': '/forums',
        'hltv-sp-hidden-user-tags-help': '/forums',
        'hltv-sp-local-user-scores-help': '/forums',
        'hltv-sp-local-downvotes-help': '/forums',
        'hltv-sp-signed-out-local-voting-help': '/forums',
        'hltv-sp-green-upvotes-help': '/forums',
        'hltv-sp-username-blocking-help': '/forums',
        'hltv-sp-sticky-match-header-help': '/matches',
        'hltv-sp-match-player-form-overlays-help': '/matches',
        'hltv-sp-match-prediction-help': '/matches',
        'hltv-sp-full-map-names-help': '/stats/players/matches/21167/donk',
        'hltv-sp-stats-column-chooser-help': '/stats/players',
        'hltv-sp-stats-multi-sort-help': '/stats/players',
        'hltv-sp-stats-csv-export-help': '/stats/players',
        'hltv-sp-player-match-sparklines-help': '/stats/players',
        'hltv-sp-stats-table-period-comparison-help': '/stats/players',
        'hltv-sp-team-performance-difference-help': '/stats/teams/ftu',
        'hltv-sp-player-map-matrix-help': '/stats/players',
        'hltv-sp-player-consistency-score-help': '/stats/players',
        'hltv-sp-player-page-period-comparison-help': '/stats/players',
        'hltv-sp-player-comparison-enhancements-help': '/stats/players/compare',
    });
    const FEATURE_PAGE_PATHS = new Set(Object.values(FEATURE_PAGE_PATH_BY_HELP_ID));
    const STATS_FEATURE_PATH_PREFIX = '/stats/';
    if (window.self !== window.top || window.location.origin !== HLTV_ORIGIN) return;

    const safeFetch = typeof globalThis.fetch === 'function'
        ? globalThis.fetch.bind(globalThis)
        : null;
    const SafeXMLHttpRequest = globalThis.XMLHttpRequest;
    const safePrompt = typeof globalThis.prompt === 'function'
        ? globalThis.prompt.bind(globalThis)
        : null;
    const safeConfirm = typeof globalThis.confirm === 'function'
        ? globalThis.confirm.bind(globalThis)
        : null;
    const capturedFirefoxExtensionRuntime = (() => {
        try {
            const runtime = globalThis.browser?.runtime;
            if (typeof runtime?.id !== 'string'
                || !runtime.id
                || runtime.id.length > 200
                || typeof runtime.getURL !== 'function') return null;
            const getURL = runtime.getURL.bind(runtime);
            const manifestUrl = new URL(getURL('manifest.json'));
            if (!['moz-extension:', 'chrome-extension:'].includes(manifestUrl.protocol)
                || manifestUrl.username
                || manifestUrl.password
                || !manifestUrl.pathname.endsWith('/manifest.json')) return null;
            return Object.freeze({
                id: runtime.id,
                getURL,
            });
        } catch {
            return null;
        }
    })();
    const capturedLayoutBootstrapRelease = (() => {
        if (!capturedFirefoxExtensionRuntime) return null;
        try {
            const api = globalThis.HLTV_SP_LAYOUT_BOOTSTRAP;
            return Object.isFrozen(api) && typeof api?.release === 'function'
                ? api.release.bind(api)
                : null;
        } catch {
            return null;
        }
    })();
    const safeLockRequest = (() => {
        try {
            const lockManager = globalThis.navigator?.locks;
            return typeof lockManager?.request === 'function'
                ? lockManager.request.bind(lockManager)
                : null;
        } catch {
            return null;
        }
    })();

    const CONFIG = Object.freeze({
        storagePrefix: 'hltvForumSidebarPlus.',
        requestTimeoutMs: 15000,
        fetchDelayMs: 500,
        maxHtmlChars: 5_000_000,
        maxHtmlBytes: 20_000_000,
        maxTeamSearchResponseChars: 500_000,
        maxTeamSearchResponseBytes: 2_000_000,
        maxReplyResponseChars: 100_000,
        maxReplyResponseBytes: 400_000,
        maxUsernameResponseChars: 50_000,
        maxUsernameResponseBytes: 200_000,
        maxThreadsPerForum: 50,
        forumPageSize: 30,
        maxForumPagesPerRefresh: 5,
        maxForumOffset: 600,
        maxCachedThreadsPerForum: 300,
        maxThreadTitleChars: 300,
        maxPreviewChars: 5000,
        maxPreviewImages: 20,
        maxPreviewImagesPerPost: 4,
        maxPreviewTeamLogos: 100,
        maxPreviewDraftComposers: 20,
        maxReplyChars: 50_000,
        maxSavedDrafts: 50,
        maxSavedDraftBodyChars: 50_000,
        maxSavedDraftAggregateBytes: 2 * 1024 * 1024,
        maxPreviewCacheEntries: 30,
        maxPreviewCacheChars: 2_000_000,
        previewCacheTtlMs: 10 * 60 * 1000,
        forumCacheTtlMs: 3 * 60 * 1000,
        forumCacheRetentionMs: 30 * 60 * 1000,
        maxReadEntries: 750,
        maxSelfPostNumbersPerThread: 500,
        readRetentionMs: 120 * 24 * 60 * 60 * 1000,
        maxUserTags: 500,
        maxUserTagChars: 80,
        maxVisibleUserTagChars: 24,
        maxHiddenUserTags: 100,
        maxLocalReactions: 10_000,
        localReactionTombstoneRetentionMs: 30 * 24 * 60 * 60 * 1000,
        maxActionErrorChars: 300,
        maxDiagnosticEntries: 500,
        diagnosticRetentionMs: 7 * 24 * 60 * 60 * 1000,
        maxImportBytes: 5 * 1024 * 1024,
        maxUsernameSuggestions: 10,
        nativeMatchTeamLimit: 5,
        maxExtendedMatchTeams: 50,
        maxTeamNameChars: 100,
        maxTeamSearchResults: 10,
        teamSearchDebounceMs: 250,
        matchFilterDebounceMs: 80,
        previewReadDwellMs: 5000,
        actionFenceMs: 60 * 1000,
        pendingActionFenceMs: 2 * 60 * 1000,
        voteSnapshotRetentionMs: 10 * 60 * 1000,
        fastVoteBaselineMaxAgeMs: 2 * 60 * 1000,
        minValidTimestampMs: 1_262_304_000_000,
        debug: false,
    });

    const STORAGE_KEYS = Object.freeze({
        readState: 'readStateV1',
        userTags: 'userAnnotationsV1',
        localReactions: 'localReactionsV1',
        provisionalLocalUpvotes: 'provisionalLocalUpvotesV1',
        forumCache: 'forumCacheV1',
        homepageActivityCache: 'homepageActivityCacheV1',
        extendedMatchTeams: 'extendedMatchTeamsV1',
        debugLog: 'debugLogV1',
        syncPulse: 'syncPulseV1',
    });
    const SAVED_DRAFT_STORAGE_PREFIX = `${CONFIG.storagePrefix}savedDraftV1.`;
    const SAVED_DRAFT_SCHEMA = 1;
    const CURRENT_TOPIC_FORUM_IDS = new Set([
        'CounterStrike',
        'Fantasy',
        'Betting',
        'Hardware',
        'BugsSuggestions',
        'OffTopic',
    ]);
    const NATIVE_DRAFT_ACTION_STYLE_PROPERTIES = Object.freeze([
        'background-color',
        'border-bottom-color',
        'border-bottom-left-radius',
        'border-bottom-right-radius',
        'border-bottom-style',
        'border-bottom-width',
        'border-top-color',
        'border-top-left-radius',
        'border-top-right-radius',
        'border-top-style',
        'border-top-width',
        'border-left-color',
        'border-left-style',
        'border-left-width',
        'border-right-color',
        'border-right-style',
        'border-right-width',
        'box-shadow',
        'box-sizing',
        'color',
        'cursor',
        'font-family',
        'font-size',
        'font-style',
        'font-variant',
        'font-weight',
        'height',
        'letter-spacing',
        'line-height',
        'min-height',
        'padding-bottom',
        'padding-left',
        'padding-right',
        'padding-top',
        'text-align',
        'text-shadow',
        'text-transform',
        'transition',
        'vertical-align',
        'white-space',
    ]);

    const WIN_ADJUSTED_RATINGS_DESCRIPTION = [
        'The calculation of WAR starts with each player\'s normal HLTV rating, then estimates how much ratings on this page tend to rise or fall with team success. For each one-team player, it turns the team\'s wins, draws, and losses into a team win percentage. It then looks across all usable players on the page and measures the general relationship between team win percentage and player rating. If players on stronger teams tend to have higher ratings, the script treats part of that rating as team-context inflation. Each player\'s rating is then adjusted by removing the amount explained by being on a team above or below the page\'s average team win percentage. Players on stronger-than-average teams are pulled down; players on weaker-than-average teams are lifted. Players with multiple teams are not adjusted and show ?, because the script cannot know how much of their rating came from each team. The result, WAR, is not a perfect measure of individual skill; it is a simple team-win correction meant to make ratings less dependent on how often the player\'s team won.',
        '',
        'Yes, it works with filters.',
        '',
        'Calculation',
        '',
        'Variables',
        '* R_i: HLTV Rating',
        '* W_i: Team win %',
        '* W_avg: Average team win % across teams present on the table',
        '* \u03B2\u0302: Estimated rating change for a 100 percentage-point win-rate difference [\u03B2\u0302 = Cov(W, R) / Var(W)]',
        '',
        'Final formula',
        '* WAR_i = R_i - \u03B2\u0302 * (W_i - W_avg)',
    ].join('\n');
    const KPR_ESTIMATE_HELP = [
        'On the stats pages, HLTV shows three relevant variables for calculating KPR:',
        '',
        '* Rounds (Rounds played)',
        '* K-D Diff (Kills - Deaths)',
        '* K/D (Kill/Death ratio)',
        '',
        'In principle, given these variables, one can calculate the exact KPR by multiplying K/D with the K-D Diff, and dividing that by (K/D ratio - 1) * rounds played. However, there are two issues with this:',
        '',
        '1. If the K/D ratio = 1.0, and K-D Diff = 0, then it\'s impossible to calculate KPR.',
        '2. HLTV rounds its K/D ratio value to the nearest two decimals, so in cases where the K/D ratio is very close to 1.0, the error bars vary greatly.',
        '',
        'So the best that can be done is to estimate a range of possible KPR values; the closer the player\'s K/D ratio is to 1.0, the wider the margin of error. This does exactly that, and then puts the KPR range in as an additional column on the stats pages. Sorting the column uses the average of the minimum and maximum values in the possible KPR range.',
    ].join('\n');
    const MATCH_PLAYER_METRICS = Object.freeze([
        ['rating', 'Rating'],
        ['kpr', 'KPR'],
        ['dpr', 'DPR'],
        ['kast', 'KAST'],
        ['adr', 'ADR'],
        ['multiKillRating', 'Multi-kill rating'],
        ['roundSwing', 'Round Swing'],
    ]);
    const DEFAULT_MATCH_PLAYER_METRICS = Object.freeze(['rating', 'kpr']);
    const STATS_MATCH_HISTORY_ROW_OPTIONS = Object.freeze([
        100, 200, 300, 400, 500, 'all',
    ]);
    const PREVIOUS_PERIOD_METRICS = Object.freeze([
        ['rating', 'Rating'],
        ['kpr', 'KPR'],
        ['dpr', 'DPR'],
        ['adr', 'ADR'],
        ['kast', 'KAST'],
        ['net-kpr', 'Net kills per round'],
    ]);
    const MATCH_PLAYER_METRIC_IDS = new Set(MATCH_PLAYER_METRICS.map(([id]) => id));
    const FORUMS = Object.freeze([
        {
            id: 'offtopic',
            label: 'Off-Topic',
            url: 'https://www.hltv.org/forums/offtopic',
            color: '#e5484d',
        },
        {
            id: 'counterstrike',
            label: 'Counter-Strike',
            url: 'https://www.hltv.org/forums/counterstrike',
            color: '#ffae00',
        },
        {
            id: 'fantasy',
            label: 'Fantasy',
            url: 'https://www.hltv.org/forums/fantasy',
            color: '#8e5bd9',
        },
        {
            id: 'betting',
            label: 'Betting',
            url: 'https://www.hltv.org/forums/betting',
            color: '#2ea043',
        },
        {
            id: 'hardware',
            label: 'Hardware & Tweaks',
            url: 'https://www.hltv.org/forums/hardware',
            color: '#9da7b3',
        },
        {
            id: 'bugs',
            label: 'Bugs & Suggestions',
            url: 'https://www.hltv.org/forums/bugs',
            color: '#3d8bfd',
        },
    ]);

    const CONTENT_TYPE_COLORS = Object.freeze({
        news: '#f778ba',
        match: '#00a6a6',
        unknown: '#6e7681',
    });

    const ACTIVITY_SOURCES = Object.freeze([
        ...FORUMS.map((forum) => Object.freeze({
            ...forum,
            kind: 'forum',
        })),
        Object.freeze({
            id: 'news',
            label: 'News',
            kind: 'news',
            url: `${HLTV_ORIGIN}/`,
            color: CONTENT_TYPE_COLORS.news,
        }),
        Object.freeze({
            id: 'matches',
            label: 'Matches',
            kind: 'match',
            url: `${HLTV_ORIGIN}/`,
            color: CONTENT_TYPE_COLORS.match,
        }),
    ]);

    const DEFAULT_ACTIVITY_SOURCE_COLORS = Object.freeze(Object.fromEntries(
        ACTIVITY_SOURCES.map((source) => [source.id, source.color]),
    ));

    const DEFAULT_FORUM_THREAD_LIMITS = Object.freeze({
        offtopic: 10,
        counterstrike: 10,
        fantasy: 5,
        betting: 5,
        hardware: 5,
        bugs: 5,
        news: 5,
        matches: 5,
    });

    const LAYOUT_WIDTH_PRESETS = Object.freeze({
        default: Object.freeze({ contentExtraPx: 0, sidebarExtraPx: 0 }),
        wide: Object.freeze({ contentExtraPx: 120, sidebarExtraPx: 80 }),
        extra: Object.freeze({ contentExtraPx: 240, sidebarExtraPx: 140 }),
    });

    const SORT_STATES = Object.freeze([
        {
            id: 'default',
            oldId: 'default',
            icon: '\uD83D\uDCAC',
            title: 'Sort order: Default (newest activity first)',
        },
        {
            id: 'comments',
            oldId: 'high',
            icon: '\uD83D\uDD3D',
            title: 'Sort order: Comment count (high to low)',
        },
        {
            id: 'created',
            oldId: 'type',
            icon: '\uD83D\uDCC5',
            title: 'Sort order: Thread creation order (newest first)',
        },
    ]);

    const DEFAULT_SETTINGS = Object.freeze({
        extensionDisabled: false,
        predictionMarketPercent: 50,
        selectedForums: ['offtopic', 'counterstrike'],
        activitySourceColors: { ...DEFAULT_ACTIVITY_SOURCE_COLORS },
        enableCustomThreadFetching: true,
        enableCustomThreadColors: true,
        changeUpvoteStyle: true,
        enableWinAdjustedRatings: true,
        winAdjustedAutoRun: false,
        showFullMapNames: true,
        enableThreadPreviews: true,
        enableOriginalPosterHighlight: true,
        enableReadStatus: true,
        replyComposerAfterOriginalPost: true,
        enableSavedDrafts: true,
        enableUserTags: true,
        enableLocalUserScores: true,
        enableLocalDownvotes: true,
        enableUsernameBlocking: true,
        enableSignedOutLocalVoting: true,
        enableExtendedMatchFilter: true,
        strictSelectedTeamMatches: true,
        movePostNewTopicToTop: true,
        hiddenUserTags: [],
        layoutWidthPreset: 'extra',
        largeSidebarText: true,
        forumThreadLimits: { ...DEFAULT_FORUM_THREAD_LIMITS },
        showRelativeAges: true,
        enableDiagnosticLogging: false,
        enableStickyMatchHeader: true,
        enableMatchPlayerFormOverlays: true,
        enableMatchPrediction: true,
        matchPredictionMode: 'stats',
        enableTeamPerformanceDifference: true,
        matchPlayerPrimaryMetrics: DEFAULT_MATCH_PLAYER_METRICS,
        matchPlayerPrimaryMetric1: 'rating',
        matchPlayerPrimaryMetric2: 'kpr',
        enableStatsColumnChooser: true,
        enableStatsMultiSort: true,
        statsOptionalColumnsV2: { ranking: [], matches: [] },
        enableStatsCsvExport: true,
        enablePlayerMatchSparklines: true,
        enableExtendedMatchHistoryLoading: true,
        playerMatchTrendMetric: 'rating',
        enablePlayerMapMatrix: true,
        enablePlayerComparisonEnhancements: true,
        enablePlayerConsistencyScore: true,
        enableStatsTablePeriodComparison: true,
        enablePlayerPagePeriodComparison: true,
        previousPeriodMetric: 'rating',
        sortOrder: 'default',
    });

    const forumById = new Map(FORUMS.map((forum) => [forum.id, forum]));
    const forumByUrl = new Map(FORUMS.map((forum) => [normaliseForumUrl(forum.url), forum]));
    const activitySourceById = new Map(ACTIVITY_SOURCES.map((source) => [source.id, source]));

    const state = {
        settings: { ...DEFAULT_SETTINGS },
        sidebar: null,
        sortButton: null,
        modalHost: null,
        modalBackdrop: null,
        modalSettingsDirty: false,
        modalSettingsExternalChange: false,
        modalSettingsSaving: false,
        modalSettingsSnapshot: null,
        statusElement: null,
        sidebarObserver: null,
        suppressSidebarObserver: false,
        forumFetchAbortController: null,
        fetchRunId: 0,
        nextSequence: 0,
        nextDefaultOrder: 0,
        defaultOrderCaptured: false,
        sortSavePromise: Promise.resolve(),
        forumCacheById: new Map(),
        threadMetadataByKey: new Map(),
        readEntries: new Map(),
        userTags: new Map(),
        localReactions: new Map(),
        provisionalLocalUpvotes: new Map(),
        localReactionResetAt: 0,
        localUserScores: new Map(),
        reactionSavePromise: Promise.resolve(),
        reactionActionReservations: new Map(),
        pendingReactionActions: new Map(),
        provisionalUpvoteConversions: new Set(),
        deferredVoteSnapshots: new Map(),
        unconfirmedVoteKeys: new Set(),
        pendingReplyActions: new Map(),
        unconfirmedReplyThreads: new Set(),
        hiddenUserTagSet: new Set(),
        hiddenUserTagSignature: '',
        previewPanel: null,
        previewAbortController: null,
        previewCache: new Map(),
        previewHoverTimer: null,
        previewCloseTimer: null,
        previewActiveLink: null,
        previewPointerInside: false,
        previewReadCandidate: null,
        previewData: null,
        previewCollapsedReplyIds: new Set(),
        previewCollapseThreadId: '',
        previewCommentTopology: null,
        previewRevealedNotificationReplyId: '',
        previewLastCommentTarget: null,
        previewLastCommentDismissHandler: null,
        previewLastCommentObserver: null,
        previewProgrammaticScrollUntil: 0,
        previewReadDwellTimer: null,
        previewReadDwellGeneration: 0,
        previewReadVisibilityHandler: null,
        previewReadBlurHandler: null,
        previewReadFocusHandler: null,
        previewContextMenuActive: false,
        previewContextMenuDismissHandler: null,
        pendingSelfReplyDiscovery: new Set(),
        dirtySelfPostThreads: new Set(),
        contentObserver: null,
        contentObserverTimer: null,
        relativeAgeTimer: null,
        relativeAgeVisibilityHandler: null,
        readSaveTimer: null,
        readVisibilityHandler: null,
        readTrackingKey: '',
        readTrackingPostCount: -1,
        nativeReplyComposerPlaceholder: null,
        nativeReplyComposerOriginForum: null,
        pendingContentRoots: new Set(),
        pendingContentGlobalTasks: new Set(),
        syncListenerId: null,
        syncSenderId: createRandomId('tab'),
        syncApplyDepth: 0,
        deferredSyncPulseKinds: new Set(),
        pendingRemoteSyncKinds: new Set(),
        remoteSyncTimer: null,
        privateCacheListenerId: null,
        sidebarListElement: null,
        layoutResizeHandler: null,
        layoutVisibilityHandler: null,
        layoutPageShowHandler: null,
        layoutResizeTimer: null,
        layoutStartupTimer: null,
        layoutStartupGeneration: 0,
        layoutBootstrapReleased: false,
        forumCacheNeedsPersist: false,
        homepageActivityCache: new Map(),
        extendedMatchTeams: new Map(),
        matchFilterObserver: null,
        matchFilterObservedRoot: null,
        matchFilterTimer: null,
        matchFilterClickHandler: null,
        matchFilterNavigationHandler: null,
        matchTeamSearchAbortController: null,
        matchTeamSearchTimer: null,
        matchTeamSearchInput: null,
        matchTeamSearchInputHandler: null,
        matchTeamSearchKeydownHandler: null,
        postNewTopicPlaceholder: null,
        blockMenuHost: null,
        blockMenuAbortController: null,
        blockMenuGeneration: 0,
        blockContextMenuHandler: null,
        blockDismissHandler: null,
        pageBlockedUserIds: new Set(),
        nativeMutationGuardReady: false,
        savedDraftStorageListenerId: null,
        savedDraftRefreshTimer: null,
        savedDraftIdentityObserver: null,
        savedDraftAccountId: '',
        initialDataReady: false,
        pageVoteStateFetchedAt: Date.now(),
        transientStorageWrites: 0,
    };

    const privateUiRoots = new WeakMap();
    const privateUiHostsByRoot = new WeakMap();
    const privateUiMetadata = new WeakMap();
    const previewReplyFields = new WeakMap();
    const previewDraftBindings = new WeakMap();
    const previewDraftBindingRecords = new Set();
    const nativeDraftBindings = new WeakMap();
    const nativeDraftBindingRecords = new Set();
    const topicDraftBindings = new WeakMap();
    const topicDraftBindingRecords = new Set();
    const blockedUserIndicatorByLink = new WeakMap();
    const extendedMatchTeamSearchNativeValues = new WeakMap();
    const nativeVoteOriginalTitles = new WeakMap();
    const privateUiStyleSheets = new Map();
    const matchFilterResetButtons = new WeakSet();
    const previewHoverTargets = new WeakSet();
    let trustedMainUiStyleText = '';

    const PRIVATE_UI_STYLES = Object.freeze({
        score: `
            :host {
                display: inline-flex;
                margin-left: 3px;
                vertical-align: middle;
            }
            .hltv-sp-user-score-value {
                background: rgba(67, 95, 122, 0.38);
                border: 1px solid #52677b;
                border-radius: 999px;
                color: #a6bfd7;
                display: inline-block;
                font-family: inherit;
                font-size: 9px;
                font-weight: 700;
                line-height: 1.2;
                min-width: 0;
                padding: 0 3px;
                pointer-events: none;
                text-align: center;
                text-decoration: none;
                width: auto;
                white-space: nowrap;
            }
            .hltv-sp-user-score-value.hltv-sp-negative {
                background: rgba(229, 72, 77, 0.16);
                border-color: rgba(229, 72, 77, 0.42);
                color: #ff7b72;
            }
        `,
        blockMenu: `
            :host {
                display: block;
                position: fixed;
                z-index: 2147483646;
            }
            .hltv-sp-block-menu {
                background: #202a34;
                border: 1px solid #435467;
                border-radius: 2px;
                box-shadow: 0 7px 22px rgba(0, 0, 0, 0.5);
                box-sizing: border-box;
                color: #d8dde2;
                font-family: Open Sans, sans-serif;
                font-size: 12px;
                min-width: 180px;
                padding: 5px;
            }
            .hltv-sp-block-menu-title {
                color: #929a9e;
                font-size: 10px;
                line-height: 1.3;
                max-width: 260px;
                overflow: hidden;
                padding: 3px 6px 5px;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
            .hltv-sp-block-menu button,
            .hltv-sp-block-menu a {
                appearance: none;
                background: transparent;
                border: 0;
                border-radius: 2px;
                color: #d8dde2;
                cursor: pointer;
                display: block;
                font: inherit;
                padding: 6px;
                text-align: left;
                text-decoration: none;
                width: 100%;
            }
            .hltv-sp-block-menu button:hover:not(:disabled),
            .hltv-sp-block-menu button:focus-visible,
            .hltv-sp-block-menu a:hover,
            .hltv-sp-block-menu a:focus-visible {
                background: rgba(135, 163, 191, 0.16);
                outline: none;
            }
            .hltv-sp-block-menu button:disabled {
                cursor: default;
                opacity: 0.62;
            }
            .hltv-sp-block-menu-status {
                color: #929a9e;
                font-size: 10px;
                line-height: 1.35;
                max-width: 260px;
                padding: 5px 6px 3px;
            }
            .hltv-sp-block-menu-status:empty {
                display: none;
            }
            .hltv-sp-block-menu-status.hltv-sp-error {
                color: #ff9b94;
            }
        `,
        tag: `
            :host {
                display: inline-flex;
                margin-left: 5px;
                position: relative;
                vertical-align: middle;
                z-index: 19;
            }
            .hltv-sp-tag-button-value,
            .hltv-sp-user-tag-value {
                box-sizing: border-box;
                font-family: inherit;
                text-decoration: none;
            }
            .hltv-sp-tag-button-value {
                color: inherit;
                cursor: pointer;
                font-size: 11px;
                opacity: 0.72;
            }
            .hltv-sp-tag-button-value:hover {
                opacity: 1;
            }
            .hltv-sp-user-tag-value {
                background: rgba(142, 91, 217, 0.18);
                border: 1px solid rgba(142, 91, 217, 0.48);
                border-radius: 999px;
                color: #c6a8f5;
                cursor: pointer;
                display: inline-block;
                font-size: 9px;
                line-height: 1.25;
                max-width: 120px;
                overflow: hidden;
                padding: 1px 5px;
                text-overflow: ellipsis;
                text-transform: none;
                white-space: nowrap;
            }
            .hltv-sp-user-tag-value:hover {
                border-color: #c6a8f5;
            }
        `,
        read: `
            :host {
                display: inline-flex;
                flex: 0 0 auto;
                margin: 0 5px 0 0;
                width: 29px;
            }
            .hltv-sp-read-badge-value {
                background: #2ea043;
                border-radius: 999px;
                color: #fff;
                font-family: inherit;
                font-size: 9px;
                padding: 1px 4px;
                text-align: center;
                width: 100%;
                white-space: nowrap;
            }
            .hltv-sp-read-badge-value.hltv-sp-unread {
                background: #e5484d;
            }
            .hltv-sp-read-badge-value.hltv-sp-untracked {
                background: #6e7681;
            }
        `,
        downvote: `
            :host {
                display: inline-flex;
                flex: 0 0 auto;
            }
            :host(.hltv-sp-preview-downvote) {
                width: auto;
            }
            :host(.hltv-sp-native-downvote) {
                width: auto;
            }
            button {
                appearance: none;
                box-sizing: border-box;
                cursor: pointer;
                font-family: inherit;
                width: 100%;
            }
            button:disabled {
                cursor: default;
                opacity: 0.5;
            }
            .hltv-sp-preview-downvote {
                align-items: center;
                background: #364250;
                border: 1px solid #52677b;
                border-radius: 2px;
                color: #929a9e;
                display: inline-flex;
                font: inherit;
                justify-content: center;
                line-height: 1.15;
                min-width: 24px;
                padding: 3px 6px;
                width: auto;
            }
            .hltv-sp-preview-downvote:hover:not(:disabled) {
                background: #45515f;
                border-color: #87a3bf;
                color: #fff;
            }
            .hltv-sp-native-downvote {
                align-items: center;
                background: #364250;
                border: 0;
                border-radius: 4px;
                color: rgba(146, 154, 158, 0.65);
                display: flex;
                font: inherit;
                gap: 4px;
                height: 19px;
                line-height: 19px;
                margin-right: 8px;
                overflow: hidden;
                padding: 0 6px;
                transform: scale(1);
                transition: 200ms ease;
                user-select: none;
                vertical-align: middle;
                width: auto;
            }
            .hltv-sp-native-downvote:hover:not(:disabled) {
                background-color: #45515f;
                color: #fff;
            }
            .hltv-sp-native-downvote > .hltv-sp-minus-icon {
                display: inline-block;
                font-size: 12px;
                font-weight: 900;
                line-height: 1;
                transform: scaleX(1.15);
                transform-origin: center;
                -webkit-text-stroke: 0.35px currentColor;
            }
            .hltv-sp-preview-downvote > .hltv-sp-minus-icon {
                font-weight: 700;
            }
            .hltv-sp-downvote-count {
                font-weight: 400;
            }
            .hltv-sp-native-downvote > .slide-wrapper {
                display: flex;
                flex-direction: column;
                position: relative;
                top: 50%;
                transform: translateY(-50%);
                transition: transform 200ms ease;
            }
            .hltv-sp-native-downvote > .slide-wrapper > .slide-in,
            .hltv-sp-native-downvote > .slide-wrapper > .slide-out {
                flex: 0 0 19px;
                height: 19px;
                line-height: 19px;
            }
            .hltv-sp-native-downvote.hltv-sp-active > .slide-wrapper {
                transform: translateY(0);
            }
            button.hltv-sp-active {
                background: rgba(229, 72, 77, 0.28);
                border-color: rgba(229, 72, 77, 0.72);
                color: #ff9b94;
            }
        `,
        matchFilter: `
            :host {
                display: block;
            }
            .hltv-sp-match-team-picker {
                color: #929a9e;
                font-family: Open Sans, sans-serif;
                font-size: 12px;
                padding: 0;
                position: relative;
            }
            .hltv-sp-match-team-list {
                display: grid;
                gap: 2px;
                margin: 2px 0 4px;
            }
            .hltv-sp-match-team-row,
            .hltv-sp-match-team-result {
                align-items: center;
                background: rgba(54, 66, 80, 0.72);
                border: 0;
                border-radius: 3px;
                color: #c5c9cc;
                display: flex;
                font: inherit;
                gap: 7px;
                min-height: 28px;
                padding: 4px 7px;
                text-align: left;
                width: 100%;
            }
            .hltv-sp-match-team-name {
                flex: 1 1 auto;
                min-width: 0;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
            .hltv-sp-match-team-marker {
                align-items: center;
                background: #27313c;
                border: 1px solid rgba(255, 255, 255, 0.16);
                border-radius: 50%;
                box-sizing: border-box;
                color: #aeb4b8;
                display: inline-flex;
                flex: 0 0 20px;
                font-size: 10px;
                font-weight: 700;
                height: 20px;
                justify-content: center;
                line-height: 1;
                text-transform: uppercase;
                width: 20px;
            }
            .hltv-sp-match-team-remove {
                appearance: none;
                background: transparent;
                border: 0;
                color: #929a9e;
                cursor: pointer;
                font: inherit;
                padding: 2px 4px;
            }
            .hltv-sp-match-team-remove:hover,
            .hltv-sp-match-team-result:hover {
                color: #fff;
            }
            .hltv-sp-match-team-search {
                background: #1f2933;
                border: 1px solid #435467;
                border-radius: 2px;
                box-sizing: border-box;
                color: #d8dde2;
                font: inherit;
                padding: 6px 7px;
                width: 100%;
            }
            .hltv-sp-match-team-results {
                background: #202a34;
                border: 1px solid #435467;
                box-shadow: 0 5px 14px rgba(0, 0, 0, 0.45);
                display: grid;
                gap: 2px;
                left: 10px;
                max-height: 220px;
                overflow: auto;
                position: absolute;
                right: 10px;
                z-index: 4;
            }
            .hltv-sp-match-team-results[hidden] {
                display: none;
            }
            .hltv-sp-match-team-result {
                border-radius: 0;
                cursor: pointer;
            }
            .hltv-sp-match-team-status {
                color: #aeb4b8;
                font-size: 10px;
                line-height: 1.35;
                min-height: 14px;
                padding-top: 4px;
            }
        `,
    });

    function createPrivateUiHost({
        tagName = 'span',
        className = '',
        styleText = '',
        metadata = null,
    } = {}) {
        const host = document.createElement(tagName);
        host.className = className;
        const root = host.attachShadow({ mode: 'closed' });
        privateUiRoots.set(host, root);
        privateUiHostsByRoot.set(root, host);
        if (metadata) privateUiMetadata.set(host, metadata);
        if (styleText) {
            let adopted = false;
            if ('adoptedStyleSheets' in root
                && typeof CSSStyleSheet === 'function'
                && typeof CSSStyleSheet.prototype.replaceSync === 'function') {
                try {
                    let sheet = privateUiStyleSheets.get(styleText);
                    if (!sheet) {
                        sheet = new CSSStyleSheet();
                        sheet.replaceSync(styleText);
                        privateUiStyleSheets.set(styleText, sheet);
                    }
                    root.adoptedStyleSheets = [...root.adoptedStyleSheets, sheet];
                    adopted = true;
                } catch {
                    adopted = false;
                }
            }
            if (!adopted) {
                const style = document.createElement('style');
                style.textContent = styleText;
                root.appendChild(style);
            }
        }
        return { host, root };
    }

    function privateUiHostForNode(node) {
        if (!node) return null;
        if (privateUiRoots.has(node)) return node;
        const root = typeof node.getRootNode === 'function' ? node.getRootNode() : null;
        return privateUiHostsByRoot.get(root) || null;
    }

    function privateUiRootForNode(node) {
        const host = privateUiHostForNode(node);
        return host ? privateUiRoots.get(host) || null : null;
    }

    function privateUiControl(node, selector) {
        return privateUiRootForNode(node)?.querySelector(selector) || null;
    }

    function isNodeWithinPrivateUiScope(node, scope) {
        if (!node?.isConnected || !scope?.isConnected) return false;
        let current = node;
        for (let depth = 0; depth < 8; depth += 1) {
            if (current === scope || scope.contains(current)) return true;
            const root = typeof current.getRootNode === 'function'
                ? current.getRootNode()
                : null;
            const outerHost = privateUiHostsByRoot.get(root) || null;
            if (!outerHost || outerHost === current) return false;
            current = outerHost;
        }
        return false;
    }

    function isPrivateUiHostWithin(host, scope) {
        if (!host?.isConnected) return false;
        if (!scope || scope === document) return true;
        if (scope === host) return true;
        return typeof scope.contains === 'function' && scope.contains(host);
    }

    function queryPrivateUiAll(scope, selector) {
        const queryScope = scope?.querySelectorAll ? scope : document;
        const matches = [...queryScope.querySelectorAll(selector)];
        for (const host of document.querySelectorAll('.hltv-sp-private-ui-host')) {
            if (!isPrivateUiHostWithin(host, queryScope)) continue;
            matches.push(...(privateUiRoots.get(host)?.querySelectorAll(selector) || []));
        }
        return [...new Set(matches)];
    }

    const privateUiContentWorldApi = Object.freeze({
        querySelector(scope, selector) {
            return queryPrivateUiAll(scope, selector)[0] || null;
        },
        querySelectorAll(scope, selector) {
            return queryPrivateUiAll(scope, selector);
        },
        getRoot(host) {
            return privateUiRoots.get(host) || null;
        },
        getHost(node) {
            return privateUiHostForNode(node);
        },
    });
    try {
        Object.defineProperty(globalThis, 'HLTV_SP_PRIVATE_UI', {
            configurable: true,
            value: privateUiContentWorldApi,
        });
    } catch {
        // A managed page may prevent defining globals. The private UI still works.
    }

    function recordDiagnostic(level, args) {
        if (!featureRuntimeEnabled) return;
        try {
            const api = globalThis.HLTV_SP_DIAGNOSTICS;
            if (typeof api?.record !== 'function') return;
            const message = typeof args[0] === 'string' ? args[0] : 'extension-event';
            const error = args.find((value, index) => (
                index > 0
                && value
                && (value instanceof Error
                    || (typeof value === 'object' && typeof value.message === 'string'))
            )) || null;
            api.record(level, message, error);
        } catch {
            // Diagnostics must never affect site behavior or recursively log failures.
        }
    }

    function log(...args) {
        recordDiagnostic('debug', args);
        if (CONFIG.debug) {
            console.log('[HLTV Enhancements]', ...args);
        }
    }

    function warn(...args) {
        recordDiagnostic('warn', args);
        console.warn('[HLTV Enhancements]', ...args);
    }

    function hasCurrentUiVersion(element) {
        return element?.dataset?.hltvSpBuild === SCRIPT_VERSION;
    }

    function hasCompleteCurrentStyles(element) {
        return hasCurrentUiVersion(element)
            && element?.dataset?.hltvSpCssBuild === SCRIPT_VERSION;
    }

    function stampUiVersion(element) {
        if (element instanceof Element) {
            // v1.6.1 only understands this compatibility stamp. Keeping it stable
            // prevents an enabled older copy from replacing newer UI elements.
            element.dataset.hltvSpVersion = UI_COMPAT_VERSION;
            element.dataset.hltvSpBuild = SCRIPT_VERSION;
        }
        return element;
    }

    function hasCompleteSettingsModal() {
        const backdrop = state.modalBackdrop;
        const title = backdrop?.querySelector('#hltv-sp-title');
        const feedbackLink = backdrop?.querySelector('#hltv-sp-feedback-link');
        return Boolean(
            state.modalHost?.isConnected
            &&
            hasCurrentUiVersion(backdrop)
            && backdrop.querySelector('#hltv-sp-form')
            && backdrop.querySelector('#hltv-sp-forum-settings')
            && backdrop.querySelector('#hltv-sp-layout-settings')
            && backdrop.querySelector('#hltv-sp-sidebar-activity-settings')
            && backdrop.querySelector('#hltv-sp-match-filter-settings')
            && backdrop.querySelector('#hltv-sp-thread-pages-settings')
            && backdrop.querySelector('#hltv-sp-user-reaction-settings')
            && backdrop.querySelector('#hltv-sp-user-actions-settings')
            && backdrop.querySelector('#hltv-sp-stats-settings')
            && backdrop.querySelector('#hltv-sp-match-page-settings')
            && backdrop.querySelector('#hltv-sp-player-analytics-settings')
            && backdrop.querySelector('#hltv-sp-saved-drafts')
            && backdrop.querySelector('.hltv-sp-saved-drafts-manager')
            && backdrop.querySelector('.hltv-sp-saved-drafts-list')
            && backdrop.querySelector('#hltv-sp-delete-all-drafts')
            && backdrop.querySelector('#hltv-sp-data-settings')
            && backdrop.querySelector('#hltv-sp-layout-width')
            && backdrop.querySelector('#hltv-sp-large-sidebar-text')
            && backdrop.querySelector('#hltv-sp-local-user-scores')
            && backdrop.querySelector('#hltv-sp-local-downvotes')
            && backdrop.querySelector('#hltv-sp-username-blocking')
            && backdrop.querySelector('#hltv-sp-signed-out-local-voting')
            && backdrop.querySelector('#hltv-sp-extended-match-filter')
            && backdrop.querySelector('#hltv-sp-strict-selected-teams')
            && backdrop.querySelector('#hltv-sp-move-post-new-topic')
            && backdrop.querySelector('#hltv-sp-reply-composer-after-op')
            && backdrop.querySelector('#hltv-sp-original-poster-highlight')
            && backdrop.querySelector('#hltv-sp-enable-saved-drafts')
            && backdrop.querySelector('#hltv-sp-full-map-names')
            && backdrop.querySelector('#hltv-sp-diagnostic-logging')
            && backdrop.querySelector('#hltv-sp-sticky-match-header')
            && backdrop.querySelector('#hltv-sp-match-player-form-overlays')
            && backdrop.querySelector('#hltv-sp-match-prediction')
            && backdrop.querySelector('#hltv-sp-extension-disabled')
            && backdrop.querySelector('#hltv-sp-match-prediction-mode')
            && backdrop.querySelector('#hltv-sp-prediction-market-percent')
            && backdrop.querySelector('#hltv-sp-team-performance-difference')
            && backdrop.querySelector('#hltv-sp-custom-thread-fetching')
            && backdrop.querySelector('#hltv-sp-custom-thread-colors')
            && backdrop.querySelector('#hltv-sp-stats-column-chooser')
            && backdrop.querySelector('#hltv-sp-extended-match-history-loading')
            && backdrop.querySelector('#hltv-sp-stats-table-period-comparison')
            && backdrop.querySelector('#hltv-sp-player-page-period-comparison')
            && backdrop.querySelector('#hltv-sp-player-map-matrix')
            && backdrop.querySelector('#hltv-sp-import-settings')
            && backdrop.querySelector('#hltv-sp-import-settings-file')
            && backdrop.querySelector('#hltv-sp-import-user-data')
            && backdrop.querySelector('#hltv-sp-import-user-data-file')
            && backdrop.querySelector('#hltv-sp-export-settings')
            && backdrop.querySelector('#hltv-sp-export-user-data')
            && backdrop.querySelector('#hltv-sp-export-debug-log')
            && backdrop.querySelector('#hltv-sp-clear-debug-log')
            && backdrop.querySelector('#hltv-sp-reset-local-user-scores')
            && feedbackLink?.localName === 'a'
            && feedbackLink.getAttribute('href') === FEEDBACK_MAILTO
            && backdrop.querySelectorAll('.hltv-sp-setting-row').length === 45
            && backdrop.querySelectorAll('button.hltv-sp-setting-info').length === 45
            && backdrop.querySelectorAll(
                'button.hltv-sp-setting-info > svg.hltv-sp-info-icon',
            ).length === 45
            && backdrop.querySelectorAll('.hltv-sp-setting-help').length === 45
            && title?.textContent.includes(`v${SCRIPT_VERSION}`),
        );
    }

    function hasCompleteSettingsButton() {
        const button = document.getElementById('hltv-sp-cog');
        return Boolean(
            hasCurrentUiVersion(button)
            && button.dataset.hltvSpComponent === 'settings-button'
            && button.type === 'button'
            && button.querySelector(':scope > i.fa.fa-cog'),
        );
    }

    function hasCompleteCurrentUi() {
        return hasCompleteSettingsModal()
            && hasCompleteSettingsButton();
    }

    function removeManagedUi() {
        state.modalHost?.remove();
        state.modalHost = null;
        state.modalBackdrop = null;
        state.statusElement = null;
        document.querySelector('.hltv-sp-settings-host')?.remove();
        document.getElementById('hltv-sp-cog')?.remove();
        document.getElementById('hltv-sp-sort-button')?.remove();
        for (const panel of document.querySelectorAll('.hltv-sp-preview-panel')) panel.remove();
    }

    function delay(ms, signal = null) {
        return new Promise((resolve, reject) => {
            if (signal?.aborted) {
                reject(makeAbortError());
                return;
            }

            const timeoutId = window.setTimeout(() => {
                signal?.removeEventListener('abort', onAbort);
                resolve();
            }, ms);

            const onAbort = () => {
                window.clearTimeout(timeoutId);
                reject(makeAbortError());
            };

            signal?.addEventListener('abort', onAbort, { once: true });
        });
    }

    function runWhenDocumentReady(callback) {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', callback, { once: true });
        } else {
            callback();
        }
    }

    function safeSyncModule(moduleName, moduleObject) {
        try {
            if (moduleObject && typeof moduleObject.sync === 'function') {
                moduleObject.sync();
            }
            return true;
        } catch (error) {
            warn(`${moduleName} sync failed.`, error);
            return false;
        }
    }

    function syncOptionalModules() {
        if (!featureRuntimeEnabled) return { winOk: true, kprOk: true };
        const winOk = safeSyncModule('Win-adjusted ratings module', WinAdjustedRatings);
        const kprOk = safeSyncModule('full map names module', FullMapNames);
        return { winOk, kprOk };
    }

    const fallbackPrivateCache = new Map();

    function extensionPrivateStorage() {
        const storage = globalThis.HLTV_SP_EXTENSION?.storage;
        return storage
            && typeof storage.ready === 'function'
            && typeof storage.getCachedValue === 'function'
            && typeof storage.setCachedValue === 'function'
            && typeof storage.removeCachedValue === 'function'
            && typeof storage.getCachedEntriesByPrefix === 'function'
            ? storage
            : null;
    }

    function extensionPrivateActionLocks() {
        const actionLocks = globalThis.HLTV_SP_EXTENSION?.actionLocks;
        return actionLocks && typeof actionLocks.acquire === 'function'
            ? actionLocks
            : null;
    }

    async function ensurePrivateStorageReady() {
        const storage = extensionPrivateStorage();
        if (storage) await storage.ready();
    }

    function safePrivateCacheGet(key) {
        try {
            const storage = extensionPrivateStorage();
            return storage
                ? storage.getCachedValue(String(key), null)
                : fallbackPrivateCache.get(String(key)) ?? null;
        } catch (error) {
            log(`Could not read extension-private cache key "${key}".`, error);
            return null;
        }
    }

    function safePrivateCacheSet(key, value) {
        try {
            const storage = extensionPrivateStorage();
            if (storage) {
                storage.setCachedValue(String(key), value).catch((error) => {
                    log(`Could not persist extension-private cache key "${key}".`, error);
                });
            } else {
                fallbackPrivateCache.set(String(key), value);
            }
            return true;
        } catch (error) {
            log(`Could not write extension-private cache key "${key}".`, error);
            return false;
        }
    }

    async function privateCacheSetAndWait(key, value) {
        const storage = extensionPrivateStorage();
        if (storage) {
            await storage.setCachedValue(String(key), value);
        } else {
            fallbackPrivateCache.set(String(key), value);
        }
    }

    function safePrivateCacheRemove(key) {
        try {
            const storage = extensionPrivateStorage();
            if (storage) {
                storage.removeCachedValue(String(key)).catch((error) => {
                    log(`Could not remove extension-private cache key "${key}".`, error);
                });
            } else {
                fallbackPrivateCache.delete(String(key));
            }
            return true;
        } catch (error) {
            log(`Could not remove extension-private cache key "${key}".`, error);
            return false;
        }
    }

    async function privateCacheRemoveAndWait(key) {
        const storage = extensionPrivateStorage();
        if (storage) {
            await storage.removeCachedValue(String(key));
        } else {
            fallbackPrivateCache.delete(String(key));
        }
    }

    function privateCacheEntriesByPrefix(prefix) {
        const storage = extensionPrivateStorage();
        if (storage) return storage.getCachedEntriesByPrefix(String(prefix));
        return [...fallbackPrivateCache.entries()]
            .filter(([key]) => key.startsWith(String(prefix)));
    }

    async function privateCacheRemoveMany(keys) {
        const normalisedKeys = [...new Set(keys.map((key) => String(key)).filter(Boolean))];
        if (!normalisedKeys.length) return;
        const storage = extensionPrivateStorage();
        if (storage && typeof storage.removeValues === 'function') {
            await storage.removeValues(normalisedKeys);
            return;
        }
        for (const key of normalisedKeys) fallbackPrivateCache.delete(key);
    }

    function actionFenceStorageKey(kind, target) {
        if (kind === 'vote' && parseReactionKey(target)) {
            return `${CONFIG.storagePrefix}actionFence.vote.${target}`;
        }
        if (kind === 'reply' && /^\d{1,20}$/.test(String(target || ''))) {
            return `${CONFIG.storagePrefix}actionFence.reply.${target}`;
        }
        return '';
    }

    function isActionLockTarget(kind, target) {
        if (kind === 'vote') return Boolean(parseReactionKey(target));
        if (kind === 'reply' || kind === 'block' || kind === 'draft') {
            return /^\d{1,20}$/.test(String(target || ''));
        }
        return false;
    }

    function readActionFence(kind, target) {
        const key = actionFenceStorageKey(kind, target);
        if (!key) return null;
        const rawValue = safePrivateCacheGet(key);
        if (!rawValue) return null;
        try {
            const value = JSON.parse(rawValue);
            const expiresAt = Number(value?.expiresAt);
            const now = Date.now();
            const status = value?.status === 'pending' ? 'pending' : 'unconfirmed';
            const maximumLifetime = status === 'pending'
                ? CONFIG.pendingActionFenceMs
                : CONFIG.actionFenceMs;
            if (!Number.isFinite(expiresAt)
                || expiresAt <= now
                || expiresAt > now + maximumLifetime + 5000) {
                safePrivateCacheRemove(key);
                return null;
            }
            const ownerId = /^[A-Za-z0-9_.:-]{1,100}$/.test(String(value?.ownerId || ''))
                ? String(value.ownerId)
                : '';
            return { ownerId, status, expiresAt };
        } catch {
            safePrivateCacheRemove(key);
            return null;
        }
    }

    function hasActionFence(kind, target) {
        return Boolean(readActionFence(kind, target));
    }

    function setActionFence(kind, target, status = 'unconfirmed') {
        const key = actionFenceStorageKey(kind, target);
        if (!key) return false;
        const normalisedStatus = status === 'pending' ? 'pending' : 'unconfirmed';
        const value = JSON.stringify({
            schema: 1,
            ownerId: state.syncSenderId,
            status: normalisedStatus,
            expiresAt: Date.now() + (
                normalisedStatus === 'pending'
                    ? CONFIG.pendingActionFenceMs
                    : CONFIG.actionFenceMs
            ),
        });
        const saved = safePrivateCacheSet(key, value);
        if (saved) {
            maybeSweepTransientActionStorage();
            if (state.nativeMutationGuardReady) refreshActionFenceUi();
        }
        return saved;
    }

    async function setActionFenceAndWait(kind, target, status = 'unconfirmed') {
        const key = actionFenceStorageKey(kind, target);
        if (!key) return false;
        const normalisedStatus = status === 'pending' ? 'pending' : 'unconfirmed';
        try {
            await privateCacheSetAndWait(key, JSON.stringify({
                schema: 1,
                ownerId: state.syncSenderId,
                status: normalisedStatus,
                expiresAt: Date.now() + (
                    normalisedStatus === 'pending'
                        ? CONFIG.pendingActionFenceMs
                        : CONFIG.actionFenceMs
                ),
            }));
            maybeSweepTransientActionStorage();
            if (state.nativeMutationGuardReady) refreshActionFenceUi();
            return true;
        } catch (error) {
            log(`Could not persist action fence "${key}".`, error);
            return false;
        }
    }

    function clearOwnedPendingActionFence(kind, target) {
        const key = actionFenceStorageKey(kind, target);
        const fence = readActionFence(kind, target);
        if (!key
            || !fence
            || fence.ownerId !== state.syncSenderId
            || fence.status !== 'pending') return false;
        const removed = safePrivateCacheRemove(key);
        if (removed && state.nativeMutationGuardReady) refreshActionFenceUi();
        return removed;
    }

    async function clearOwnedPendingActionFenceAndWait(kind, target) {
        const key = actionFenceStorageKey(kind, target);
        const fence = readActionFence(kind, target);
        if (!key
            || !fence
            || fence.ownerId !== state.syncSenderId
            || fence.status !== 'pending') return false;
        try {
            await privateCacheRemoveAndWait(key);
            if (state.nativeMutationGuardReady) refreshActionFenceUi();
            return true;
        } catch (error) {
            log(`Could not remove action fence "${key}".`, error);
            return false;
        }
    }

    function isVoteActionBlocked(reactionKey) {
        return state.reactionActionReservations.has(reactionKey)
            || state.pendingReactionActions.has(reactionKey)
            || state.unconfirmedVoteKeys.has(reactionKey)
            || hasActionFence('vote', reactionKey);
    }

    function isReplyActionBlocked(threadId) {
        const normalisedThreadId = String(threadId || '');
        return state.pendingReplyActions.has(normalisedThreadId)
            || state.unconfirmedReplyThreads.has(normalisedThreadId)
            || hasActionFence('reply', normalisedThreadId);
    }

    function voteSnapshotStorageKey(reactionKey) {
        return parseReactionKey(reactionKey)
            ? `${CONFIG.storagePrefix}voteSnapshot.${reactionKey}`
            : '';
    }

    function readVoteSnapshot(reactionKey) {
        const key = voteSnapshotStorageKey(reactionKey);
        const rawValue = key ? safePrivateCacheGet(key) : null;
        if (!rawValue) return null;
        try {
            const value = JSON.parse(rawValue);
            const verifiedAt = Number(value?.verifiedAt);
            const count = Number(value?.count);
            const now = Date.now();
            if (typeof value?.active !== 'boolean'
                || typeof value?.canVote !== 'boolean'
                || !Number.isFinite(count)
                || Math.abs(count) > 1_000_000
                || !Number.isFinite(verifiedAt)
                || verifiedAt < now - CONFIG.voteSnapshotRetentionMs
                || verifiedAt > now + 5000) {
                safePrivateCacheRemove(key);
                return null;
            }
            return {
                active: value.active,
                canVote: value.canVote,
                count,
                verifiedAt,
            };
        } catch {
            safePrivateCacheRemove(key);
            return null;
        }
    }

    function writeVoteSnapshot(reactionKey, confirmed) {
        const key = voteSnapshotStorageKey(reactionKey);
        if (!key || !confirmed) return false;
        const saved = safePrivateCacheSet(key, JSON.stringify({
            schema: 1,
            active: Boolean(confirmed.active),
            canVote: Boolean(confirmed.canVote),
            count: Number(confirmed.count),
            verifiedAt: Number(confirmed.verifiedAt || Date.now()),
        }));
        if (saved) maybeSweepTransientActionStorage();
        return saved;
    }

    function maybeSweepTransientActionStorage() {
        state.transientStorageWrites += 1;
        if (state.transientStorageWrites % 25 === 0) {
            sweepTransientActionStorage();
        }
    }

    function sweepTransientActionStorage() {
        const actionPrefix = `${CONFIG.storagePrefix}actionFence.`;
        const snapshotPrefix = `${CONFIG.storagePrefix}voteSnapshot.`;
        const now = Date.now();
        const entries = [
            ...privateCacheEntriesByPrefix(actionPrefix),
            ...privateCacheEntriesByPrefix(snapshotPrefix),
        ].slice(0, 50_000);
        for (const [key, rawValue] of entries) {
            let keep = false;
            try {
                const value = JSON.parse(rawValue || '');
                if (key.startsWith(actionPrefix)) {
                    const expiresAt = Number(value?.expiresAt);
                    const maximumLifetime = value?.status === 'pending'
                        ? CONFIG.pendingActionFenceMs
                        : CONFIG.actionFenceMs;
                    keep = Number.isFinite(expiresAt)
                        && expiresAt > now
                        && expiresAt <= now + maximumLifetime + 5000;
                } else {
                    const verifiedAt = Number(value?.verifiedAt);
                    keep = Number.isFinite(verifiedAt)
                        && verifiedAt >= now - CONFIG.voteSnapshotRetentionMs
                        && verifiedAt <= now + 5000;
                }
            } catch {
                keep = false;
            }
            if (!keep) safePrivateCacheRemove(key);
        }
    }

    async function storageGet(key, fallbackValue) {
        try {
            if (typeof GM !== 'undefined' && typeof GM.getValue === 'function') {
                return await GM.getValue(key, fallbackValue);
            }

            if (typeof GM_getValue === 'function') {
                return await GM_getValue(key, fallbackValue);
            }
        } catch (error) {
            warn(`Could not read setting "${key}" from extension storage.`, error);
        }

        const rawValue = safePrivateCacheGet(`${CONFIG.storagePrefix}${key}`);
        if (rawValue === null) return fallbackValue;

        try {
            return JSON.parse(rawValue);
        } catch {
            return rawValue;
        }
    }

    async function storageSet(key, value) {
        if (typeof GM !== 'undefined' && typeof GM.setValue === 'function') {
            try {
                await GM.setValue(key, value);
                return;
            } catch (error) {
                warn(`Could not write setting "${key}" to extension storage.`, error);
                throw error;
            }
        }
        if (typeof GM_setValue === 'function') {
            try {
                await GM_setValue(key, value);
                return;
            } catch (error) {
                warn(`Could not write setting "${key}" to extension storage.`, error);
                throw error;
            }
        }

        if (!safePrivateCacheSet(`${CONFIG.storagePrefix}${key}`, JSON.stringify(value))) {
            throw new Error(`Could not persist setting "${key}".`);
        }
    }

    async function storageSetMany(values) {
        if (!values || typeof values !== 'object' || Array.isArray(values)) {
            throw new TypeError('A batch storage write must be an object.');
        }
        const entries = Object.entries(values);
        if (!entries.length) return;
        const extensionStorage = extensionPrivateStorage();
        if (extensionStorage && typeof extensionStorage.setValues === 'function') {
            await extensionStorage.ready();
            await extensionStorage.setValues(Object.fromEntries(entries));
            return;
        }
        await Promise.all(entries.map(([key, value]) => storageSet(key, value)));
    }

    function hasPrivateStorage() {
        return (typeof GM !== 'undefined' && typeof GM.getValue === 'function' && typeof GM.setValue === 'function')
            || (typeof GM_getValue === 'function' && typeof GM_setValue === 'function');
    }

    async function privateStorageGet(key, fallbackValue) {
        if (!hasPrivateStorage()) return fallbackValue;

        try {
            if (typeof GM !== 'undefined' && typeof GM.getValue === 'function') {
                return await GM.getValue(key, fallbackValue);
            }
            return await GM_getValue(key, fallbackValue);
        } catch (error) {
            warn(`Could not read private extension data "${key}".`, error);
            return fallbackValue;
        }
    }

    async function privateStorageSet(key, value) {
        if (!hasPrivateStorage()) {
            throw new Error('Private extension storage is unavailable.');
        }

        if (typeof GM !== 'undefined' && typeof GM.setValue === 'function') {
            await GM.setValue(key, value);
        } else {
            await GM_setValue(key, value);
        }
    }

    async function privateStorageRemove(key) {
        const normalisedKey = String(key);
        const extensionStorage = extensionPrivateStorage();
        if (extensionStorage) {
            await extensionStorage.ready();
            await extensionStorage.removeCachedValue(normalisedKey);
            return;
        }
        if (typeof GM !== 'undefined' && typeof GM.deleteValue === 'function') {
            await GM.deleteValue(normalisedKey);
            return;
        }
        if (typeof GM_deleteValue === 'function') {
            await GM_deleteValue(normalisedKey);
            return;
        }
        // Older userscript managers may expose private reads/writes without a
        // deletion grant. A null record is equivalent to an empty diagnostic log.
        await privateStorageSet(normalisedKey, null);
    }

    async function privateStorageGetStrict(key) {
        if (!hasPrivateStorage()) {
            throw new Error('Private extension storage is unavailable.');
        }
        if (typeof GM !== 'undefined' && typeof GM.getValue === 'function') {
            return GM.getValue(key, null);
        }
        return GM_getValue(key, null);
    }

    function createRandomId(prefix = 'id') {
        const bytes = new Uint32Array(3);
        if (globalThis.crypto?.getRandomValues) {
            globalThis.crypto.getRandomValues(bytes);
        } else {
            bytes[0] = Date.now() >>> 0;
            bytes[1] = Math.floor(Math.random() * 0xffffffff);
            bytes[2] = Math.floor(Math.random() * 0xffffffff);
        }
        return `${prefix}_${[...bytes].map((value) => value.toString(36)).join('')}`;
    }

    function savedDraftError(code, message) {
        const error = new Error(message);
        error.name = 'SavedDraftError';
        error.code = code;
        error.publicMessage = message;
        return error;
    }

    function hasSavedDraftStorage() {
        const storage = extensionPrivateStorage();
        return Boolean(
            storage
            && typeof storage.getAuthoritativeEntriesByPrefix === 'function'
            && extensionPrivateActionLocks(),
        );
    }

    function savedDraftIntegrationEnabled() {
        return Boolean(state.settings.enableSavedDrafts && hasSavedDraftStorage());
    }

    function isSavedDraftId(value) {
        return typeof value === 'string'
            && /^[A-Za-z][A-Za-z0-9_]{3,63}$/.test(value);
    }

    function isSavedTopicForumId(value) {
        const forumId = String(value || '');
        return forumId === ''
            || CURRENT_TOPIC_FORUM_IDS.has(forumId)
            || /^\d{1,10}$/.test(forumId);
    }

    function normaliseSavedDraftPath(value, kind) {
        const url = parseSameOriginUrl(value);
        if (!url || url.search || url.hash) return '';
        if (kind === 'topic') {
            return url.pathname === '/forums/create-thread' ? url.pathname : '';
        }
        return /^\/(?:forums\/threads|news|matches)\/\d{1,20}(?:\/|$)/i.test(
            url.pathname,
        ) ? url.pathname : '';
    }

    function savedReplyDraftStorageKey(accountId, threadId, replyId = '') {
        if (!/^\d{1,20}$/.test(String(accountId || ''))
            || !/^\d{1,20}$/.test(String(threadId || ''))
            || (replyId && !/^\d{1,20}$/.test(String(replyId)))) return '';
        return `${SAVED_DRAFT_STORAGE_PREFIX}${accountId}.reply.${threadId}.${replyId || 'root'}`;
    }

    function savedTopicDraftStorageKey(accountId, id) {
        if (!/^\d{1,20}$/.test(String(accountId || '')) || !isSavedDraftId(id)) return '';
        return `${SAVED_DRAFT_STORAGE_PREFIX}${accountId}.topic.${id}`;
    }

    function savedDraftStorageKeyForRecord(record) {
        return record?.kind === 'reply'
            ? savedReplyDraftStorageKey(record.accountId, record.threadId, record.replyId)
            : record?.kind === 'topic'
                ? savedTopicDraftStorageKey(record.accountId, record.id)
                : '';
    }

    function savedDraftRecordByteSize(record) {
        try {
            return utf8ByteLength(
                JSON.stringify(record),
                CONFIG.maxSavedDraftAggregateBytes,
            );
        } catch {
            return CONFIG.maxSavedDraftAggregateBytes + 1;
        }
    }

    function savedDraftAccountStoragePrefix(accountId) {
        const normalisedAccountId = String(accountId || '');
        return /^\d{1,20}$/.test(normalisedAccountId)
            ? `${SAVED_DRAFT_STORAGE_PREFIX}${normalisedAccountId}.`
            : '';
    }

    function normaliseSavedDraftRecord(key, rawValue) {
        if (!rawValue || typeof rawValue !== 'object' || Array.isArray(rawValue)) return null;
        const schema = Number(rawValue.schema);
        const kind = rawValue.kind === 'reply' || rawValue.kind === 'topic'
            ? rawValue.kind
            : '';
        const accountId = String(rawValue.accountId || '');
        const id = String(rawValue.id || '');
        const revision = String(rawValue.revision || '');
        const threadId = String(rawValue.threadId || '');
        const replyId = String(rawValue.replyId || '');
        const path = normaliseSavedDraftPath(rawValue.path, kind);
        const title = typeof rawValue.title === 'string' ? rawValue.title : '';
        const context = typeof rawValue.context === 'string' ? rawValue.context : '';
        const subject = typeof rawValue.subject === 'string' ? rawValue.subject : '';
        const forumId = String(rawValue.forumId || '');
        const forumLabel = typeof rawValue.forumLabel === 'string'
            ? rawValue.forumLabel
            : '';
        const body = typeof rawValue.body === 'string' ? rawValue.body : '';
        const createdAt = Number(rawValue.createdAt);
        const updatedAt = Number(rawValue.updatedAt);
        const now = Date.now();
        if (schema !== SAVED_DRAFT_SCHEMA
            || !kind
            || !/^\d{1,20}$/.test(accountId)
            || !isSavedDraftId(id)
            || !isSavedDraftId(revision)
            || !path
            || title.length > CONFIG.maxThreadTitleChars
            || context.length > CONFIG.maxThreadTitleChars
            || subject.length > CONFIG.maxThreadTitleChars
            || forumLabel.length > 100
            || body.length > CONFIG.maxSavedDraftBodyChars
            || !Number.isFinite(createdAt)
            || !Number.isFinite(updatedAt)
            || createdAt < CONFIG.minValidTimestampMs
            || updatedAt < createdAt
            || updatedAt > now + 5 * 60 * 1000
            || !isSavedTopicForumId(forumId)) return null;
        if (kind === 'reply') {
            if (!/^\d{1,20}$/.test(threadId)
                || (replyId && !/^\d{1,20}$/.test(replyId))
                || !body.trim()
                || subject
                || forumId
                || forumLabel) return null;
        } else if (threadId
            || replyId
            || (!subject.trim() && !body.trim())) return null;
        const record = {
            schema: SAVED_DRAFT_SCHEMA,
            id,
            revision,
            accountId,
            kind,
            threadId,
            replyId,
            path,
            title,
            context,
            subject,
            forumId,
            forumLabel,
            body,
            createdAt,
            updatedAt,
        };
        if (savedDraftStorageKeyForRecord(record) !== String(key)
            || savedDraftRecordByteSize(record) > CONFIG.maxSavedDraftAggregateBytes) return null;
        return record;
    }

    function normaliseSavedDraftEntriesForAccount(accountId, rawEntries) {
        const normalisedAccountId = String(accountId || '');
        const prefix = savedDraftAccountStoragePrefix(normalisedAccountId);
        if (!prefix || !Array.isArray(rawEntries)) return [];
        return rawEntries
            .filter(([key]) => String(key).startsWith(prefix))
            .map(([key, value]) => {
                const record = normaliseSavedDraftRecord(key, value);
                return record?.accountId === normalisedAccountId
                    ? { key: String(key), record }
                    : null;
            })
            .filter(Boolean)
            .sort((first, second) => (
                second.record.updatedAt - first.record.updatedAt
                || first.key.localeCompare(second.key)
            ));
    }

    function savedDraftEntriesForAccount(accountId = extractCurrentUserId()) {
        const prefix = savedDraftAccountStoragePrefix(accountId);
        if (!prefix || !hasSavedDraftStorage()) return [];
        return normaliseSavedDraftEntriesForAccount(
            accountId,
            privateCacheEntriesByPrefix(prefix),
        );
    }

    async function authoritativeSavedDraftEntriesForAccount(accountId) {
        const storage = extensionPrivateStorage();
        const prefix = savedDraftAccountStoragePrefix(accountId);
        if (!storage
            || !prefix
            || typeof storage.getAuthoritativeEntriesByPrefix !== 'function') {
            throw savedDraftError(
                'storage-unavailable',
                'Saved drafts could not be refreshed safely.',
            );
        }
        let rawEntries;
        try {
            rawEntries = await storage.getAuthoritativeEntriesByPrefix(prefix);
        } catch (error) {
            log('Could not refresh saved drafts from authoritative storage.', error);
            throw savedDraftError(
                'storage-unavailable',
                'Saved drafts could not be refreshed safely. Try again.',
            );
        }
        return normaliseSavedDraftEntriesForAccount(accountId, rawEntries);
    }

    async function withSavedDraftAccountLock(accountId, operation) {
        const normalisedAccountId = String(accountId || '');
        if (!savedDraftAccountStoragePrefix(normalisedAccountId)
            || typeof operation !== 'function') {
            throw savedDraftError('account-unavailable', 'Sign in to manage saved drafts.');
        }
        return withCrossTabActionLock('draft', normalisedAccountId, async () => {
            if (extractCurrentUserId() !== normalisedAccountId) {
                throw savedDraftError('account-changed', 'The signed-in HLTV account changed.');
            }
            const entries = await authoritativeSavedDraftEntriesForAccount(
                normalisedAccountId,
            );
            if (extractCurrentUserId() !== normalisedAccountId) {
                throw savedDraftError('account-changed', 'The signed-in HLTV account changed.');
            }
            return operation({
                storage: extensionPrivateStorage(),
                entries,
            });
        });
    }

    function savedDraftForReplyTarget(accountId, threadId, replyId = '') {
        const key = savedReplyDraftStorageKey(accountId, threadId, replyId);
        if (!key || !hasSavedDraftStorage()) return null;
        const record = normaliseSavedDraftRecord(key, safePrivateCacheGet(key));
        return record ? { key, record } : null;
    }

    async function saveDraftRecord(input, existingTopicKey = '') {
        const storage = extensionPrivateStorage();
        if (!storage) {
            throw savedDraftError(
                'storage-unavailable',
                'Durable drafts require the packaged Firefox extension.',
            );
        }
        const accountId = String(extractCurrentUserId() || '');
        if (!/^\d{1,20}$/.test(accountId)) {
            throw savedDraftError(
                'account-unavailable',
                'Sign in to HLTV before saving a private draft.',
            );
        }
        if (String(input?.accountId || accountId) !== accountId) {
            throw savedDraftError('account-changed', 'The signed-in HLTV account changed.');
        }
        const kind = input?.kind === 'topic' ? 'topic' : 'reply';
        const body = typeof input?.body === 'string' ? input.body : '';
        const subject = kind === 'topic' && typeof input?.subject === 'string'
            ? input.subject
            : '';
        if (body.length > CONFIG.maxSavedDraftBodyChars) {
            throw savedDraftError(
                'body-too-long',
                `Drafts are limited to ${CONFIG.maxSavedDraftBodyChars.toLocaleString('en-US')} characters.`,
            );
        }
        if (subject.length > CONFIG.maxThreadTitleChars) {
            throw savedDraftError(
                'subject-too-long',
                `Draft subjects are limited to ${CONFIG.maxThreadTitleChars.toLocaleString('en-US')} characters.`,
            );
        }
        if (kind === 'reply' ? !body.trim() : (!subject.trim() && !body.trim())) {
            throw savedDraftError('empty', 'Write something before saving this draft.');
        }
        const threadId = kind === 'reply' ? String(input?.threadId || '') : '';
        const replyId = kind === 'reply' ? String(input?.replyId || '') : '';
        const forumId = kind === 'topic' ? String(input?.forumId || '') : '';
        if (kind === 'reply' && (!/^\d{1,20}$/.test(threadId)
            || (replyId && !/^\d{1,20}$/.test(replyId)))) {
            throw savedDraftError('target-unavailable', 'This reply target cannot be saved safely.');
        }
        if (!isSavedTopicForumId(forumId)) {
            throw savedDraftError(
                'target-unavailable',
                'This forum selection cannot be saved safely.',
            );
        }
        const path = normaliseSavedDraftPath(input?.path, kind);
        if (!path) {
            throw savedDraftError('target-unavailable', 'This draft destination cannot be saved safely.');
        }
        return withSavedDraftAccountLock(accountId, async ({
            storage: lockedStorage,
            entries: currentEntries,
        }) => {
            let previous = null;
            let id = '';
            let key = '';
            if (kind === 'reply') {
                key = savedReplyDraftStorageKey(accountId, threadId, replyId);
                previous = currentEntries.find((entry) => entry.key === key)?.record || null;
                id = previous?.id || createRandomId('draft');
            } else {
                previous = currentEntries.find(
                    (entry) => entry.key === existingTopicKey,
                )?.record || null;
                if (previous?.kind !== 'topic') previous = null;
                id = previous?.id || createRandomId('topic');
                key = savedTopicDraftStorageKey(accountId, id);
            }
            const now = Date.now();
            const record = {
                schema: SAVED_DRAFT_SCHEMA,
                id,
                revision: createRandomId('revision'),
                accountId,
                kind,
                threadId,
                replyId,
                path,
                title: cleanText(input?.title).slice(0, CONFIG.maxThreadTitleChars),
                context: cleanText(input?.context).slice(0, CONFIG.maxThreadTitleChars),
                subject,
                forumId,
                forumLabel: kind === 'topic'
                    ? cleanText(input?.forumLabel).slice(0, 100)
                    : '',
                body,
                createdAt: previous?.createdAt || now,
                updatedAt: now,
            };
            if (!key || !normaliseSavedDraftRecord(key, record)) {
                throw savedDraftError('invalid', 'This draft could not be validated safely.');
            }
            const otherEntries = currentEntries.filter((entry) => entry.key !== key);
            if (otherEntries.length + 1 > CONFIG.maxSavedDrafts) {
                throw savedDraftError(
                    'entry-limit',
                    `You already have ${CONFIG.maxSavedDrafts} saved drafts for this HLTV account. Delete one before saving another.`,
                );
            }
            const totalBytes = savedDraftRecordByteSize(record)
                + otherEntries.reduce((total, entry) => (
                    total + savedDraftRecordByteSize(entry.record)
                ), 0);
            if (totalBytes > CONFIG.maxSavedDraftAggregateBytes) {
                throw savedDraftError(
                    'storage-limit',
                    'Saved drafts for this HLTV account have reached their 2 MiB limit. Delete one before saving another.',
                );
            }
            await lockedStorage.setCachedValue(key, record);
            const afterEntries = await authoritativeSavedDraftEntriesForAccount(accountId);
            const confirmed = afterEntries.find((entry) => entry.key === key)?.record || null;
            if (!confirmed || confirmed.revision !== record.revision) {
                throw savedDraftError(
                    'write-conflict',
                    'Another tab changed this draft while it was being saved.',
                );
            }
            const afterBytes = afterEntries.reduce((total, entry) => (
                total + savedDraftRecordByteSize(entry.record)
            ), 0);
            if (afterEntries.length > CONFIG.maxSavedDrafts
                || afterBytes > CONFIG.maxSavedDraftAggregateBytes) {
                await lockedStorage.removeCachedValue(key);
                throw savedDraftError(
                    'write-conflict',
                    'The saved-draft limit changed while this draft was being saved. No older draft was removed.',
                );
            }
            return { key, record };
        });
    }

    async function removeSavedDraftIfRevision(
        key,
        accountId,
        revision,
        expectedBody = null,
    ) {
        if (!isSavedDraftId(revision)
            || !savedDraftAccountStoragePrefix(accountId)) return false;
        return withSavedDraftAccountLock(accountId, async ({ storage, entries }) => {
            const current = entries.find((entry) => entry.key === String(key))?.record || null;
            if (!current
                || current.accountId !== accountId
                || current.revision !== revision
                || (expectedBody !== null && current.body !== String(expectedBody))) return false;
            await storage.removeCachedValue(String(key));
            return true;
        });
    }

    function matchingSavedReplyDraft(descriptor, body) {
        const accountId = extractCurrentUserId();
        if (!descriptor
            || descriptor.kind !== 'reply'
            || descriptor.accountId !== accountId) return null;
        const entry = savedDraftForReplyTarget(
            accountId,
            descriptor.threadId,
            descriptor.replyId,
        );
        return entry?.record.body === String(body || '')
            ? {
                key: entry.key,
                accountId,
                revision: entry.record.revision,
            }
            : null;
    }

    async function removeSavedDraft(key, expectedRevision) {
        const accountId = extractCurrentUserId();
        if (!isSavedDraftId(expectedRevision)) {
            throw savedDraftError('invalid', 'This saved draft is no longer valid.');
        }
        return withSavedDraftAccountLock(accountId, async ({ storage, entries }) => {
            const current = entries.find((entry) => entry.key === String(key))?.record || null;
            if (!current || current.accountId !== accountId) {
                throw savedDraftError(
                    'account-changed',
                    'This draft is not available to the signed-in HLTV account.',
                );
            }
            if (current.revision !== expectedRevision) {
                throw savedDraftError(
                    'write-conflict',
                    'Another tab updated this draft. Review it before deleting it.',
                );
            }
            await storage.removeCachedValue(String(key));
        });
    }

    async function removeAllSavedDraftsForCurrentAccount(accountId, expectedEntries) {
        const normalisedAccountId = String(accountId || '');
        const accountPrefix = savedDraftAccountStoragePrefix(normalisedAccountId);
        if (!hasSavedDraftStorage() || !accountPrefix) {
            throw savedDraftError('account-unavailable', 'Sign in to manage saved drafts.');
        }
        if (!Array.isArray(expectedEntries)
            || expectedEntries.length > CONFIG.maxSavedDrafts) {
            throw savedDraftError('invalid', 'The confirmed saved-draft list is no longer valid.');
        }
        const expectedRevisions = new Map();
        for (const entry of expectedEntries) {
            const key = String(entry?.key || '');
            const revision = String(entry?.revision || '');
            if (!key.startsWith(accountPrefix)
                || !isSavedDraftId(revision)
                || expectedRevisions.has(key)) {
                throw savedDraftError(
                    'invalid',
                    'The confirmed saved-draft list is no longer valid.',
                );
            }
            expectedRevisions.set(key, revision);
        }
        return withSavedDraftAccountLock(
            normalisedAccountId,
            async ({ storage, entries }) => {
                const currentByKey = new Map(entries.map((entry) => [entry.key, entry.record]));
                const keys = [...expectedRevisions].flatMap(([key, revision]) => (
                    currentByKey.get(key)?.revision === revision ? [key] : []
                ));
                const skipped = expectedRevisions.size - keys.length;
                if (keys.length) await storage.removeValues(keys);
                return { removed: keys.length, skipped };
            },
        );
    }

    function clampInteger(value, minimum, maximum, fallbackValue) {
        const parsed = Number.parseInt(String(value), 10);
        return Number.isFinite(parsed)
            ? Math.min(maximum, Math.max(minimum, parsed))
            : fallbackValue;
    }

    function normaliseForumThreadLimits(value) {
        const source = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
        return Object.fromEntries(ACTIVITY_SOURCES.map((activitySource) => [
            activitySource.id,
            clampInteger(
                source[activitySource.id],
                1,
                CONFIG.maxThreadsPerForum,
                DEFAULT_FORUM_THREAD_LIMITS[activitySource.id],
            ),
        ]));
    }

    function normaliseActivitySourceColor(value, fallbackValue) {
        const color = String(value || '').trim();
        return /^#[0-9a-f]{6}$/i.test(color) ? color.toLowerCase() : fallbackValue;
    }

    function normaliseActivitySourceColors(value) {
        const source = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
        return Object.fromEntries(ACTIVITY_SOURCES.map((activitySource) => [
            activitySource.id,
            normaliseActivitySourceColor(
                source[activitySource.id],
                DEFAULT_ACTIVITY_SOURCE_COLORS[activitySource.id],
            ),
        ]));
    }

    function activitySourceColor(sourceId) {
        return state.settings.activitySourceColors?.[sourceId]
            || DEFAULT_ACTIVITY_SOURCE_COLORS[sourceId]
            || CONTENT_TYPE_COLORS.unknown;
    }

    function normaliseUserTag(value) {
        return String(value ?? '')
            .replace(/[\r\n]+/g, ' ')
            .trim()
            .slice(0, CONFIG.maxUserTagChars);
    }

    function normaliseHiddenUserTags(value) {
        const source = Array.isArray(value)
            ? value
            : typeof value === 'string' ? value.split(/\r?\n/) : [];
        const tags = [];
        const seen = new Set();
        for (const rawTag of source) {
            const tag = normaliseUserTag(rawTag);
            if (!tag || seen.has(tag)) continue;
            seen.add(tag);
            tags.push(tag);
            if (tags.length >= CONFIG.maxHiddenUserTags) break;
        }
        return tags;
    }

    function normaliseExtendedMatchTeams(value) {
        const source = value?.schema === 1 && Array.isArray(value.teams)
            ? value.teams
            : Array.isArray(value) ? value : [];
        const teams = new Map();
        for (const rawTeam of source) {
            const id = String(rawTeam?.id ?? '');
            const name = cleanText(rawTeam?.name).slice(0, CONFIG.maxTeamNameChars);
            if (!/^\d{1,20}$/.test(id) || !name || teams.has(id)) continue;
            teams.set(id, { id, name });
            if (teams.size >= CONFIG.maxExtendedMatchTeams) break;
        }
        return teams;
    }

    async function saveExtendedMatchTeams() {
        await storageSet(STORAGE_KEYS.extendedMatchTeams, {
            schema: 1,
            updatedAt: Date.now(),
            teams: [...state.extendedMatchTeams.values()],
        });
        await emitSyncPulse(['matchTeams']);
    }

    function normaliseLayoutWidthPreset(value) {
        return Object.prototype.hasOwnProperty.call(LAYOUT_WIDTH_PRESETS, value)
            ? value
            : DEFAULT_SETTINGS.layoutWidthPreset;
    }

    function normaliseMatchPlayerMetric(value, fallback = 'rating') {
        return MATCH_PLAYER_METRIC_IDS.has(value) ? value : fallback;
    }

    function normaliseMatchPlayerMetrics(value, legacyFirst, legacySecond) {
        const legacy = [
            normaliseMatchPlayerMetric(
                legacyFirst,
                DEFAULT_MATCH_PLAYER_METRICS[0],
            ),
            normaliseMatchPlayerMetric(
                legacySecond,
                DEFAULT_MATCH_PLAYER_METRICS[1],
            ),
        ];
        const source = Array.isArray(value)
            ? value.slice(0, MATCH_PLAYER_METRICS.length)
            : legacy;
        const selected = [];
        for (const rawKey of source) {
            const key = String(rawKey || '');
            if (MATCH_PLAYER_METRIC_IDS.has(key) && !selected.includes(key)) {
                selected.push(key);
            }
        }
        return selected.length ? selected : [...DEFAULT_MATCH_PLAYER_METRICS];
    }

    function legacyMatchPlayerMetricPair(value) {
        const selected = normaliseMatchPlayerMetrics(value);
        return [
            selected[0],
            selected[1] || (selected[0] === 'rating' ? 'kpr' : 'rating'),
        ];
    }

    function normalisePreviousPeriodMetric(value) {
        const metric = cleanText(value)
            .toLowerCase()
            .replace(/\brating\s*[123](?:\.0)?\b/g, 'rating')
            .replace(/[^a-z0-9%]+/g, '-')
            .replace(/^-+|-+$/g, '')
            .slice(0, 80);
        return metric || DEFAULT_SETTINGS.previousPeriodMetric;
    }

    function normaliseStoredMetricName(value, fallback = 'rating') {
        const metric = cleanText(value).toLowerCase().replace(/[^a-z0-9+/-]+/g, '-');
        return metric.slice(0, 80) || fallback;
    }

    function normaliseStatsMatchHistoryRows(value) {
        if (String(value).toLowerCase() === 'all') return 'all';
        const numeric = Number(value);
        return STATS_MATCH_HISTORY_ROW_OPTIONS.includes(numeric) ? numeric : 100;
    }

    function normaliseStatsOptionalColumns(
        value,
        legacyKprEstimate = null,
        legacyDerivedColumns = null,
        legacyKprMatchHistory = null,
        legacyWarEnabled = null,
    ) {
        const allowed = {
            ranking: new Set(['kpr', 'dpr', 'kills-per-map', 'war']),
            matches: new Set(['kpr', 'dpr']),
        };
        const result = { ranking: [], matches: [] };
        for (const type of Object.keys(result)) {
            const source = Array.isArray(value?.[type]) ? value[type] : [];
            result[type] = [...new Set(source.filter((id) => allowed[type].has(id)))];
        }
        if (value == null) {
            const hasLegacyChoices = legacyKprEstimate !== null
                || legacyDerivedColumns !== null
                || legacyKprMatchHistory !== null;
            if (!hasLegacyChoices) {
                result.ranking.push(...allowed.ranking);
                result.matches.push(...allowed.matches);
            } else {
                if (legacyKprEstimate === true) result.ranking.push('kpr');
                if (legacyDerivedColumns === true) {
                    result.ranking.push('dpr', 'kills-per-map');
                    result.matches.push('dpr');
                }
                const matchHistoryKpr = legacyKprMatchHistory === null
                    ? legacyKprEstimate
                    : legacyKprMatchHistory;
                if (matchHistoryKpr === true) result.matches.push('kpr');
            }
            if (legacyWarEnabled !== false) result.ranking.push('war');
        } else if (legacyWarEnabled === true && !result.ranking.includes('war')) {
            // Migrate the former standalone WAR switch into the column selection.
            result.ranking.push('war');
        }
        for (const type of Object.keys(result)) {
            const selected = new Set(result[type]);
            result[type] = [...allowed[type]].filter((id) => selected.has(id));
        }
        return result;
    }

    function normaliseMatchPredictionMode(value) {
        return value === 'market' || value === 'stats-only' ? value : 'stats';
    }

    function normalisePredictionMarketPercent(value) {
        return typeof value === 'number' && Number.isFinite(value)
            ? Math.min(100, Math.max(0, value))
            : DEFAULT_SETTINGS.predictionMarketPercent;
    }

    async function loadSettings() {
        const [
            rawExtensionDisabled,
            rawPredictionMarketPercent,
            rawActivitySources,
            rawDisplayedForums,
            rawSelectedForums,
            rawHideMatches,
            rawHideNews,
            rawRemoveNewsMatches,
            rawActivitySourceColors,
            rawEnableCustomThreadFetching,
            rawEnableCustomThreadColors,
            rawChangeUpvoteStyle,
            rawEnableWinAdjustedRatings,
            rawWinAdjustedAutoRun,
            rawEnableKprEstimate,
            rawEnableKprMatchHistory,
            rawShowFullMapNames,
            rawEnableThreadPreviews,
            rawEnableOriginalPosterHighlight,
            rawEnableReadStatus,
            rawReplyComposerAfterOriginalPost,
            rawEnableSavedDrafts,
            rawEnableUserTags,
            rawEnableLocalUserScores,
            rawEnableLocalDownvotes,
            rawEnableUsernameBlocking,
            rawEnableSignedOutLocalVoting,
            rawEnableExtendedMatchFilter,
            rawStrictSelectedTeamMatches,
            rawMovePostNewTopicToTop,
            rawHiddenUserTags,
            rawLayoutWidthPreset,
            rawLargeSidebarText,
            rawForumThreadLimits,
            rawShowRelativeAges,
            rawEnableDiagnosticLogging,
            rawEnableStickyMatchHeader,
            rawEnableMatchPlayerFormOverlays,
            rawEnableMatchPrediction,
            rawMatchPredictionMode,
            rawEnableTeamPerformanceDifference,
            rawMatchPlayerPrimaryMetrics,
            rawMatchPlayerPrimaryMetric1,
            rawMatchPlayerPrimaryMetric2,
            rawEnableStatsColumnChooser,
            rawEnableStatsMultiSort,
            rawEnableDerivedStatsColumns,
            rawStatsOptionalColumnsV2,
            rawEnableStatsCsvExport,
            rawEnablePlayerMatchSparklines,
            rawEnableExtendedMatchHistoryLoading,
            rawPlayerMatchTrendMetric,
            rawEnablePlayerMapMatrix,
            rawEnablePlayerComparisonEnhancements,
            rawEnablePlayerConsistencyScore,
            rawEnablePreviousPeriodComparison,
            rawEnableStatsTablePeriodComparison,
            rawEnablePlayerPagePeriodComparison,
            rawPreviousPeriodMetric,
            rawSortOrder,
        ] = await Promise.all([
            storageGet('extensionDisabled', DEFAULT_SETTINGS.extensionDisabled),
            storageGet('predictionMarketPercent', DEFAULT_SETTINGS.predictionMarketPercent),
            storageGet('activitySourcesV2', null),
            storageGet('displayedForumsV1', null),
            storageGet('selectedForums', null),
            storageGet('hideMatches', null),
            storageGet('hideNews', null),
            storageGet('removeNewsMatches', null),
            storageGet('activitySourceColorsV1', DEFAULT_SETTINGS.activitySourceColors),
            storageGet(
                'enableCustomThreadFetching',
                DEFAULT_SETTINGS.enableCustomThreadFetching,
            ),
            storageGet(
                'enableCustomThreadColors',
                DEFAULT_SETTINGS.enableCustomThreadColors,
            ),
            storageGet('changeUpvoteStyle', DEFAULT_SETTINGS.changeUpvoteStyle),
            storageGet('enableWinAdjustedRatings', null),
            storageGet('winAdjustedAutoRun', null),
            storageGet('enableKprEstimate', null),
            storageGet('enableKprMatchHistory', null),
            storageGet('showFullMapNames', DEFAULT_SETTINGS.showFullMapNames),
            storageGet('enableThreadPreviews', DEFAULT_SETTINGS.enableThreadPreviews),
            storageGet(
                'enableOriginalPosterHighlight',
                DEFAULT_SETTINGS.enableOriginalPosterHighlight,
            ),
            storageGet('enableReadStatus', DEFAULT_SETTINGS.enableReadStatus),
            storageGet(
                'replyComposerAfterOriginalPost',
                DEFAULT_SETTINGS.replyComposerAfterOriginalPost,
            ),
            storageGet('enableSavedDrafts', DEFAULT_SETTINGS.enableSavedDrafts),
            storageGet('enableUserTags', DEFAULT_SETTINGS.enableUserTags),
            storageGet('enableLocalUserScores', DEFAULT_SETTINGS.enableLocalUserScores),
            storageGet('enableLocalDownvotes', null),
            storageGet('enableUsernameBlocking', DEFAULT_SETTINGS.enableUsernameBlocking),
            storageGet(
                'enableSignedOutLocalVoting',
                DEFAULT_SETTINGS.enableSignedOutLocalVoting,
            ),
            storageGet(
                'enableExtendedMatchFilter',
                DEFAULT_SETTINGS.enableExtendedMatchFilter,
            ),
            storageGet(
                'strictSelectedTeamMatches',
                DEFAULT_SETTINGS.strictSelectedTeamMatches,
            ),
            storageGet(
                'movePostNewTopicToTop',
                DEFAULT_SETTINGS.movePostNewTopicToTop,
            ),
            storageGet('hiddenUserTags', DEFAULT_SETTINGS.hiddenUserTags),
            storageGet('layoutWidthPreset', DEFAULT_SETTINGS.layoutWidthPreset),
            storageGet('largeSidebarText', DEFAULT_SETTINGS.largeSidebarText),
            storageGet('forumThreadLimits', DEFAULT_SETTINGS.forumThreadLimits),
            storageGet('showRelativeAges', DEFAULT_SETTINGS.showRelativeAges),
            storageGet(
                'enableDiagnosticLogging',
                DEFAULT_SETTINGS.enableDiagnosticLogging,
            ),
            storageGet('enableStickyMatchHeader', DEFAULT_SETTINGS.enableStickyMatchHeader),
            storageGet(
                'enableMatchPlayerFormOverlays',
                DEFAULT_SETTINGS.enableMatchPlayerFormOverlays,
            ),
            storageGet('enableMatchPrediction', DEFAULT_SETTINGS.enableMatchPrediction),
            storageGet('matchPredictionMode', DEFAULT_SETTINGS.matchPredictionMode),
            storageGet(
                'enableTeamPerformanceDifference',
                DEFAULT_SETTINGS.enableTeamPerformanceDifference,
            ),
            storageGet('matchPlayerPrimaryMetrics', null),
            storageGet(
                'matchPlayerPrimaryMetric1',
                DEFAULT_SETTINGS.matchPlayerPrimaryMetric1,
            ),
            storageGet(
                'matchPlayerPrimaryMetric2',
                DEFAULT_SETTINGS.matchPlayerPrimaryMetric2,
            ),
            storageGet('enableStatsColumnChooser', DEFAULT_SETTINGS.enableStatsColumnChooser),
            storageGet('enableStatsMultiSort', DEFAULT_SETTINGS.enableStatsMultiSort),
            storageGet('enableDerivedStatsColumns', null),
            storageGet('statsOptionalColumnsV2', null),
            storageGet('enableStatsCsvExport', DEFAULT_SETTINGS.enableStatsCsvExport),
            storageGet(
                'enablePlayerMatchSparklines',
                DEFAULT_SETTINGS.enablePlayerMatchSparklines,
            ),
            storageGet(
                'enableExtendedMatchHistoryLoading',
                DEFAULT_SETTINGS.enableExtendedMatchHistoryLoading,
            ),
            storageGet('playerMatchTrendMetric', DEFAULT_SETTINGS.playerMatchTrendMetric),
            storageGet('enablePlayerMapMatrix', DEFAULT_SETTINGS.enablePlayerMapMatrix),
            storageGet(
                'enablePlayerComparisonEnhancements',
                DEFAULT_SETTINGS.enablePlayerComparisonEnhancements,
            ),
            storageGet(
                'enablePlayerConsistencyScore',
                DEFAULT_SETTINGS.enablePlayerConsistencyScore,
            ),
            storageGet(
                'enablePreviousPeriodComparison',
                null,
            ),
            storageGet('enableStatsTablePeriodComparison', null),
            storageGet('enablePlayerPagePeriodComparison', null),
            storageGet('previousPeriodMetric', DEFAULT_SETTINGS.previousPeriodMetric),
            storageGet('sortOrder', null),
        ]);

        const legacyHideNewsMatches = rawRemoveNewsMatches === null
            ? null
            : toBoolean(rawRemoveNewsMatches, null);
        const hideMatches = toBoolean(
            rawHideMatches,
            legacyHideNewsMatches ?? false,
        );
        const hideNews = toBoolean(
            rawHideNews,
            legacyHideNewsMatches ?? false,
        );
        const hasLegacySourceSelection = Array.isArray(rawDisplayedForums)
            || Array.isArray(rawSelectedForums)
            || rawHideMatches !== null
            || rawHideNews !== null
            || rawRemoveNewsMatches !== null;
        const legacySelectedForums = Array.isArray(rawSelectedForums)
            ? normaliseSelectedForumIds(rawSelectedForums)
            : [];
        const migratedForumIds = Array.isArray(rawDisplayedForums)
            ? normaliseSelectedForumIds(rawDisplayedForums)
            : legacySelectedForums.length ? legacySelectedForums : FORUMS.map((forum) => forum.id);
        const selectedForums = Array.isArray(rawActivitySources)
            ? normaliseSelectedActivitySourceIds(rawActivitySources)
            : !hasLegacySourceSelection
                ? [...DEFAULT_SETTINGS.selectedForums]
                : [
                    ...migratedForumIds,
                    ...(hideNews ? [] : ['news']),
                    ...(hideMatches ? [] : ['matches']),
                ];
        const enableLocalUserScores = toBoolean(
            rawEnableLocalUserScores,
            DEFAULT_SETTINGS.enableLocalUserScores,
        );
        const legacyWarEnabled = rawEnableWinAdjustedRatings === null
            ? null
            : toBoolean(rawEnableWinAdjustedRatings, DEFAULT_SETTINGS.enableWinAdjustedRatings);
        const statsOptionalColumnsV2 = normaliseStatsOptionalColumns(
            rawStatsOptionalColumnsV2,
            rawEnableKprEstimate === null
                ? null
                : toBoolean(rawEnableKprEstimate, false),
            rawEnableDerivedStatsColumns === null
                ? null
                : toBoolean(rawEnableDerivedStatsColumns, false),
            rawEnableKprMatchHistory === null
                ? null
                : toBoolean(rawEnableKprMatchHistory, false),
            legacyWarEnabled,
        );
        const enableStatsColumnChooser = toBoolean(
            rawEnableStatsColumnChooser,
            DEFAULT_SETTINGS.enableStatsColumnChooser,
        );

        const matchPlayerPrimaryMetrics = normaliseMatchPlayerMetrics(
            rawMatchPlayerPrimaryMetrics,
            rawMatchPlayerPrimaryMetric1,
            rawMatchPlayerPrimaryMetric2,
        );
        const [
            matchPlayerPrimaryMetric1,
            matchPlayerPrimaryMetric2,
        ] = legacyMatchPlayerMetricPair(matchPlayerPrimaryMetrics);

        return {
            extensionDisabled: toBoolean(rawExtensionDisabled, false),
            predictionMarketPercent: normalisePredictionMarketPercent(rawPredictionMarketPercent),
            selectedForums,
            activitySourceColors: normaliseActivitySourceColors(rawActivitySourceColors),
            enableCustomThreadFetching: toBoolean(
                rawEnableCustomThreadFetching,
                DEFAULT_SETTINGS.enableCustomThreadFetching,
            ),
            enableCustomThreadColors: toBoolean(
                rawEnableCustomThreadColors,
                DEFAULT_SETTINGS.enableCustomThreadColors,
            ),
            changeUpvoteStyle: toBoolean(rawChangeUpvoteStyle, DEFAULT_SETTINGS.changeUpvoteStyle),
            enableWinAdjustedRatings: enableStatsColumnChooser
                && statsOptionalColumnsV2.ranking.includes('war'),
            winAdjustedAutoRun: toBoolean(
                rawWinAdjustedAutoRun,
                DEFAULT_SETTINGS.winAdjustedAutoRun,
            ),
            showFullMapNames: toBoolean(
                rawShowFullMapNames,
                DEFAULT_SETTINGS.showFullMapNames,
            ),
            enableThreadPreviews: toBoolean(rawEnableThreadPreviews, DEFAULT_SETTINGS.enableThreadPreviews),
            enableOriginalPosterHighlight: toBoolean(
                rawEnableOriginalPosterHighlight,
                DEFAULT_SETTINGS.enableOriginalPosterHighlight,
            ),
            enableReadStatus: toBoolean(rawEnableReadStatus, DEFAULT_SETTINGS.enableReadStatus),
            replyComposerAfterOriginalPost: toBoolean(
                rawReplyComposerAfterOriginalPost,
                DEFAULT_SETTINGS.replyComposerAfterOriginalPost,
            ),
            enableSavedDrafts: toBoolean(rawEnableSavedDrafts, DEFAULT_SETTINGS.enableSavedDrafts),
            enableUserTags: toBoolean(rawEnableUserTags, DEFAULT_SETTINGS.enableUserTags),
            enableLocalUserScores,
            enableLocalDownvotes: rawEnableLocalDownvotes === null
                ? enableLocalUserScores
                : toBoolean(rawEnableLocalDownvotes, DEFAULT_SETTINGS.enableLocalDownvotes),
            enableUsernameBlocking: toBoolean(
                rawEnableUsernameBlocking,
                DEFAULT_SETTINGS.enableUsernameBlocking,
            ),
            enableSignedOutLocalVoting: toBoolean(
                rawEnableSignedOutLocalVoting,
                DEFAULT_SETTINGS.enableSignedOutLocalVoting,
            ),
            enableExtendedMatchFilter: toBoolean(
                rawEnableExtendedMatchFilter,
                DEFAULT_SETTINGS.enableExtendedMatchFilter,
            ),
            strictSelectedTeamMatches: toBoolean(
                rawStrictSelectedTeamMatches,
                DEFAULT_SETTINGS.strictSelectedTeamMatches,
            ),
            movePostNewTopicToTop: toBoolean(
                rawMovePostNewTopicToTop,
                DEFAULT_SETTINGS.movePostNewTopicToTop,
            ),
            hiddenUserTags: normaliseHiddenUserTags(rawHiddenUserTags),
            layoutWidthPreset: normaliseLayoutWidthPreset(rawLayoutWidthPreset),
            largeSidebarText: toBoolean(rawLargeSidebarText, DEFAULT_SETTINGS.largeSidebarText),
            forumThreadLimits: normaliseForumThreadLimits(rawForumThreadLimits),
            showRelativeAges: toBoolean(rawShowRelativeAges, DEFAULT_SETTINGS.showRelativeAges),
            enableDiagnosticLogging: toBoolean(
                rawEnableDiagnosticLogging,
                DEFAULT_SETTINGS.enableDiagnosticLogging,
            ),
            enableStickyMatchHeader: toBoolean(
                rawEnableStickyMatchHeader,
                DEFAULT_SETTINGS.enableStickyMatchHeader,
            ),
            enableMatchPlayerFormOverlays: toBoolean(
                rawEnableMatchPlayerFormOverlays,
                DEFAULT_SETTINGS.enableMatchPlayerFormOverlays,
            ),
            enableMatchPrediction: toBoolean(
                rawEnableMatchPrediction,
                DEFAULT_SETTINGS.enableMatchPrediction,
            ),
            matchPredictionMode: normaliseMatchPredictionMode(rawMatchPredictionMode),
            enableTeamPerformanceDifference: toBoolean(
                rawEnableTeamPerformanceDifference,
                DEFAULT_SETTINGS.enableTeamPerformanceDifference,
            ),
            matchPlayerPrimaryMetrics,
            matchPlayerPrimaryMetric1,
            matchPlayerPrimaryMetric2,
            enableStatsColumnChooser,
            enableStatsMultiSort: toBoolean(
                rawEnableStatsMultiSort,
                DEFAULT_SETTINGS.enableStatsMultiSort,
            ),
            statsOptionalColumnsV2,
            enableStatsCsvExport: toBoolean(
                rawEnableStatsCsvExport,
                DEFAULT_SETTINGS.enableStatsCsvExport,
            ),
            enablePlayerMatchSparklines: toBoolean(
                rawEnablePlayerMatchSparklines,
                DEFAULT_SETTINGS.enablePlayerMatchSparklines,
            ),
            enableExtendedMatchHistoryLoading: toBoolean(
                rawEnableExtendedMatchHistoryLoading,
                DEFAULT_SETTINGS.enableExtendedMatchHistoryLoading,
            ),
            playerMatchTrendMetric: normaliseStoredMetricName(
                rawPlayerMatchTrendMetric,
                DEFAULT_SETTINGS.playerMatchTrendMetric,
            ),
            enablePlayerMapMatrix: toBoolean(
                rawEnablePlayerMapMatrix,
                DEFAULT_SETTINGS.enablePlayerMapMatrix,
            ),
            enablePlayerComparisonEnhancements: toBoolean(
                rawEnablePlayerComparisonEnhancements,
                DEFAULT_SETTINGS.enablePlayerComparisonEnhancements,
            ),
            enablePlayerConsistencyScore: toBoolean(
                rawEnablePlayerConsistencyScore,
                DEFAULT_SETTINGS.enablePlayerConsistencyScore,
            ),
            enableStatsTablePeriodComparison: rawEnableStatsTablePeriodComparison === null
                ? toBoolean(
                    rawEnablePreviousPeriodComparison,
                    DEFAULT_SETTINGS.enableStatsTablePeriodComparison,
                )
                : toBoolean(
                    rawEnableStatsTablePeriodComparison,
                    DEFAULT_SETTINGS.enableStatsTablePeriodComparison,
                ),
            enablePlayerPagePeriodComparison: rawEnablePlayerPagePeriodComparison === null
                ? toBoolean(
                    rawEnablePreviousPeriodComparison,
                    DEFAULT_SETTINGS.enablePlayerPagePeriodComparison,
                )
                : toBoolean(
                    rawEnablePlayerPagePeriodComparison,
                    DEFAULT_SETTINGS.enablePlayerPagePeriodComparison,
                ),
            previousPeriodMetric: normalisePreviousPeriodMetric(rawPreviousPeriodMetric),
            sortOrder: normaliseSortOrder(rawSortOrder || DEFAULT_SETTINGS.sortOrder),
        };
    }

    function settingsStoragePayload(settings) {
        const selectedForumIds = settings.selectedForums.filter((sourceId) => forumById.has(sourceId));
        const matchPlayerPrimaryMetrics = normaliseMatchPlayerMetrics(
            settings.matchPlayerPrimaryMetrics,
            settings.matchPlayerPrimaryMetric1,
            settings.matchPlayerPrimaryMetric2,
        );
        const [
            matchPlayerPrimaryMetric1,
            matchPlayerPrimaryMetric2,
        ] = legacyMatchPlayerMetricPair(matchPlayerPrimaryMetrics);
        return {
            extensionDisabled: Boolean(settings.extensionDisabled),
            matchPredictionMode: normaliseMatchPredictionMode(settings.matchPredictionMode),
            predictionMarketPercent: normalisePredictionMarketPercent(settings.predictionMarketPercent),
            activitySourcesV2: [...settings.selectedForums],
            displayedForumsV1: selectedForumIds,
            selectedForums: selectedForumIds,
            hideMatches: !settings.selectedForums.includes('matches'),
            hideNews: !settings.selectedForums.includes('news'),
            activitySourceColorsV1: normaliseActivitySourceColors(
                settings.activitySourceColors,
            ),
            enableCustomThreadFetching: Boolean(settings.enableCustomThreadFetching),
            enableCustomThreadColors: Boolean(settings.enableCustomThreadColors),
            changeUpvoteStyle: Boolean(settings.changeUpvoteStyle),
            enableWinAdjustedRatings: Boolean(settings.enableWinAdjustedRatings),
            winAdjustedAutoRun: Boolean(settings.winAdjustedAutoRun),
            showFullMapNames: Boolean(settings.showFullMapNames),
            enableThreadPreviews: Boolean(settings.enableThreadPreviews),
            enableOriginalPosterHighlight: Boolean(settings.enableOriginalPosterHighlight),
            enableReadStatus: Boolean(settings.enableReadStatus),
            replyComposerAfterOriginalPost: Boolean(settings.replyComposerAfterOriginalPost),
            enableSavedDrafts: Boolean(settings.enableSavedDrafts),
            enableUserTags: Boolean(settings.enableUserTags),
            enableLocalUserScores: Boolean(settings.enableLocalUserScores),
            enableLocalDownvotes: Boolean(settings.enableLocalDownvotes),
            enableUsernameBlocking: Boolean(settings.enableUsernameBlocking),
            enableSignedOutLocalVoting: Boolean(settings.enableSignedOutLocalVoting),
            enableExtendedMatchFilter: Boolean(settings.enableExtendedMatchFilter),
            strictSelectedTeamMatches: Boolean(settings.strictSelectedTeamMatches),
            movePostNewTopicToTop: Boolean(settings.movePostNewTopicToTop),
            hiddenUserTags: normaliseHiddenUserTags(settings.hiddenUserTags),
            layoutWidthPreset: normaliseLayoutWidthPreset(settings.layoutWidthPreset),
            largeSidebarText: Boolean(settings.largeSidebarText),
            forumThreadLimits: normaliseForumThreadLimits(settings.forumThreadLimits),
            showRelativeAges: Boolean(settings.showRelativeAges),
            enableDiagnosticLogging: Boolean(settings.enableDiagnosticLogging),
            enableStickyMatchHeader: Boolean(settings.enableStickyMatchHeader),
            enableMatchPlayerFormOverlays: Boolean(settings.enableMatchPlayerFormOverlays),
            enableMatchPrediction: Boolean(settings.enableMatchPrediction),
            enableTeamPerformanceDifference: Boolean(
                settings.enableTeamPerformanceDifference,
            ),
            matchPlayerPrimaryMetrics,
            matchPlayerPrimaryMetric1,
            matchPlayerPrimaryMetric2,
            enableStatsColumnChooser: Boolean(settings.enableStatsColumnChooser),
            enableStatsMultiSort: Boolean(settings.enableStatsMultiSort),
            statsOptionalColumnsV2: normaliseStatsOptionalColumns(
                settings.statsOptionalColumnsV2,
            ),
            enableStatsCsvExport: Boolean(settings.enableStatsCsvExport),
            enablePlayerMatchSparklines: Boolean(settings.enablePlayerMatchSparklines),
            enableExtendedMatchHistoryLoading: Boolean(
                settings.enableExtendedMatchHistoryLoading,
            ),
            enablePlayerMapMatrix: Boolean(settings.enablePlayerMapMatrix),
            enablePlayerComparisonEnhancements: Boolean(
                settings.enablePlayerComparisonEnhancements,
            ),
            enablePlayerConsistencyScore: Boolean(settings.enablePlayerConsistencyScore),
            enableStatsTablePeriodComparison: Boolean(
                settings.enableStatsTablePeriodComparison,
            ),
            enablePlayerPagePeriodComparison: Boolean(
                settings.enablePlayerPagePeriodComparison,
            ),
            previousPeriodMetric: normalisePreviousPeriodMetric(
                settings.previousPeriodMetric,
            ),
            sortOrder: normaliseSortOrder(settings.sortOrder),
        };
    }

    async function saveSettings(settings) {
        await storageSetMany(settingsStoragePayload(settings));
        await emitSyncPulse(['settings']);
    }

    async function saveSortOrder(sortOrder) {
        await storageSet('sortOrder', sortOrder);
        await emitSyncPulse(['settings']);
    }

    function queueSortOrderSave(sortOrder) {
        state.sortSavePromise = state.sortSavePromise
            .catch(() => undefined)
            .then(() => saveSortOrder(sortOrder));
        return state.sortSavePromise;
    }

    function normaliseSelfPostNumbers(value, threshold = 0) {
        if (!Array.isArray(value)) return [];
        const numbers = [...new Set(value
            .map((item) => clampInteger(item, 1, 10_000_000, 0))
            .filter((item) => item > threshold))]
            .sort((a, b) => a - b);
        return numbers.slice(-CONFIG.maxSelfPostNumbersPerThread);
    }

    function normaliseReadState(value) {
        const now = Date.now();
        const source = (value?.schema === 1 || value?.schema === 2)
            && value.entries
            && typeof value.entries === 'object'
            ? value.entries
            : {};
        const entries = [];

        for (const [key, rawEntry] of Object.entries(source)) {
            const threadId = /^\d{1,20}$/.test(key)
                ? key
                : key.match(/^\/forums\/threads\/(\d{1,20})(?:\/|$)/i)?.[1];
            if (!threadId || !rawEntry || typeof rawEntry !== 'object') continue;
            const visitedAt = Number(rawEntry.visitedAt);
            if (!Number.isFinite(visitedAt) || visitedAt < now - CONFIG.readRetentionMs || visitedAt > now + 300000) continue;

            const seenReplyCount = clampInteger(
                rawEntry.seenReplyCount ?? rawEntry.commentsSeen,
                0,
                10_000_000,
                0,
            );
            const maxPostNo = clampInteger(
                rawEntry.maxPostNo ?? rawEntry.commentsSeen,
                0,
                10_000_000,
                0,
            );
            entries.push([threadId, {
                seenReplyCount,
                maxPostNo,
                selfPostNumbers: normaliseSelfPostNumbers(
                    rawEntry.selfPostNumbers,
                    Math.max(seenReplyCount, maxPostNo),
                ),
                visitedAt,
            }]);
        }

        entries.sort((a, b) => b[1].visitedAt - a[1].visitedAt);
        const deduplicated = [];
        const seenThreadIds = new Set();
        for (const entry of entries) {
            if (seenThreadIds.has(entry[0])) continue;
            seenThreadIds.add(entry[0]);
            deduplicated.push(entry);
        }
        return new Map(deduplicated.slice(0, CONFIG.maxReadEntries));
    }

    function serialiseReadState() {
        const entries = [...state.readEntries.entries()]
            .sort((a, b) => b[1].visitedAt - a[1].visitedAt)
            .slice(0, CONFIG.maxReadEntries);
        return {
            schema: 2,
            updatedAt: Date.now(),
            entries: Object.fromEntries(entries),
        };
    }

    function mergeReadStateMaps(first, second) {
        const merged = new Map(first);
        for (const [threadId, incoming] of second) {
            const current = merged.get(threadId);
            if (!current) {
                merged.set(threadId, incoming);
                continue;
            }
            const seenReplyCount = Math.max(current.seenReplyCount, incoming.seenReplyCount);
            const maxPostNo = Math.max(current.maxPostNo, incoming.maxPostNo);
            merged.set(threadId, {
                seenReplyCount,
                maxPostNo,
                selfPostNumbers: normaliseSelfPostNumbers(
                    [
                        ...(current.selfPostNumbers || []),
                        ...(incoming.selfPostNumbers || []),
                    ],
                    Math.max(seenReplyCount, maxPostNo),
                ),
                visitedAt: Math.max(current.visitedAt, incoming.visitedAt),
            });
        }
        return new Map([...merged.entries()]
            .sort((a, b) => b[1].visitedAt - a[1].visitedAt)
            .slice(0, CONFIG.maxReadEntries));
    }

    async function saveReadState() {
        if (!hasPrivateStorage()) return;
        await withLocalReactionStorageLock(async () => {
            const stored = normaliseReadState(
                await privateStorageGet(STORAGE_KEYS.readState, null),
            );
            state.readEntries = mergeReadStateMaps(stored, state.readEntries);
            await privateStorageSet(STORAGE_KEYS.readState, serialiseReadState());
            await emitSyncPulse(['readState']);
        });
    }

    function normaliseUserTags(value) {
        const source = (value?.schema === 1 || value?.schema === 2)
            && value.users
            && typeof value.users === 'object'
            ? value.users
            : {};
        const users = [];

        for (const [userId, rawEntry] of Object.entries(source)) {
            if (!/^\d{1,20}$/.test(userId) || !rawEntry || typeof rawEntry !== 'object') continue;
            // `note` is accepted for a lossless upgrade from versions before tags were renamed.
            const tag = normaliseUserTag(rawEntry.tag ?? rawEntry.note);
            if (!tag) continue;
            const updatedAt = Number(rawEntry.updatedAt);
            users.push([userId, {
                name: cleanText(rawEntry.name).slice(0, 100),
                tag,
                updatedAt: Number.isFinite(updatedAt) ? updatedAt : 0,
            }]);
        }

        users.sort((a, b) => b[1].updatedAt - a[1].updatedAt);
        return new Map(users.slice(0, CONFIG.maxUserTags));
    }

    function serialiseUserTags() {
        const users = Object.fromEntries(
            [...state.userTags.entries()].slice(0, CONFIG.maxUserTags).map(([userId, entry]) => [
                userId,
                {
                    name: entry.name,
                    tag: entry.tag,
                    // Keep older open tabs compatible during a script upgrade.
                    note: entry.tag,
                    updatedAt: entry.updatedAt,
                },
            ]),
        );
        return {
            schema: 1,
            updatedAt: Date.now(),
            users,
        };
    }

    async function saveUserTags() {
        if (!hasPrivateStorage()) return;
        await privateStorageSet(STORAGE_KEYS.userTags, serialiseUserTags());
        await emitSyncPulse(['notes']);
    }

    function parseVoteEndpoint(value) {
        const url = parseSameOriginUrl(value);
        if (!url || url.search || url.hash) return null;
        const match = url.pathname.match(/^\/(thread|reply)-plus-toogle\/(\d{1,20})\/?$/i);
        if (!match) return null;
        const kind = match[1].toLowerCase();
        const id = match[2];
        return {
            kind,
            id,
            key: `${kind}:${id}`,
            path: `/${kind}-plus-toogle/${id}`,
        };
    }

    function parseReactionKey(value) {
        const match = String(value || '').match(/^(thread|reply):(\d{1,20})$/);
        return match ? { kind: match[1], id: match[2], key: `${match[1]}:${match[2]}` } : null;
    }

    function compareReactionEntries(first, second) {
        const timestampDifference = Number(first?.updatedAt || 0) - Number(second?.updatedAt || 0);
        if (timestampDifference) return timestampDifference;
        return String(first?.mutationId || '').localeCompare(String(second?.mutationId || ''));
    }

    function normaliseLocalReactionResetTimestamp(value) {
        const timestamp = Number(value);
        if (!Number.isFinite(timestamp) || timestamp === 0) return 0;
        const now = Date.now();
        return timestamp >= CONFIG.minValidTimestampMs && timestamp <= now + 300000
            ? timestamp
            : 0;
    }

    function localReactionResetAtFromRecord(value) {
        return value?.schema === 2
            ? normaliseLocalReactionResetTimestamp(value.resetAt)
            : 0;
    }

    function normaliseLocalReactions(value, minimumResetAt = 0) {
        const now = Date.now();
        const resetAt = Math.max(
            normaliseLocalReactionResetTimestamp(minimumResetAt),
            localReactionResetAtFromRecord(value),
        );
        const source = (value?.schema === 1 || value?.schema === 2)
            && value.reactions
            && typeof value.reactions === 'object'
            ? value.reactions
            : {};
        const reactions = [];

        let inspected = 0;
        for (const [rawKey, rawEntry] of Object.entries(source)) {
            inspected += 1;
            if (inspected > CONFIG.maxLocalReactions * 4) break;
            const identity = parseReactionKey(rawKey);
            if (!identity || !rawEntry || typeof rawEntry !== 'object') continue;
            const authorId = String(rawEntry.authorId ?? '');
            const reactionValue = Number(rawEntry.value);
            const updatedAt = Number(rawEntry.updatedAt);
            if (!/^\d{1,20}$/.test(authorId)
                || ![-1, 0, 1].includes(reactionValue)
                || !Number.isFinite(updatedAt)
                || updatedAt < CONFIG.minValidTimestampMs
                || updatedAt > now + 300000
                || updatedAt <= resetAt
                || (reactionValue === 0
                    && updatedAt < now - CONFIG.localReactionTombstoneRetentionMs)) continue;
            const rawMutationId = String(rawEntry.mutationId || `${updatedAt}:legacy`);
            const mutationId = /^[A-Za-z0-9_.:-]{1,80}$/.test(rawMutationId)
                ? rawMutationId
                : `${updatedAt}:legacy`;
            reactions.push([identity.key, {
                authorId,
                value: reactionValue,
                updatedAt,
                mutationId,
            }]);
        }

        reactions.sort((a, b) => compareReactionEntries(b[1], a[1]));
        return new Map(reactions.slice(0, CONFIG.maxLocalReactions));
    }

    function mergeLocalReactionMaps(first, second, resetAt = state.localReactionResetAt) {
        const merged = new Map(first);
        for (const [key, incoming] of second) {
            const current = merged.get(key);
            if (!current || compareReactionEntries(incoming, current) > 0) {
                merged.set(key, incoming);
            }
        }
        return normaliseLocalReactions({
            schema: 2,
            resetAt,
            reactions: Object.fromEntries(merged),
        }, resetAt);
    }

    function localReactionMapsEqual(first, second) {
        if (first.size !== second.size) return false;
        for (const [key, entry] of first) {
            const other = second.get(key);
            if (!other
                || entry.authorId !== other.authorId
                || entry.value !== other.value
                || entry.updatedAt !== other.updatedAt
                || entry.mutationId !== other.mutationId) return false;
        }
        return true;
    }

    function serialiseLocalReactions(
        reactions = state.localReactions,
        resetAt = state.localReactionResetAt,
    ) {
        return {
            schema: 2,
            resetAt: normaliseLocalReactionResetTimestamp(resetAt),
            updatedAt: Date.now(),
            reactions: Object.fromEntries(
                [...reactions.entries()]
                    .sort((a, b) => compareReactionEntries(b[1], a[1]))
                    .slice(0, CONFIG.maxLocalReactions),
            ),
        };
    }

    function mergeLocalReactionRecord(
        storedValue,
        localReactions = state.localReactions,
        localResetAt = state.localReactionResetAt,
    ) {
        const resetAt = Math.max(
            normaliseLocalReactionResetTimestamp(localResetAt),
            localReactionResetAtFromRecord(storedValue),
        );
        const stored = normaliseLocalReactions(storedValue, resetAt);
        const local = normaliseLocalReactions(
            serialiseLocalReactions(localReactions, localResetAt),
            resetAt,
        );
        return {
            resetAt,
            reactions: mergeLocalReactionMaps(stored, local, resetAt),
        };
    }

    function rebuildLocalUserScores() {
        const scores = new Map();
        for (const reaction of state.localReactions.values()) {
            if (reaction.value === 0) continue;
            scores.set(reaction.authorId, (scores.get(reaction.authorId) || 0) + reaction.value);
        }
        state.localUserScores = scores;
    }

    function getLocalReactionValue(reactionKey) {
        return state.localReactions.get(String(reactionKey || ''))?.value || 0;
    }

    function normaliseProvisionalLocalUpvotes(value, reactions = null) {
        const source = value?.schema === 1
            && value.upvotes
            && typeof value.upvotes === 'object'
            ? value.upvotes
            : {};
        const now = Date.now();
        const upvotes = [];
        let inspected = 0;
        for (const [rawKey, rawEntry] of Object.entries(source)) {
            inspected += 1;
            if (inspected > CONFIG.maxLocalReactions * 4) break;
            const identity = parseReactionKey(rawKey);
            const authorId = String(rawEntry?.authorId ?? '');
            const mutationId = String(rawEntry?.reactionMutationId || '');
            const updatedAt = Number(rawEntry?.updatedAt);
            if (!identity
                || !/^\d{1,20}$/.test(authorId)
                || !/^[A-Za-z0-9_.:-]{1,80}$/.test(mutationId)
                || !Number.isFinite(updatedAt)
                || updatedAt < CONFIG.minValidTimestampMs
                || updatedAt > now + 300000) continue;
            if (reactions) {
                const reaction = reactions.get(identity.key);
                if (!reaction
                    || reaction.value !== 1
                    || reaction.authorId !== authorId
                    || reaction.mutationId !== mutationId) continue;
            }
            upvotes.push([identity.key, {
                authorId,
                reactionMutationId: mutationId,
                updatedAt,
            }]);
        }
        upvotes.sort((a, b) => b[1].updatedAt - a[1].updatedAt);
        return new Map(upvotes.slice(0, CONFIG.maxLocalReactions));
    }

    function mergeProvisionalLocalUpvotes(first, second, reactions = null) {
        const merged = new Map(first);
        for (const [key, incoming] of second) {
            const current = merged.get(key);
            const reaction = reactions?.get(key);
            const currentMatches = Boolean(
                reaction
                && current?.authorId === reaction.authorId
                && current?.reactionMutationId === reaction.mutationId,
            );
            const incomingMatches = Boolean(
                reaction
                && incoming?.authorId === reaction.authorId
                && incoming?.reactionMutationId === reaction.mutationId,
            );
            if (!current
                || incoming.updatedAt > current.updatedAt
                || (incoming.updatedAt === current.updatedAt
                    && incomingMatches !== currentMatches
                    && incomingMatches)
                || (incoming.updatedAt === current.updatedAt
                    && incomingMatches === currentMatches
                    && incoming.reactionMutationId.localeCompare(
                        current.reactionMutationId,
                    ) > 0)) {
                merged.set(key, incoming);
            }
        }
        return new Map(
            [...merged.entries()]
                .sort((a, b) => b[1].updatedAt - a[1].updatedAt)
                .slice(0, CONFIG.maxLocalReactions),
        );
    }

    function serialiseProvisionalLocalUpvotes(
        upvotes = state.provisionalLocalUpvotes,
    ) {
        return {
            schema: 1,
            updatedAt: Date.now(),
            upvotes: Object.fromEntries(
                [...upvotes.entries()]
                    .sort((a, b) => b[1].updatedAt - a[1].updatedAt)
                    .slice(0, CONFIG.maxLocalReactions),
            ),
        };
    }

    function isProvisionalLocalUpvote(reactionKey) {
        const key = String(reactionKey || '');
        const marker = state.provisionalLocalUpvotes.get(key);
        const reaction = state.localReactions.get(key);
        return Boolean(marker
            && reaction?.value === 1
            && marker.authorId === reaction.authorId
            && marker.reactionMutationId === reaction.mutationId);
    }

    async function readCanonicalLocalReactionState(reactionKey) {
        const identity = parseReactionKey(reactionKey);
        if (!identity || !hasPrivateStorage()) {
            return { reaction: null, provisional: false };
        }
        const [reactionValue, provisionalValue] = await Promise.all([
            privateStorageGetStrict(STORAGE_KEYS.localReactions),
            privateStorageGetStrict(STORAGE_KEYS.provisionalLocalUpvotes),
        ]);
        const resetAt = localReactionResetAtFromRecord(reactionValue);
        const reactions = normaliseLocalReactions(reactionValue, resetAt);
        const provisional = normaliseProvisionalLocalUpvotes(
            provisionalValue,
            reactions,
        );
        return {
            reaction: reactions.get(identity.key) || null,
            provisional: provisional.has(identity.key),
        };
    }

    function readLocalReactionStorageLease() {
        const key = `${CONFIG.storagePrefix}localReactionStorageLeaseV1`;
        const rawValue = safePrivateCacheGet(key);
        if (!rawValue) return null;
        try {
            const value = JSON.parse(rawValue);
            const owner = String(value?.owner || '');
            const expiresAt = Number(value?.expiresAt);
            if (!/^[A-Za-z0-9_:-]{1,100}$/.test(owner)
                || !Number.isFinite(expiresAt)
                || expiresAt <= Date.now()
                || expiresAt > Date.now() + 30000) {
                safePrivateCacheRemove(key);
                return null;
            }
            return { key, owner, expiresAt };
        } catch {
            safePrivateCacheRemove(key);
            return null;
        }
    }

    async function withLocalReactionStorageLease(operation) {
        const key = `${CONFIG.storagePrefix}localReactionStorageLeaseV1`;
        const owner = createRandomId('reaction-lease');
        const acquisitionDeadline = Date.now() + 5000;
        const leaseDurationMs = 10000;

        while (Date.now() < acquisitionDeadline) {
            const current = readLocalReactionStorageLease();
            if (current && current.owner !== owner) {
                await delay(15 + Math.floor(Math.random() * 25));
                continue;
            }

            try {
                await privateCacheSetAndWait(key, JSON.stringify({
                    owner,
                    expiresAt: Date.now() + leaseDurationMs,
                }));
            } catch (error) {
                log('Could not store the cross-tab reaction lease.', error);
                throw new Error('Could not store the cross-tab reaction lease.');
            }

            await delay(20 + Math.floor(Math.random() * 20));
            if (readLocalReactionStorageLease()?.owner !== owner) continue;

            const heartbeat = window.setInterval(() => {
                if (readLocalReactionStorageLease()?.owner !== owner) return;
                privateCacheSetAndWait(key, JSON.stringify({
                    owner,
                    expiresAt: Date.now() + leaseDurationMs,
                })).catch((error) => log('Could not renew the cross-tab reaction lease.', error));
            }, 2000);

            let result;
            let completed = false;
            let operationError = null;
            try {
                result = await operation();
                completed = true;
            } catch (error) {
                operationError = error;
            } finally {
                window.clearInterval(heartbeat);
            }

            const stillOwner = readLocalReactionStorageLease()?.owner === owner;
            if (stillOwner) await privateCacheRemoveAndWait(key);
            if (operationError) throw operationError;
            if (completed && stillOwner) return result;

            // A stale contender replaced the lease while the operation ran.
            // Re-run after reacquiring so its canonical read merges both writes.
            await delay(15 + Math.floor(Math.random() * 25));
        }

        throw new Error('Timed out acquiring the cross-tab reaction lease.');
    }

    async function withLocalReactionStorageLock(operation) {
        // Firefox content scripts can expose a page-realm LockManager whose
        // returned thenable is blocked by the compartment boundary. The
        // extension-private storage lease provides the same cross-tab guard
        // without passing promises through that boundary.
        if (capturedFirefoxExtensionRuntime || typeof safeLockRequest !== 'function') {
            return withLocalReactionStorageLease(operation);
        }
        let operationStarted = false;
        try {
            return await safeLockRequest(
                'hltv-forum-sidebar-plus-local-reactions-v1',
                { mode: 'exclusive' },
                () => {
                    operationStarted = true;
                    return operation();
                },
            );
        } catch (error) {
            if (operationStarted) throw error;
            log('Cross-tab reaction lock is unavailable; using a storage lease.', error);
            return withLocalReactionStorageLease(operation);
        }
    }

    function hasCrossTabActionLocks() {
        if (capturedFirefoxExtensionRuntime) {
            return Boolean(extensionPrivateActionLocks());
        }
        return typeof safeLockRequest === 'function';
    }

    function crossTabActionError(kind, reason) {
        const actionLabel = kind === 'reply'
            ? 'reply'
            : kind === 'block'
                ? 'block action'
                : kind === 'draft' ? 'saved-draft change' : 'vote';
        if (kind === 'draft') {
            return makeActionError(
                reason === 'contended'
                    ? 'Another tab already holds the saved-draft action lock.'
                    : 'Cross-tab saved-draft locking is unavailable.',
                reason === 'contended'
                    ? 'Another tab is changing saved drafts for this account. Try again in a moment.'
                    : 'Saved drafts were not changed because cross-tab protection is unavailable.',
            );
        }
        if (reason === 'contended') {
            return makeActionError(
                `Another tab already holds the ${actionLabel} action lock.`,
                `Another tab is already processing this ${actionLabel}. No duplicate request was sent.`,
            );
        }
        return makeActionError(
            `Cross-tab ${actionLabel} locking is unavailable.`,
            `For safety, no ${actionLabel} was sent because this browser could not guarantee duplicate-action protection.`,
        );
    }

    async function withCrossTabActionLock(kind, target, operation) {
        if (!isActionLockTarget(kind, target)) {
            throw makeActionError('Invalid action-lock target.', 'This action is unavailable.');
        }
        if (capturedFirefoxExtensionRuntime) {
            const actionLocks = extensionPrivateActionLocks();
            if (!actionLocks) throw crossTabActionError(kind, 'unavailable');
            let lease;
            try {
                lease = await actionLocks.acquire(kind, String(target));
            } catch (error) {
                log(`Extension-private ${kind} action lock acquisition failed.`, error);
                throw crossTabActionError(
                    kind,
                    error?.code === 'contended' ? 'contended' : 'unavailable',
                );
            }
            if (!lease || typeof lease.release !== 'function') {
                throw crossTabActionError(kind, 'unavailable');
            }
            try {
                return await operation();
            } finally {
                try {
                    lease.release();
                } catch (error) {
                    log(`Extension-private ${kind} action lock release failed.`, error);
                }
            }
        }
        if (typeof safeLockRequest !== 'function') {
            throw crossTabActionError(kind, 'unavailable');
        }
        let callbackReached = false;
        try {
            const result = await safeLockRequest(
                `hltv-forum-sidebar-plus-${kind}-${target}`,
                { mode: 'exclusive', ifAvailable: true },
                (lock) => {
                    callbackReached = true;
                    if (!lock) throw crossTabActionError(kind, 'contended');
                    return operation();
                },
            );
            if (!callbackReached) throw crossTabActionError(kind, 'unavailable');
            return result;
        } catch (error) {
            if (callbackReached) throw error;
            log(`Cross-tab ${kind} action lock acquisition failed.`, error);
            throw crossTabActionError(kind, 'unavailable');
        }
    }

    function queueLocalReactionMutation(reactionKey, authorId, value, options = {}) {
        const identity = parseReactionKey(reactionKey);
        const normalisedAuthorId = String(authorId || '');
        const normalisedValue = Number(value);
        const provisional = Boolean(options.provisional && normalisedValue === 1);
        if (!identity
            || !/^\d{1,20}$/.test(normalisedAuthorId)
            || ![-1, 0, 1].includes(normalisedValue)
            || !hasPrivateStorage()) {
            return Promise.reject(new Error('Local reaction data is unavailable or invalid.'));
        }

        state.reactionSavePromise = state.reactionSavePromise
            .catch(() => undefined)
            .then(() => withLocalReactionStorageLock(async () => {
                const [storedValue, storedProvisionalValue] = await Promise.all([
                    privateStorageGetStrict(STORAGE_KEYS.localReactions),
                    privateStorageGetStrict(STORAGE_KEYS.provisionalLocalUpvotes),
                ]);
                const merged = mergeLocalReactionRecord(
                    storedValue,
                    state.localReactions,
                    state.localReactionResetAt,
                );
                const next = merged.reactions;
                const current = next.get(identity.key);
                const mutation = {
                    authorId: normalisedAuthorId,
                    value: normalisedValue,
                    updatedAt: Math.max(
                        Date.now(),
                        merged.resetAt + 1,
                        Number(current?.updatedAt || 0) + 1,
                    ),
                    mutationId: createRandomId('reaction'),
                };
                next.set(identity.key, mutation);
                let provisionalUpvotes = mergeProvisionalLocalUpvotes(
                    normaliseProvisionalLocalUpvotes(storedProvisionalValue),
                    state.provisionalLocalUpvotes,
                    next,
                );
                if (provisional) {
                    provisionalUpvotes.set(identity.key, {
                        authorId: normalisedAuthorId,
                        reactionMutationId: mutation.mutationId,
                        updatedAt: mutation.updatedAt,
                    });
                    await privateStorageSet(
                        STORAGE_KEYS.provisionalLocalUpvotes,
                        serialiseProvisionalLocalUpvotes(provisionalUpvotes),
                    );
                }
                const bounded = normaliseLocalReactions(
                    serialiseLocalReactions(next, merged.resetAt),
                    merged.resetAt,
                );
                await privateStorageSet(
                    STORAGE_KEYS.localReactions,
                    serialiseLocalReactions(bounded, merged.resetAt),
                );

                const confirmedValue = await privateStorageGetStrict(STORAGE_KEYS.localReactions);
                const confirmedResetAt = Math.max(
                    merged.resetAt,
                    localReactionResetAtFromRecord(confirmedValue),
                );
                const confirmed = normaliseLocalReactions(confirmedValue, confirmedResetAt);
                const pending = normaliseLocalReactions(
                    serialiseLocalReactions(bounded, merged.resetAt),
                    confirmedResetAt,
                );
                const union = mergeLocalReactionMaps(
                    pending,
                    confirmed,
                    confirmedResetAt,
                );
                if (confirmedValue?.schema !== 2
                    || localReactionResetAtFromRecord(confirmedValue) !== confirmedResetAt
                    || !localReactionMapsEqual(confirmed, union)) {
                    await privateStorageSet(
                        STORAGE_KEYS.localReactions,
                        serialiseLocalReactions(union, confirmedResetAt),
                    );
                }
                const unionEntry = union.get(identity.key);
                if (!provisional
                    || unionEntry?.value !== 1
                    || unionEntry.authorId !== normalisedAuthorId
                    || unionEntry.mutationId !== mutation.mutationId) {
                    provisionalUpvotes.delete(identity.key);
                }
                provisionalUpvotes = normaliseProvisionalLocalUpvotes(
                    serialiseProvisionalLocalUpvotes(provisionalUpvotes),
                    union,
                );
                try {
                    await privateStorageSet(
                        STORAGE_KEYS.provisionalLocalUpvotes,
                        serialiseProvisionalLocalUpvotes(provisionalUpvotes),
                    );
                } catch (error) {
                    log('Could not sweep provisional local-upvote markers.', error);
                }
                state.localReactionResetAt = confirmedResetAt;
                state.localReactions = union;
                state.provisionalLocalUpvotes = provisionalUpvotes;
                rebuildLocalUserScores();
                refreshLocalReactionUi(normalisedAuthorId, identity.key);
                await emitSyncPulse(['reactions']);
            }));
        return state.reactionSavePromise;
    }

    function resetAllLocalReactionCounts() {
        if (!hasPrivateStorage()) {
            return Promise.reject(new Error('Private extension storage is unavailable.'));
        }

        state.reactionSavePromise = state.reactionSavePromise
            .catch(() => undefined)
            .then(() => withLocalReactionStorageLock(async () => {
                const storedValue = await privateStorageGetStrict(STORAGE_KEYS.localReactions);
                const merged = mergeLocalReactionRecord(
                    storedValue,
                    state.localReactions,
                    state.localReactionResetAt,
                );
                const newestReactionAt = Math.max(
                    0,
                    ...[...merged.reactions.values()].map((entry) => Number(entry.updatedAt || 0)),
                );
                const resetAt = Math.max(
                    Date.now(),
                    merged.resetAt + 1,
                    newestReactionAt,
                );
                const reset = new Map();
                for (const [reactionKey, current] of merged.reactions) {
                    reset.set(reactionKey, {
                        authorId: current.authorId,
                        value: 0,
                        updatedAt: Math.max(resetAt + 1, Number(current.updatedAt || 0) + 1),
                        mutationId: createRandomId('reaction-reset'),
                    });
                }

                const bounded = normaliseLocalReactions(
                    serialiseLocalReactions(reset, resetAt),
                    resetAt,
                );
                await privateStorageSet(
                    STORAGE_KEYS.localReactions,
                    serialiseLocalReactions(bounded, resetAt),
                );

                const confirmedValue = await privateStorageGetStrict(STORAGE_KEYS.localReactions);
                const confirmedResetAt = Math.max(
                    resetAt,
                    localReactionResetAtFromRecord(confirmedValue),
                );
                const confirmed = normaliseLocalReactions(confirmedValue, confirmedResetAt);
                const pending = normaliseLocalReactions(
                    serialiseLocalReactions(bounded, resetAt),
                    confirmedResetAt,
                );
                const union = mergeLocalReactionMaps(
                    pending,
                    confirmed,
                    confirmedResetAt,
                );
                if (confirmedValue?.schema !== 2
                    || localReactionResetAtFromRecord(confirmedValue) !== confirmedResetAt
                    || !localReactionMapsEqual(confirmed, union)) {
                    await privateStorageSet(
                        STORAGE_KEYS.localReactions,
                        serialiseLocalReactions(union, confirmedResetAt),
                    );
                }
                await privateStorageSet(
                    STORAGE_KEYS.provisionalLocalUpvotes,
                    serialiseProvisionalLocalUpvotes(new Map()),
                );
                state.localReactionResetAt = confirmedResetAt;
                state.localReactions = union;
                state.provisionalLocalUpvotes = new Map();
                rebuildLocalUserScores();
                refreshLocalReactionUi();
                await emitSyncPulse(['reactions']);
            }));
        return state.reactionSavePromise;
    }

    async function handleResetLocalReactionCounts(button) {
        if (typeof safeConfirm !== 'function') {
            setModalStatus('Counts could not be reset because browser confirmation is unavailable.');
            return;
        }
        let firstConfirmation = false;
        let secondConfirmation = false;
        try {
            firstConfirmation = safeConfirm(
                'Are you sure you want to reset all local user reaction counts?',
            );
            if (firstConfirmation) {
                secondConfirmation = safeConfirm(
                    'Are you REALLY sure? This permanently clears every local upvote and downvote count.',
                );
            }
        } catch (error) {
            log('Browser confirmation failed while resetting local reaction counts.', error);
            setModalStatus('Counts were not reset because browser confirmation failed.');
            return;
        }
        if (!firstConfirmation || !secondConfirmation) return;

        button.disabled = true;
        button.setAttribute('aria-busy', 'true');
        setModalStatus('Resetting local reaction counts\u2026');
        try {
            await resetAllLocalReactionCounts();
            setModalStatus('All local reaction counts were reset.');
        } catch (error) {
            warn('Could not reset local reaction counts.', error);
            setModalStatus('Could not reset local reaction counts. No confirmed reset was applied.');
        } finally {
            button.disabled = !hasPrivateStorage();
            button.setAttribute('aria-busy', 'false');
        }
    }

    function normaliseCachedThread(rawThread, forumId) {
        if (!rawThread || typeof rawThread !== 'object' || !forumById.has(forumId)) return null;
        const url = parseSameOriginUrl(rawThread.href);
        if (!url || !/^\/forums\/threads\/\d+(?:\/|$)/i.test(url.pathname)) return null;

        const activityAt = Number(rawThread.activityAt);
        const createdAt = Number(rawThread.createdAt);
        const latestTimestamp = Date.now() + 300000;
        return {
            key: linkKey(url.href),
            href: url.href,
            title: cleanText(rawThread.title).slice(0, CONFIG.maxThreadTitleChars),
            comments: clampInteger(rawThread.comments, 0, 10_000_000, 0),
            created: extractCreationSortValue(url.href),
            createdAt: Number.isFinite(createdAt)
                && createdAt >= CONFIG.minValidTimestampMs
                && createdAt <= latestTimestamp ? createdAt : 0,
            activityAt: Number.isFinite(activityAt)
                && activityAt >= CONFIG.minValidTimestampMs
                && activityAt <= latestTimestamp ? activityAt : 0,
            forumId,
        };
    }

    function normaliseForumCache(value) {
        const now = Date.now();
        const result = new Map();
        const source = value?.schema === 1 && value.forums && typeof value.forums === 'object'
            ? value.forums
            : {};

        for (const forum of FORUMS) {
            const rawForum = source[forum.id];
            const updatedAt = Number(rawForum?.updatedAt);
            if (!Number.isFinite(updatedAt) || updatedAt < now - CONFIG.forumCacheRetentionMs || updatedAt > now + 300000) continue;
            const threads = Array.isArray(rawForum.threads)
                ? rawForum.threads
                    .map((thread) => normaliseCachedThread(thread, forum.id))
                    .filter(Boolean)
                    .slice(0, CONFIG.maxCachedThreadsPerForum)
                : [];
            const rawNextOffset = clampInteger(
                rawForum?.nextOffset,
                0,
                CONFIG.maxForumOffset + CONFIG.forumPageSize,
                threads.length >= CONFIG.forumPageSize ? CONFIG.forumPageSize : 0,
            );
            const nextOffset = rawNextOffset - (rawNextOffset % CONFIG.forumPageSize);
            result.set(forum.id, {
                updatedAt,
                threads,
                nextOffset,
                exhausted: Boolean(rawForum?.exhausted),
            });
        }
        return result;
    }

    function objectHasExactlyKeys(value, expectedKeys) {
        if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
        const actualKeys = Object.keys(value).sort();
        const sortedExpectedKeys = [...expectedKeys].sort();
        return actualKeys.length === sortedExpectedKeys.length
            && actualKeys.every((key, index) => key === sortedExpectedKeys[index]);
    }

    function cachedThreadMatchesCanonical(rawThread, thread) {
        const keys = [
            'key',
            'href',
            'title',
            'comments',
            'created',
            'createdAt',
            'activityAt',
            'forumId',
        ];
        return objectHasExactlyKeys(rawThread, keys)
            && rawThread.key === thread.key
            && rawThread.href === thread.href
            && rawThread.title === thread.title
            && rawThread.comments === thread.comments
            && rawThread.created === thread.created
            && rawThread.createdAt === thread.createdAt
            && rawThread.activityAt === thread.activityAt
            && rawThread.forumId === thread.forumId;
    }

    function forumCacheNeedsPersistAfterNormalisation(rawValue, cacheByForumId) {
        if (rawValue === null || rawValue === undefined) return false;
        if (rawValue?.schema !== 1
            || !rawValue.forums
            || typeof rawValue.forums !== 'object'
            || Array.isArray(rawValue.forums)) return true;

        const rawForumIds = Object.keys(rawValue.forums).sort();
        const normalisedForumIds = [...cacheByForumId.keys()].sort();
        if (rawForumIds.length !== normalisedForumIds.length
            || rawForumIds.some((forumId, index) => forumId !== normalisedForumIds[index])) {
            return true;
        }

        for (const [forumId, entry] of cacheByForumId) {
            const rawEntry = rawValue.forums[forumId];
            if (!objectHasExactlyKeys(rawEntry, [
                'updatedAt',
                'threads',
                'nextOffset',
                'exhausted',
            ])) return true;
            if (rawEntry.updatedAt !== entry.updatedAt
                || rawEntry.nextOffset !== entry.nextOffset
                || rawEntry.exhausted !== entry.exhausted
                || !Array.isArray(rawEntry.threads)
                || rawEntry.threads.length !== entry.threads.length) return true;
            if (entry.threads.some((thread, index) => (
                !cachedThreadMatchesCanonical(rawEntry.threads[index], thread)
            ))) return true;
        }
        return false;
    }

    function normaliseCachedHomepageItem(rawItem, sourceId) {
        if (!rawItem || typeof rawItem !== 'object') return null;
        const source = activitySourceById.get(sourceId);
        const url = parseSameOriginUrl(rawItem.href);
        const idPattern = sourceId === 'news'
            ? /^\/news\/(\d{1,20})(?:\/|$)/i
            : /^\/matches\/(\d{1,20})(?:\/|$)/i;
        const id = url?.pathname.match(idPattern)?.[1] || '';
        const title = cleanText(rawItem.title).slice(0, CONFIG.maxThreadTitleChars);
        if (!source || source.kind === 'forum' || !url || !id || !title) return null;
        const comments = sourceId === 'matches'
            ? 0
            : rawItem.comments === null
                ? null
                : clampInteger(rawItem.comments, 0, 10_000_000, 0);
        const scheduledAt = Number(rawItem.scheduledAt);
        return {
            key: linkKey(url.href),
            href: url.href,
            title,
            comments,
            trailingText: sourceId === 'matches'
                ? '0'
                : cleanText(rawItem.trailingText).slice(0, 60),
            created: Number(id),
            createdAt: 0,
            activityAt: 0,
            scheduledAt: Number.isFinite(scheduledAt) && scheduledAt > 0 ? scheduledAt : 0,
            relativeAgeLabel: cleanText(rawItem.relativeAgeLabel).slice(0, 60),
            sourceId,
            kind: source.kind,
            featured: Boolean(rawItem.featured),
            eventName: cleanText(rawItem.eventName).slice(0, 200),
            isLive: Boolean(rawItem.isLive),
            isLan: Boolean(rawItem.isLan),
            stars: clampInteger(rawItem.stars, 0, 5, 0),
        };
    }

    function normaliseHomepageActivityCache(value) {
        const result = new Map();
        const now = Date.now();
        const sources = value?.schema === 1 && value.sources && typeof value.sources === 'object'
            ? value.sources
            : {};
        for (const sourceId of ['news', 'matches']) {
            const rawSource = sources[sourceId];
            const updatedAt = Number(rawSource?.updatedAt);
            if (!Number.isFinite(updatedAt)
                || updatedAt < now - CONFIG.forumCacheRetentionMs
                || updatedAt > now + 300000) continue;
            const items = Array.isArray(rawSource?.items)
                ? rawSource.items
                    .map((item) => normaliseCachedHomepageItem(item, sourceId))
                    .filter(Boolean)
                    .slice(0, CONFIG.maxCachedThreadsPerForum)
                : [];
            result.set(sourceId, { updatedAt, items });
        }
        return result;
    }

    function registerThreadMetadata(thread) {
        const sourceId = thread?.sourceId || thread?.forumId || '';
        if (!thread?.key || !activitySourceById.has(sourceId)) return;
        const previous = state.threadMetadataByKey.get(thread.key) || {};
        state.threadMetadataByKey.set(thread.key, {
            ...previous,
            ...thread,
            sourceId,
            createdAt: thread.createdAt || previous.createdAt || 0,
            activityAt: thread.activityAt || previous.activityAt || 0,
        });
    }

    async function saveForumCache(cacheByForumId) {
        await storageSet(STORAGE_KEYS.forumCache, {
            schema: 1,
            updatedAt: Date.now(),
            forums: Object.fromEntries([...cacheByForumId.entries()].map(([forumId, entry]) => [
                forumId,
                {
                    updatedAt: entry.updatedAt,
                    threads: entry.threads,
                    nextOffset: entry.nextOffset,
                    exhausted: Boolean(entry.exhausted),
                },
            ])),
        });
    }

    async function saveHomepageActivityCache(cacheBySourceId) {
        await storageSet(STORAGE_KEYS.homepageActivityCache, {
            schema: 1,
            updatedAt: Date.now(),
            sources: Object.fromEntries([...cacheBySourceId.entries()].map(
                ([sourceId, entry]) => [
                    sourceId,
                    {
                        updatedAt: entry.updatedAt,
                        items: entry.items,
                    },
                ],
            )),
        });
    }

    async function loadFeatureData() {
        const [
            rawReadState,
            rawUserTags,
            rawLocalReactions,
            rawProvisionalLocalUpvotes,
            rawForumCache,
            rawHomepageActivityCache,
            rawExtendedMatchTeams,
        ] = await Promise.all([
            privateStorageGet(STORAGE_KEYS.readState, null),
            privateStorageGet(STORAGE_KEYS.userTags, null),
            privateStorageGet(STORAGE_KEYS.localReactions, null),
            privateStorageGet(STORAGE_KEYS.provisionalLocalUpvotes, null),
            storageGet(STORAGE_KEYS.forumCache, null),
            storageGet(STORAGE_KEYS.homepageActivityCache, null),
            storageGet(STORAGE_KEYS.extendedMatchTeams, null),
        ]);

        state.readEntries = normaliseReadState(rawReadState);
        state.userTags = normaliseUserTags(rawUserTags);
        state.localReactionResetAt = localReactionResetAtFromRecord(rawLocalReactions);
        state.localReactions = normaliseLocalReactions(
            rawLocalReactions,
            state.localReactionResetAt,
        );
        state.provisionalLocalUpvotes = normaliseProvisionalLocalUpvotes(
            rawProvisionalLocalUpvotes,
            state.localReactions,
        );
        rebuildLocalUserScores();

        const forumCache = normaliseForumCache(rawForumCache);
        state.forumCacheNeedsPersist = forumCacheNeedsPersistAfterNormalisation(
            rawForumCache,
            forumCache,
        );
        for (const entry of forumCache.values()) {
            for (const thread of entry.threads) registerThreadMetadata(thread);
        }
        state.homepageActivityCache = normaliseHomepageActivityCache(
            rawHomepageActivityCache,
        );
        state.extendedMatchTeams = normaliseExtendedMatchTeams(rawExtendedMatchTeams);
        for (const entry of state.homepageActivityCache.values()) {
            for (const item of entry.items) registerThreadMetadata(item);
        }
        return forumCache;
    }

    function toBoolean(value, fallbackValue) {
        if (typeof value === 'boolean') return value;
        if (value === 'true') return true;
        if (value === 'false') return false;
        return fallbackValue;
    }

    function parseSameOriginUrl(value) {
        try {
            const url = new URL(String(value || ''), HLTV_ORIGIN);
            if (url.origin !== HLTV_ORIGIN
                || url.protocol !== 'https:'
                || url.username
                || url.password
                || url.pathname.startsWith('//')) {
                return null;
            }
            return url;
        } catch {
            return null;
        }
    }

    function parseTeamStatsUrl(value) {
        const url = parseSameOriginUrl(value);
        return url && /^\/stats\/teams\/\d+(?:\/[^/]+)?\/?$/i.test(url.pathname) ? url : null;
    }

    function normaliseForumUrl(url) {
        const parsedUrl = parseSameOriginUrl(url);
        return parsedUrl ? parsedUrl.pathname.replace(/\/$/, '').toLowerCase() : '';
    }

    function normaliseSelectedForumIds(value) {
        if (!Array.isArray(value)) return FORUMS.map((forum) => forum.id);

        const ids = value
            .map((item) => {
                const stringValue = String(item || '');
                if (forumById.has(stringValue)) return stringValue;

                const byUrl = forumByUrl.get(normaliseForumUrl(stringValue));
                return byUrl ? byUrl.id : null;
            })
            .filter(Boolean);

        return [...new Set(ids)];
    }

    function normaliseSelectedActivitySourceIds(value) {
        if (!Array.isArray(value)) return [...DEFAULT_SETTINGS.selectedForums];
        const ids = value
            .map((item) => {
                const stringValue = String(item || '');
                if (activitySourceById.has(stringValue)) return stringValue;
                const byUrl = forumByUrl.get(normaliseForumUrl(stringValue));
                return byUrl ? byUrl.id : null;
            })
            .filter(Boolean);
        return [...new Set(ids)];
    }

    function normaliseSortOrder(value) {
        if (value === 'high') return 'comments';
        if (value === 'type') return 'created';
        if (SORT_STATES.some((sortState) => sortState.id === value)) return value;
        return DEFAULT_SETTINGS.sortOrder;
    }

    function getSortState(sortOrder) {
        return SORT_STATES.find((sortState) => sortState.id === sortOrder) || SORT_STATES[0];
    }

    function getNextSortOrder(sortOrder) {
        const index = SORT_STATES.findIndex((sortState) => sortState.id === sortOrder);
        const nextIndex = index === -1 ? 0 : (index + 1) % SORT_STATES.length;
        return SORT_STATES[nextIndex].id;
    }

    function injectStyles() {
        const existingStyle = document.getElementById('hltv-sp-style');
        const forumRules = FORUMS.map((forum) => (
            `.activitylist a.${forumClassName(forum)} { --hltv-sp-entry-color: ${forum.color}; }`
        )).join('\n');

        const style = document.createElement('style');
        style.id = 'hltv-sp-style';
        stampUiVersion(style);
        style.dataset.hltvSpCssBuild = SCRIPT_VERSION;
        style.dataset.hltvSpRuntimeState = 'starting';
        style.dataset.hltvSpStartedAt = String(Date.now());
        const settingsButtonStyleText = `
            button[id^="hltv-sp-"],
            button[class^="hltv-sp-"],
            button[class*=" hltv-sp-"],
            [class^="hltv-sp-"] button,
            [class*=" hltv-sp-"] button,
            button[class^="hltv-v2-"],
            button[class*=" hltv-v2-"],
            [class^="hltv-v2-"] button,
            [class*=" hltv-v2-"] button {
                cursor: pointer;
            }

            #hltv-sp-cog {
                appearance: none;
                align-self: center;
                background: transparent;
                border: 0;
                box-sizing: border-box;
                color: #87a3bf;
                cursor: pointer;
                display: inline-flex;
                align-items: center;
                justify-content: center;
                font: inherit;
                font-size: 12px;
                height: var(--navbar-height-gt-smartphone, 40px);
                line-height: 1;
                margin: 0;
                padding: 0;
                flex: 0 0 24px;
                vertical-align: middle;
                width: 24px;
            }

            /* The 24px cog plus HLTV's 24px flex gap moves the search anchor
               48px left. Reduce only the expanded inner visuals by 48px so
               their native left edges stay clear of the Majors navigation. */
            @media (min-width: 501px) {
                #navBarContainerFull .user-wrap.hltv-sp-header-cog-reserved
                    > .navsearch-wrap.search-bar-expanded .navsearch form,
                #navBarContainerFull .user-wrap.hltv-sp-header-cog-reserved
                    > .navsearch-wrap:focus-within .navsearch form {
                    width: 112px !important;
                }

                #navBarContainerFull .user-wrap.hltv-sp-header-cog-reserved
                    > .navsearch-wrap.search-bar-expanded .navsearch-background-bar,
                #navBarContainerFull .user-wrap.hltv-sp-header-cog-reserved
                    > .navsearch-wrap:focus-within .navsearch-background-bar {
                    width: 267px !important;
                }
            }

            #hltv-sp-cog > .fa-cog {
                color: #87a3bf !important;
                display: block;
                line-height: 1;
            }

            #hltv-sp-cog:hover,
            #hltv-sp-cog:focus-visible {
                filter: brightness(1.25);
                outline: none;
            }

            #hltv-sp-cog.hltv-sp-fixed {
                position: fixed;
                top: 10px;
                right: 12px;
                z-index: 99997;
                background: rgba(0, 0, 0, 0.55);
                border-radius: 4px;
                height: 32px;
                padding: 6px;
                width: 32px;
            }
        `;

        style.textContent = `
            ${settingsButtonStyleText}
            #hltv-sp-sort-button {
                appearance: none;
                background: transparent;
                border: 0;
                cursor: pointer;
                font-size: 14px;
                line-height: 1;
                margin-right: 8px;
                padding: 0 2px 0 0;
                vertical-align: middle;
            }

            #hltv-sp-sort-button:hover,
            #hltv-sp-sort-button:focus-visible {
                filter: brightness(1.25);
                outline: none;
            }

            #hltv-sp-modal-backdrop {
                align-items: center;
                background: rgba(0, 0, 0, 0.5);
                display: none;
                inset: 0;
                justify-content: center;
                position: fixed;
                z-index: 100000;
            }

            #hltv-sp-modal-backdrop.hltv-sp-open {
                display: flex;
            }

            #hltv-sp-modal {
                --hltv-ui-page: #1b1f23;
                --hltv-ui-panel: #252f39;
                --hltv-ui-panel-strong: #2d3844;
                --hltv-ui-input: #1f2933;
                --hltv-ui-border: #435467;
                --hltv-ui-border-strong: #52677b;
                --hltv-ui-text: #929a9e;
                --hltv-ui-text-strong: #d8dde2;
                --hltv-ui-heading: #87a3bf;
                --hltv-ui-accent: #87a3bf;
                --hltv-ui-button: #435f7a;
                --hltv-ui-button-hover: #506e8a;
                background: var(--hltv-ui-page);
                border: 1px solid var(--hltv-ui-border);
                border-radius: 2px;
                border-top: 3px solid var(--hltv-ui-accent);
                box-shadow: 0 8px 30px rgba(0, 0, 0, 0.45);
                box-sizing: border-box;
                color: var(--hltv-ui-text);
                max-height: calc(100vh - 40px);
                overflow: auto;
                padding: 18px 20px 20px;
                position: relative;
                width: min(540px, calc(100vw - 32px));
            }

            #hltv-sp-modal h2 {
                color: var(--hltv-ui-text-strong);
                font-size: 18px;
                line-height: 1.25;
                margin: 0 34px 14px 0;
            }

            #hltv-sp-modal fieldset {
                background: var(--hltv-ui-panel);
                border: 1px solid var(--hltv-ui-border);
                border-radius: 2px;
                margin: 0 0 14px;
                padding: 12px;
            }

            #hltv-sp-modal legend {
                color: var(--hltv-ui-heading);
                font-weight: 700;
                padding: 0 6px;
            }

            #hltv-sp-modal label {
                color: var(--hltv-ui-text-strong);
                cursor: pointer;
                display: flex;
                gap: 7px;
                align-items: center;
                line-height: 1.3;
            }

            #hltv-sp-modal input[type="checkbox"] {
                accent-color: var(--hltv-ui-accent);
            }

            #hltv-sp-modal input:focus-visible,
            #hltv-sp-modal select:focus-visible {
                border-color: var(--hltv-ui-accent);
                outline: 1px solid var(--hltv-ui-accent);
                outline-offset: 0;
            }

            .hltv-sp-grid {
                display: grid;
                gap: 8px 14px;
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }

            .hltv-sp-forum-limit-row {
                --hltv-sp-forum-color: #6e7681;
                border-left: 3px solid var(--hltv-sp-forum-color);
                min-width: 0;
                padding-left: 6px;
                position: relative;
            }

            .hltv-sp-source-color-input {
                border: 0;
                cursor: pointer;
                height: 100%;
                left: -3px;
                margin: 0;
                opacity: 0;
                padding: 0;
                position: absolute;
                top: 0;
                width: 10px;
            }

            .hltv-sp-forum-limit-row:has(.hltv-sp-source-color-input:focus-visible) {
                outline: 1px solid #87a3bf;
                outline-offset: 2px;
            }

            .hltv-sp-source-color-note {
                align-items: center;
                color: var(--hltv-ui-text);
                display: flex;
                font-size: 10px;
                gap: 7px;
                margin: -2px 0 8px;
            }

            .hltv-sp-source-color-note[data-disabled="true"] {
                opacity: 0.55;
            }

            .hltv-sp-source-color-reset {
                background: transparent;
                border: 0;
                color: var(--hltv-ui-accent);
                cursor: pointer;
                font: inherit;
                padding: 0;
                text-decoration: underline;
            }

            .hltv-sp-source-color-reset:disabled {
                cursor: default;
                opacity: 0.6;
            }

            .hltv-sp-number-input,
            #hltv-sp-modal input[type="number"] {
                background: var(--hltv-ui-input);
                border: 1px solid var(--hltv-ui-border);
                border-radius: 2px;
                box-sizing: border-box;
                color: var(--hltv-ui-text-strong);
                padding: 4px 5px;
                width: 56px;
            }

            #hltv-sp-layout-width {
                background: var(--hltv-ui-input);
                border: 1px solid var(--hltv-ui-border);
                border-radius: 2px;
                color: var(--hltv-ui-text-strong);
                font: inherit;
                max-width: 100%;
                min-width: 0;
                padding: 4px 5px;
            }

            .hltv-sp-metric-pair {
                display: inline-flex;
                gap: 4px;
                min-width: 0;
            }

            .hltv-sp-metric-pair select,
            #hltv-sp-previous-period-metric,
            #hltv-sp-match-prediction-mode {
                background: var(--hltv-ui-input);
                border: 1px solid var(--hltv-ui-border);
                border-radius: 2px;
                color: var(--hltv-ui-text-strong);
                font: inherit;
                max-width: 112px;
                min-width: 0;
                padding: 3px 4px;
            }

            #hltv-sp-hidden-user-tags {
                background: var(--hltv-ui-page);
                border: 1px solid var(--hltv-ui-border);
                border-radius: 2px;
                box-sizing: border-box;
                color: var(--hltv-ui-text-strong);
                font: inherit;
                min-height: 58px;
                padding: 5px 6px;
                width: 100%;
            }

            #hltv-sp-hidden-user-tags[data-disabled="true"] {
                opacity: 0.55;
            }

            .hltv-sp-hidden-tag-list {
                display: flex;
                flex-wrap: wrap;
                gap: 5px;
                min-height: 24px;
            }

            .hltv-sp-hidden-tag-empty {
                color: var(--hltv-ui-text);
                font-size: 11px;
                padding: 3px 1px;
            }

            .hltv-sp-hidden-tag-chip {
                align-items: center;
                background: var(--hltv-ui-panel-strong);
                border: 1px solid var(--hltv-ui-border-strong);
                border-radius: 2px;
                display: inline-flex;
                gap: 3px;
                max-width: 100%;
                padding: 2px 3px 2px 6px;
            }

            .hltv-sp-hidden-tag-value {
                overflow-wrap: anywhere;
            }

            .hltv-sp-hidden-tag-chip button,
            .hltv-sp-hidden-tag-add {
                background: var(--hltv-ui-button);
                border: 1px solid var(--hltv-ui-border-strong);
                border-radius: 2px;
                color: var(--hltv-ui-text-strong);
                cursor: pointer;
                font: inherit;
                line-height: 1.2;
                padding: 2px 5px;
            }

            .hltv-sp-hidden-tag-add {
                margin-top: 5px;
            }

            .hltv-sp-setting-help {
                color: var(--hltv-ui-text);
                font-size: 10px;
                grid-column: 1 / -1;
                line-height: 1.35;
                white-space: pre-line;
            }

            .hltv-sp-setting-help[hidden] {
                display: none !important;
            }

            .hltv-sp-setting-help a {
                color: var(--hltv-ui-accent);
            }

            .hltv-sp-match-player-metric-options {
                background: var(--hltv-ui-page);
                border: 1px solid var(--hltv-ui-border);
                border-radius: 2px;
                display: grid;
                gap: 6px 10px;
                grid-template-columns: repeat(2, minmax(0, 1fr));
                margin-top: 7px;
                padding: 7px;
                white-space: normal;
            }

            .hltv-sp-match-player-metric-option {
                align-items: center;
                color: var(--hltv-ui-text-strong);
                display: flex;
                gap: 5px;
                min-width: 0;
            }

            .hltv-sp-match-player-metric-option input {
                accent-color: var(--hltv-ui-accent);
                margin: 0;
            }

            .hltv-sp-feature-page-action {
                appearance: none;
                background: var(--hltv-ui-button);
                border: 1px solid var(--hltv-ui-border-strong);
                border-radius: 2px;
                color: var(--hltv-ui-text-strong);
                display: block;
                font: inherit;
                margin-top: 7px;
                padding: 4px 7px;
            }

            .hltv-sp-recent-activity-master + .hltv-sp-recent-activity-master {
                margin-top: 6px;
            }

            .hltv-sp-war-setting .hltv-sp-setting-help {
                white-space: pre-line;
            }

            .hltv-sp-options {
                display: grid;
                gap: 8px;
            }

            .hltv-sp-setting-row {
                align-items: center;
                display: grid;
                gap: 5px 8px;
                grid-template-columns: minmax(0, 1fr) auto auto;
                min-width: 0;
            }

            .hltv-sp-setting-row > label {
                min-width: 0;
            }

            .hltv-sp-setting-body {
                grid-column: 1 / -1;
            }

            .hltv-sp-setting-info {
                appearance: none;
                background: transparent;
                border: 1px solid rgba(135, 163, 191, 0.72);
                border-radius: 50%;
                box-sizing: border-box;
                color: var(--hltv-ui-accent);
                cursor: pointer;
                align-items: center;
                display: inline-flex;
                grid-column: 3;
                height: 20px;
                justify-self: end;
                line-height: 0;
                min-width: 20px;
                padding: 0;
                justify-content: center;
                text-decoration: none;
                width: 20px;
            }

            .hltv-sp-setting-info > .hltv-sp-info-icon {
                display: block;
                fill: currentColor;
                flex: 0 0 12px;
                height: 12px;
                pointer-events: none;
                transform: translate(0, 0);
                width: 12px;
            }

            .hltv-sp-setting-info:hover {
                background: rgba(135, 163, 191, 0.16);
            }

            .hltv-sp-setting-info:focus-visible {
                background: rgba(135, 163, 191, 0.16);
                outline: 2px solid rgba(135, 163, 191, 0.9);
                outline-offset: 1px;
            }

            .hltv-sp-setting-secondary-action {
                appearance: none;
                background: var(--hltv-ui-button);
                border: 1px solid var(--hltv-ui-border-strong);
                border-radius: 2px;
                color: var(--hltv-ui-text-strong);
                cursor: pointer;
                font: inherit;
                font-size: 10px;
                padding: 4px 6px;
                white-space: nowrap;
            }

            .hltv-sp-setting-secondary-action:hover:not(:disabled),
            .hltv-sp-setting-secondary-action:focus-visible {
                background: var(--hltv-ui-button-hover);
                border-color: var(--hltv-ui-accent);
                outline: none;
            }

            .hltv-sp-setting-secondary-action:disabled {
                cursor: default;
                opacity: 0.55;
            }

            @media (max-width: 520px) {
                #hltv-sp-modal {
                    padding: 14px;
                }

                #hltv-sp-modal fieldset {
                    margin-bottom: 10px;
                    padding: 9px;
                }

                .hltv-sp-grid {
                    grid-template-columns: minmax(0, 1fr);
                }

                .hltv-sp-setting-row {
                    grid-template-columns: minmax(0, 1fr) auto;
                }

                .hltv-sp-setting-info {
                    grid-column: 2;
                    grid-row: 1;
                }

                .hltv-sp-setting-secondary {
                    grid-column: 1 / -1;
                    justify-self: start;
                    max-width: 100%;
                }
            }

            .hltv-sp-actions {
                align-items: center;
                background: var(--hltv-ui-page);
                border-bottom: 1px solid var(--hltv-ui-border);
                display: grid;
                gap: 8px;
                grid-template-columns: minmax(0, 1fr) auto auto;
                margin: 0 -20px 14px;
                padding: 8px 20px;
                position: sticky;
                top: 0;
                z-index: 20;
            }

            .hltv-sp-actions button {
                border: 1px solid var(--hltv-ui-border-strong);
                border-radius: 2px;
                cursor: pointer;
                padding: 6px 11px;
            }

            .hltv-sp-actions button[type="submit"] {
                background: var(--hltv-ui-button);
                color: #f4f7f9;
                font-weight: 700;
            }

            .hltv-sp-actions button:hover:not(:disabled),
            .hltv-sp-actions button:focus-visible {
                background: var(--hltv-ui-button-hover);
                border-color: var(--hltv-ui-accent);
                outline: none;
            }

            .hltv-sp-actions button:disabled {
                cursor: default;
                opacity: 0.65;
            }

            .hltv-sp-actions button[type="button"] {
                background: #34495e;
                color: var(--hltv-ui-text-strong);
            }

            @media (max-width: 520px) {
                .hltv-sp-actions {
                    margin-left: -14px;
                    margin-right: -14px;
                    padding-left: 14px;
                    padding-right: 14px;
                }
            }

            .hltv-sp-data-actions {
                display: flex;
                flex-wrap: wrap;
                gap: 6px;
            }

            .hltv-sp-data-note {
                color: var(--hltv-ui-text);
                font-size: 10px;
                line-height: 1.4;
                margin: 0;
            }

            .hltv-sp-settings-footer {
                display: flex;
                justify-content: center;
                padding-top: 2px;
            }

            .hltv-sp-feedback-link {
                align-items: center;
                background: var(--hltv-ui-button);
                border: 1px solid var(--hltv-ui-border-strong);
                border-radius: 2px;
                box-sizing: border-box;
                color: var(--hltv-ui-text-strong);
                display: inline-flex;
                font-size: 11px;
                font-weight: 700;
                justify-content: center;
                min-height: 30px;
                padding: 6px 11px;
                text-align: center;
                text-decoration: none;
            }

            .hltv-sp-feedback-link:hover,
            .hltv-sp-feedback-link:focus-visible {
                background: var(--hltv-ui-button-hover);
                border-color: var(--hltv-ui-accent);
                color: #fff;
                outline: none;
            }

            .hltv-sp-saved-drafts-summary,
            .hltv-sp-saved-drafts-empty {
                color: var(--hltv-ui-text);
                font-size: 10px;
                line-height: 1.4;
                margin: 0;
            }

            .hltv-sp-saved-drafts-list {
                display: grid;
                gap: 7px;
                list-style: none;
                margin: 8px 0;
                padding: 0;
            }

            .hltv-sp-saved-draft-entry {
                background: var(--hltv-ui-input);
                border: 1px solid var(--hltv-ui-border);
                border-radius: 2px;
                display: grid;
                gap: 4px;
                padding: 7px;
            }

            .hltv-sp-saved-draft-title {
                color: var(--hltv-ui-text-strong);
                font-size: 11px;
                font-weight: 700;
                overflow-wrap: anywhere;
            }

            .hltv-sp-saved-draft-context,
            .hltv-sp-saved-draft-updated {
                color: var(--hltv-ui-text);
                font-size: 10px;
                overflow-wrap: anywhere;
            }

            .hltv-sp-saved-draft-actions {
                display: flex;
                flex-wrap: wrap;
                gap: 5px;
            }

            .hltv-sp-saved-draft-open {
                align-items: center;
                background: var(--hltv-ui-button);
                border: 1px solid var(--hltv-ui-border-strong);
                border-radius: 2px;
                color: var(--hltv-ui-text-strong);
                display: inline-flex;
                font-size: 10px;
                padding: 4px 6px;
                text-decoration: none;
            }

            .hltv-sp-saved-draft-open:hover,
            .hltv-sp-saved-draft-open:focus-visible {
                background: var(--hltv-ui-button-hover);
                border-color: var(--hltv-ui-accent);
                color: #fff;
                outline: none;
            }

            #hltv-sp-close {
                appearance: none;
                background: transparent;
                border: 0;
                color: var(--hltv-ui-heading);
                cursor: pointer;
                font-size: 24px;
                line-height: 1;
                padding: 0;
                position: absolute;
                right: 13px;
                top: 10px;
            }

            #hltv-sp-status {
                color: var(--hltv-ui-text);
                font-size: 12px;
                min-height: 16px;
                min-width: 0;
            }

            body .activitylist a.hltv-sp-source-hidden {
                display: none !important;
            }

            a.hltv-sp-post-new-topic-top {
                box-sizing: border-box;
                display: block;
                margin-bottom: 8px;
            }

            a.hotmatch-box.hltv-sp-extra-team-match,
            .col-box-con.result-box.hltv-sp-extra-team-match {
                display: block !important;
            }

            a.hotmatch-box.hltv-sp-extra-team-match > .teambox.match {
                display: flex !important;
            }

            a.hotmatch-box.hltv-sp-team-filter-hidden,
            .col-box-con.result-box.hltv-sp-team-filter-hidden {
                display: none !important;
            }

            .hltv-sp-extended-match-team .match-filter-remove-team,
            .hltv-sp-extended-match-team-result {
                cursor: pointer;
            }

            input.hltv-sp-extended-match-team-search-owned {
                cursor: text;
                opacity: 1;
            }

            .tt-dataset-teamSearch.hltv-sp-native-team-search-suppressed {
                display: none !important;
            }

            .hltv-sp-extended-match-team-result {
                align-items: center;
                display: flex;
                gap: 7px;
            }

            .hltv-sp-extended-match-team-results[hidden] {
                display: none !important;
            }

            .hltv-sp-visually-hidden {
                clip: rect(0 0 0 0) !important;
                clip-path: inset(50%) !important;
                height: 1px !important;
                overflow: hidden !important;
                position: absolute !important;
                white-space: nowrap !important;
                width: 1px !important;
            }

            @media (min-width: 975px) {
                body.hltv-sp-expanded-layout .bgPadding {
                    max-width: var(--hltv-sp-layout-background-width) !important;
                    width: var(--hltv-sp-layout-background-width) !important;
                }

                body.hltv-sp-expanded-layout .bgPadding > .widthControl {
                    max-width: var(--hltv-sp-layout-shell-width) !important;
                    width: var(--hltv-sp-layout-shell-width) !important;
                }

                body.hltv-sp-expanded-layout.cols1111 .bgPadding > .widthControl > .colCon,
                body.hltv-sp-expanded-layout.colsCustom1111 .bgPadding > .widthControl > .colCon {
                    grid-template-columns: 160px minmax(0, 1fr) 145px var(--hltv-sp-layout-sidebar-width) !important;
                }

                body.hltv-sp-expanded-layout.cols1101 .bgPadding > .widthControl > .colCon,
                body.hltv-sp-expanded-layout.colsCustom1101 .bgPadding > .widthControl > .colCon {
                    grid-template-columns: 160px minmax(0, 1fr) var(--hltv-sp-layout-sidebar-width) !important;
                }

                body.hltv-sp-expanded-layout.cols0101 .bgPadding > .widthControl > .colCon,
                body.hltv-sp-expanded-layout.colsCustom0101 .bgPadding > .widthControl > .colCon {
                    grid-template-columns: minmax(0, 1fr) var(--hltv-sp-layout-sidebar-width) !important;
                }
            }

            .hltv-sp-sidebar-list > a.activity:not(.hltv-sp-source-hidden) {
                align-items: center;
                box-sizing: border-box;
                display: flex !important;
                min-width: 0;
                padding-right: 4px !important;
            }

            .activitylist.hltv-sp-sidebar-list > a.activity.hltv-sp-colored-entry {
                padding-left: 7px !important;
            }

            .hltv-sp-sidebar-list > a.activity > .topic {
                display: block;
                flex: 1 1 auto;
                max-width: none !important;
                min-width: 0;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                width: auto !important;
            }

            body.hltv-sp-large-sidebar-text .hltv-sp-sidebar-list > a.activity {
                min-height: 22px;
            }

            body.hltv-sp-large-sidebar-text .hltv-sp-sidebar-list > a.activity > .topic {
                font-size: 12px !important;
                line-height: 1.35 !important;
            }

            .hltv-sp-sidebar-list > a.activity > .hltv-sp-sport-count,
            .hltv-sp-sidebar-list > a.activity > .hltv-sp-read-badge,
            .hltv-sp-sidebar-list > a.activity > .hltv-sp-relative-age {
                flex: 0 0 auto;
            }

            .activitylist a.hltv-sp-sport-pool {
                align-items: center;
                display: flex !important;
                max-width: 100%;
                min-width: 0;
                overflow: hidden;
            }

            .activitylist a.hltv-sp-sport-pool > .topic {
                display: block;
                flex: 1 1 auto;
                min-width: 0;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }

            .activitylist a.hltv-sp-sport-pool > .hltv-sp-sport-count,
            .activitylist a.hltv-sp-sport-pool > .hltv-sp-read-badge,
            .activitylist a.hltv-sp-sport-pool > .hltv-sp-relative-age {
                flex: 0 0 auto;
            }

            body.hltv-sp-green-upvotes .plus-button.active {
                background-color: darkgreen !important;
                color: lightgreen !important;
                font-weight: 700 !important;
            }

            .activitylist a.hltv-sp-extra {
                position: relative;
            }

            .activitylist a.hltv-sp-colored-entry {
                border-left: 0 !important;
                box-sizing: border-box;
                box-shadow: inset 3px 0 0 var(--hltv-sp-entry-color, ${CONTENT_TYPE_COLORS.unknown}) !important;
                padding-left: 7px;
            }

            .activitylist a.hltv-sp-type-news {
                --hltv-sp-entry-color: ${CONTENT_TYPE_COLORS.news};
            }

            .activitylist a.hltv-sp-type-match {
                --hltv-sp-entry-color: ${CONTENT_TYPE_COLORS.match};
            }

            .activitylist a.hltv-sp-forum-unknown {
                --hltv-sp-entry-color: ${CONTENT_TYPE_COLORS.unknown};
            }

            .hltv-sp-preview-panel {
                --hltv-sp-preview-source-color: #87a3bf;
                --hltv-ui-panel: #202a34;
                --hltv-ui-panel-strong: #2d3844;
                --hltv-ui-input: #1f2933;
                --hltv-ui-border: #435467;
                --hltv-ui-border-strong: #52677b;
                --hltv-ui-text: #929a9e;
                --hltv-ui-text-strong: #d8dde2;
                --hltv-ui-heading: #87a3bf;
                --hltv-ui-button: #435f7a;
                --hltv-ui-button-hover: #506e8a;
                background: var(--hltv-ui-panel);
                border: 1px solid var(--hltv-ui-border);
                border-left: 3px solid var(--hltv-sp-preview-source-color);
                border-radius: 2px;
                box-shadow: 0 7px 22px rgba(0, 0, 0, 0.42);
                box-sizing: border-box;
                color: var(--hltv-ui-text-strong);
                display: none;
                font-size: 13px;
                line-height: 1.45;
                max-height: min(70vh, 620px);
                overflow: auto;
                overscroll-behavior: contain;
                padding: 9px;
                position: fixed;
                width: min(500px, calc(100vw - 20px));
                white-space: pre-wrap;
                z-index: 99996;
            }

            .hltv-sp-preview-panel.hltv-sp-open {
                display: block;
            }

            .hltv-sp-preview-panel.hltv-sp-preview-native-colors {
                --hltv-sp-preview-source-color: var(--hltv-ui-heading);
                border-left-color: transparent;
            }

            .hltv-sp-preview-panel.hltv-sp-preview-native-colors
            a.hltv-sp-preview-thread-title:hover,
            .hltv-sp-preview-panel.hltv-sp-preview-native-colors
            a.hltv-sp-preview-thread-title:focus-visible {
                color: #fff;
            }

            .hltv-sp-preview-panel.hltv-sp-preview-native-colors
            .hltv-sp-preview-thread {
                background: var(--hltv-ui-panel-strong);
                border-left-color: transparent;
            }

            .hltv-sp-preview-heading {
                align-items: center;
                color: var(--hltv-ui-heading);
                display: flex;
                font-weight: 700;
                gap: 6px;
                justify-content: space-between;
                margin-bottom: 5px;
            }

            .hltv-sp-preview-heading > span {
                align-items: center;
                display: flex;
                flex-wrap: wrap;
                min-width: 0;
            }

            .hltv-sp-preview-forum,
            .hltv-sp-preview-locked {
                border: 1px solid currentColor;
                border-radius: 999px;
                display: inline-block;
                font-size: 10px;
                font-weight: 700;
                margin-left: 6px;
                padding: 1px 5px;
                vertical-align: 1px;
            }

            .hltv-sp-preview-locked {
                color: #ff9b94;
            }

            .hltv-sp-preview-thread,
            .hltv-sp-preview-comment {
                border-radius: 2px;
                padding: 7px 8px;
                position: relative;
            }

            .hltv-sp-preview-thread-title {
                color: var(--hltv-ui-text-strong);
                display: block;
                font-size: 15px;
                font-weight: 700;
                margin: 1px 0 7px;
                overflow-wrap: anywhere;
                text-decoration: none;
            }

            a.hltv-sp-preview-thread-title:hover,
            a.hltv-sp-preview-thread-title:focus-visible {
                color: var(--hltv-sp-preview-source-color);
                text-decoration: underline;
            }

            .hltv-sp-preview-thread {
                background: var(--hltv-ui-panel-strong);
                border-left: 3px solid var(--hltv-sp-preview-source-color);
                margin-bottom: 8px;
            }

            .hltv-sp-preview-comments-label {
                color: var(--hltv-ui-heading);
                font-size: 10px;
                font-weight: 700;
                letter-spacing: 0.04em;
                margin: 6px 0 4px;
                text-transform: uppercase;
            }

            .hltv-sp-preview-comment {
                background: #27333f;
                border-left: 3px solid var(--hltv-ui-border-strong);
                box-sizing: border-box;
                margin-top: 5px;
            }

            .hltv-sp-preview-comment[data-hltv-sp-thread-depth] {
                margin-left: min(calc(var(--hltv-sp-thread-depth, 0) * 16px), 96px);
            }

            .hltv-sp-preview-comment[data-hltv-sp-thread-depth]:not([data-hltv-sp-thread-depth="0"]) {
                border-left-color: #52677b;
            }

            .hltv-sp-preview-comment-node,
            .hltv-sp-preview-branch,
            .hltv-sp-preview-branch-children {
                min-width: 0;
                position: relative;
            }

            .hltv-sp-preview-branch-toggle {
                appearance: none;
                background: transparent;
                border: 0;
                bottom: 0;
                color: var(--hltv-ui-heading);
                cursor: pointer;
                display: block;
                left: calc(var(--hltv-sp-branch-depth, 0) * 16px);
                margin: 0;
                padding: 0;
                position: absolute;
                top: 0;
                width: 16px;
                z-index: 2;
            }

            .hltv-sp-preview-branch-toggle::before {
                background: var(--hltv-ui-border-strong);
                bottom: 0;
                content: '';
                left: 7px;
                position: absolute;
                top: 0;
                width: 1px;
            }

            .hltv-sp-preview-branch-toggle:hover::before,
            .hltv-sp-preview-branch-toggle:focus-visible::before {
                background: var(--hltv-sp-preview-source-color);
                width: 2px;
            }

            .hltv-sp-preview-branch-toggle:focus-visible {
                background: rgba(135, 163, 191, 0.12);
                outline: 2px solid var(--hltv-sp-preview-source-color);
                outline-offset: -2px;
            }

            .hltv-sp-preview-branch-summary {
                display: none;
                font-size: 10px;
                font-weight: 700;
                line-height: 1;
                white-space: nowrap;
            }

            .hltv-sp-preview-branch.hltv-sp-collapsed {
                min-height: 26px;
            }

            .hltv-sp-preview-branch.hltv-sp-collapsed
            > .hltv-sp-preview-branch-toggle {
                align-items: center;
                bottom: auto;
                display: inline-flex;
                min-height: 24px;
                padding: 0 7px 0 19px;
                width: max-content;
            }

            .hltv-sp-preview-branch.hltv-sp-collapsed
            > .hltv-sp-preview-branch-toggle
            > .hltv-sp-preview-branch-summary {
                display: inline;
            }

            .hltv-sp-preview-branch-children[hidden] {
                display: none !important;
            }

            .hltv-sp-preview-comment-node[data-hltv-sp-parent-reply-id]
            > .hltv-sp-preview-comment::before {
                border-top: 1px solid var(--hltv-ui-border-strong);
                content: '';
                left: -8px;
                position: absolute;
                top: 15px;
                width: 8px;
            }

            .hltv-sp-preview-parent-reference {
                color: #87a3bf;
                font-weight: 600;
            }

            .hltv-sp-preview-comment.hltv-sp-preview-notification-target {
                background: #344352;
                border-left-color: #87a3bf;
                box-shadow:
                    inset 0 0 0 1px rgba(135, 163, 191, 0.78),
                    0 0 0 1px rgba(15, 20, 25, 0.45);
            }

            .hltv-sp-preview-comment.hltv-sp-preview-last-comment-target {
                background-image: linear-gradient(
                    rgba(135, 163, 191, 0.13),
                    rgba(135, 163, 191, 0.13)
                );
                outline: 1px solid rgba(135, 163, 191, 0.85);
                outline-offset: -4px;
            }

            .hltv-sp-preview-post-meta {
                align-items: center;
                color: var(--hltv-ui-text);
                display: flex;
                font-size: 10px;
                gap: 5px;
                justify-content: space-between;
                margin-bottom: 4px;
            }

            .hltv-sp-preview-author-meta {
                align-items: center;
                display: inline-flex;
                flex-wrap: wrap;
                gap: 3px;
                min-width: 0;
            }

            .forum-topbar .hltv-sp-original-poster-author,
            .hltv-sp-preview-author-meta .hltv-sp-original-poster-author {
                background: #3d719e !important;
                border-radius: 2px;
                color: #fff !important;
                display: inline-block;
                font-weight: 700;
                line-height: 1.25;
                padding: 1px 4px;
            }

            .forum-topbar .hltv-sp-original-poster-author:hover,
            .forum-topbar .hltv-sp-original-poster-author:focus-visible,
            .hltv-sp-preview-author-meta .hltv-sp-original-poster-author:hover,
            .hltv-sp-preview-author-meta .hltv-sp-original-poster-author:focus-visible {
                background: #4578a4 !important;
                color: #fff !important;
            }

            .hltv-sp-preview-user-flag {
                flex: 0 0 auto;
                height: 10px;
                object-fit: cover;
                width: 15px;
            }

            .hltv-sp-preview-user-flair {
                align-items: center;
                color: #d58b93;
                display: inline-flex;
                gap: 2px;
                max-width: 130px;
                min-width: 0;
                text-decoration: none;
            }

            .hltv-sp-preview-user-flair-logo {
                flex: 0 0 auto;
                height: 15px;
                object-fit: contain;
                width: 15px;
            }

            .hltv-sp-preview-user-flair:hover,
            .hltv-sp-preview-user-flair:focus-visible {
                color: #f0aab1;
                text-decoration: underline;
            }

            .hltv-sp-preview-user-flair-label {
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }

            .hltv-sp-preview-post-text {
                color: var(--hltv-ui-text-strong);
                white-space: pre-wrap;
            }

            .hltv-sp-preview-embeds {
                display: grid;
                gap: 6px;
                margin-top: 7px;
                white-space: normal;
            }

            .hltv-sp-preview-embed-link {
                background: #1f2933;
                border: 1px solid var(--hltv-ui-border);
                border-radius: 2px;
                display: block;
                line-height: 0;
                overflow: hidden;
                width: fit-content;
            }

            .hltv-sp-preview-embed-link:hover,
            .hltv-sp-preview-embed-link:focus-visible {
                border-color: #87a3bf;
                outline: none;
            }

            .hltv-sp-preview-embed-image {
                display: block;
                height: auto;
                max-height: 360px;
                max-width: 100%;
                object-fit: contain;
                width: auto;
            }

            .hltv-sp-preview-votes {
                background: rgba(46, 160, 67, 0.22);
                border: 1px solid rgba(46, 160, 67, 0.48);
                border-radius: 999px;
                color: #7ee787;
                font-size: 10px;
                line-height: 1;
                padding: 2px 5px;
                white-space: nowrap;
            }

            .hltv-sp-preview-votes.hltv-sp-negative {
                background: rgba(229, 72, 77, 0.18);
                border-color: rgba(229, 72, 77, 0.46);
                color: #ff7b72;
            }

            .hltv-sp-preview-actions {
                align-items: center;
                display: inline-flex;
                flex: 0 0 auto;
                gap: 4px;
            }

            .hltv-sp-preview-actions button,
            .hltv-sp-preview-reply {
                appearance: none;
                background: var(--hltv-ui-button);
                border: 1px solid var(--hltv-ui-border-strong);
                border-radius: 2px;
                color: var(--hltv-ui-text-strong);
                cursor: pointer;
                font: inherit;
                line-height: 1.15;
                min-width: 24px;
                padding: 3px 6px;
            }

            .hltv-sp-preview-actions button:hover:not(:disabled),
            .hltv-sp-preview-reply:hover:not(:disabled) {
                background: var(--hltv-ui-button-hover);
                border-color: #87a3bf;
                color: #fff;
            }

            .hltv-sp-preview-actions button:disabled,
            .hltv-sp-preview-reply:disabled {
                cursor: default;
                opacity: 0.5;
            }

            .plus-button.hltv-sp-action-fenced,
            .newreply-post.hltv-sp-action-fenced {
                cursor: not-allowed !important;
                opacity: 0.5 !important;
            }

            .plus-button.hltv-sp-action-fenced.hltv-sp-pending,
            .hltv-sp-preview-upvote.hltv-sp-pending {
                opacity: 1 !important;
            }

            .hltv-sp-preview-upvote.hltv-sp-active {
                background: rgba(46, 160, 67, 0.3);
                border-color: rgba(46, 160, 67, 0.75);
                color: #7ee787;
            }

            .plus-button.hltv-sp-provisional-upvote,
            .hltv-sp-preview-upvote.hltv-sp-provisional-upvote {
                background: rgba(219, 87, 154, 0.34) !important;
                border-color: rgba(255, 126, 190, 0.78) !important;
                color: #ffc2df !important;
            }

            .plus-button.hltv-sp-provisional-upvote:hover,
            .hltv-sp-preview-upvote.hltv-sp-provisional-upvote:hover:not(:disabled) {
                background: rgba(219, 87, 154, 0.5) !important;
                color: #fff !important;
            }

            .hltv-sp-preview-downvote {
                color: var(--hltv-ui-text);
            }

            button.hltv-sp-local-downvote.hltv-sp-active {
                background: rgba(229, 72, 77, 0.28);
                border-color: rgba(229, 72, 77, 0.72);
                color: #ff9b94;
            }

            .forum-bottombar > button.hltv-sp-native-downvote {
                appearance: none;
                align-items: center;
                background: #364250;
                border: 0;
                border-radius: 4px;
                box-sizing: border-box;
                color: rgba(146, 154, 158, 0.65);
                cursor: pointer;
                display: flex;
                font: inherit;
                gap: 4px;
                height: 19px;
                line-height: 19px;
                margin-right: 8px;
                overflow: hidden;
                padding: 0 6px;
                transition: background-color 200ms ease, color 200ms ease;
            }

            .forum-bottombar > button.hltv-sp-native-downvote:hover:not(:disabled) {
                color: #fff;
            }

            .forum-bottombar > button.hltv-sp-native-downvote:disabled {
                cursor: default;
                opacity: 0.5;
            }

            button.hltv-sp-native-downvote > .hltv-sp-minus-icon {
                display: inline-block;
                font-size: 12px;
                font-weight: 900;
                transform: scaleX(1.15);
                transform-origin: center;
                -webkit-text-stroke: 0.35px currentColor;
            }

            button.hltv-sp-local-downvote > .hltv-sp-downvote-count {
                font-weight: 400;
            }

            button.hltv-sp-native-downvote > .slide-wrapper {
                display: flex;
                flex-direction: column;
                position: relative;
                top: 50%;
                transform: translateY(-50%);
                transition: transform 200ms ease;
            }

            button.hltv-sp-native-downvote > .slide-wrapper > .slide-in,
            button.hltv-sp-native-downvote > .slide-wrapper > .slide-out {
                flex: 0 0 19px;
                height: 19px;
                line-height: 19px;
            }

            button.hltv-sp-native-downvote.hltv-sp-active > .slide-wrapper {
                transform: translateY(0);
            }

            .forum-bottombar > button.hltv-sp-native-downvote.hltv-sp-active {
                background: rgba(229, 72, 77, 0.25);
                color: #ff9b94;
            }

            .hltv-sp-preview-post-footer {
                align-items: center;
                display: flex;
                gap: 7px;
                justify-content: flex-end;
                margin-top: 7px;
            }

            .hltv-sp-preview-reply {
                font-size: 11px;
            }

            .hltv-sp-preview-action-status {
                color: #ffb4ad;
                flex: 1 1 auto;
                font-size: 10px;
                min-height: 1em;
                overflow-wrap: anywhere;
            }

            .hltv-sp-local-action-status {
                color: #ffb4ad;
                float: right;
                font-size: 10px;
                margin: 4px 7px 0 0;
                max-width: 240px;
                overflow-wrap: anywhere;
            }

            .hltv-sp-user-score {
                background: transparent;
                border: 0;
                color: inherit;
                display: inline-flex;
                font: inherit;
                margin-left: 3px;
                padding: 0;
                text-decoration: none !important;
                vertical-align: middle;
            }

            .forum[data-forum-thread-id] > .hltv-sp-relocated-reply-composer {
                margin: 8px 0;
            }

            .hltv-sp-preview-composer-surface {
                background: #252f39;
                border: 1px solid var(--hltv-ui-border);
                border-radius: 2px;
                margin-top: 9px;
                padding: 8px;
                position: relative;
            }

            .hltv-sp-preview-composer[hidden],
            .hltv-sp-private-ui-host.hltv-sp-preview-composer[hidden] {
                display: none !important;
            }

            .hltv-sp-preview-composer-title {
                color: var(--hltv-ui-heading);
                font-size: 11px;
                font-weight: 700;
                margin-bottom: 5px;
            }

            .hltv-sp-preview-composer textarea {
                background: var(--hltv-ui-input);
                border: 1px solid var(--hltv-ui-border);
                border-radius: 2px;
                box-sizing: border-box;
                color: var(--hltv-ui-text-strong);
                font: inherit;
                line-height: 1.45;
                min-height: 86px;
                padding: 7px;
                resize: vertical;
                width: 100%;
            }

            .hltv-sp-preview-composer textarea:focus {
                border-color: #87a3bf;
                outline: none;
            }

            .hltv-sp-preview-reply-frame {
                background: transparent;
                border: 0;
                display: block;
                height: 132px;
                width: 100%;
            }

            .hltv-sp-preview-reply-unavailable {
                background: rgba(229, 72, 77, 0.12);
                border: 1px solid rgba(229, 72, 77, 0.45);
                color: #ffb4ad;
                padding: 8px;
            }

            .hltv-sp-preview-composer-actions {
                align-items: center;
                display: flex;
                gap: 8px;
                justify-content: flex-end;
                margin-top: 6px;
            }

            .hltv-sp-preview-composer-status {
                color: var(--hltv-ui-text);
                flex: 1 1 auto;
                font-size: 10px;
                overflow-wrap: anywhere;
            }

            .hltv-sp-preview-composer-status.hltv-sp-error {
                color: #ffb4ad;
            }

            .hltv-sp-preview-composer-post,
            .hltv-sp-save-draft,
            .hltv-sp-restore-draft {
                background: var(--hltv-ui-button);
                border: 1px solid var(--hltv-ui-border-strong);
                border-radius: 2px;
                color: #f4f7f9;
                cursor: pointer;
                font-weight: 700;
                padding: 5px 10px;
            }

            .hltv-sp-preview-composer-post:hover:not(:disabled),
            .hltv-sp-preview-composer-post:focus-visible,
            .hltv-sp-save-draft:hover:not(:disabled),
            .hltv-sp-save-draft:focus-visible,
            .hltv-sp-restore-draft:hover:not(:disabled),
            .hltv-sp-restore-draft:focus-visible {
                background: var(--hltv-ui-button-hover);
                border-color: #87a3bf;
                outline: none;
            }

            .hltv-sp-preview-composer-post:disabled,
            .hltv-sp-save-draft:disabled,
            .hltv-sp-restore-draft:disabled {
                cursor: default;
                opacity: 0.6;
            }

            .hltv-sp-draft-controls {
                align-items: center;
                display: flex;
                gap: 6px;
                justify-content: flex-end;
                margin-top: 6px;
            }

            .hltv-sp-draft-status {
                color: var(--hltv-ui-text, #929a9e);
                flex: 1 1 auto;
                font-size: 10px;
                min-height: 1em;
                overflow-wrap: anywhere;
            }

            .hltv-sp-draft-status.hltv-sp-error {
                color: #ffb4ad;
            }

            .hltv-sp-username-suggestions {
                background: var(--hltv-ui-panel);
                border: 1px solid var(--hltv-ui-border);
                border-radius: 2px;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
                display: none;
                left: 8px;
                max-height: 150px;
                overflow: auto;
                position: absolute;
                right: 8px;
                z-index: 20;
            }

            .hltv-sp-username-suggestions.hltv-sp-open {
                display: block;
            }

            .hltv-sp-username-suggestions button {
                background: transparent;
                border: 0;
                color: var(--hltv-ui-text-strong);
                cursor: pointer;
                display: block;
                padding: 5px 7px;
                text-align: left;
                width: 100%;
            }

            .hltv-sp-username-suggestions button:hover,
            .hltv-sp-username-suggestions button:focus-visible {
                background: rgba(135, 163, 191, 0.18);
                outline: none;
            }

            .hltv-sp-tag-button {
                cursor: pointer;
                font-size: 11px;
                margin-left: 5px;
                opacity: 0.72;
                position: relative;
                z-index: 1;
            }

            .hltv-sp-tag-button:hover {
                opacity: 1;
            }

            .hltv-sp-user-tag {
                background: rgba(142, 91, 217, 0.18);
                border: 1px solid rgba(142, 91, 217, 0.48);
                border-radius: 999px;
                color: #c6a8f5;
                cursor: pointer;
                display: inline-block;
                font-size: 9px;
                line-height: 1.25;
                margin-left: 5px;
                max-width: 120px;
                overflow: hidden;
                padding: 1px 5px;
                position: relative;
                text-overflow: ellipsis;
                text-transform: none;
                vertical-align: middle;
                white-space: nowrap;
                z-index: 1;
            }

            .hltv-sp-user-tag:hover {
                border-color: #c6a8f5;
            }

            .hltv-sp-blocked-user-indicator {
                background: rgba(229, 72, 77, 0.16);
                border: 1px solid rgba(229, 72, 77, 0.52);
                border-radius: 999px;
                color: #ff9b94;
                display: inline-block;
                font-size: 9px;
                font-weight: 700;
                line-height: 1.25;
                margin-left: 5px;
                padding: 1px 5px;
                text-transform: none;
                vertical-align: middle;
                white-space: nowrap;
            }

            .hltv-sp-tag-hidden-comment {
                display: none !important;
            }

            .activitylist a.hltv-sp-preview-active .topic {
                background: rgba(135, 163, 191, 0.20);
                border-radius: 2px;
                box-shadow: 0 0 0 2px rgba(135, 163, 191, 0.35);
                color: inherit;
            }

            .hltv-sp-read-badge {
                background: transparent;
                border: 0;
                color: inherit;
                display: inline-flex;
                font: inherit;
                margin: 0 5px 0 0;
                padding: 0;
            }

            .hltv-sp-relative-age {
                color: #929a9e;
                font-size: 9px;
                margin-left: 5px;
                white-space: nowrap;
            }

            .hltv-sp-post-relative-age {
                color: #929a9e;
                flex: 0 0 auto;
                font-size: 10px;
                margin: 0 auto 0 5px;
                padding-right: 6px;
                white-space: nowrap;
            }

            .forum-bottombar > .time[data-hltv-sp-timestamp] {
                flex: 0 0 auto !important;
                margin-right: 0 !important;
            }

            body.hltv-sp-hide-relative-ages .hltv-sp-post-relative-age,
            body.hltv-sp-hide-relative-ages .hltv-sp-preview-relative-age {
                display: none;
            }

            .hltv-sp-first-unread {
                border-left: 3px solid #e5484d !important;
                scroll-margin-top: 64px;
            }

            .hltv-sp-preview-panel .hltv-sp-first-unread {
                scroll-margin-top: 12px;
            }

            .hltv-sp-first-unread-jump {
                background: #e5484d;
                border: 0;
                border-radius: 3px;
                color: #fff;
                cursor: pointer;
                margin: 8px 0;
                padding: 5px 8px;
            }

            .hltv-sp-preview-comment-navigation {
                align-items: center;
                display: flex;
                flex-wrap: wrap;
                gap: 6px;
                margin: 8px 0;
            }

            .hltv-sp-preview-comment-navigation .hltv-sp-first-unread-jump {
                margin: 0;
            }

            .hltv-sp-preview-comment-navigation[hidden] {
                display: none;
            }

            .hltv-sp-preview-last-comment-jump {
                background: var(--hltv-ui-panel-strong);
                border: 1px solid var(--hltv-ui-border-strong);
                border-radius: 3px;
                color: var(--hltv-ui-text-strong);
                cursor: pointer;
                padding: 4px 8px;
            }

            .hltv-sp-quote-line {
                background: #25313c;
                border-left: 3px solid #8e5bd9;
                box-sizing: border-box;
                color: #b8c1c8;
                display: block;
                margin: 3px 0;
                overflow-wrap: anywhere;
                padding: 2px 7px;
                white-space: pre-wrap;
            }

            ${forumRules}
        `;

        trustedMainUiStyleText = style.textContent;
        if (!featureRuntimeEnabled) {
            // The full sheet stays inside the modal's closed shadow root. Only
            // the shared cog/header rules are installed into the disabled page.
            style.textContent = settingsButtonStyleText;
        }
        if (hasCompleteCurrentStyles(existingStyle)) {
            return { style: existingStyle, created: false };
        }
        existingStyle?.remove();
        document.head.appendChild(style);
        return { style, created: true };
    }

    function reserveHeaderSettingsWidth(target) {
        if (!target.matches('#navBarContainerFull .user-wrap')) return;
        const search = target.querySelector(':scope > .navsearch-wrap');
        if (!search) return;
        delete target.dataset.hltvSpNativeSearchWidth;
        target.style.removeProperty('--hltv-sp-header-search-width');
        target.classList.add('hltv-sp-header-cog-reserved');
    }

    function placeSettingsButton(button) {
        const target = document.querySelector('#navBarContainerFull .user-wrap')
            || document.querySelector('.user-wrap')
            || document.querySelector('#navBarContainerFull');

        if (!target) {
            button.classList.add('hltv-sp-fixed');
            document.body.appendChild(button);
            return;
        }

        button.classList.remove('hltv-sp-fixed');
        target.appendChild(button);
        reserveHeaderSettingsWidth(target);
    }

    function createCogwheel() {
        const existingButton = document.getElementById('hltv-sp-cog');
        if (hasCompleteSettingsButton()) {
            placeSettingsButton(existingButton);
            return;
        }
        existingButton?.remove();

        const button = document.createElement('button');
        button.id = 'hltv-sp-cog';
        stampUiVersion(button);
        button.dataset.hltvSpComponent = 'settings-button';
        button.type = 'button';
        const icon = document.createElement('i');
        icon.className = 'fa fa-cog';
        icon.setAttribute('aria-hidden', 'true');
        button.appendChild(icon);
        button.title = 'HLTV Enhancements settings';
        button.setAttribute('aria-label', 'HLTV Enhancements settings');
        button.addEventListener('click', openSettingsModal);

        placeSettingsButton(button);
    }

    function featurePageDateRange(now = new Date()) {
        const end = now instanceof Date && Number.isFinite(now.getTime())
            ? now
            : new Date();
        const endYear = end.getFullYear();
        const endMonth = end.getMonth();
        const endDay = end.getDate();
        const targetMonthIndex = endMonth - 3;
        const startYear = endYear + Math.floor(targetMonthIndex / 12);
        const startMonth = ((targetMonthIndex % 12) + 12) % 12;
        const lastStartMonthDay = new Date(startYear, startMonth + 1, 0).getDate();
        const start = new Date(startYear, startMonth, Math.min(endDay, lastStartMonthDay));
        const format = (date) => [
            String(date.getFullYear()).padStart(4, '0'),
            String(date.getMonth() + 1).padStart(2, '0'),
            String(date.getDate()).padStart(2, '0'),
        ].join('-');
        return { startDate: format(start), endDate: format(end) };
    }

    function featurePageUrl(path) {
        if (!FEATURE_PAGE_PATHS.has(path)) return null;
        const url = new URL(path, HLTV_ORIGIN);
        if (url.origin !== HLTV_ORIGIN || url.pathname !== path) return null;
        if (path.startsWith(STATS_FEATURE_PATH_PREFIX)) {
            const range = featurePageDateRange();
            url.searchParams.set('startDate', range.startDate);
            url.searchParams.set('endDate', range.endDate);
        }
        return url;
    }

    function openFeaturePage(helpId) {
        const path = FEATURE_PAGE_PATH_BY_HELP_ID[helpId];
        const url = featurePageUrl(path);
        if (!url) return;
        const link = document.createElement('a');
        link.href = url.href;
        link.target = '_blank';
        link.rel = 'noopener noreferrer';
        link.hidden = true;
        document.body.appendChild(link);
        link.click();
        link.remove();
    }

    function createSettingRow({
        primary,
        description,
        helpId,
        secondary = [],
        body = [],
        helpBody = [],
        sourceUrl = '',
        className = '',
    }) {
        const row = document.createElement('div');
        row.className = `hltv-sp-setting-row${className ? ` ${className}` : ''}`;
        const settingName = cleanText(primary?.textContent) || 'this setting';

        const help = document.createElement('div');
        help.id = helpId;
        help.className = 'hltv-sp-setting-help';
        help.hidden = true;
        help.appendChild(document.createTextNode(description));
        help.append(...helpBody);
        if (sourceUrl) {
            const source = document.createElement('a');
            source.href = sourceUrl;
            source.target = '_blank';
            source.rel = 'noopener noreferrer';
            source.textContent = ' Open the original script page.';
            source.title = 'Open the original GreasyFork script page in a new tab';
            source.addEventListener('click', (event) => event.stopPropagation());
            help.appendChild(source);
        }
        if (FEATURE_PAGE_PATH_BY_HELP_ID[helpId]) {
            const featurePage = document.createElement('button');
            featurePage.type = 'button';
            featurePage.className = 'hltv-sp-feature-page-action';
            featurePage.textContent = 'Try it on HLTV';
            featurePage.addEventListener('click', (event) => {
                event.stopPropagation();
                openFeaturePage(helpId);
            });
            help.appendChild(featurePage);
        }

        const info = document.createElement('button');
        info.type = 'button';
        info.className = 'hltv-sp-setting-info';
        const svgNamespace = 'http://www.w3.org/2000/svg';
        const infoIcon = document.createElementNS(svgNamespace, 'svg');
        infoIcon.setAttribute('class', 'hltv-sp-info-icon');
        infoIcon.setAttribute('viewBox', '0 0 20 20');
        infoIcon.setAttribute('aria-hidden', 'true');
        infoIcon.setAttribute('focusable', 'false');
        const infoDot = document.createElementNS(svgNamespace, 'circle');
        infoDot.setAttribute('class', 'hltv-sp-info-icon-dot');
        infoDot.setAttribute('cx', '10');
        infoDot.setAttribute('cy', '5');
        infoDot.setAttribute('r', '1.4');
        const infoStem = document.createElementNS(svgNamespace, 'rect');
        infoStem.setAttribute('class', 'hltv-sp-info-icon-stem');
        infoStem.setAttribute('x', '8.6');
        infoStem.setAttribute('y', '8');
        infoStem.setAttribute('width', '2.8');
        infoStem.setAttribute('height', '7');
        infoStem.setAttribute('rx', '1.4');
        infoIcon.append(infoDot, infoStem);
        info.appendChild(infoIcon);
        info.title = `Show details for ${settingName}`;
        info.setAttribute('aria-label', `Show details for ${settingName}`);
        info.setAttribute('aria-controls', help.id);
        info.setAttribute('aria-expanded', 'false');
        info.addEventListener('click', (event) => {
            event.stopPropagation();
            const expanded = info.getAttribute('aria-expanded') === 'true';
            help.hidden = expanded;
            info.setAttribute('aria-expanded', expanded ? 'false' : 'true');
            const action = expanded ? 'Show' : 'Hide';
            info.title = `${action} details for ${settingName}`;
            info.setAttribute('aria-label', `${action} details for ${settingName}`);
        });

        for (const element of secondary) element.classList.add('hltv-sp-setting-secondary');
        row.append(primary, ...secondary, info);
        for (const element of body) {
            element.classList.add('hltv-sp-setting-body');
            row.appendChild(element);
        }
        row.appendChild(help);
        return row;
    }

    function hiddenUserTagEditorValues(editor) {
        if (!(editor instanceof Element)) return [];
        return normaliseHiddenUserTags(
            [...editor.querySelectorAll('.hltv-sp-hidden-tag-chip')]
                .map((chip) => chip.dataset.hltvSpTag || ''),
        );
    }

    function promptForHiddenUserTag(initialValue = '') {
        if (!safePrompt) {
            setModalStatus('Firefox did not make the private tag prompt available.');
            return null;
        }
        const response = safePrompt(
            `Exact local tag to hide (maximum ${CONFIG.maxUserTagChars} characters):`,
            initialValue,
        );
        if (response === null) return null;
        const flattened = String(response).replace(/[\r\n]+/g, ' ').trim();
        if (!flattened) {
            setModalStatus('A hidden tag cannot be empty.');
            return null;
        }
        if (flattened.length > CONFIG.maxUserTagChars) {
            setModalStatus(`A hidden tag can contain at most ${CONFIG.maxUserTagChars} characters.`);
            return null;
        }
        return normaliseUserTag(flattened);
    }

    function renderHiddenUserTagEditor(editor, values) {
        if (!(editor instanceof Element)) return;
        const tags = normaliseHiddenUserTags(values);
        const disabled = editor.dataset.disabled === 'true';
        editor.replaceChildren();

        const list = document.createElement('div');
        list.className = 'hltv-sp-hidden-tag-list';
        if (!tags.length) {
            const empty = document.createElement('span');
            empty.className = 'hltv-sp-hidden-tag-empty';
            empty.textContent = 'No tags are hidden.';
            list.appendChild(empty);
        }
        for (const tag of tags) {
            const chip = document.createElement('span');
            chip.className = 'hltv-sp-hidden-tag-chip';
            chip.dataset.hltvSpTag = tag;

            const value = document.createElement('span');
            value.className = 'hltv-sp-hidden-tag-value';
            value.textContent = tag;

            const edit = document.createElement('button');
            edit.type = 'button';
            edit.textContent = 'Edit';
            edit.disabled = disabled;
            edit.addEventListener('click', () => {
                const replacement = promptForHiddenUserTag(tag);
                if (replacement === null) return;
                const next = hiddenUserTagEditorValues(editor);
                const index = next.indexOf(tag);
                if (index < 0) return;
                if (next.some((candidate, candidateIndex) => (
                    candidateIndex !== index && candidate === replacement
                ))) {
                    setModalStatus('That exact tag is already in the hidden list.');
                    return;
                }
                next[index] = replacement;
                state.modalSettingsDirty = true;
                renderHiddenUserTagEditor(editor, next);
                setModalStatus('');
            });

            const remove = document.createElement('button');
            remove.type = 'button';
            remove.textContent = '\u00D7';
            remove.title = `Remove hidden tag ${tag}`;
            remove.setAttribute('aria-label', `Remove hidden tag ${tag}`);
            remove.disabled = disabled;
            remove.addEventListener('click', () => {
                state.modalSettingsDirty = true;
                renderHiddenUserTagEditor(
                    editor,
                    hiddenUserTagEditorValues(editor).filter((candidate) => candidate !== tag),
                );
                setModalStatus('');
            });

            chip.append(value, edit, remove);
            list.appendChild(chip);
        }

        const add = document.createElement('button');
        add.type = 'button';
        add.className = 'hltv-sp-hidden-tag-add';
        add.textContent = 'Add tag';
        add.disabled = disabled || tags.length >= CONFIG.maxHiddenUserTags;
        add.addEventListener('click', () => {
            const tag = promptForHiddenUserTag('');
            if (tag === null) return;
            const next = hiddenUserTagEditorValues(editor);
            if (next.includes(tag)) {
                setModalStatus('That exact tag is already in the hidden list.');
                return;
            }
            if (next.length >= CONFIG.maxHiddenUserTags) {
                setModalStatus(`At most ${CONFIG.maxHiddenUserTags} hidden tags are allowed.`);
                return;
            }
            next.push(tag);
            state.modalSettingsDirty = true;
            renderHiddenUserTagEditor(editor, next);
            setModalStatus('');
        });

        editor.append(list, add);
    }

    function exportTimestamp() {
        return new Date().toISOString();
    }

    function exportFilename(kind) {
        return `hltv-enhancements-${kind}-${exportTimestamp().replace(/[:.]/g, '-')}.json`;
    }

    function downloadLocalJson(kind, value) {
        if (typeof globalThis.URL?.createObjectURL !== 'function'
            || typeof globalThis.URL?.revokeObjectURL !== 'function') {
            throw new Error('Local downloads are unavailable.');
        }
        const blob = new Blob([`${JSON.stringify(value, null, 2)}\n`], {
            type: 'application/json',
        });
        const objectUrl = globalThis.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = objectUrl;
        link.download = exportFilename(kind);
        link.rel = 'noopener';
        try {
            link.click();
        } finally {
            globalThis.setTimeout(() => globalThis.URL.revokeObjectURL(objectUrl), 0);
        }
    }

    function exportEnvelope(format, payload) {
        return {
            format,
            schemaVersion: 1,
            extensionVersion: SCRIPT_VERSION,
            exportedAt: exportTimestamp(),
            ...payload,
        };
    }

    async function runOnSiteDataAction(button, progress, success, operation) {
        if (!(button instanceof HTMLButtonElement) || button.disabled) return;
        button.disabled = true;
        button.setAttribute('aria-busy', 'true');
        setModalStatus(progress);
        try {
            await operation();
            setModalStatus(success);
        } catch (error) {
            warn('Local data action failed.', error);
            const message = String(error?.message || '');
            setModalStatus(/^Choose an HLTV Enhancements (?:settings|user-data) export\.$/
                .test(message)
                ? message
                : 'The local data action could not be completed.');
        } finally {
            button.disabled = false;
            button.setAttribute('aria-busy', 'false');
        }
    }

    function normaliseStatsColumnLayoutsForExport(value) {
        const source = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
        const output = {};
        for (const tableType of ['ranking', 'matches']) {
            const item = source[tableType] && typeof source[tableType] === 'object'
                ? source[tableType]
                : {};
            output[tableType] = {
                order: [...new Set((Array.isArray(item.order) ? item.order : [])
                    .map((entry) => cleanText(entry).slice(0, 40))
                    .filter(Boolean))].slice(0, 40),
                hidden: [...new Set((Array.isArray(item.hidden) ? item.hidden : [])
                    .map((entry) => cleanText(entry).slice(0, 40))
                    .filter(Boolean))].slice(0, 40),
            };
        }
        return output;
    }

    function normaliseStatsMultiSortForExport(value) {
        const source = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
        const output = {};
        for (const tableType of ['ranking', 'matches']) {
            output[tableType] = (Array.isArray(source[tableType]) ? source[tableType] : [])
                .slice(0, 12)
                .map((entry) => ({
                    id: cleanText(entry?.id).slice(0, 40),
                    direction: entry?.direction === 'asc' ? 'asc' : 'desc',
                }))
                .filter((entry) => entry.id);
        }
        return output;
    }

    function canonicalSettingsForExport(dynamic = {}) {
        const matchPlayerPrimaryMetrics = normaliseMatchPlayerMetrics(
            state.settings.matchPlayerPrimaryMetrics,
            state.settings.matchPlayerPrimaryMetric1,
            state.settings.matchPlayerPrimaryMetric2,
        );
        const [
            matchPlayerPrimaryMetric1,
            matchPlayerPrimaryMetric2,
        ] = legacyMatchPlayerMetricPair(matchPlayerPrimaryMetrics);
        return {
            selectedSources: [...state.settings.selectedForums],
            sourceLimits: { ...state.settings.forumThreadLimits },
            sourceColors: { ...state.settings.activitySourceColors },
            enableCustomThreadFetching: Boolean(
                state.settings.enableCustomThreadFetching,
            ),
            enableCustomThreadColors: Boolean(state.settings.enableCustomThreadColors),
            layoutWidthPreset: state.settings.layoutWidthPreset,
            largeSidebarText: Boolean(state.settings.largeSidebarText),
            movePostNewTopicToTop: Boolean(state.settings.movePostNewTopicToTop),
            showRelativeAges: Boolean(state.settings.showRelativeAges),
            enableExtendedMatchFilter: Boolean(state.settings.enableExtendedMatchFilter),
            strictSelectedTeamMatches: Boolean(state.settings.strictSelectedTeamMatches),
            enableThreadPreviews: Boolean(state.settings.enableThreadPreviews),
            enableOriginalPosterHighlight: Boolean(
                state.settings.enableOriginalPosterHighlight,
            ),
            enableReadStatus: Boolean(state.settings.enableReadStatus),
            replyComposerAfterOriginalPost: Boolean(
                state.settings.replyComposerAfterOriginalPost,
            ),
            enableSavedDrafts: Boolean(state.settings.enableSavedDrafts),
            enableUserTags: Boolean(state.settings.enableUserTags),
            hiddenUserTags: [...state.settings.hiddenUserTags],
            enableLocalUserScores: Boolean(state.settings.enableLocalUserScores),
            enableLocalDownvotes: Boolean(state.settings.enableLocalDownvotes),
            changeUpvoteStyle: Boolean(state.settings.changeUpvoteStyle),
            enableSignedOutLocalVoting: Boolean(state.settings.enableSignedOutLocalVoting),
            enableUsernameBlocking: Boolean(state.settings.enableUsernameBlocking),
            winAdjustedAutoRun: Boolean(state.settings.winAdjustedAutoRun),
            showFullMapNames: Boolean(state.settings.showFullMapNames),
            enableDiagnosticLogging: Boolean(state.settings.enableDiagnosticLogging),
            enableStickyMatchHeader: Boolean(state.settings.enableStickyMatchHeader),
            enableMatchPlayerFormOverlays: Boolean(
                state.settings.enableMatchPlayerFormOverlays,
            ),
            enableMatchPrediction: Boolean(state.settings.enableMatchPrediction),
            matchPredictionMode: normaliseMatchPredictionMode(
                dynamic.matchPredictionMode ?? state.settings.matchPredictionMode,
            ),
            extensionDisabled: Boolean(dynamic.extensionDisabled ?? state.settings.extensionDisabled),
            predictionMarketPercent: normalisePredictionMarketPercent(
                dynamic.predictionMarketPercent ?? state.settings.predictionMarketPercent,
            ),
            enableTeamPerformanceDifference: Boolean(
                state.settings.enableTeamPerformanceDifference,
            ),
            matchPlayerPrimaryMetrics,
            matchPlayerPrimaryMetric1,
            matchPlayerPrimaryMetric2,
            enableStatsColumnChooser: Boolean(state.settings.enableStatsColumnChooser),
            enableStatsMultiSort: Boolean(state.settings.enableStatsMultiSort),
            statsOptionalColumnsV2: normaliseStatsOptionalColumns(
                dynamic.statsOptionalColumnsV2 ?? state.settings.statsOptionalColumnsV2,
            ),
            enableStatsCsvExport: Boolean(state.settings.enableStatsCsvExport),
            enablePlayerMatchSparklines: Boolean(
                state.settings.enablePlayerMatchSparklines,
            ),
            enableExtendedMatchHistoryLoading: Boolean(
                state.settings.enableExtendedMatchHistoryLoading,
            ),
            playerMatchTrendMetric: normaliseStoredMetricName(
                dynamic.playerMatchTrendMetric ?? state.settings.playerMatchTrendMetric,
                DEFAULT_SETTINGS.playerMatchTrendMetric,
            ),
            statsMatchHistoryRowsV2: normaliseStatsMatchHistoryRows(
                dynamic.statsMatchHistoryRowsV2,
            ),
            enablePlayerMapMatrix: Boolean(state.settings.enablePlayerMapMatrix),
            enablePlayerComparisonEnhancements: Boolean(
                state.settings.enablePlayerComparisonEnhancements,
            ),
            enablePlayerConsistencyScore: Boolean(
                state.settings.enablePlayerConsistencyScore,
            ),
            enableStatsTablePeriodComparison: Boolean(
                state.settings.enableStatsTablePeriodComparison,
            ),
            enablePlayerPagePeriodComparison: Boolean(
                state.settings.enablePlayerPagePeriodComparison,
            ),
            previousPeriodMetric: normalisePreviousPeriodMetric(
                state.settings.previousPeriodMetric,
            ),
            statsColumnLayout: normaliseStatsColumnLayoutsForExport(
                dynamic.statsColumnLayout,
            ),
            statsMultiSort: normaliseStatsMultiSortForExport(dynamic.statsMultiSort),
            sortOrder: normaliseSortOrder(state.settings.sortOrder),
            additionalMatchTeams: [...(dynamic.extendedMatchTeams ?? state.extendedMatchTeams).values()].map((team) => ({
                id: team.id,
                name: team.name,
            })),
        };
    }

    function userTagsForExport(tags) {
        return [...tags.entries()]
            .map(([userId, entry]) => ({
                userId,
                name: entry.name,
                tag: entry.tag,
                updatedAt: entry.updatedAt,
            }))
            .sort((first, second) => second.updatedAt - first.updatedAt)
            .slice(0, CONFIG.maxUserTags);
    }

    function readStateForExport(readEntries) {
        return [...readEntries.entries()]
            .map(([threadId, entry]) => ({
                threadId,
                seenReplyCount: entry.seenReplyCount,
                maxPostNo: entry.maxPostNo,
                selfPostNumbers: [...(entry.selfPostNumbers || [])],
                visitedAt: entry.visitedAt,
            }))
            .sort((first, second) => second.visitedAt - first.visitedAt)
            .slice(0, CONFIG.maxReadEntries);
    }

    function reactionsForExport(reactions) {
        return [...reactions.entries()]
            .filter(([, entry]) => entry.value !== 0)
            .map(([reactionKey, entry]) => ({
                reactionKey,
                authorId: entry.authorId,
                value: entry.value,
                updatedAt: entry.updatedAt,
            }))
            .sort((first, second) => second.updatedAt - first.updatedAt)
            .slice(0, CONFIG.maxLocalReactions);
    }

    function reactionScoresForExport(reactions) {
        const scores = new Map();
        for (const reaction of reactions) {
            scores.set(reaction.authorId, (scores.get(reaction.authorId) || 0) + reaction.value);
        }
        return [...scores.entries()]
            .map(([userId, score]) => ({ userId, score }))
            .sort((first, second) => second.score - first.score || first.userId.localeCompare(second.userId));
    }

    async function exportSavedSettingsOnSite(button) {
        await runOnSiteDataAction(
            button,
            'Preparing local settings export…',
            'Saved settings were exported.',
            async () => {
                const [
                    statsColumnLayout,
                    statsMultiSort,
                    statsOptionalColumnsV2,
                    playerMatchTrendMetric,
                    statsMatchHistoryRowsV2,
                    matchPredictionMode,
                    extensionDisabled,
                    predictionMarketPercent,
                    extendedMatchTeams,
                ]
                    = await Promise.all([
                    storageGet('statsColumnLayoutV2', {}),
                    storageGet('statsMultiSortV2', {}),
                    storageGet('statsOptionalColumnsV2', state.settings.statsOptionalColumnsV2),
                    storageGet('playerMatchTrendMetric', state.settings.playerMatchTrendMetric),
                    storageGet('statsMatchHistoryRowsV2', 100),
                    storageGet('matchPredictionMode', DEFAULT_SETTINGS.matchPredictionMode),
                    storageGet('extensionDisabled', DEFAULT_SETTINGS.extensionDisabled),
                    storageGet('predictionMarketPercent', DEFAULT_SETTINGS.predictionMarketPercent),
                    storageGet(STORAGE_KEYS.extendedMatchTeams, null),
                ]);
                downloadLocalJson(
                    'settings',
                    exportEnvelope('hltv-enhancements-settings', {
                        settings: canonicalSettingsForExport({
                            statsColumnLayout,
                            statsMultiSort,
                            statsOptionalColumnsV2,
                            playerMatchTrendMetric,
                            statsMatchHistoryRowsV2,
                            matchPredictionMode,
                            extensionDisabled,
                            predictionMarketPercent,
                            extendedMatchTeams: normaliseExtendedMatchTeams(extendedMatchTeams),
                        }),
                    }),
                );
            },
        );
    }

    async function exportUserDataOnSite(button) {
        await runOnSiteDataAction(
            button,
            'Preparing local user-data export…',
            'User data was exported.',
            async () => {
                if (!hasPrivateStorage()) throw new Error('Private storage is unavailable.');
                await state.reactionSavePromise.catch(() => undefined);
                const [rawTags, rawReadState, rawReactions, rawProvisional, rawTeams] = await Promise.all([
                    privateStorageGetStrict(STORAGE_KEYS.userTags),
                    privateStorageGetStrict(STORAGE_KEYS.readState),
                    privateStorageGetStrict(STORAGE_KEYS.localReactions),
                    privateStorageGetStrict(STORAGE_KEYS.provisionalLocalUpvotes),
                    storageGet(STORAGE_KEYS.extendedMatchTeams, null),
                ]);
                const tags = normaliseUserTags(rawTags);
                const readEntries = normaliseReadState(rawReadState);
                const resetAt = localReactionResetAtFromRecord(rawReactions);
                const reactions = normaliseLocalReactions(rawReactions, resetAt);
                const provisional = normaliseProvisionalLocalUpvotes(
                    rawProvisional,
                    reactions,
                );
                const exportedReactions = reactionsForExport(reactions);
                downloadLocalJson(
                    'user-data',
                    exportEnvelope('hltv-enhancements-user-data', {
                        data: {
                            userTags: userTagsForExport(tags),
                            readState: readStateForExport(readEntries),
                            reactions: exportedReactions,
                            userReactionScores: reactionScoresForExport(exportedReactions),
                            provisionalLocalUpvotes: [...provisional.entries()].map(
                                ([reactionKey, entry]) => ({
                                    reactionKey,
                                    authorId: entry.authorId,
                                    reactionMutationId: entry.reactionMutationId,
                                    updatedAt: entry.updatedAt,
                                }),
                            ),
                            additionalMatchTeams: [...normaliseExtendedMatchTeams(rawTeams).values()].map(
                                (team) => ({ id: team.id, name: team.name }),
                            ),
                        },
                    }),
                );
            },
        );
    }

    function isPlainImportRecord(value) {
        return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
    }

    function importSyncPulse(changed) {
        return {
            schema: 1,
            senderId: state.syncSenderId,
            nonce: createRandomId('sync'),
            changed: [...new Set(changed)],
            at: Date.now(),
        };
    }

    function normaliseImportedSettings(rawSettings, currentSettings) {
        if (!isPlainImportRecord(rawSettings)) {
            throw new Error('The settings payload is missing or invalid.');
        }
        const imported = {
            ...currentSettings,
            selectedForums: [...currentSettings.selectedForums],
            forumThreadLimits: { ...currentSettings.forumThreadLimits },
            activitySourceColors: { ...currentSettings.activitySourceColors },
            hiddenUserTags: [...currentSettings.hiddenUserTags],
            statsOptionalColumnsV2: normaliseStatsOptionalColumns(
                currentSettings.statsOptionalColumnsV2,
            ),
        };
        let recognised = 0;
        const apply = (key, operation) => {
            if (!Object.hasOwn(rawSettings, key)) return;
            recognised += 1;
            operation(rawSettings[key]);
        };

        apply('selectedSources', (value) => {
            if (!Array.isArray(value)) throw new Error('selectedSources must be an array.');
            imported.selectedForums = normaliseSelectedActivitySourceIds(value);
        });
        apply('sourceLimits', (value) => {
            if (!isPlainImportRecord(value)) throw new Error('sourceLimits must be an object.');
            imported.forumThreadLimits = normaliseForumThreadLimits({
                ...imported.forumThreadLimits,
                ...value,
            });
        });
        apply('sourceColors', (value) => {
            if (!isPlainImportRecord(value)) throw new Error('sourceColors must be an object.');
            imported.activitySourceColors = normaliseActivitySourceColors({
                ...imported.activitySourceColors,
                ...value,
            });
        });

        const booleanKeys = [
            'extensionDisabled',
            'enableCustomThreadFetching', 'enableCustomThreadColors',
            'largeSidebarText', 'movePostNewTopicToTop', 'showRelativeAges',
            'enableExtendedMatchFilter', 'strictSelectedTeamMatches',
            'enableThreadPreviews', 'enableOriginalPosterHighlight', 'enableReadStatus',
            'replyComposerAfterOriginalPost', 'enableSavedDrafts',
            'enableUserTags', 'enableLocalUserScores',
            'enableLocalDownvotes', 'changeUpvoteStyle', 'enableSignedOutLocalVoting',
            'enableUsernameBlocking', 'enableWinAdjustedRatings', 'winAdjustedAutoRun',
            'showFullMapNames', 'enableDiagnosticLogging',
            'enableStickyMatchHeader', 'enableMatchPlayerFormOverlays',
            'enableMatchPrediction',
            'enableTeamPerformanceDifference',
            'enableStatsColumnChooser', 'enableStatsMultiSort', 'enableStatsCsvExport',
            'enablePlayerMatchSparklines', 'enableExtendedMatchHistoryLoading',
            'enablePlayerMapMatrix',
            'enablePlayerComparisonEnhancements', 'enablePlayerConsistencyScore',
            'enableStatsTablePeriodComparison', 'enablePlayerPagePeriodComparison',
        ];
        for (const key of booleanKeys) {
            apply(key, (value) => {
                if (typeof value !== 'boolean') throw new Error(`${key} must be a boolean.`);
                imported[key] = value;
            });
        }
        apply('predictionMarketPercent', (value) => {
            if (typeof value !== 'number' || !Number.isFinite(value) || value < 0 || value > 100) {
                throw new Error('predictionMarketPercent must be a number from 0 to 100.');
            }
            imported.predictionMarketPercent = value;
        });
        apply('matchPredictionMode', (value) => {
            if (!['market', 'stats', 'stats-only'].includes(value)) {
                throw new Error('matchPredictionMode must be market, stats, or stats-only.');
            }
            imported.matchPredictionMode = value;
        });
        if (Object.hasOwn(rawSettings, 'enableWinAdjustedRatings')
            && !Object.hasOwn(rawSettings, 'statsOptionalColumnsV2')) {
            const selected = new Set(imported.statsOptionalColumnsV2.ranking);
            if (rawSettings.enableWinAdjustedRatings === true) selected.add('war');
            else selected.delete('war');
            imported.statsOptionalColumnsV2.ranking = [...selected];
        }
        apply('enableKprMatchHistory', (value) => {
            if (typeof value !== 'boolean') {
                throw new Error('enableKprMatchHistory must be a boolean.');
            }
            if (Object.hasOwn(rawSettings, 'statsOptionalColumnsV2')) return;
            const selected = new Set(imported.statsOptionalColumnsV2.matches);
            if (value) selected.add('kpr');
            else selected.delete('kpr');
            imported.statsOptionalColumnsV2.matches = [...selected];
        });
        apply('layoutWidthPreset', (value) => {
            imported.layoutWidthPreset = normaliseLayoutWidthPreset(value);
        });
        apply('hiddenUserTags', (value) => {
            if (!Array.isArray(value)) throw new Error('hiddenUserTags must be an array.');
            imported.hiddenUserTags = normaliseHiddenUserTags(value);
        });
        const hasImportedMetricArray = Object.hasOwn(
            rawSettings,
            'matchPlayerPrimaryMetrics',
        );
        apply('matchPlayerPrimaryMetrics', (value) => {
            if (!Array.isArray(value)) {
                throw new Error('matchPlayerPrimaryMetrics must be an array.');
            }
            imported.matchPlayerPrimaryMetrics = normaliseMatchPlayerMetrics(value);
        });
        apply('matchPlayerPrimaryMetric1', (value) => {
            imported.matchPlayerPrimaryMetric1 = normaliseMatchPlayerMetric(
                value,
                imported.matchPlayerPrimaryMetric1,
            );
        });
        apply('matchPlayerPrimaryMetric2', (value) => {
            imported.matchPlayerPrimaryMetric2 = normaliseMatchPlayerMetric(
                value,
                imported.matchPlayerPrimaryMetric2,
            );
        });
        if (!hasImportedMetricArray
            && (Object.hasOwn(rawSettings, 'matchPlayerPrimaryMetric1')
                || Object.hasOwn(rawSettings, 'matchPlayerPrimaryMetric2'))) {
            imported.matchPlayerPrimaryMetrics = normaliseMatchPlayerMetrics(
                null,
                imported.matchPlayerPrimaryMetric1,
                imported.matchPlayerPrimaryMetric2,
            );
        }
        [
            imported.matchPlayerPrimaryMetric1,
            imported.matchPlayerPrimaryMetric2,
        ] = legacyMatchPlayerMetricPair(imported.matchPlayerPrimaryMetrics);
        apply('statsOptionalColumnsV2', (value) => {
            if (!isPlainImportRecord(value)) {
                throw new Error('statsOptionalColumnsV2 must be an object.');
            }
            imported.statsOptionalColumnsV2 = normaliseStatsOptionalColumns(value);
            imported.enableWinAdjustedRatings = imported.statsOptionalColumnsV2.ranking.includes('war');
        });
        apply('playerMatchTrendMetric', (value) => {
            imported.playerMatchTrendMetric = normaliseStoredMetricName(
                value,
                imported.playerMatchTrendMetric,
            );
        });
        apply('previousPeriodMetric', (value) => {
            imported.previousPeriodMetric = normalisePreviousPeriodMetric(value);
        });
        apply('sortOrder', (value) => {
            imported.sortOrder = normaliseSortOrder(value);
        });

        const dynamic = {};
        apply('statsMatchHistoryRowsV2', (value) => {
            const normalised = normaliseStatsMatchHistoryRows(value);
            if (normalised !== value && String(value).toLowerCase() !== 'all') {
                throw new Error('statsMatchHistoryRowsV2 must be 100, 200, 300, 400, 500, or all.');
            }
            dynamic.statsMatchHistoryRowsV2 = normalised;
        });
        apply('statsColumnLayout', (value) => {
            if (!isPlainImportRecord(value)) throw new Error('statsColumnLayout must be an object.');
            dynamic.statsColumnLayoutV2 = normaliseStatsColumnLayoutsForExport(value);
        });
        apply('statsMultiSort', (value) => {
            if (!isPlainImportRecord(value)) throw new Error('statsMultiSort must be an object.');
            dynamic.statsMultiSortV2 = normaliseStatsMultiSortForExport(value);
        });

        let teams = null;
        apply('additionalMatchTeams', (value) => {
            if (!Array.isArray(value)) throw new Error('additionalMatchTeams must be an array.');
            teams = normaliseExtendedMatchTeams(value);
        });
        if (!recognised) throw new Error('The file contains no recognised settings.');
        return { imported, dynamic, teams };
    }

    function importedUserTags(value) {
        if (!Array.isArray(value)) throw new Error('userTags must be an array.');
        const users = {};
        for (const raw of value.slice(0, CONFIG.maxUserTags * 4)) {
            const userId = String(raw?.userId ?? '');
            const tag = normaliseUserTag(raw?.tag);
            const updatedAt = Number(raw?.updatedAt);
            if (!/^\d{1,20}$/.test(userId)
                || !tag
                || !Number.isFinite(updatedAt)
                || updatedAt < 0
                || updatedAt > Date.now() + 300000) continue;
            users[userId] = {
                name: cleanText(raw?.name).slice(0, 100),
                tag,
                note: tag,
                updatedAt,
            };
        }
        return normaliseUserTags({ schema: 1, users });
    }

    function importedReadState(value) {
        if (!Array.isArray(value)) throw new Error('readState must be an array.');
        const entries = {};
        for (const raw of value.slice(0, CONFIG.maxReadEntries * 4)) {
            const threadId = String(raw?.threadId ?? '');
            if (!/^\d{1,20}$/.test(threadId)) continue;
            entries[threadId] = {
                seenReplyCount: raw.seenReplyCount,
                maxPostNo: raw.maxPostNo,
                selfPostNumbers: raw.selfPostNumbers,
                visitedAt: raw.visitedAt,
            };
        }
        return normaliseReadState({ schema: 2, entries });
    }

    function importedReactionState(value) {
        if (!Array.isArray(value)) throw new Error('reactions must be an array.');
        const reactions = {};
        for (const raw of value.slice(0, CONFIG.maxLocalReactions * 4)) {
            const identity = parseReactionKey(raw?.reactionKey);
            const updatedAt = Number(raw?.updatedAt);
            const mutationId = /^[A-Za-z0-9_.:-]{1,80}$/.test(String(raw?.mutationId || ''))
                ? String(raw.mutationId)
                : `${updatedAt}:import`;
            if (!identity) continue;
            reactions[identity.key] = {
                authorId: String(raw?.authorId ?? ''),
                value: Number(raw?.value),
                updatedAt,
                mutationId,
            };
        }
        return normaliseLocalReactions({ schema: 2, resetAt: 0, reactions }, 0);
    }

    function importedProvisionalUpvotes(value, reactions) {
        if (!Array.isArray(value)) {
            throw new Error('provisionalLocalUpvotes must be an array.');
        }
        const upvotes = {};
        for (const raw of value.slice(0, CONFIG.maxLocalReactions * 4)) {
            const identity = parseReactionKey(raw?.reactionKey);
            const reaction = identity ? reactions.get(identity.key) : null;
            const authorId = String(raw?.authorId ?? '');
            const updatedAt = Number(raw?.updatedAt);
            const suppliedMutationId = String(raw?.reactionMutationId || '');
            const reactionMutationId = /^[A-Za-z0-9_.:-]{1,80}$/.test(suppliedMutationId)
                ? suppliedMutationId
                : reaction?.mutationId || '';
            if (!identity || reaction?.value !== 1 || reaction.authorId !== authorId) continue;
            upvotes[identity.key] = { authorId, reactionMutationId, updatedAt };
        }
        return normaliseProvisionalLocalUpvotes({ schema: 1, upvotes }, reactions);
    }

    function serialiseImportedUserTags(tags) {
        return {
            schema: 1,
            updatedAt: Date.now(),
            users: Object.fromEntries([...tags.entries()]
                .sort((first, second) => second[1].updatedAt - first[1].updatedAt)
                .slice(0, CONFIG.maxUserTags)
                .map(([userId, entry]) => [userId, {
                    name: entry.name,
                    tag: entry.tag,
                    note: entry.tag,
                    updatedAt: entry.updatedAt,
                }])),
        };
    }

    function serialiseImportedReadState(entries) {
        return {
            schema: 2,
            updatedAt: Date.now(),
            entries: Object.fromEntries([...entries.entries()]
                .sort((first, second) => second[1].visitedAt - first[1].visitedAt)
                .slice(0, CONFIG.maxReadEntries)),
        };
    }

    async function importSettingsEnvelope(envelope) {
        const currentSettings = await loadSettings();
        const { imported, dynamic, teams } = normaliseImportedSettings(envelope.settings, currentSettings);
        const payload = {
            ...settingsStoragePayload(imported),
            extensionDisabled: Boolean(imported.extensionDisabled),
            predictionMarketPercent: normalisePredictionMarketPercent(imported.predictionMarketPercent),
            matchPredictionMode: normaliseMatchPredictionMode(imported.matchPredictionMode),
            playerMatchTrendMetric: normaliseStoredMetricName(
                imported.playerMatchTrendMetric,
                DEFAULT_SETTINGS.playerMatchTrendMetric,
            ),
            ...dynamic,
        };
        const changed = ['settings'];
        if (teams) {
            payload[STORAGE_KEYS.extendedMatchTeams] = {
                schema: 1,
                updatedAt: Date.now(),
                teams: [...teams.values()],
            };
            changed.push('matchTeams');
        }
        payload[STORAGE_KEYS.syncPulse] = importSyncPulse(changed);
        await storageSetMany(payload);
        state.modalSettingsDirty = false;
        state.modalSettingsExternalChange = false;
        await applyRemoteSync(new Set(changed));
    }

    async function importUserDataEnvelope(envelope) {
        if (!hasPrivateStorage() || !isPlainImportRecord(envelope.data)) {
            throw new Error('The user-data payload is missing or unavailable.');
        }
        const data = envelope.data;
        const recognisedKeys = [
            'userTags', 'readState', 'reactions',
            'provisionalLocalUpvotes', 'additionalMatchTeams',
        ].filter((key) => Object.hasOwn(data, key));
        if (!recognisedKeys.length) throw new Error('The file contains no recognised user data.');

        const incomingTags = Object.hasOwn(data, 'userTags')
            ? importedUserTags(data.userTags)
            : new Map();
        const incomingRead = Object.hasOwn(data, 'readState')
            ? importedReadState(data.readState)
            : new Map();
        const incomingReactions = Object.hasOwn(data, 'reactions')
            ? importedReactionState(data.reactions)
            : new Map();
        const incomingTeams = Object.hasOwn(data, 'additionalMatchTeams')
            ? normaliseExtendedMatchTeams(data.additionalMatchTeams)
            : new Map();

        await withLocalReactionStorageLock(async () => {
            const [rawTags, rawRead, rawReactions, rawProvisional, rawTeams] = await Promise.all([
                privateStorageGetStrict(STORAGE_KEYS.userTags),
                privateStorageGetStrict(STORAGE_KEYS.readState),
                privateStorageGetStrict(STORAGE_KEYS.localReactions),
                privateStorageGetStrict(STORAGE_KEYS.provisionalLocalUpvotes),
                storageGet(STORAGE_KEYS.extendedMatchTeams, null),
            ]);
            const mergedTags = normaliseUserTags(rawTags);
            for (const [userId, incoming] of incomingTags) {
                const current = mergedTags.get(userId);
                if (!current || incoming.updatedAt > current.updatedAt) {
                    mergedTags.set(userId, incoming);
                }
            }
            const mergedRead = mergeReadStateMaps(
                normaliseReadState(rawRead),
                incomingRead,
            );
            const resetAt = localReactionResetAtFromRecord(rawReactions);
            const currentReactions = normaliseLocalReactions(rawReactions, resetAt);
            const mergedReactions = mergeLocalReactionMaps(
                currentReactions,
                incomingReactions,
                resetAt,
            );
            const currentProvisional = normaliseProvisionalLocalUpvotes(
                rawProvisional,
                mergedReactions,
            );
            const incomingProvisional = Object.hasOwn(data, 'provisionalLocalUpvotes')
                ? importedProvisionalUpvotes(data.provisionalLocalUpvotes, mergedReactions)
                : new Map();
            const mergedProvisional = mergeProvisionalLocalUpvotes(
                currentProvisional,
                incomingProvisional,
                mergedReactions,
            );
            const mergedTeams = normaliseExtendedMatchTeams(rawTeams);
            for (const [teamId, team] of incomingTeams) {
                if (!mergedTeams.has(teamId)) mergedTeams.set(teamId, team);
            }
            await storageSetMany({
                [STORAGE_KEYS.userTags]: serialiseImportedUserTags(mergedTags),
                [STORAGE_KEYS.readState]: serialiseImportedReadState(mergedRead),
                [STORAGE_KEYS.localReactions]: serialiseLocalReactions(
                    mergedReactions,
                    resetAt,
                ),
                [STORAGE_KEYS.provisionalLocalUpvotes]: serialiseProvisionalLocalUpvotes(
                    mergedProvisional,
                ),
                [STORAGE_KEYS.extendedMatchTeams]: {
                    schema: 1,
                    updatedAt: Date.now(),
                    teams: [...mergedTeams.values()].slice(0, CONFIG.maxExtendedMatchTeams),
                },
                [STORAGE_KEYS.syncPulse]: importSyncPulse([
                    'readState', 'notes', 'reactions', 'matchTeams',
                ]),
            });
        });
        await applyRemoteSync(new Set(['readState', 'notes', 'reactions', 'matchTeams']));
    }

    async function readImportEnvelope(file) {
        if (!file
            || typeof file !== 'object'
            || typeof file.text !== 'function'
            || !Number.isFinite(Number(file.size))) {
            throw new Error('No readable file was selected.');
        }
        if (file.size <= 0 || file.size > CONFIG.maxImportBytes) {
            throw new Error('Import files must be between 1 byte and 5 MiB.');
        }
        const text = await file.text();
        if (!text || text.length > CONFIG.maxImportBytes) {
            throw new Error('The import file is empty or too large.');
        }
        let envelope;
        try {
            envelope = JSON.parse(text);
        } catch {
            throw new Error('The selected file is not valid JSON.');
        }
        if (!isPlainImportRecord(envelope)
            || envelope.schemaVersion !== 1
            || !['hltv-enhancements-settings', 'hltv-enhancements-user-data']
                .includes(envelope.format)) {
            throw new Error('This is not a supported HLTV Enhancements export.');
        }
        return envelope;
    }

    async function importLocalDataOnSite(input, button, expectedFormat) {
        const file = input?.files?.[0];
        if (!file) return;
        await runOnSiteDataAction(
            button,
            'Validating and importing the local file…',
            'The local file was imported and merged successfully.',
            async () => {
                const envelope = await readImportEnvelope(file);
                if (envelope.format !== expectedFormat) {
                    throw new Error(expectedFormat === 'hltv-enhancements-settings'
                        ? 'Choose an HLTV Enhancements settings export.'
                        : 'Choose an HLTV Enhancements user-data export.');
                }
                if (envelope.format === 'hltv-enhancements-settings') {
                    await importSettingsEnvelope(envelope);
                } else {
                    await importUserDataEnvelope(envelope);
                }
            },
        );
        input.value = '';
    }

    function scrubDebugExportText(value, maximumLength = 240) {
        return String(value || '')
            .replace(/[\u0000-\u001f\u007f]/g, ' ')
            .replace(/\b(?:https?|moz-extension|chrome-extension):\/\/[^\s)]+/gi, '[url]')
            .replace(/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi, '[email]')
            .replace(/\b(?:\d{1,3}\.){3}\d{1,3}\b/g, '[ip]')
            .replace(/\b[A-Za-z0-9_-]{32,}\b/g, '[token]')
            .replace(/\b\d{3,}\b/g, '#')
            .replace(/\s+/g, ' ')
            .trim()
            .slice(0, maximumLength);
    }

    function debugEntriesForExport(value) {
        const now = Date.now();
        const source = value?.schema === 1 && Array.isArray(value.entries)
            ? value.entries
            : [];
        const levels = new Set(['debug', 'info', 'warn', 'error']);
        const routes = new Set([
            'home', 'forum-create', 'thread', 'forum', 'stats-player-matches',
            'stats-players', 'stats', 'profile', 'matches', 'news', 'other',
        ]);
        const entries = [];
        for (const rawEntry of source.slice(-CONFIG.maxDiagnosticEntries * 2)) {
            const at = Math.trunc(Number(rawEntry?.at));
            const level = levels.has(rawEntry?.level) ? rawEntry.level : '';
            const storedEvent = scrubDebugExportText(rawEntry?.event, 80);
            const event = /^extension-(?:diagnostics|settings|storage|action-lock|reaction|reply|thread-preview|activity|user-action|read-state|match-filter|layout|war|kpr|sync|request|export|module|event)$/.test(storedEvent)
                ? storedEvent
                : 'extension-event';
            const route = routes.has(rawEntry?.route) ? rawEntry.route : 'other';
            if (!Number.isFinite(at)
                || at < now - CONFIG.diagnosticRetentionMs
                || at > now + 300000
                || !level
                || !event) continue;
            const rawError = rawEntry?.error && typeof rawEntry.error === 'object'
                && !Array.isArray(rawEntry.error)
                ? rawEntry.error
                : null;
            let error = null;
            if (rawError) {
                const name = /^[A-Za-z][A-Za-z0-9_.-]{0,79}$/.test(String(rawError.name || ''))
                    ? String(rawError.name)
                    : 'Error';
                const code = /^[A-Za-z0-9_.:-]{1,80}$/.test(String(rawError.code || ''))
                    ? String(rawError.code)
                    : '';
                const stack = (Array.isArray(rawError.stack) ? rawError.stack : [])
                    .map(String)
                    .filter((frame) => /^(?:content|background|popup|ui)\/[A-Za-z0-9._/-]+\.js:\d+:\d+$/.test(frame))
                    .slice(0, 8);
                error = {
                    name,
                    ...(code ? { code } : {}),
                    ...(stack.length ? { stack } : {}),
                };
            }
            entries.push({
                at,
                level,
                event,
                route,
                count: clampInteger(rawEntry.count, 1, 10_000, 1),
                ...(error ? { error } : {}),
            });
        }
        return entries.slice(-CONFIG.maxDiagnosticEntries);
    }

    async function exportDebugLogOnSite(button) {
        await runOnSiteDataAction(
            button,
            'Preparing local debug-log export…',
            'Debug log was exported.',
            async () => {
                if (!hasPrivateStorage()) throw new Error('Private storage is unavailable.');
                const rawLog = await privateStorageGetStrict(STORAGE_KEYS.debugLog);
                downloadLocalJson(
                    'debug-log',
                    exportEnvelope('hltv-enhancements-debug-log', {
                        log: {
                            localOnly: true,
                            automaticallyTransmitted: false,
                            retentionDays: 7,
                            redaction: 'No drafts, post text, usernames, tags, cookies, credentials, raw HTML, response bodies, full URLs, query strings, fragments, or numeric profile/thread identifiers.',
                            entries: debugEntriesForExport(rawLog),
                        },
                    }),
                );
            },
        );
    }

    async function clearDebugLogOnSite(button) {
        let confirmed = false;
        try {
            confirmed = safeConfirm?.('Clear the entire local diagnostic log?') === true;
        } catch {
            confirmed = false;
        }
        if (!confirmed) return;
        await runOnSiteDataAction(
            button,
            'Clearing local debug log…',
            'Local debug log was cleared.',
            async () => {
                if (!hasPrivateStorage()) throw new Error('Private storage is unavailable.');
                await privateStorageRemove(STORAGE_KEYS.debugLog);
            },
        );
    }

    async function clearCachedRankingsOnSite(button) {
        await runOnSiteDataAction(
            button,
            'Clearing cached rankings…',
            'Cached rankings were cleared; archived forecasts are preserved.',
            async () => {
                const result = await globalThis.HLTV_SP_EXTENSION?.rankingCache?.clear();
                if (!result?.ok) throw new Error('Cached rankings could not be cleared.');
            },
        );
    }

    function savedDraftOpenHref(record) {
        const url = parseSameOriginUrl(record?.path);
        if (!url) return '';
        if (record.kind === 'reply' && record.replyId) url.hash = `r${record.replyId}`;
        return url.href;
    }

    function renderSavedDraftManager() {
        const manager = state.modalBackdrop?.querySelector('.hltv-sp-saved-drafts-manager');
        if (!manager) return;
        const summary = manager.querySelector('.hltv-sp-saved-drafts-summary');
        const list = manager.querySelector('.hltv-sp-saved-drafts-list');
        const empty = manager.querySelector('.hltv-sp-saved-drafts-empty');
        const deleteAll = manager.querySelector('#hltv-sp-delete-all-drafts');
        if (!summary || !list || !empty || !deleteAll) return;
        list.replaceChildren();
        const accountId = extractCurrentUserId();
        if (!hasSavedDraftStorage()) {
            summary.textContent = 'Durable drafts require the packaged Firefox extension.';
            empty.textContent = 'Saved drafts are unavailable.';
            empty.hidden = false;
            deleteAll.disabled = true;
            return;
        }
        if (!/^\d{1,20}$/.test(String(accountId || ''))) {
            summary.textContent = 'Sign in to HLTV to view this account’s saved drafts.';
            empty.textContent = 'Draft contents stay hidden while the account cannot be verified.';
            empty.hidden = false;
            deleteAll.disabled = true;
            return;
        }
        const entries = savedDraftEntriesForAccount(accountId);
        const totalBytes = entries.reduce((total, entry) => (
            total + savedDraftRecordByteSize(entry.record)
        ), 0);
        summary.textContent = `${entries.length} of ${CONFIG.maxSavedDrafts} drafts · `
            + `${(totalBytes / (1024 * 1024)).toFixed(2)} of 2.00 MiB used`;
        empty.textContent = 'No drafts are saved for this HLTV account.';
        empty.hidden = Boolean(entries.length);
        deleteAll.disabled = !entries.length;
        for (const entry of entries) {
            const { record } = entry;
            const item = document.createElement('li');
            item.className = 'hltv-sp-saved-draft-entry';
            const draftTitle = document.createElement('div');
            draftTitle.className = 'hltv-sp-saved-draft-title';
            draftTitle.textContent = record.kind === 'topic'
                ? record.subject || 'Untitled topic'
                : record.title || 'Saved reply';
            const context = document.createElement('div');
            context.className = 'hltv-sp-saved-draft-context';
            context.textContent = record.context || (
                record.kind === 'topic' ? 'New forum topic' : 'Reply draft'
            );
            const updated = document.createElement('time');
            updated.className = 'hltv-sp-saved-draft-updated';
            updated.dateTime = new Date(record.updatedAt).toISOString();
            updated.title = new Date(record.updatedAt).toLocaleString();
            updated.textContent = `Updated ${formatRelativeAge(record.updatedAt)}`;
            const itemActions = document.createElement('div');
            itemActions.className = 'hltv-sp-saved-draft-actions';
            const open = document.createElement('a');
            open.className = 'hltv-sp-saved-draft-open';
            open.href = savedDraftOpenHref(record);
            open.textContent = 'Open';
            open.title = record.replyId
                ? 'Open the original page at this reply.'
                : 'Open the original draft destination.';
            itemActions.appendChild(open);
            const binding = currentBindingForSavedDraft(entry);
            if (binding) {
                const restore = document.createElement('button');
                restore.type = 'button';
                restore.className = 'hltv-sp-setting-secondary-action hltv-sp-saved-draft-restore';
                restore.textContent = 'Restore here';
                restore.addEventListener('click', () => {
                    restore.disabled = true;
                    restoreSavedDraftIntoBinding(binding, entry)
                        .then(() => closeSettingsModal())
                        .catch((error) => {
                            restore.disabled = false;
                            setModalStatus(savedDraftPublicError(error));
                        });
                });
                itemActions.appendChild(restore);
            }
            const remove = document.createElement('button');
            remove.type = 'button';
            remove.className = 'hltv-sp-setting-secondary-action hltv-sp-saved-draft-delete';
            remove.textContent = 'Delete';
            remove.addEventListener('click', () => {
                let confirmed = false;
                try {
                    confirmed = safeConfirm?.(
                        `Delete the saved draft “${record.kind === 'topic'
                            ? record.subject || 'Untitled topic'
                            : record.title || 'Saved reply'}”?`,
                    ) === true;
                } catch {
                    confirmed = false;
                }
                if (!confirmed) return;
                remove.disabled = true;
                removeSavedDraft(entry.key, record.revision)
                    .then(() => {
                        setModalStatus('Saved draft deleted.');
                        renderSavedDraftManager();
                        refreshAllSavedDraftUi();
                    })
                    .catch((error) => {
                        remove.disabled = false;
                        setModalStatus(savedDraftPublicError(error));
                    });
            });
            itemActions.appendChild(remove);
            item.append(draftTitle, context, updated, itemActions);
            list.appendChild(item);
        }
    }

    function createSettingsModal() {
        if (hasCompleteSettingsModal()) {
            state.statusElement = state.modalBackdrop.querySelector('#hltv-sp-status');
            return;
        }
        state.modalHost?.remove();
        document.querySelector('.hltv-sp-settings-host')?.remove();
        state.modalHost = null;
        state.modalBackdrop = null;
        state.statusElement = null;

        const { host: modalHost, root: modalRoot } = createPrivateUiHost({
            tagName: 'div',
            className: 'hltv-sp-private-ui-host hltv-sp-settings-host',
            styleText: `
                :host {
                    display: contents;
                }
                ${trustedMainUiStyleText}
            `,
        });
        stampUiVersion(modalHost);

        const backdrop = document.createElement('div');
        backdrop.id = 'hltv-sp-modal-backdrop';
        stampUiVersion(backdrop);
        backdrop.addEventListener('click', (event) => {
            if (event.target === backdrop) closeSettingsModal();
        });

        const modal = document.createElement('section');
        modal.id = 'hltv-sp-modal';
        modal.setAttribute('role', 'dialog');
        modal.setAttribute('aria-modal', 'true');
        modal.setAttribute('aria-labelledby', 'hltv-sp-title');

        const closeButton = document.createElement('button');
        closeButton.id = 'hltv-sp-close';
        closeButton.type = 'button';
        closeButton.textContent = '\u00D7';
        closeButton.title = 'Close';
        closeButton.setAttribute('aria-label', 'Close');
        closeButton.addEventListener('click', closeSettingsModal);

        const title = document.createElement('h2');
        title.id = 'hltv-sp-title';
        title.textContent = `HLTV Enhancements settings (v${SCRIPT_VERSION})`;

        const form = document.createElement('form');
        form.id = 'hltv-sp-form';
        form.addEventListener('submit', handleSettingsSubmit);
        const markSettingsDirty = (event) => {
            if (event.target?.type !== 'file') state.modalSettingsDirty = true;
        };
        form.addEventListener('input', markSettingsDirty);
        form.addEventListener('change', markSettingsDirty);

        const extensionFieldset = document.createElement('fieldset');
        const extensionLegend = document.createElement('legend');
        extensionLegend.textContent = 'Extension';
        const masterLabel = document.createElement('label');
        const masterCheckbox = document.createElement('input');
        masterCheckbox.id = 'hltv-sp-extension-disabled';
        masterCheckbox.type = 'checkbox';
        masterLabel.append(masterCheckbox, document.createTextNode('Disable HLTV Enhancements'));
        extensionFieldset.append(extensionLegend, createSettingRow({
            primary: masterLabel,
            helpId: 'hltv-sp-extension-disabled-help',
            description: 'Pause all enhancements without changing your individual settings or saved data. The settings cog remains available. Save, then manually reload open HLTV tabs to apply this change. Uncheck it here or in the extension popup and reload to enable again.',
        }));

        const forumFieldset = document.createElement('fieldset');
        forumFieldset.id = 'hltv-sp-forum-settings';
        const forumLegend = document.createElement('legend');
        forumLegend.textContent = 'Forums to display and fetch';

        const customFetchingLabel = document.createElement('label');
        const customFetchingCheckbox = document.createElement('input');
        customFetchingCheckbox.id = 'hltv-sp-custom-thread-fetching';
        customFetchingCheckbox.type = 'checkbox';
        customFetchingLabel.append(
            customFetchingCheckbox,
            document.createTextNode('Fetch additional recent-activity threads'),
        );
        const customFetchingSetting = createSettingRow({
            primary: customFetchingLabel,
            helpId: 'hltv-sp-custom-thread-fetching-help',
            description: 'Add more forum, news, and match rows from the sources you select. Turning this off removes extension-added rows while keeping your source choices.',
            className: 'hltv-sp-recent-activity-master',
        });

        const customColorsLabel = document.createElement('label');
        const customColorsCheckbox = document.createElement('input');
        customColorsCheckbox.id = 'hltv-sp-custom-thread-colors';
        customColorsCheckbox.type = 'checkbox';
        customColorsLabel.append(
            customColorsCheckbox,
            document.createTextNode('Use custom recent-activity thread colors'),
        );
        const customColorsSetting = createSettingRow({
            primary: customColorsLabel,
            helpId: 'hltv-sp-custom-thread-colors-help',
            description: 'Apply the saved source colors to native and extension-added recent-activity rows and preview accents. Turning this off restores HLTV\'s native row styling without deleting your saved colors.',
            className: 'hltv-sp-recent-activity-master',
        });
        const sourceColorNote = document.createElement('div');
        sourceColorNote.className = 'hltv-sp-source-color-note';
        const sourceColorNoteText = document.createElement('span');
        sourceColorNoteText.textContent = 'Click a color bar to change it.';
        const resetSourceColors = document.createElement('button');
        resetSourceColors.type = 'button';
        resetSourceColors.className = 'hltv-sp-source-color-reset';
        resetSourceColors.textContent = 'Reset colors';
        resetSourceColors.addEventListener('click', () => {
            state.modalSettingsDirty = true;
            for (const source of ACTIVITY_SOURCES) {
                const input = form.elements.namedItem(`sourceColor:${source.id}`);
                if (!(input instanceof HTMLInputElement)) continue;
                input.value = DEFAULT_ACTIVITY_SOURCE_COLORS[source.id];
                input.closest('.hltv-sp-forum-limit-row')?.style.setProperty(
                    '--hltv-sp-forum-color',
                    input.value,
                );
            }
        });
        sourceColorNote.append(sourceColorNoteText, resetSourceColors);
        const forumGrid = document.createElement('div');
        forumGrid.className = 'hltv-sp-grid';

        customFetchingCheckbox.addEventListener(
            'change',
            () => syncForumSourceSettingsControls(form),
        );
        customColorsCheckbox.addEventListener(
            'change',
            () => syncForumSourceSettingsControls(form),
        );

        for (const source of ACTIVITY_SOURCES) {
            const label = document.createElement('label');

            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.name = 'selectedForums';
            checkbox.value = source.id;

            const text = document.createElement('span');
            text.textContent = source.label;

            const limitInput = document.createElement('input');
            limitInput.className = 'hltv-sp-number-input';
            limitInput.type = 'number';
            limitInput.name = `forumLimit:${source.id}`;
            limitInput.min = '1';
            limitInput.max = String(CONFIG.maxThreadsPerForum);
            limitInput.step = '1';
            limitInput.title = `Maximum additional ${source.label} entries to fetch`;
            limitInput.setAttribute(
                'aria-label',
                `Maximum additional ${source.label} entries to fetch`,
            );

            const colorInput = document.createElement('input');
            colorInput.type = 'color';
            colorInput.className = 'hltv-sp-source-color-input';
            colorInput.name = `sourceColor:${source.id}`;
            colorInput.title = `Change the ${source.label} thread color`;
            colorInput.setAttribute('aria-label', colorInput.title);

            label.append(checkbox, text);
            const description = source.kind === 'forum'
                ? `Keep native ${source.label} rows and fetch up to the number on the right as additional older threads.`
                : source.kind === 'news'
                    ? 'Keep native news rows and fetch up to the number on the right as additional front-page news entries.'
                    : "Keep native match rows and fetch up to the number on the right as additional front-page matches without changing HLTV's match filter.";
            const row = createSettingRow({
                primary: label,
                secondary: [limitInput],
                helpId: `hltv-sp-forum-${source.id}-help`,
                description,
                className: 'hltv-sp-forum-limit-row',
            });
            row.style.setProperty('--hltv-sp-forum-color', source.color);
            colorInput.addEventListener('input', () => {
                row.style.setProperty(
                    '--hltv-sp-forum-color',
                    normaliseActivitySourceColor(colorInput.value, source.color),
                );
            });
            row.prepend(colorInput);
            forumGrid.appendChild(row);
        }

        forumFieldset.append(
            forumLegend,
            customFetchingSetting,
            customColorsSetting,
            sourceColorNote,
            forumGrid,
        );

        const sidebarActivityFieldset = document.createElement('fieldset');
        sidebarActivityFieldset.id = 'hltv-sp-sidebar-activity-settings';
        const sidebarActivityLegend = document.createElement('legend');
        sidebarActivityLegend.textContent = 'Sidebar & activity';
        const sidebarActivityOptions = document.createElement('div');
        sidebarActivityOptions.className = 'hltv-sp-options';

        const greenUpvotesLabel = document.createElement('label');
        const greenUpvotesCheckbox = document.createElement('input');
        greenUpvotesCheckbox.id = 'hltv-sp-green-upvotes';
        greenUpvotesCheckbox.type = 'checkbox';
        const greenUpvotesText = document.createElement('span');
        greenUpvotesText.textContent = 'Change upvoted comment +1 buttons to green';
        greenUpvotesLabel.append(greenUpvotesCheckbox, greenUpvotesText);
        const greenUpvotesSetting = createSettingRow({
            primary: greenUpvotesLabel,
            helpId: 'hltv-sp-green-upvotes-help',
            description: 'Color a real, active HLTV +1 button green so your current HLTV upvotes are easier to spot. Pink is reserved for local +1s saved when HLTV voting is unavailable, such as while signed out. This setting does not recolor or submit those pink local votes.',
        });

        const relativeAgesLabel = document.createElement('label');
        const relativeAgesCheckbox = document.createElement('input');
        relativeAgesCheckbox.id = 'hltv-sp-relative-ages';
        relativeAgesCheckbox.type = 'checkbox';
        const relativeAgesText = document.createElement('span');
        relativeAgesText.textContent = 'Show relative post ages in threads and previews';
        relativeAgesLabel.append(relativeAgesCheckbox, relativeAgesText);
        const relativeAgesSetting = createSettingRow({
            primary: relativeAgesLabel,
            helpId: 'hltv-sp-relative-ages-help',
            description: 'Show how long ago original posts and comments were made on thread pages and in previews.',
        });

        const movePostNewTopicLabel = document.createElement('label');
        const movePostNewTopicCheckbox = document.createElement('input');
        movePostNewTopicCheckbox.id = 'hltv-sp-move-post-new-topic';
        movePostNewTopicCheckbox.type = 'checkbox';
        const movePostNewTopicText = document.createElement('span');
        movePostNewTopicText.textContent = 'Move Post new topic to the top of the sidebar';
        movePostNewTopicLabel.append(movePostNewTopicCheckbox, movePostNewTopicText);
        const movePostNewTopicSetting = createSettingRow({
            primary: movePostNewTopicLabel,
            helpId: 'hltv-sp-move-post-new-topic-help',
            description: 'Move HLTV\'s existing Post new topic button above the recent-activity rows. Turning this off restores its original position.',
        });

        const threadPreviewsLabel = document.createElement('label');
        const threadPreviewsCheckbox = document.createElement('input');
        threadPreviewsCheckbox.id = 'hltv-sp-thread-previews';
        threadPreviewsCheckbox.type = 'checkbox';
        const threadPreviewsText = document.createElement('span');
        threadPreviewsText.textContent = 'Enable thread previews on title hover';
        threadPreviewsLabel.append(threadPreviewsCheckbox, threadPreviewsText);
        const threadPreviewsSetting = createSettingRow({
            primary: threadPreviewsLabel,
            helpId: 'hltv-sp-thread-previews-help',
            description: 'Hover a forum title to load its original post, comments, votes, tags, and reply controls without leaving the current page.',
        });

        const readStatusLabel = document.createElement('label');
        const readStatusCheckbox = document.createElement('input');
        readStatusCheckbox.id = 'hltv-sp-read-status';
        readStatusCheckbox.type = 'checkbox';
        const readStatusText = document.createElement('span');
        readStatusText.textContent = 'Enable thread read status and first-unread tracking';
        readStatusLabel.append(readStatusCheckbox, readStatusText);
        const readStatusSetting = createSettingRow({
            primary: readStatusLabel,
            helpId: 'hltv-sp-read-status-help',
            description: 'Track read threads locally and add first-unread jump controls to thread pages and previews. Scrolling inside a preview or keeping it open for five continuous seconds marks its loaded comments as read; your own replies are ignored as unread.',
        });

        const extendedMatchFilterLabel = document.createElement('label');
        const extendedMatchFilterCheckbox = document.createElement('input');
        extendedMatchFilterCheckbox.id = 'hltv-sp-extended-match-filter';
        extendedMatchFilterCheckbox.type = 'checkbox';
        const extendedMatchFilterText = document.createElement('span');
        extendedMatchFilterText.textContent = 'Add more teams to the match filter';
        extendedMatchFilterLabel.append(
            extendedMatchFilterCheckbox,
            extendedMatchFilterText,
        );
        const extendedMatchFilterSetting = createSettingRow({
            primary: extendedMatchFilterLabel,
            helpId: 'hltv-sp-extended-match-filter-help',
            description: 'Extend HLTV\'s native Search team field beyond its five built-in team slots. Extra selections appear in the same Team list, stay local, and work only while HLTV\'s match filter is enabled.',
        });

        const strictSelectedTeamsLabel = document.createElement('label');
        const strictSelectedTeamsCheckbox = document.createElement('input');
        strictSelectedTeamsCheckbox.id = 'hltv-sp-strict-selected-teams';
        strictSelectedTeamsCheckbox.type = 'checkbox';
        const strictSelectedTeamsText = document.createElement('span');
        strictSelectedTeamsText.textContent = 'Only show matches involving selected teams';
        strictSelectedTeamsLabel.append(
            strictSelectedTeamsCheckbox,
            strictSelectedTeamsText,
        );
        const strictSelectedTeamsSetting = createSettingRow({
            primary: strictSelectedTeamsLabel,
            helpId: 'hltv-sp-strict-selected-teams-help',
            description: 'When HLTV\'s match filter is enabled, hide every match that does not contain a selected native or additional team, including high-status matches. Turning off HLTV\'s star or dropdown filter immediately restores its normal unfiltered view.',
        });
        const replyComposerPlacementLabel = document.createElement('label');
        const replyComposerPlacementCheckbox = document.createElement('input');
        replyComposerPlacementCheckbox.id = 'hltv-sp-reply-composer-after-op';
        replyComposerPlacementCheckbox.type = 'checkbox';
        const replyComposerPlacementText = document.createElement('span');
        replyComposerPlacementText.textContent = 'Place the main reply composer above the comments';
        replyComposerPlacementLabel.append(
            replyComposerPlacementCheckbox,
            replyComposerPlacementText,
        );
        const replyComposerPlacementSetting = createSettingRow({
            primary: replyComposerPlacementLabel,
            helpId: 'hltv-sp-reply-composer-after-op-help',
            description: 'Move the main reply box directly below the original post on thread pages and previews, or directly before the first main comment on news and match pages. Threaded reply boxes stay beside their target comments.',
        });

        const layoutWidthLabel = document.createElement('label');
        layoutWidthLabel.htmlFor = 'hltv-sp-layout-width';
        layoutWidthLabel.textContent = 'Page and recent-activity width';
        const layoutWidthSelect = document.createElement('select');
        layoutWidthSelect.id = 'hltv-sp-layout-width';
        const layoutWidthOptions = [
            ['default', 'HLTV default'],
            ['wide', 'Wide (+120 main / +80 sidebar)'],
            ['extra', 'Extra wide (+240 main / +140 sidebar)'],
        ];
        for (const [value, label] of layoutWidthOptions) {
            const option = document.createElement('option');
            option.value = value;
            option.textContent = label;
            layoutWidthSelect.appendChild(option);
        }
        const layoutWidthSetting = createSettingRow({
            primary: layoutWidthLabel,
            secondary: [layoutWidthSelect],
            helpId: 'hltv-sp-layout-width-help',
            description: 'Desktop only. Widen the main page and recent-activity sidebar by using available side space; the layout scales down on narrower windows.',
        });

        const largeSidebarTextLabel = document.createElement('label');
        const largeSidebarTextCheckbox = document.createElement('input');
        largeSidebarTextCheckbox.id = 'hltv-sp-large-sidebar-text';
        largeSidebarTextCheckbox.type = 'checkbox';
        const largeSidebarTextText = document.createElement('span');
        largeSidebarTextText.textContent = 'Use larger recent-activity thread text';
        largeSidebarTextLabel.append(largeSidebarTextCheckbox, largeSidebarTextText);
        const largeSidebarTextSetting = createSettingRow({
            primary: largeSidebarTextLabel,
            helpId: 'hltv-sp-large-sidebar-text-help',
            description: 'Increase recent-activity title size and row height for easier reading on large displays.',
        });

        const layoutFieldset = document.createElement('fieldset');
        layoutFieldset.id = 'hltv-sp-layout-settings';
        const layoutLegend = document.createElement('legend');
        layoutLegend.textContent = 'Page layout';
        const layoutOptions = document.createElement('div');
        layoutOptions.className = 'hltv-sp-options';
        layoutOptions.append(layoutWidthSetting, largeSidebarTextSetting);
        layoutFieldset.append(layoutLegend, layoutOptions);

        const userTagsLabel = document.createElement('label');
        const userTagsCheckbox = document.createElement('input');
        userTagsCheckbox.id = 'hltv-sp-user-tags';
        userTagsCheckbox.type = 'checkbox';
        const userTagsText = document.createElement('span');
        userTagsText.textContent = 'Enable local user tags';
        userTagsLabel.append(userTagsCheckbox, userTagsText);
        const userTagsSetting = createSettingRow({
            primary: userTagsLabel,
            helpId: 'hltv-sp-user-tags-help',
            description: 'Add private tags beside HLTV usernames, including in thread previews. Tags stay in this extension storage.',
        });

        const localScoresLabel = document.createElement('label');
        const localScoresCheckbox = document.createElement('input');
        localScoresCheckbox.id = 'hltv-sp-local-user-scores';
        localScoresCheckbox.type = 'checkbox';
        const localScoresText = document.createElement('span');
        localScoresText.textContent = 'Show local user reaction counters';
        localScoresLabel.append(localScoresCheckbox, localScoresText);
        const resetLocalScoresButton = document.createElement('button');
        resetLocalScoresButton.id = 'hltv-sp-reset-local-user-scores';
        resetLocalScoresButton.type = 'button';
        resetLocalScoresButton.className = 'hltv-sp-setting-secondary-action';
        resetLocalScoresButton.textContent = 'Reset counts';
        resetLocalScoresButton.addEventListener('click', () => {
            handleResetLocalReactionCounts(resetLocalScoresButton);
        });
        const localScoresSetting = createSettingRow({
            primary: localScoresLabel,
            secondary: [resetLocalScoresButton],
            helpId: 'hltv-sp-local-user-scores-help',
            description: 'Show the private reaction score kept for each username. Tracking continues while this display is off; adding an HLTV +1 raises the score by one and removing it lowers the score by one.',
        });

        const localDownvotesLabel = document.createElement('label');
        const localDownvotesCheckbox = document.createElement('input');
        localDownvotesCheckbox.id = 'hltv-sp-local-downvotes';
        localDownvotesCheckbox.type = 'checkbox';
        const localDownvotesText = document.createElement('span');
        localDownvotesText.textContent = 'Show local downvote buttons';
        localDownvotesLabel.append(localDownvotesCheckbox, localDownvotesText);
        const localDownvotesSetting = createSettingRow({
            primary: localDownvotesLabel,
            helpId: 'hltv-sp-local-downvotes-help',
            description: 'Add a private minus button beside thread and comment votes. It makes that post contribute -1 instead of a recorded +1, and sends no downvote to HLTV.',
        });

        const signedOutLocalVotingLabel = document.createElement('label');
        const signedOutLocalVotingCheckbox = document.createElement('input');
        signedOutLocalVotingCheckbox.id = 'hltv-sp-signed-out-local-voting';
        signedOutLocalVotingCheckbox.type = 'checkbox';
        const signedOutLocalVotingText = document.createElement('span');
        signedOutLocalVotingText.textContent = 'Allow local voting when HLTV voting is unavailable';
        signedOutLocalVotingLabel.append(
            signedOutLocalVotingCheckbox,
            signedOutLocalVotingText,
        );
        const signedOutLocalVotingSetting = createSettingRow({
            primary: signedOutLocalVotingLabel,
            helpId: 'hltv-sp-signed-out-local-voting-help',
            description: 'When HLTV cannot accept a +1, keep it locally and show it in pink. After signing in, clicking that pink +1 converts it to a real HLTV upvote without counting twice.',
        });
        if (!hasPrivateStorage()) {
            localScoresCheckbox.disabled = true;
            localScoresLabel.title = 'Private extension storage is required for local user scores.';
            resetLocalScoresButton.disabled = true;
            localDownvotesCheckbox.disabled = true;
            localDownvotesLabel.title = 'Private extension storage is required for local downvotes.';
            signedOutLocalVotingCheckbox.disabled = true;
            signedOutLocalVotingLabel.title = 'Private extension storage is required for local voting.';
        }

        const tagFilterLabel = document.createElement('label');
        tagFilterLabel.textContent = 'Hide comments from users with these tags';
        const tagFilterEditor = document.createElement('div');
        tagFilterEditor.id = 'hltv-sp-hidden-user-tags';
        tagFilterEditor.setAttribute('role', 'group');
        tagFilterEditor.setAttribute('aria-label', tagFilterLabel.textContent);
        renderHiddenUserTagEditor(tagFilterEditor, []);
        const tagFilterSetting = createSettingRow({
            primary: tagFilterLabel,
            body: [tagFilterEditor],
            helpId: 'hltv-sp-hidden-user-tags-help',
            description: 'Hide comments by users whose local tag exactly matches an entry here. Matching is case-sensitive and tags may contain spaces. Add and edit actions use a private Firefox prompt.',
            className: 'hltv-sp-tag-filter-setting',
        });
        userTagsCheckbox.addEventListener('change', () => syncUserTagSettingsControls(form));

        const usernameBlockingLabel = document.createElement('label');
        const usernameBlockingCheckbox = document.createElement('input');
        usernameBlockingCheckbox.id = 'hltv-sp-username-blocking';
        usernameBlockingCheckbox.type = 'checkbox';
        const usernameBlockingText = document.createElement('span');
        usernameBlockingText.textContent = 'Enable right-click username actions';
        usernameBlockingLabel.append(usernameBlockingCheckbox, usernameBlockingText);
        const usernameBlockingSetting = createSettingRow({
            primary: usernameBlockingLabel,
            helpId: 'hltv-sp-username-blocking-help',
            description: 'Right-click a linked HLTV username to open its profile in a new tab or block or unblock that account through HLTV. The extension checks the current profile state before offering the block action.',
        });

        const fullMapNamesLabel = document.createElement('label');
        const fullMapNamesCheckbox = document.createElement('input');
        fullMapNamesCheckbox.id = 'hltv-sp-full-map-names';
        fullMapNamesCheckbox.type = 'checkbox';
        const fullMapNamesText = document.createElement('span');
        fullMapNamesText.textContent = 'Show full map names on player match history pages';
        fullMapNamesLabel.append(fullMapNamesCheckbox, fullMapNamesText);
        const fullMapNamesRow = createSettingRow({
            primary: fullMapNamesLabel,
            helpId: 'hltv-sp-full-map-names-help',
            description: 'Replace HLTV map abbreviations such as d2, mrg, and anb with Dust2, Mirage, and Anubis on supported player match-history tables. Unknown codes remain unchanged.',
        });

        const createV2CheckboxSetting = ({
            id,
            label,
            description,
            secondary = [],
            helpBody = [],
        }) => {
            const settingLabel = document.createElement('label');
            const checkbox = document.createElement('input');
            checkbox.id = id;
            checkbox.type = 'checkbox';
            const text = document.createElement('span');
            text.textContent = label;
            settingLabel.append(checkbox, text);
            return {
                checkbox,
                row: createSettingRow({
                    primary: settingLabel,
                    secondary,
                    helpId: `${id}-help`,
                    description,
                    helpBody,
                }),
            };
        };
        const createMetricSelect = (id, options, ariaLabel) => {
            const select = document.createElement('select');
            select.id = id;
            select.setAttribute('aria-label', ariaLabel);
            for (const [value, label] of options) {
                const option = document.createElement('option');
                option.value = value;
                option.textContent = label;
                select.appendChild(option);
            }
            return select;
        };

        const createMatchPlayerMetricOptions = () => {
            const group = document.createElement('div');
            group.className = 'hltv-sp-match-player-metric-options';
            group.dataset.matchPlayerMetricOptions = 'true';
            group.setAttribute('role', 'group');
            group.setAttribute(
                'aria-label',
                'Statistics shown on match lineup player cards',
            );
            for (const [value, labelText] of MATCH_PLAYER_METRICS) {
                const label = document.createElement('label');
                label.className = 'hltv-sp-match-player-metric-option';
                const input = document.createElement('input');
                input.type = 'checkbox';
                input.value = value;
                input.dataset.matchPlayerMetric = value;
                label.append(input, document.createTextNode(labelText));
                group.appendChild(label);
            }
            group.addEventListener('change', (event) => {
                if (group.querySelector('input[data-match-player-metric]:checked')) return;
                if (event.target instanceof HTMLInputElement) event.target.checked = true;
            });
            return group;
        };

        const stickyMatchHeaderSetting = createV2CheckboxSetting({
            id: 'hltv-sp-sticky-match-header',
            label: 'Show a sticky match header while scrolling',
            description: 'Keep a compact match summary below HLTV\'s navigation after the normal header scrolls away. Scheduled, TBD, live, and finished matches are supported; live summaries update the series, map, round, and current score.',
        });
        const matchPlayerMetricOptions = createMatchPlayerMetricOptions();
        const matchPlayerFormSetting = createV2CheckboxSetting({
            id: 'hltv-sp-match-player-form-overlays',
            label: 'Show recent-form statistics on match lineups',
            description: 'Use Past 3 months values on each player image. Choose any combination of Rating, KPR, DPR, KAST, ADR, multi-kill, and Round Swing below; the same chooser is available from the Lineup stats button on supported match pages.',
            helpBody: [matchPlayerMetricOptions],
        });
        const matchPredictionSetting = createV2CheckboxSetting({
            id: 'hltv-sp-match-prediction',
            label: 'Show match result predictions',
            description: 'Estimate the likely winner before a match. Market + stats is the default and includes the detailed calculation breakdown. It blends market-derived map chances with opponent-adjusted map results at your selected market share (default 50%). Team ranking points are used only to adjust for opponent strength, never as a direct own-team baseline. If one component is unavailable, its single-source fallback is labeled explicitly. Stats only uses opponent-adjusted map results alone, ignores market odds and the saved market weight, and reports unavailable when statistics are missing; it never falls back to market odds. Each match document allows three prediction-source attempts plus all needed historical ranking weeks, up to 15 weekly ranking attempts. Weekly rankings are shared across tabs and restarts; missing historical ranking weeks are labeled explicitly. Market-estimated uses only the median of valid de-vigged bookmaker probabilities, never falls back to page statistics, and reports when odds are unavailable. Predictions are estimates, not betting advice.',
        });
        const predictionMode = createMetricSelect('hltv-sp-match-prediction-mode', [
            ['stats', 'Market + stats'],
            ['stats-only', 'Stats only'],
            ['market', 'Market-estimated'],
        ], 'Prediction mode');
        const predictionModeLabel = document.createElement('label');
        predictionModeLabel.textContent = 'Prediction mode ';
        predictionModeLabel.appendChild(predictionMode);
        const predictionPercentLabel = document.createElement('label');
        predictionPercentLabel.textContent = 'Market weight (%) ';
        const predictionPercent = document.createElement('input');
        predictionPercent.id = 'hltv-sp-prediction-market-percent';
        predictionPercent.type = 'number';
        predictionPercent.min = '0';
        predictionPercent.max = '100';
        predictionPercent.step = 'any';
        predictionPercentLabel.appendChild(predictionPercent);
        predictionMode.addEventListener('change', () => syncPredictionMarketControl(form));
        const predictionNote = document.createElement('p');
        predictionNote.className = 'hltv-sp-data-note';
        predictionNote.textContent = 'Market + stats combines the selected market percentage with opponent-adjusted map results. Stats only uses statistics alone without market input. Market-estimated always uses 100% market probability. The saved market weight applies only to Market + stats.';
        const predictionOptions = document.createElement('div');
        predictionOptions.className = 'hltv-sp-setting-body hltv-sp-options';
        predictionOptions.append(predictionModeLabel, predictionPercentLabel, predictionNote);
        matchPredictionSetting.row.insertBefore(
            predictionOptions,
            matchPredictionSetting.row.querySelector('.hltv-sp-setting-help'),
        );
        const teamPerformanceDifferenceSetting = createV2CheckboxSetting({
            id: 'hltv-sp-team-performance-difference',
            label: 'Show team Overperformance Score',
            description: 'Add a sortable OS column to team FTU tables. OS compares actual T-side round-win performance with an expectation dynamically fitted from CT opening-duel strength across the active filtered cohort. Scores are not comparable between different filter cohorts. It can offer a rough signal of IGL or team-system strength, but it does not isolate or prove an IGL\'s individual impact.',
        });
        const statsColumnChooserSetting = createV2CheckboxSetting({
            id: 'hltv-sp-stats-column-chooser',
            label: 'Enable stats-table column controls',
            description: 'Add a Columns control to player ranking and match-history tables. Every available column starts visible, including WAR, estimated ranking-table KPR, and exact match-history KPR. Selecting WAR reveals its calculation controls; each calculated column has an in-table explanation. Hidden columns and column order are stored separately for each table type.',
        });
        const statsMultiSortSetting = createV2CheckboxSetting({
            id: 'hltv-sp-stats-multi-sort',
            label: 'Enable multi-column sorting',
            description: 'Click a table header to replace the sort; Shift-click adds or changes a secondary sort. The full stable sort order persists across page loads.',
        });
        const statsCsvSetting = createV2CheckboxSetting({
            id: 'hltv-sp-stats-csv-export',
            label: 'Enable CSV export for stats tables',
            description: 'Export currently loaded rows, visible columns, extension columns, displayed column order, and current sort order. Spreadsheet-formula prefixes are escaped.',
        });
        const matchSparklineSetting = createV2CheckboxSetting({
            id: 'hltv-sp-player-match-sparklines',
            label: 'Show selectable player match-history trends',
            description: 'Plot any numeric statistic available in the loaded match-history table over the latest 100 maps, with locked labeled axes and a five-map rolling line. Point details appear immediately while a dot is hovered or focused, then disappear on pointer exit or blur.',
        });
        const extendedMatchHistorySetting = createV2CheckboxSetting({
            id: 'hltv-sp-extended-match-history-loading',
            label: 'Extend player match-history loading beyond 100 maps',
            description: 'Add a Rows to show selector beneath player match-history tables with 100, 200, 300, 400, 500, and ALL choices. Extra pages are fetched from the same filtered player history and the remembered choice is reused. Turning this off cancels loading, removes extension-fetched rows and the selector, and restores HLTV\'s native pager.',
        });
        const originalPosterHighlightSetting = createV2CheckboxSetting({
            id: 'hltv-sp-original-poster-highlight',
            label: 'Highlight posts by the original poster',
            description: 'Give the thread creator\'s username a blue background with white text on their original post and later replies, both on normal thread pages and in thread previews.',
        });
        const savedDraftsSetting = createV2CheckboxSetting({
            id: 'hltv-sp-enable-saved-drafts',
            label: 'Add saved-draft controls to forum composers',
            description: 'Add Save as draft and Restore saved draft controls to new-topic, thread-reply, and preview composers. Turning this off removes those composer controls without deleting saved records; the draft manager below remains available.',
        });

        const playerMapMatrixSetting = createV2CheckboxSetting({
            id: 'hltv-sp-player-map-matrix',
            label: 'Add a map-by-stat matrix to player pages',
            description: 'Add a Map matrix tab to player stats pages. It groups the current filtered match history by map and shows sortable Rating, KPR, DPR, K-D, and maps-played statistics.',
        });
        const comparisonEnhancementsSetting = createV2CheckboxSetting({
            id: 'hltv-sp-player-comparison-enhancements',
            label: 'Enhance player comparison pages',
            description: 'Add compact deltas, lead summaries, player-swap and filter-sync links, CSV export, and a full-width trend graph. The graph can show raw matches, a 10-map average, or a trailing daily mean over 1-365 days, plus an optional straight trend line. Hover or focus a point for its matchup, date, map, K-D, and selected value.',
        });
        const consistencyScoreSetting = createV2CheckboxSetting({
            id: 'hltv-sp-player-consistency-score',
            label: 'Show a player consistency score',
            description: 'Measure how much Rating varies across maps under the current player filters. At least 10 rated maps are required. Score = round(100 * max(0, 1 - SD / 1.00)); Rating SD 0 is 100, and Rating SD 1.00 or higher is 0. Scores of 60 or more are Good and green, 40-59 are Mixed, and scores below 40 are Poor and red.',
        });
        const previousPeriodMetricSelect = createMetricSelect(
            'hltv-sp-previous-period-metric',
            PREVIOUS_PERIOD_METRICS,
            'Date-period comparison statistic',
        );
        const statsTablePeriodSetting = createV2CheckboxSetting({
            id: 'hltv-sp-stats-table-period-comparison',
            label: 'Compare stats-table data with another date period',
            description: 'Add a persistent Baseline delta column to player ranking tables. The same feature can be enabled or removed from the table\'s Columns control. Baseline dates are stored in the page URL; specific-event filters disable comparison.',
            secondary: [previousPeriodMetricSelect],
        });
        const playerPagePeriodSetting = createV2CheckboxSetting({
            id: 'hltv-sp-player-page-period-comparison',
            label: 'Compare player-page statistics with another date period',
            description: 'Compare an individual player page\'s current native date range with selectable baseline dates. If no baseline is supplied, the immediately preceding equal-length period is used. This is independent of the ranking-table Baseline delta column.',
        });
        sidebarActivityOptions.append(
            movePostNewTopicSetting,
        );
        sidebarActivityFieldset.append(sidebarActivityLegend, sidebarActivityOptions);

        const matchFilterFieldset = document.createElement('fieldset');
        matchFilterFieldset.id = 'hltv-sp-match-filter-settings';
        const matchFilterLegend = document.createElement('legend');
        matchFilterLegend.textContent = 'Match filtering';
        const matchFilterOptions = document.createElement('div');
        matchFilterOptions.className = 'hltv-sp-options';
        matchFilterOptions.append(
            extendedMatchFilterSetting,
            strictSelectedTeamsSetting,
        );
        matchFilterFieldset.append(matchFilterLegend, matchFilterOptions);

        const threadPagesFieldset = document.createElement('fieldset');
        threadPagesFieldset.id = 'hltv-sp-thread-pages-settings';
        const threadPagesLegend = document.createElement('legend');
        threadPagesLegend.textContent = 'Thread pages & previews';
        const threadPagesOptions = document.createElement('div');
        threadPagesOptions.className = 'hltv-sp-options';
        threadPagesOptions.append(
            threadPreviewsSetting,
            readStatusSetting,
            relativeAgesSetting,
            replyComposerPlacementSetting,
            originalPosterHighlightSetting.row,
        );
        threadPagesFieldset.append(threadPagesLegend, threadPagesOptions);

        const userReactionFieldset = document.createElement('fieldset');
        userReactionFieldset.id = 'hltv-sp-user-reaction-settings';
        const userReactionLegend = document.createElement('legend');
        userReactionLegend.textContent = 'User tags & reactions';
        const userReactionOptions = document.createElement('div');
        userReactionOptions.className = 'hltv-sp-options';
        userReactionOptions.append(
            userTagsSetting,
            tagFilterSetting,
            localScoresSetting,
            localDownvotesSetting,
            signedOutLocalVotingSetting,
            greenUpvotesSetting,
        );
        userReactionFieldset.append(userReactionLegend, userReactionOptions);

        const userActionsFieldset = document.createElement('fieldset');
        userActionsFieldset.id = 'hltv-sp-user-actions-settings';
        const userActionsLegend = document.createElement('legend');
        userActionsLegend.textContent = 'User actions';
        const userActionsOptions = document.createElement('div');
        userActionsOptions.className = 'hltv-sp-options';
        userActionsOptions.append(usernameBlockingSetting);
        userActionsFieldset.append(userActionsLegend, userActionsOptions);

        const statsFieldset = document.createElement('fieldset');
        statsFieldset.id = 'hltv-sp-stats-settings';
        const statsLegend = document.createElement('legend');
        statsLegend.textContent = 'Stats pages & tables';
        const statsOptions = document.createElement('div');
        statsOptions.className = 'hltv-sp-options';
        statsOptions.append(
            fullMapNamesRow,
            statsColumnChooserSetting.row,
            statsMultiSortSetting.row,
            statsCsvSetting.row,
            extendedMatchHistorySetting.row,
            matchSparklineSetting.row,
            statsTablePeriodSetting.row,
            teamPerformanceDifferenceSetting.row,
        );
        statsFieldset.append(statsLegend, statsOptions);

        const matchPageFieldset = document.createElement('fieldset');
        matchPageFieldset.id = 'hltv-sp-match-page-settings';
        const matchPageLegend = document.createElement('legend');
        matchPageLegend.textContent = 'Match pages';
        const matchPageOptions = document.createElement('div');
        matchPageOptions.className = 'hltv-sp-options';
        matchPageOptions.append(
            stickyMatchHeaderSetting.row,
            matchPlayerFormSetting.row,
            matchPredictionSetting.row,
        );
        matchPageFieldset.append(matchPageLegend, matchPageOptions);

        const playerAnalyticsFieldset = document.createElement('fieldset');
        playerAnalyticsFieldset.id = 'hltv-sp-player-analytics-settings';
        const playerAnalyticsLegend = document.createElement('legend');
        playerAnalyticsLegend.textContent = 'Player analytics';
        const playerAnalyticsOptions = document.createElement('div');
        playerAnalyticsOptions.className = 'hltv-sp-options';
        playerAnalyticsOptions.append(
            playerMapMatrixSetting.row,
            comparisonEnhancementsSetting.row,
            consistencyScoreSetting.row,
            playerPagePeriodSetting.row,
        );
        playerAnalyticsFieldset.append(playerAnalyticsLegend, playerAnalyticsOptions);

        const savedDraftFieldset = document.createElement('fieldset');
        savedDraftFieldset.id = 'hltv-sp-saved-drafts';
        const savedDraftLegend = document.createElement('legend');
        savedDraftLegend.textContent = 'Saved drafts';
        const savedDraftManager = document.createElement('div');
        savedDraftManager.className = 'hltv-sp-saved-drafts-manager';
        const savedDraftSummary = document.createElement('p');
        savedDraftSummary.className = 'hltv-sp-saved-drafts-summary';
        const savedDraftEmpty = document.createElement('p');
        savedDraftEmpty.className = 'hltv-sp-saved-drafts-empty';
        const savedDraftList = document.createElement('ul');
        savedDraftList.className = 'hltv-sp-saved-drafts-list';
        const deleteAllDrafts = document.createElement('button');
        deleteAllDrafts.id = 'hltv-sp-delete-all-drafts';
        deleteAllDrafts.type = 'button';
        deleteAllDrafts.className = 'hltv-sp-setting-secondary-action';
        deleteAllDrafts.textContent = 'Delete all saved drafts';
        deleteAllDrafts.addEventListener('click', () => {
            const accountId = extractCurrentUserId();
            const confirmedEntries = savedDraftEntriesForAccount(accountId).map((entry) => ({
                key: entry.key,
                revision: entry.record.revision,
            }));
            const count = confirmedEntries.length;
            let confirmed = false;
            try {
                confirmed = count > 0 && safeConfirm?.(
                    `Delete all ${count} saved drafts for the signed-in HLTV account?`,
                ) === true;
            } catch {
                confirmed = false;
            }
            if (!confirmed) return;
            deleteAllDrafts.disabled = true;
            removeAllSavedDraftsForCurrentAccount(accountId, confirmedEntries)
                .then(({ removed, skipped }) => {
                    const preservedMessage = skipped > 0
                        ? ` ${skipped} ${skipped === 1 ? 'draft was' : 'drafts were'} changed or already removed and left untouched.`
                        : '';
                    setModalStatus(
                        `${removed} saved ${removed === 1 ? 'draft was' : 'drafts were'} deleted.`
                        + preservedMessage,
                    );
                    renderSavedDraftManager();
                    refreshAllSavedDraftUi();
                })
                .catch((error) => {
                    deleteAllDrafts.disabled = false;
                    setModalStatus(savedDraftPublicError(error));
                });
        });
        const savedDraftNote = document.createElement('p');
        savedDraftNote.className = 'hltv-sp-data-note';
        savedDraftNote.textContent = 'Draft text stays in extension-private storage and is shown only for the verified signed-in HLTV account. Open returns to the original destination; Restore never replaces a nonempty composer.';
        savedDraftManager.append(
            savedDraftSummary,
            savedDraftEmpty,
            savedDraftList,
            deleteAllDrafts,
            savedDraftNote,
        );
        savedDraftFieldset.append(
            savedDraftLegend,
            savedDraftsSetting.row,
            savedDraftManager,
        );

        const dataFieldset = document.createElement('fieldset');
        dataFieldset.id = 'hltv-sp-data-settings';
        const dataLegend = document.createElement('legend');
        dataLegend.textContent = 'Data & diagnostics';
        const dataOptions = document.createElement('div');
        dataOptions.className = 'hltv-sp-options';

        const diagnosticLabel = document.createElement('label');
        const diagnosticCheckbox = document.createElement('input');
        diagnosticCheckbox.id = 'hltv-sp-diagnostic-logging';
        diagnosticCheckbox.type = 'checkbox';
        const diagnosticText = document.createElement('span');
        diagnosticText.textContent = 'Enable local diagnostic logging';
        diagnosticLabel.append(diagnosticCheckbox, diagnosticText);
        const diagnosticSetting = createSettingRow({
            primary: diagnosticLabel,
            helpId: 'hltv-sp-diagnostic-logging-help',
            description: 'Off by default. Store a capped, redacted seven-day troubleshooting log in extension-private storage. It never records post or reply text, usernames, tags, cookies, credentials, raw HTML, response bodies, full URLs, or numeric profile/thread identifiers, and it never sends anything automatically. Turning this off stops new entries; use Clear to remove existing entries.',
        });

        const dataActions = document.createElement('div');
        dataActions.className = 'hltv-sp-data-actions';
        const makeDataAction = (id, text, handler) => {
            const button = document.createElement('button');
            button.id = id;
            button.type = 'button';
            button.className = 'hltv-sp-setting-secondary-action';
            button.textContent = text;
            button.addEventListener('click', () => handler(button));
            return button;
        };
        const makeImportControl = ({ id, inputId, text, format }) => {
            const input = document.createElement('input');
            input.id = inputId;
            input.type = 'file';
            input.accept = '.json,application/json';
            input.hidden = true;
            const button = makeDataAction(id, text, () => input.click());
            input.addEventListener('change', () => {
                importLocalDataOnSite(input, button, format).catch((error) => {
                    warn('Local import failed.', error);
                    input.value = '';
                    setModalStatus('The selected local file could not be imported.');
                });
            });
            return { button, input };
        };
        const settingsImport = makeImportControl({
            id: 'hltv-sp-import-settings',
            inputId: 'hltv-sp-import-settings-file',
            text: 'Import settings',
            format: 'hltv-enhancements-settings',
        });
        const userDataImport = makeImportControl({
            id: 'hltv-sp-import-user-data',
            inputId: 'hltv-sp-import-user-data-file',
            text: 'Import user data',
            format: 'hltv-enhancements-user-data',
        });
        const exportSettingsButton = makeDataAction(
            'hltv-sp-export-settings',
            'Export saved settings',
            exportSavedSettingsOnSite,
        );
        const exportUserDataButton = makeDataAction(
            'hltv-sp-export-user-data',
            'Export user data',
            exportUserDataOnSite,
        );
        const exportDebugButton = makeDataAction(
            'hltv-sp-export-debug-log',
            'Export debug log',
            exportDebugLogOnSite,
        );
        const clearDebugButton = makeDataAction(
            'hltv-sp-clear-debug-log',
            'Clear debug log',
            clearDebugLogOnSite,
        );
        const clearRankingsButton = makeDataAction(
            'hltv-sp-clear-cached-rankings',
            'Clear cached rankings',
            clearCachedRankingsOnSite,
        );
        clearRankingsButton.title = 'Remove downloaded weekly world rankings. Archived forecasts and saved settings are preserved.';
        clearRankingsButton.disabled = typeof globalThis.HLTV_SP_EXTENSION?.rankingCache?.clear !== 'function';
        dataActions.append(
            settingsImport.button,
            userDataImport.button,
            exportSettingsButton,
            exportUserDataButton,
            exportDebugButton,
            clearDebugButton,
            clearRankingsButton,
            settingsImport.input,
            userDataImport.input,
        );
        const dataNote = document.createElement('p');
        dataNote.className = 'hltv-sp-data-note';
        dataNote.textContent = 'Imports and exports stay local. Settings files replace recognised settings; user-data files merge by identity and keep the newer timestamp. User-data files can contain private tags and local reading and reaction history.';
        dataOptions.append(diagnosticSetting, dataActions, dataNote);
        dataFieldset.append(dataLegend, dataOptions);

        if (!hasPrivateStorage()) {
            diagnosticCheckbox.disabled = true;
            diagnosticLabel.title = 'The packaged Firefox extension is required for diagnostic logging.';
            userDataImport.button.disabled = true;
            exportUserDataButton.disabled = true;
            exportDebugButton.disabled = true;
            clearDebugButton.disabled = true;
        }

        const settingsFooter = document.createElement('footer');
        settingsFooter.className = 'hltv-sp-settings-footer';
        const feedbackLink = document.createElement('a');
        feedbackLink.id = 'hltv-sp-feedback-link';
        feedbackLink.className = 'hltv-sp-feedback-link';
        feedbackLink.setAttribute('href', FEEDBACK_MAILTO);
        feedbackLink.textContent = 'Report a bug or submit feedback';
        settingsFooter.appendChild(feedbackLink);

        const actions = document.createElement('div');
        actions.className = 'hltv-sp-actions';

        const cancelButton = document.createElement('button');
        cancelButton.type = 'button';
        cancelButton.textContent = 'Cancel';
        cancelButton.addEventListener('click', closeSettingsModal);

        const saveButton = document.createElement('button');
        saveButton.type = 'submit';
        saveButton.textContent = 'Save';

        const status = document.createElement('div');
        status.id = 'hltv-sp-status';
        status.setAttribute('aria-live', 'polite');
        actions.append(status, cancelButton, saveButton);

        form.append(
            actions,
            extensionFieldset,
            forumFieldset,
            layoutFieldset,
            sidebarActivityFieldset,
            matchFilterFieldset,
            matchPageFieldset,
            threadPagesFieldset,
            userReactionFieldset,
            userActionsFieldset,
            statsFieldset,
            playerAnalyticsFieldset,
            savedDraftFieldset,
            dataFieldset,
            settingsFooter,
        );
        modal.append(closeButton, title, form);
        backdrop.appendChild(modal);
        modalRoot.appendChild(backdrop);
        document.body.appendChild(modalHost);

        state.modalHost = modalHost;
        state.modalBackdrop = backdrop;
        state.statusElement = status;

        document.addEventListener('keydown', (event) => {
            if (event.key === 'Escape' && state.modalBackdrop?.classList.contains('hltv-sp-open')) {
                closeSettingsModal();
            }
        });
    }

    function openSettingsModal() {
        if (!hasCompleteSettingsModal()) {
            state.modalHost?.remove();
            document.querySelector('.hltv-sp-settings-host')?.remove();
            state.modalHost = null;
            state.modalBackdrop = null;
            state.statusElement = null;
            createSettingsModal();
        }
        state.modalSettingsDirty = false;
        state.modalSettingsExternalChange = false;
        refreshSettingsModal();
        state.modalBackdrop?.classList.add('hltv-sp-open');
    }

    function closeSettingsModal() {
        const form = state.modalBackdrop?.querySelector('#hltv-sp-form');
        for (const info of form?.querySelectorAll(
            '.hltv-sp-setting-info[aria-expanded="true"]',
        ) || []) {
            const helpId = info.getAttribute('aria-controls');
            const help = helpId
                ? [...form.querySelectorAll('.hltv-sp-setting-help')]
                    .find((candidate) => candidate.id === helpId)
                : null;
            if (help) help.hidden = true;
            info.setAttribute('aria-expanded', 'false');
            const settingName = cleanText(info.closest('.hltv-sp-setting-row')
                ?.querySelector('label')?.textContent) || 'this setting';
            info.title = `Show details for ${settingName}`;
            info.setAttribute('aria-label', `Show details for ${settingName}`);
        }
        state.modalBackdrop?.classList.remove('hltv-sp-open');
        state.modalSettingsDirty = false;
        state.modalSettingsExternalChange = false;
        setModalStatus('');
    }

    function refreshSettingsModal() {
        const form = state.modalBackdrop?.querySelector('#hltv-sp-form');
        if (!form) return;

        form.querySelector('#hltv-sp-extension-disabled').checked = state.settings.extensionDisabled;
        form.querySelector('#hltv-sp-match-prediction-mode').value = state.settings.matchPredictionMode;
        form.querySelector('#hltv-sp-prediction-market-percent').value = String(state.settings.predictionMarketPercent);
        state.modalSettingsSnapshot = {
            extensionDisabled: state.settings.extensionDisabled,
            matchPredictionMode: state.settings.matchPredictionMode,
            predictionMarketPercent: state.settings.predictionMarketPercent,
        };
        syncPredictionMarketControl(form);

        const selected = new Set(state.settings.selectedForums);
        form.querySelector('#hltv-sp-custom-thread-fetching').checked = (
            state.settings.enableCustomThreadFetching
        );
        form.querySelector('#hltv-sp-custom-thread-colors').checked = (
            state.settings.enableCustomThreadColors
        );
        for (const checkbox of form.querySelectorAll('input[name="selectedForums"]')) {
            checkbox.checked = selected.has(checkbox.value);
        }
        for (const source of ACTIVITY_SOURCES) {
            const input = form.elements.namedItem(`forumLimit:${source.id}`);
            if (input) input.value = String(state.settings.forumThreadLimits[source.id]);
            const colorInput = form.elements.namedItem(`sourceColor:${source.id}`);
            if (colorInput) {
                colorInput.value = activitySourceColor(source.id);
                colorInput.closest('.hltv-sp-forum-limit-row')?.style.setProperty(
                    '--hltv-sp-forum-color',
                    colorInput.value,
                );
            }
        }

        form.querySelector('#hltv-sp-green-upvotes').checked = state.settings.changeUpvoteStyle;
        form.querySelector('#hltv-sp-relative-ages').checked = state.settings.showRelativeAges;
        form.querySelector('#hltv-sp-thread-previews').checked = state.settings.enableThreadPreviews;
        form.querySelector('#hltv-sp-original-poster-highlight').checked = (
            state.settings.enableOriginalPosterHighlight
        );
        form.querySelector('#hltv-sp-read-status').checked = state.settings.enableReadStatus;
        form.querySelector('#hltv-sp-reply-composer-after-op').checked = (
            state.settings.replyComposerAfterOriginalPost
        );
        form.querySelector('#hltv-sp-enable-saved-drafts').checked = (
            state.settings.enableSavedDrafts
        );
        form.querySelector('#hltv-sp-layout-width').value = state.settings.layoutWidthPreset;
        form.querySelector('#hltv-sp-large-sidebar-text').checked = state.settings.largeSidebarText;
        form.querySelector('#hltv-sp-user-tags').checked = state.settings.enableUserTags;
        form.querySelector('#hltv-sp-local-user-scores').checked = state.settings.enableLocalUserScores;
        form.querySelector('#hltv-sp-local-downvotes').checked = state.settings.enableLocalDownvotes;
        form.querySelector('#hltv-sp-username-blocking').checked = state.settings.enableUsernameBlocking;
        form.querySelector('#hltv-sp-signed-out-local-voting').checked = (
            state.settings.enableSignedOutLocalVoting
        );
        form.querySelector('#hltv-sp-extended-match-filter').checked = (
            state.settings.enableExtendedMatchFilter
        );
        form.querySelector('#hltv-sp-strict-selected-teams').checked = (
            state.settings.strictSelectedTeamMatches
        );
        form.querySelector('#hltv-sp-move-post-new-topic').checked = (
            state.settings.movePostNewTopicToTop
        );
        renderHiddenUserTagEditor(
            form.querySelector('#hltv-sp-hidden-user-tags'),
            state.settings.hiddenUserTags,
        );
        form.querySelector('#hltv-sp-full-map-names').checked = (
            state.settings.showFullMapNames
        );
        form.querySelector('#hltv-sp-diagnostic-logging').checked = (
            state.settings.enableDiagnosticLogging
        );
        form.querySelector('#hltv-sp-sticky-match-header').checked = (
            state.settings.enableStickyMatchHeader
        );
        form.querySelector('#hltv-sp-match-player-form-overlays').checked = (
            state.settings.enableMatchPlayerFormOverlays
        );
        form.querySelector('#hltv-sp-match-prediction').checked = (
            state.settings.enableMatchPrediction
        );
        form.querySelector('#hltv-sp-team-performance-difference').checked = (
            state.settings.enableTeamPerformanceDifference
        );
        const selectedMatchMetrics = new Set(state.settings.matchPlayerPrimaryMetrics);
        for (const input of form.querySelectorAll(
            '[data-match-player-metric-options] input[data-match-player-metric]',
        )) {
            input.checked = selectedMatchMetrics.has(input.value);
        }
        form.querySelector('#hltv-sp-stats-column-chooser').checked = (
            state.settings.enableStatsColumnChooser
        );
        form.querySelector('#hltv-sp-stats-multi-sort').checked = (
            state.settings.enableStatsMultiSort
        );
        form.querySelector('#hltv-sp-stats-csv-export').checked = (
            state.settings.enableStatsCsvExport
        );
        form.querySelector('#hltv-sp-player-match-sparklines').checked = (
            state.settings.enablePlayerMatchSparklines
        );
        form.querySelector('#hltv-sp-extended-match-history-loading').checked = (
            state.settings.enableExtendedMatchHistoryLoading
        );
        form.querySelector('#hltv-sp-player-map-matrix').checked = (
            state.settings.enablePlayerMapMatrix
        );
        form.querySelector('#hltv-sp-player-comparison-enhancements').checked = (
            state.settings.enablePlayerComparisonEnhancements
        );
        form.querySelector('#hltv-sp-player-consistency-score').checked = (
            state.settings.enablePlayerConsistencyScore
        );
        form.querySelector('#hltv-sp-stats-table-period-comparison').checked = (
            state.settings.enableStatsTablePeriodComparison
        );
        form.querySelector('#hltv-sp-player-page-period-comparison').checked = (
            state.settings.enablePlayerPagePeriodComparison
        );
        const previousPeriodSelect = form.querySelector('#hltv-sp-previous-period-metric');
        previousPeriodSelect.querySelector('option[data-hltv-sp-page-selected]')?.remove();
        const previousPeriodMetric = normalisePreviousPeriodMetric(
            state.settings.previousPeriodMetric,
        );
        if (![...previousPeriodSelect.options].some((option) => (
            option.value === previousPeriodMetric
        ))) {
            const pageSelected = document.createElement('option');
            pageSelected.value = previousPeriodMetric;
            pageSelected.textContent = `Page-selected: ${previousPeriodMetric}`;
            pageSelected.dataset.hltvSpPageSelected = 'true';
            previousPeriodSelect.appendChild(pageSelected);
        }
        previousPeriodSelect.value = previousPeriodMetric;
        syncForumSourceSettingsControls(form);
        syncUserTagSettingsControls(form);
        renderSavedDraftManager();
        setModalStatus('');
    }

    function syncPredictionMarketControl(form) {
        form.querySelector('#hltv-sp-prediction-market-percent').disabled = (
            form.querySelector('#hltv-sp-match-prediction-mode').value !== 'stats'
        );
    }

    function syncForumSourceSettingsControls(
        form = state.modalBackdrop?.querySelector('#hltv-sp-form'),
    ) {
        if (!form) return;
        const fetchEnabled = Boolean(
            form.querySelector('#hltv-sp-custom-thread-fetching')?.checked,
        );
        const colorsEnabled = Boolean(
            form.querySelector('#hltv-sp-custom-thread-colors')?.checked,
        );
        for (const input of form.querySelectorAll('input[name^="forumLimit:"]')) {
            input.disabled = !fetchEnabled;
        }
        for (const input of form.querySelectorAll('input[name^="sourceColor:"]')) {
            input.disabled = !colorsEnabled;
        }
        const reset = form.querySelector('.hltv-sp-source-color-reset');
        if (reset) reset.disabled = !colorsEnabled;
        const note = form.querySelector('.hltv-sp-source-color-note');
        if (note) note.dataset.disabled = colorsEnabled ? 'false' : 'true';
    }

    function syncUserTagSettingsControls(form = state.modalBackdrop?.querySelector('#hltv-sp-form')) {
        if (!form) return;
        const enabled = Boolean(form.querySelector('#hltv-sp-user-tags')?.checked);
        const filterEditor = form.querySelector('#hltv-sp-hidden-user-tags');
        if (filterEditor) {
            filterEditor.dataset.disabled = enabled ? 'false' : 'true';
            for (const button of filterEditor.querySelectorAll('button')) {
                button.disabled = !enabled;
            }
        }
    }

    function setModalStatus(message) {
        if (state.statusElement) {
            state.statusElement.textContent = message;
        }
    }

    async function handleSettingsSubmit(event) {
        event.preventDefault();

        const form = event.currentTarget;
        if (state.modalSettingsSaving) return;
        if (state.modalSettingsExternalChange) {
            setModalStatus('Settings changed elsewhere while this form was open. Cancel and reopen it before saving.');
            return;
        }
        const saveButton = form.querySelector('button[type="submit"]');
        const selectedForums = [...form.querySelectorAll('input[name="selectedForums"]:checked')]
            .map((checkbox) => checkbox.value)
            .filter((sourceId) => activitySourceById.has(sourceId));
        const forumThreadLimits = Object.fromEntries(ACTIVITY_SOURCES.map((source) => [
            source.id,
            clampInteger(
                form.elements.namedItem(`forumLimit:${source.id}`)?.value,
                1,
                CONFIG.maxThreadsPerForum,
                state.settings.forumThreadLimits[source.id],
            ),
        ]));
        const activitySourceColors = Object.fromEntries(ACTIVITY_SOURCES.map((source) => [
            source.id,
            normaliseActivitySourceColor(
                form.elements.namedItem(`sourceColor:${source.id}`)?.value,
                DEFAULT_ACTIVITY_SOURCE_COLORS[source.id],
            ),
        ]));

        const matchPlayerPrimaryMetrics = normaliseMatchPlayerMetrics(
            [...form.querySelectorAll(
                '[data-match-player-metric-options] input[data-match-player-metric]:checked',
            )].map((input) => input.value),
        );
        const [
            matchPlayerPrimaryMetric1,
            matchPlayerPrimaryMetric2,
        ] = legacyMatchPlayerMetricPair(matchPlayerPrimaryMetrics);

        const nextSettings = {
            ...state.settings,
            extensionDisabled: form.querySelector('#hltv-sp-extension-disabled').checked,
            matchPredictionMode: normaliseMatchPredictionMode(form.querySelector('#hltv-sp-match-prediction-mode').value),
            predictionMarketPercent: normalisePredictionMarketPercent(
                Number(form.querySelector('#hltv-sp-prediction-market-percent').value || NaN),
            ),
            selectedForums,
            forumThreadLimits,
            activitySourceColors,
            enableCustomThreadFetching: form.querySelector(
                '#hltv-sp-custom-thread-fetching',
            ).checked,
            enableCustomThreadColors: form.querySelector(
                '#hltv-sp-custom-thread-colors',
            ).checked,
            changeUpvoteStyle: form.querySelector('#hltv-sp-green-upvotes').checked,
            showRelativeAges: form.querySelector('#hltv-sp-relative-ages').checked,
            enableThreadPreviews: form.querySelector('#hltv-sp-thread-previews').checked,
            enableOriginalPosterHighlight: form.querySelector(
                '#hltv-sp-original-poster-highlight',
            ).checked,
            enableReadStatus: form.querySelector('#hltv-sp-read-status').checked,
            replyComposerAfterOriginalPost: form.querySelector(
                '#hltv-sp-reply-composer-after-op',
            ).checked,
            enableSavedDrafts: form.querySelector('#hltv-sp-enable-saved-drafts').checked,
            layoutWidthPreset: normaliseLayoutWidthPreset(form.querySelector('#hltv-sp-layout-width').value),
            largeSidebarText: form.querySelector('#hltv-sp-large-sidebar-text').checked,
            enableUserTags: form.querySelector('#hltv-sp-user-tags').checked,
            enableLocalUserScores: form.querySelector('#hltv-sp-local-user-scores').checked,
            enableLocalDownvotes: form.querySelector('#hltv-sp-local-downvotes').checked,
            enableUsernameBlocking: form.querySelector('#hltv-sp-username-blocking').checked,
            enableSignedOutLocalVoting: form.querySelector(
                '#hltv-sp-signed-out-local-voting',
            ).checked,
            enableExtendedMatchFilter: form.querySelector(
                '#hltv-sp-extended-match-filter',
            ).checked,
            strictSelectedTeamMatches: form.querySelector(
                '#hltv-sp-strict-selected-teams',
            ).checked,
            movePostNewTopicToTop: form.querySelector(
                '#hltv-sp-move-post-new-topic',
            ).checked,
            hiddenUserTags: hiddenUserTagEditorValues(
                form.querySelector('#hltv-sp-hidden-user-tags'),
            ),
            enableWinAdjustedRatings: form.querySelector(
                '#hltv-sp-stats-column-chooser',
            ).checked && state.settings.statsOptionalColumnsV2.ranking.includes('war'),
            showFullMapNames: form.querySelector('#hltv-sp-full-map-names').checked,
            enableDiagnosticLogging: form.querySelector(
                '#hltv-sp-diagnostic-logging',
            ).checked,
            enableStickyMatchHeader: form.querySelector(
                '#hltv-sp-sticky-match-header',
            ).checked,
            enableMatchPlayerFormOverlays: form.querySelector(
                '#hltv-sp-match-player-form-overlays',
            ).checked,
            enableMatchPrediction: form.querySelector('#hltv-sp-match-prediction').checked,
            enableTeamPerformanceDifference: form.querySelector(
                '#hltv-sp-team-performance-difference',
            ).checked,
            matchPlayerPrimaryMetrics,
            matchPlayerPrimaryMetric1,
            matchPlayerPrimaryMetric2,
            enableStatsColumnChooser: form.querySelector(
                '#hltv-sp-stats-column-chooser',
            ).checked,
            enableStatsMultiSort: form.querySelector('#hltv-sp-stats-multi-sort').checked,
            enableStatsCsvExport: form.querySelector('#hltv-sp-stats-csv-export').checked,
            enablePlayerMatchSparklines: form.querySelector(
                '#hltv-sp-player-match-sparklines',
            ).checked,
            enableExtendedMatchHistoryLoading: form.querySelector(
                '#hltv-sp-extended-match-history-loading',
            ).checked,
            enablePlayerMapMatrix: form.querySelector('#hltv-sp-player-map-matrix').checked,
            enablePlayerComparisonEnhancements: form.querySelector(
                '#hltv-sp-player-comparison-enhancements',
            ).checked,
            enablePlayerConsistencyScore: form.querySelector(
                '#hltv-sp-player-consistency-score',
            ).checked,
            enableStatsTablePeriodComparison: form.querySelector(
                '#hltv-sp-stats-table-period-comparison',
            ).checked,
            enablePlayerPagePeriodComparison: form.querySelector(
                '#hltv-sp-player-page-period-comparison',
            ).checked,
            previousPeriodMetric: normalisePreviousPeriodMetric(
                form.querySelector('#hltv-sp-previous-period-metric').value,
            ),
        };

        if (saveButton) saveButton.disabled = true;
        state.modalSettingsSaving = true;
        setModalStatus('Saving\u2026');

        try {
            // These choices may have changed through the toolbar since this tab
            // loaded. Preserve fresh stored values unless this form changed them.
            const snapshot = state.modalSettingsSnapshot || {};
            const [disabled, mode, percent] = await Promise.all([
                storageGet('extensionDisabled', DEFAULT_SETTINGS.extensionDisabled),
                storageGet('matchPredictionMode', DEFAULT_SETTINGS.matchPredictionMode),
                storageGet('predictionMarketPercent', DEFAULT_SETTINGS.predictionMarketPercent),
            ]);
            const fresh = {
                extensionDisabled: disabled === true,
                matchPredictionMode: normaliseMatchPredictionMode(mode),
                predictionMarketPercent: normalisePredictionMarketPercent(percent),
            };
            for (const key of Object.keys(fresh)) {
                if (nextSettings[key] === snapshot[key]) nextSettings[key] = fresh[key];
            }
            const previousSettings = state.settings;
            await saveSettings(nextSettings);
            state.settings = nextSettings;

            applyBooleanEnhancements();
            const moduleSettingsChanged = previousSettings.enableWinAdjustedRatings
                !== nextSettings.enableWinAdjustedRatings
                || previousSettings.showFullMapNames !== nextSettings.showFullMapNames;
            const moduleSync = moduleSettingsChanged
                ? syncOptionalModules()
                : { winOk: true, kprOk: true };
            const moduleWarning = (!moduleSync.winOk || !moduleSync.kprOk) ? ' Some stats module setup failed; see console.' : '';

            state.modalSettingsDirty = false;
            state.modalSettingsExternalChange = false;
            refreshSettingsModal();
            setModalStatus(featureRuntimeEnabled
                ? `Saved. Manually reload open HLTV tabs to apply changes to Disable HLTV Enhancements. Other settings update automatically.${moduleWarning}`
                : 'Saved. Manually reload open HLTV tabs to apply changes. Enhancements remain paused in this tab until reload.');

            const selectedForumsChanged = previousSettings.selectedForums.length !== nextSettings.selectedForums.length
                || previousSettings.selectedForums.some((forumId, index) => forumId !== nextSettings.selectedForums[index]);
            const limitsChanged = ACTIVITY_SOURCES.some((source) => (
                previousSettings.forumThreadLimits[source.id] !== nextSettings.forumThreadLimits[source.id]
            ));
            const fetchingChanged = previousSettings.enableCustomThreadFetching
                !== nextSettings.enableCustomThreadFetching;

            if (state.sidebar && (selectedForumsChanged || limitsChanged || fetchingChanged)) {
                refreshFetchedForumThreadsInBackground();
            }
        } catch (error) {
            warn('Settings save failed.', error);
            setModalStatus('Save failed. See console.');
        } finally {
            state.modalSettingsSaving = false;
            if (saveButton) saveButton.disabled = false;
        }
    }

    function refreshFetchedForumThreadsInBackground() {
        refreshFetchedForumThreads()
            .then((result) => {
                if (result.failedCount > 0) {
                    warn(`${result.failedCount} selected activity-source fetch failed after settings save.`);
                    if (state.modalBackdrop?.classList.contains('hltv-sp-open')) {
                        setModalStatus(`Saved. ${result.failedCount} activity-source fetch failed.`);
                    }
                }
            })
            .catch((error) => {
                warn('Forum sidebar refresh after settings save failed.', error);
                if (state.modalBackdrop?.classList.contains('hltv-sp-open')) {
                    setModalStatus('Saved. Sidebar refresh failed; see console.');
                }
            });
    }

    function applyBooleanEnhancements() {
        if (!featureRuntimeEnabled) return;
        if (!document.body) return;

        document.body.classList.remove(
            'hltv-sp-hide-news-matches',
            'hltv-sp-hide-matches',
            'hltv-sp-hide-news',
        );
        document.body.classList.toggle('hltv-sp-green-upvotes', Boolean(state.settings.changeUpvoteStyle));
        document.body.classList.toggle('hltv-sp-hide-relative-ages', !state.settings.showRelativeAges);
        document.body.classList.toggle('hltv-sp-large-sidebar-text', Boolean(state.settings.largeSidebarText));
        if (applyLayoutWidthSetting()) cancelLayoutWidthStartupRetries();
        else scheduleLayoutWidthStartupRetries();
        applyThreadPreviewSetting();
        applyOriginalPosterHighlightSetting();
        applyReadStatusSetting();
        applyReplyComposerPlacement();
        applySavedDraftSetting();
        applyUserTagSetting();
        applyLocalScoreSetting();
        applyUsernameBlockingSetting();
        applyPostNewTopicPlacement();
        applyExtendedMatchFilterSetting();
        if (!state.settings.enableCustomThreadFetching) removeFetchedActivityRows();
        if (!state.settings.enableCustomThreadColors) removeCustomActivityColors(document);
        annotateActivityColorsInRoot(document);
        syncPreviewActivityColors();
        applyForumVisibilityInRoot(document);
        syncRelativeAgeTimer({ updateNow: state.settings.showRelativeAges });
    }

    function applyThreadPreviewSetting() {
        for (const link of document.querySelectorAll('.activitylist a[href*="/forums/threads/"]')) {
            ensurePreviewHover(link);
        }
        scanNotificationPreviewTargets(document);
        if (state.settings.enableThreadPreviews) {
            createThreadPreviewPopup();
        } else {
            closeThreadPreview({ force: true });
            state.previewPanel?.remove();
            state.previewPanel = null;
        }
    }

    function applyReadStatusSetting() {
        if (state.settings.enableReadStatus) {
            setupCurrentThreadReadTracking();
            if (state.previewData && state.previewCommentTopology) {
                syncPreviewCommentNavigation(state.previewData, state.previewCommentTopology);
            }
            if (state.sidebar) annotateActivityLinks();
            schedulePreviewReadDwell(state.previewReadCandidate);
            return;
        }

        cancelPreviewReadDwell();
        window.clearTimeout(state.readSaveTimer);
        if (state.readVisibilityHandler) {
            document.removeEventListener('visibilitychange', state.readVisibilityHandler);
            state.readVisibilityHandler = null;
        }
        state.readTrackingKey = '';
        state.readTrackingPostCount = -1;
        for (const jump of document.querySelectorAll('.hltv-sp-first-unread-jump')) {
            jump.remove();
        }
        for (const element of document.querySelectorAll('.hltv-sp-first-unread')) {
            element.classList.remove('hltv-sp-first-unread');
        }
        for (const badge of document.querySelectorAll('.hltv-sp-read-badge')) badge.remove();
    }

    function findMainReplyForum() {
        if (/^\/news\/\d+(?:\/|$)/i.test(location.pathname)) {
            return document.querySelector(
                '.news-comments-wrapper > .forum[data-forum-thread-id]',
            );
        }
        if (/^\/matches\/\d+(?:\/|$)/i.test(location.pathname)) {
            return document.querySelector(
                '.match-comments > .forum[data-forum-thread-id]',
            );
        }
        if (/^\/forums\/threads\/\d+(?:\/|$)/i.test(location.pathname)
            && document.querySelector('.forumthread > .standard-box')) {
            return [...document.querySelectorAll('.forum[data-forum-thread-id]')]
                .find((forum) => !forum.closest('.fragment-comments-container')) || null;
        }
        return null;
    }

    function findNativeThreadReplyComposer() {
        const replyForum = findMainReplyForum();
        return replyForum?.querySelector(
            ':scope > .newreply-con.hltv-sp-relocated-reply-composer, '
            + ':scope > .newreply-con:not(.newReplyBox)',
        ) || null;
    }

    function restoreNativeThreadReplyComposer(composer) {
        if (!(composer instanceof Element)) return;
        const placeholder = state.nativeReplyComposerPlaceholder;
        if (placeholder?.isConnected) {
            placeholder.replaceWith(composer);
        } else {
            const replyForum = state.nativeReplyComposerOriginForum?.isConnected
                ? state.nativeReplyComposerOriginForum
                : composer.closest('.forum[data-forum-thread-id]');
            const threadedComposer = replyForum?.querySelector(
                ':scope > .newreply-con.newReplyBox',
            );
            if (threadedComposer) replyForum.insertBefore(composer, threadedComposer);
            else replyForum?.appendChild(composer);
        }
        state.nativeReplyComposerPlaceholder = null;
        state.nativeReplyComposerOriginForum = null;
        composer.classList.remove('hltv-sp-relocated-reply-composer');
    }

    function applyReplyComposerPlacement() {
        const composer = findNativeThreadReplyComposer();
        if (composer) {
            if (state.settings.replyComposerAfterOriginalPost) {
                const replyForum = findMainReplyForum();
                if (replyForum && composer.parentElement === replyForum) {
                    if (!state.nativeReplyComposerPlaceholder?.isConnected
                        && !composer.classList.contains('hltv-sp-relocated-reply-composer')) {
                        const placeholder = document.createComment(
                            'HLTV Enhancements reply composer origin',
                        );
                        composer.before(placeholder);
                        state.nativeReplyComposerPlaceholder = placeholder;
                        state.nativeReplyComposerOriginForum = replyForum;
                    }
                    const firstComment = replyForum.querySelector(':scope > .post');
                    if (firstComment && firstComment.previousElementSibling !== composer) {
                        replyForum.insertBefore(composer, firstComment);
                    } else if (!firstComment && replyForum.firstElementChild !== composer) {
                        replyForum.insertBefore(composer, replyForum.firstElementChild);
                    }
                    composer.classList.add('hltv-sp-relocated-reply-composer');
                }
            } else if (composer.classList.contains('hltv-sp-relocated-reply-composer')) {
                restoreNativeThreadReplyComposer(composer);
            }
        }

        const previewComposer = state.previewPanel?.querySelector(
            '.hltv-sp-preview-composer[data-hltv-sp-reply-id=""]',
        );
        if (previewComposer) placePreviewThreadComposer(previewComposer);
    }

    function findPostNewTopicButton() {
        return [...document.querySelectorAll(
            'a.button.colbutton.no-promode[href="/forums/create-thread"], '
            + 'a.button.colbutton.no-promode[href^="https://www.hltv.org/forums/create-thread"]',
        )].find((link) => parseSameOriginUrl(link.href)?.pathname === '/forums/create-thread')
            || null;
    }

    function applyPostNewTopicPlacement() {
        const button = findPostNewTopicButton();
        if (!button) return;
        const sidebarContainer = (state.sidebar || getSidebar())?.closest('.col-box-con')
            || document.querySelector('.right2Col > .col-box-con');

        if (state.settings.movePostNewTopicToTop && sidebarContainer?.parentElement) {
            if (!state.postNewTopicPlaceholder?.isConnected
                && !button.classList.contains('hltv-sp-post-new-topic-top')) {
                const placeholder = document.createComment(
                    'HLTV Enhancements Post new topic origin',
                );
                button.before(placeholder);
                state.postNewTopicPlaceholder = placeholder;
            }
            if (button.nextSibling !== sidebarContainer) {
                sidebarContainer.parentElement.insertBefore(button, sidebarContainer);
            }
            button.classList.add('hltv-sp-post-new-topic-top');
            return;
        }

        if (button.classList.contains('hltv-sp-post-new-topic-top')) {
            if (state.postNewTopicPlaceholder?.isConnected) {
                state.postNewTopicPlaceholder.before(button);
                state.postNewTopicPlaceholder.remove();
            } else if (sidebarContainer?.parentElement) {
                sidebarContainer.after(button);
            }
            state.postNewTopicPlaceholder = null;
            button.classList.remove('hltv-sp-post-new-topic-top');
        }
    }

    function nativeSelectedMatchTeams() {
        const teams = new Map();
        for (const row of document.querySelectorAll(
            '.match-filter-configuration .match-filter-team:not(.hltv-sp-extended-match-team)',
        )) {
            const logo = row.querySelector('.match-filter-team-logo[src]');
            const logoUrl = parseSameOriginUrl(logo?.getAttribute('src'));
            const id = logoUrl?.pathname.match(/^\/teamlogo\/(\d{1,20})\/?$/i)?.[1] || '';
            const name = cleanText(
                row.querySelector('.match-filter-team-name-placeholder')?.textContent,
            ).slice(0, CONFIG.maxTeamNameChars);
            if (id && name && !teams.has(id)) teams.set(id, { id, name });
        }
        return teams;
    }

    function nativeMatchFilterControlIsVisible(control) {
        if (!(control instanceof Element)
            || control.hidden
            || control.getAttribute('aria-hidden') === 'true') return false;
        const style = control.ownerDocument?.defaultView?.getComputedStyle(control);
        return style?.display !== 'none'
            && style?.visibility !== 'hidden'
            && style?.visibility !== 'collapse';
    }

    function nativeMatchFilterIsEnabled() {
        const heading = document.querySelector('h1.todaysMatches');
        const selectedStar = heading?.querySelector('.hotmatch-star-selected') || null;
        const unselectedStar = heading?.querySelector('.hotmatch-star-unselected') || null;
        if (selectedStar && unselectedStar) {
            const selectedVisible = nativeMatchFilterControlIsVisible(selectedStar);
            const unselectedVisible = nativeMatchFilterControlIsVisible(unselectedStar);
            // This page-local control is canonical.  Anything except the exact
            // native ON state is treated as OFF while HLTV changes the DOM.
            return selectedVisible && !unselectedVisible;
        }

        const enabledToggleSelected = Boolean(document.querySelector(
            '.toploginbar-match-filter-enabled.selected',
        ));
        const disabledToggleSelected = Boolean(document.querySelector(
            '.toploginbar-match-filter-disabled.selected',
        ));
        return enabledToggleSelected && !disabledToggleSelected;
    }

    function setExtendedMatchFilterStatus(message) {
        const status = document.querySelector('.hltv-sp-extended-match-filter-status');
        if (status) status.textContent = cleanText(message).slice(0, 240);
    }

    function nativeMatchTeamSearchInput(configuration = document) {
        return configuration?.querySelector(
            'input.match-filter-team-search[data-url^="/searchTeam"]',
        ) || null;
    }

    function nativeMatchTeamContainer(search) {
        return search?.closest('.nav-popup-elm')
            || search?.closest('.match-filter-configuration')
            || null;
    }

    function extendedMatchTeamSearchMenu(search) {
        return search?.closest('.twitter-typeahead')?.querySelector('.tt-menu') || null;
    }

    function extendedMatchTeamSearchDataset(search, create = false) {
        const menu = extendedMatchTeamSearchMenu(search);
        if (!menu) return null;
        let dataset = menu.querySelector(':scope > .hltv-sp-extended-match-team-results');
        if (!dataset && create) {
            dataset = document.createElement('div');
            dataset.className = 'tt-dataset hltv-sp-extended-match-team-results';
            dataset.hidden = true;
            menu.appendChild(dataset);
        }
        return dataset;
    }

    function nativeMatchTeamSearchDataset(search) {
        return search?.closest('.twitter-typeahead')?.querySelector(
            '.tt-dataset-teamSearch',
        ) || null;
    }

    function nativeMatchTeamLimitValue(value) {
        return cleanText(value).toLocaleLowerCase() === (
            `Max ${CONFIG.nativeMatchTeamLimit} teams allowed`
        ).toLocaleLowerCase();
    }

    function suppressNativeMatchTeamLimitValue(search) {
        if (!(search instanceof HTMLInputElement)
            || !nativeMatchTeamLimitValue(search.value)) return false;
        if (!extendedMatchTeamSearchNativeValues.has(search)) {
            extendedMatchTeamSearchNativeValues.set(search, {
                value: search.value,
                queryChanged: false,
            });
        }
        // HLTV assigns this disabled-state notice through the input's value
        // property, so it does not appear in saved outerHTML. Once the extension
        // owns the capped picker, expose an empty field for the local search.
        search.value = '';
        return true;
    }

    function extendedMatchTeamSearchShouldOwn(search) {
        return Boolean(
            state.settings.enableExtendedMatchFilter
            && search?.isConnected
            && nativeSelectedMatchTeams().size >= CONFIG.nativeMatchTeamLimit,
        );
    }

    function releaseExtendedMatchTeamSearchOwnership(search = state.matchTeamSearchInput) {
        if (!(search instanceof HTMLInputElement)) return;
        const owned = search.classList.contains('hltv-sp-extended-match-team-search-owned');
        const nativeValue = extendedMatchTeamSearchNativeValues.get(search) || null;
        extendedMatchTeamSearchNativeValues.delete(search);
        nativeMatchTeamSearchDataset(search)?.classList.remove(
            'hltv-sp-native-team-search-suppressed',
        );
        extendedMatchTeamSearchDataset(search)?.remove();
        if (!owned) return;
        search.classList.remove('hltv-sp-extended-match-team-search-owned');
        // Once ownership ends, restore the state HLTV uses for its five native slots.
        const nativeAtLimit = nativeSelectedMatchTeams().size >= CONFIG.nativeMatchTeamLimit;
        search.disabled = nativeAtLimit;
        if (nativeValue
            && !nativeValue.queryChanged
            && !search.value
            && nativeAtLimit) {
            search.value = nativeValue.value;
        }
        const menu = extendedMatchTeamSearchMenu(search);
        if (menu) menu.style.display = 'none';
    }

    function syncExtendedMatchTeamSearchOwnership(search) {
        if (!(search instanceof HTMLInputElement)) return false;
        if (!extendedMatchTeamSearchShouldOwn(search)) {
            releaseExtendedMatchTeamSearchOwnership(search);
            return false;
        }
        search.classList.add('hltv-sp-extended-match-team-search-owned');
        nativeMatchTeamSearchDataset(search)?.classList.add(
            'hltv-sp-native-team-search-suppressed',
        );
        suppressNativeMatchTeamLimitValue(search);
        const atLimit = state.extendedMatchTeams.size >= CONFIG.maxExtendedMatchTeams;
        // HLTV disables this same input at five. Beyond that point the extension
        // owns the field and its isolated suggestion dataset until native mode resumes.
        search.disabled = atLimit;
        if (atLimit) {
            setExtendedMatchFilterStatus(
                `The ${CONFIG.maxExtendedMatchTeams}-team local extension limit is full.`,
            );
        }
        return !atLimit;
    }

    function renderExtendedMatchTeamList(configuration) {
        const search = nativeMatchTeamSearchInput(configuration);
        const container = nativeMatchTeamContainer(search);
        if (!search || !container) return null;
        const searchRow = search.closest('.match-filter-popup-elm.search-typeahead')
            || search.closest('.search-typeahead')
            || search.parentElement;
        if (!searchRow?.parentElement) return null;
        const nativeIds = new Set(nativeSelectedMatchTeams().keys());
        const teams = [...state.extendedMatchTeams.values()].filter(
            (team) => !nativeIds.has(team.id),
        );
        const currentRows = [...container.querySelectorAll(
            ':scope > .hltv-sp-extended-match-team',
        )];
        const currentSignature = currentRows.map((row) => (
            `${row.dataset.hltvSpTeamId || ''}:${cleanText(
                row.querySelector('.match-filter-team-name-placeholder')?.textContent,
            )}`
        )).join('|');
        const nextSignature = teams.map((team) => `${team.id}:${team.name}`).join('|');
        if (currentSignature !== nextSignature) {
            for (const row of currentRows) row.remove();
            const fragment = document.createDocumentFragment();
            for (const team of teams) {
                const row = document.createElement('div');
                row.className = [
                    'match-filter-popup-elm',
                    'match-filter-team',
                    'hltv-sp-extended-match-team',
                ].join(' ');
                row.dataset.hltvSpTeamId = team.id;

                const identity = document.createElement('span');
                const logo = document.createElement('img');
                logo.className = 'match-filter-team-logo';
                logo.src = `/teamlogo/${team.id}`;
                logo.alt = '';
                const name = document.createElement('span');
                name.className = 'match-filter-team-name-placeholder';
                name.textContent = team.name;
                identity.append(logo, name);

                const remove = document.createElement('span');
                remove.className = 'fa fa-times match-filter-remove-team';
                remove.title = `Remove ${team.name}`;
                remove.setAttribute('role', 'button');
                remove.setAttribute('tabindex', '0');
                remove.setAttribute('aria-label', `Remove ${team.name}`);
                const removeTeam = (event) => {
                    if (event.type === 'keydown'
                        && event.key !== 'Enter'
                        && event.key !== ' ') return;
                    event.preventDefault();
                    event.stopPropagation();
                    if (!state.extendedMatchTeams.delete(team.id)) return;
                    renderExtendedMatchTeamList(configuration);
                    syncExtendedMatchTeamSearchOwnership(search);
                    applyMatchTeamFiltering();
                    saveExtendedMatchTeams().catch((error) => {
                        warn('Could not save additional match teams.', error);
                        setExtendedMatchFilterStatus('Could not save that removal.');
                    });
                };
                remove.addEventListener('click', removeTeam);
                remove.addEventListener('keydown', removeTeam);
                row.append(identity, remove);
                fragment.appendChild(row);
            }
            searchRow.before(fragment);
        }

        let status = container.querySelector(':scope > .hltv-sp-extended-match-filter-status');
        if (!status) {
            status = document.createElement('span');
            status.className = 'hltv-sp-extended-match-filter-status hltv-sp-visually-hidden';
            status.setAttribute('aria-live', 'polite');
            searchRow.after(status);
        }
        return search;
    }

    function normaliseTeamSearchResults(value) {
        if (!Array.isArray(value)) return [];
        const results = [];
        const seen = new Set();
        for (const rawTeam of value) {
            const id = String(rawTeam?.id ?? '');
            const name = cleanText(rawTeam?.name).slice(0, CONFIG.maxTeamNameChars);
            const teamUrl = parseSameOriginUrl(rawTeam?.location);
            const pathId = teamUrl?.pathname.match(/^\/team\/(\d{1,20})(?:\/|$)/i)?.[1] || '';
            if (rawTeam?.type !== 'TEAM'
                || !/^\d{1,20}$/.test(id)
                || id !== pathId
                || !name
                || seen.has(id)) continue;
            seen.add(id);
            results.push({ id, name });
            if (results.length >= CONFIG.maxTeamSearchResults) break;
        }
        return results;
    }

    async function fetchMatchTeamSearchResults(query, signal) {
        if (typeof safeFetch !== 'function') throw new Error('Search is unavailable.');
        const value = cleanText(query).slice(0, 80);
        if (value.length < 2) return [];
        const url = new URL('/searchTeam', HLTV_ORIGIN);
        url.searchParams.set('term', value);
        const requestScope = createRequestAbortScope(CONFIG.requestTimeoutMs, signal);
        try {
            const response = await safeFetch(url.href, {
                method: 'GET',
                credentials: 'include',
                cache: 'no-store',
                mode: 'same-origin',
                redirect: 'follow',
                signal: requestScope.signal,
                headers: {
                    Accept: 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                },
            });
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const responseUrl = parseSameOriginUrl(response.url || url.href);
            if (!responseUrl || responseUrl.pathname !== '/searchTeam') {
                throw new Error('Search redirected to an unexpected page.');
            }
            const text = await readBoundedUtf8Response(response, {
                label: 'Team search response',
                maxBytes: CONFIG.maxTeamSearchResponseBytes,
                maxChars: CONFIG.maxTeamSearchResponseChars,
                expectedContentTypes: ['application/json'],
            });
            return normaliseTeamSearchResults(JSON.parse(text));
        } finally {
            requestScope.cleanup();
        }
    }

    function clearExtendedMatchTeamSearchResults(search = state.matchTeamSearchInput) {
        const dataset = extendedMatchTeamSearchDataset(search);
        if (!dataset) return;
        dataset.replaceChildren();
        dataset.hidden = true;
        const menu = extendedMatchTeamSearchMenu(search);
        if (menu && extendedMatchTeamSearchShouldOwn(search)) {
            menu.classList.add('tt-empty');
            menu.style.display = 'none';
        }
    }

    function renderMatchTeamSearchResults(configuration, search, results) {
        clearExtendedMatchTeamSearchResults(search);
        if (!syncExtendedMatchTeamSearchOwnership(search)) return;
        const dataset = extendedMatchTeamSearchDataset(search, true);
        if (!dataset) return;
        const nativeIds = new Set(nativeSelectedMatchTeams().keys());
        const available = results.filter((team) => (
            !nativeIds.has(team.id) && !state.extendedMatchTeams.has(team.id)
        ));
        for (const team of available) {
            const button = document.createElement('div');
            button.className = [
                'tt-suggestion',
                'tt-selectable',
                'hltv-sp-extended-match-team-result',
            ].join(' ');
            button.setAttribute('role', 'option');
            button.setAttribute('tabindex', '0');
            button.dataset.hltvSpTeamId = team.id;
            const logo = document.createElement('img');
            logo.className = 'match-filter-team-logo';
            logo.src = `/teamlogo/${team.id}`;
            logo.alt = '';
            const name = document.createElement('span');
            name.className = 'match-filter-team-name-placeholder';
            name.textContent = team.name;
            button.append(logo, name);
            const addTeam = (event) => {
                if (event.type === 'keydown'
                    && event.key !== 'Enter'
                    && event.key !== ' ') return;
                event.preventDefault();
                event.stopPropagation();
                if (state.extendedMatchTeams.size >= CONFIG.maxExtendedMatchTeams) return;
                state.extendedMatchTeams.set(team.id, team);
                search.value = '';
                search.dispatchEvent(new Event('input', { bubbles: true }));
                clearExtendedMatchTeamSearchResults(search);
                renderExtendedMatchTeamList(configuration);
                syncExtendedMatchTeamSearchOwnership(search);
                applyMatchTeamFiltering();
                saveExtendedMatchTeams().catch((error) => {
                    warn('Could not save an additional match team.', error);
                    setExtendedMatchFilterStatus('Could not save that team.');
                });
            };
            button.addEventListener('mousedown', (event) => event.preventDefault());
            button.addEventListener('click', addTeam);
            button.addEventListener('keydown', addTeam);
            dataset.appendChild(button);
        }
        const menu = extendedMatchTeamSearchMenu(search);
        if (available.length && menu) {
            dataset.hidden = false;
            menu.classList.remove('tt-empty');
            menu.style.display = 'block';
        }
        if (!available.length && results.length) {
            setExtendedMatchFilterStatus('Those teams are already selected.');
        }
    }

    function createExtendedMatchTeamPicker(configuration) {
        for (const obsoleteHost of configuration.querySelectorAll(
            '.hltv-sp-extended-match-filter-host',
        )) obsoleteHost.remove();
        const search = renderExtendedMatchTeamList(configuration);
        if (!search) return null;
        syncExtendedMatchTeamSearchOwnership(search);
        if (state.matchTeamSearchInput === search
            && state.matchTeamSearchInputHandler
            && state.matchTeamSearchKeydownHandler) {
            return search;
        }
        if (state.matchTeamSearchInput && state.matchTeamSearchInputHandler) {
            releaseExtendedMatchTeamSearchOwnership(state.matchTeamSearchInput);
            state.matchTeamSearchInput.removeEventListener(
                'input',
                state.matchTeamSearchInputHandler,
                true,
            );
        }
        if (state.matchTeamSearchInput && state.matchTeamSearchKeydownHandler) {
            state.matchTeamSearchInput.removeEventListener(
                'keydown',
                state.matchTeamSearchKeydownHandler,
                true,
            );
        }
        state.matchTeamSearchInput = search;
        state.matchTeamSearchInputHandler = (event) => {
            window.clearTimeout(state.matchTeamSearchTimer);
            state.matchTeamSearchAbortController?.abort();
            const owned = extendedMatchTeamSearchShouldOwn(search);
            const nativeLimitValue = owned && nativeMatchTeamLimitValue(search.value);
            const available = syncExtendedMatchTeamSearchOwnership(search);
            if (owned) event.stopImmediatePropagation();
            const nativeValue = extendedMatchTeamSearchNativeValues.get(search);
            if (owned && nativeValue && !nativeLimitValue) {
                nativeValue.queryChanged = true;
            }
            clearExtendedMatchTeamSearchResults(search);
            const query = cleanText(search.value);
            if (query.length < 2
                || !available) {
                setExtendedMatchFilterStatus('');
                return;
            }
            setExtendedMatchFilterStatus('Searching for another team.');
            state.matchTeamSearchTimer = window.setTimeout(async () => {
                state.matchTeamSearchTimer = null;
                if (state.matchTeamSearchInput !== search
                    || !syncExtendedMatchTeamSearchOwnership(search)) return;
                const controller = new AbortController();
                state.matchTeamSearchAbortController = controller;
                try {
                    const matches = await fetchMatchTeamSearchResults(
                        query,
                        controller.signal,
                    );
                    if (controller.signal.aborted || cleanText(search.value) !== query) return;
                    setExtendedMatchFilterStatus(matches.length ? '' : 'No teams found.');
                    renderMatchTeamSearchResults(configuration, search, matches);
                } catch (error) {
                    if (isAbortErrorLike(error) || controller.signal.aborted) return;
                    setExtendedMatchFilterStatus('Team search failed. Try again.');
                    log('Additional-team search failed.', error);
                } finally {
                    if (state.matchTeamSearchAbortController === controller) {
                        state.matchTeamSearchAbortController = null;
                    }
                }
            }, CONFIG.teamSearchDebounceMs);
        };
        state.matchTeamSearchKeydownHandler = (event) => {
            if (event.key !== 'Enter') return;
            const selected = search.closest('.twitter-typeahead')?.querySelector(
                '.hltv-sp-extended-match-team-results '
                + '.hltv-sp-extended-match-team-result.tt-cursor',
            );
            if (!selected) return;
            event.preventDefault();
            event.stopImmediatePropagation();
            selected.click();
        };
        // Capture input only while the extension owns the field at the native cap,
        // preventing HLTV's disabled five-slot typeahead from racing our dataset.
        search.addEventListener('input', state.matchTeamSearchInputHandler, true);
        // Native results retain their normal Enter path below the five-slot cap.
        search.addEventListener('keydown', state.matchTeamSearchKeydownHandler, true);
        return search;
    }

    function applyMatchTeamFiltering() {
        for (const row of document.querySelectorAll(
            'a.hotmatch-box.hltv-sp-extra-team-match, '
            + 'a.hotmatch-box.hltv-sp-team-filter-hidden, '
            + '.col-box-con.result-box.hltv-sp-extra-team-match, '
            + '.col-box-con.result-box.hltv-sp-team-filter-hidden',
        )) {
            row.classList.remove(
                'hltv-sp-extra-team-match',
                'hltv-sp-team-filter-hidden',
            );
        }
        if (!nativeMatchFilterIsEnabled()) {
            setExtendedMatchFilterStatus('');
            return;
        }
        const list = findHomepageMatchList(document);
        if (!list) return;
        const matchFilterRoot = list.closest('.rightCol') || list;
        const rows = [
            ...list.querySelectorAll('a.hotmatch-box[href]'),
            ...matchFilterRoot.querySelectorAll(
                '.col-box-con.result-box',
            ),
        ];
        const strict = Boolean(state.settings.strictSelectedTeamMatches);
        const nativeTeams = nativeSelectedMatchTeams();
        const additionalIds = state.settings.enableExtendedMatchFilter
            ? new Set(state.extendedMatchTeams.keys())
            : new Set();
        const selectedIds = new Set([...nativeTeams.keys(), ...additionalIds]);
        if (strict && !selectedIds.size) {
            setExtendedMatchFilterStatus('Select at least one team before using strict filtering.');
            return;
        }

        const matchRows = rows.map((row) => {
            const box = row.matches('.col-box-con.result-box')
                ? row
                : row.querySelector('.teambox.match');
            const team1 = String(box?.getAttribute('team1') || '');
            const team2 = String(box?.getAttribute('team2') || '');
            return {
                row,
                valid: /^\d{1,20}$/.test(team1) && /^\d{1,20}$/.test(team2),
                team1,
                team2,
            };
        });
        if (!matchRows.some((entry) => entry.valid)) {
            setExtendedMatchFilterStatus('Match team IDs are unavailable on this page.');
            return;
        }
        setExtendedMatchFilterStatus('');
        for (const entry of matchRows) {
            if (!entry.valid) {
                if (strict) entry.row.classList.add('hltv-sp-team-filter-hidden');
                continue;
            }
            const matchesAdditional = additionalIds.has(entry.team1)
                || additionalIds.has(entry.team2);
            const matchesSelected = selectedIds.has(entry.team1)
                || selectedIds.has(entry.team2);
            if (strict) {
                entry.row.classList.toggle(
                    'hltv-sp-team-filter-hidden',
                    !matchesSelected,
                );
                if (matchesSelected && matchesAdditional) {
                    entry.row.classList.add('hltv-sp-extra-team-match');
                }
            } else if (matchesAdditional) {
                entry.row.classList.add('hltv-sp-extra-team-match');
            }
        }
    }

    function scheduleExtendedMatchFilterApply(delayMs = CONFIG.matchFilterDebounceMs) {
        window.clearTimeout(state.matchFilterTimer);
        state.matchFilterTimer = window.setTimeout(
            applyExtendedMatchFilterSetting,
            Math.max(0, Number(delayMs) || 0),
        );
    }

    function nativeMatchFilterMutation(mutation) {
        const target = mutation?.target;
        return target instanceof Element && target.matches(
            '.hotmatch-star-selected, .hotmatch-star-unselected, '
            + '.toploginbar-match-filter-enabled, '
            + '.toploginbar-match-filter-disabled',
        );
    }

    function ensureNativeMatchFilterClickHandler() {
        if (state.matchFilterClickHandler) return;
        state.matchFilterClickHandler = (event) => {
            if (!(event.target instanceof Element) || !event.target.closest(
                '.hotmatch-star-selected, .hotmatch-star-unselected, '
                + '.toploginbar-match-filter-enabled, '
                + '.toploginbar-match-filter-disabled',
            )) return;
            // HLTV updates the selected class and star visibility in its own
            // click handler.  Read that settled DOM state in the next task.
            scheduleExtendedMatchFilterApply(0);
        };
        document.addEventListener('click', state.matchFilterClickHandler);
        state.matchFilterNavigationHandler = () => scheduleExtendedMatchFilterApply(0);
        window.addEventListener('pageshow', state.matchFilterNavigationHandler, { passive: true });
        window.addEventListener('popstate', state.matchFilterNavigationHandler, { passive: true });
    }

    function removeNativeMatchFilterClickHandler() {
        if (state.matchFilterClickHandler) {
            document.removeEventListener('click', state.matchFilterClickHandler);
        }
        if (state.matchFilterNavigationHandler) {
            window.removeEventListener('pageshow', state.matchFilterNavigationHandler);
            window.removeEventListener('popstate', state.matchFilterNavigationHandler);
        }
        state.matchFilterClickHandler = null;
        state.matchFilterNavigationHandler = null;
    }

    function observeExtendedMatchFilter(configuration, matchRoot) {
        if (!state.matchFilterObserver) {
            state.matchFilterObserver = new MutationObserver(
                (mutations) => scheduleExtendedMatchFilterApply(
                    mutations.some(nativeMatchFilterMutation)
                        ? 0
                        : CONFIG.matchFilterDebounceMs,
                ),
            );
        }
        state.matchFilterObserver.disconnect();
        const observedRoots = new Set([configuration, matchRoot].filter(Boolean));
        for (const toggle of document.querySelectorAll(
            '.toploginbar-match-filter-enabled, '
            + '.toploginbar-match-filter-disabled',
        )) {
            observedRoots.add(toggle.closest('.nav-popup-elm') || toggle);
        }
        for (const root of observedRoots) {
            state.matchFilterObserver.observe(root, {
                attributes: true,
                childList: true,
                subtree: true,
                attributeFilter: [
                    'aria-hidden', 'class', 'disabled', 'hidden', 'src', 'style',
                    'team1', 'team2',
                ],
            });
        }
    }

    function applyExtendedMatchFilterSetting() {
        window.clearTimeout(state.matchFilterTimer);
        state.matchFilterTimer = null;
        state.matchFilterObserver?.disconnect();
        const configuration = document.querySelector('.match-filter-configuration');
        const matchList = findHomepageMatchList(document);

        const extendedEnabled = Boolean(state.settings.enableExtendedMatchFilter);
        const strictEnabled = Boolean(state.settings.strictSelectedTeamMatches);

        if (extendedEnabled || strictEnabled) {
            ensureNativeMatchFilterClickHandler();
        } else {
            removeNativeMatchFilterClickHandler();
        }

        if (!extendedEnabled) {
            window.clearTimeout(state.matchTeamSearchTimer);
            state.matchTeamSearchTimer = null;
            state.matchTeamSearchAbortController?.abort();
            state.matchTeamSearchAbortController = null;
            releaseExtendedMatchTeamSearchOwnership();
            clearExtendedMatchTeamSearchResults();
            if (state.matchTeamSearchInput && state.matchTeamSearchInputHandler) {
                state.matchTeamSearchInput.removeEventListener(
                    'input',
                    state.matchTeamSearchInputHandler,
                    true,
                );
            }
            if (state.matchTeamSearchInput && state.matchTeamSearchKeydownHandler) {
                state.matchTeamSearchInput.removeEventListener(
                    'keydown',
                    state.matchTeamSearchKeydownHandler,
                    true,
                );
            }
            state.matchTeamSearchInput = null;
            state.matchTeamSearchInputHandler = null;
            state.matchTeamSearchKeydownHandler = null;
            for (const host of document.querySelectorAll(
                '.hltv-sp-extended-match-filter-host',
            )) host.remove();
            for (const row of document.querySelectorAll(
                '.hltv-sp-extended-match-team, .hltv-sp-extended-match-filter-status',
            )) row.remove();
            for (const row of document.querySelectorAll(
                'a.hotmatch-box.hltv-sp-extra-team-match, '
                + '.col-box-con.result-box.hltv-sp-extra-team-match',
            )) {
                row.classList.remove('hltv-sp-extra-team-match');
            }
            if (!strictEnabled) {
                for (const row of document.querySelectorAll(
                    'a.hotmatch-box.hltv-sp-team-filter-hidden, '
                    + '.col-box-con.result-box.hltv-sp-team-filter-hidden',
                )) row.classList.remove('hltv-sp-team-filter-hidden');
                return;
            }
        }

        if (extendedEnabled && configuration) createExtendedMatchTeamPicker(configuration);
        const reset = configuration?.querySelector('[name="match-filter-reset-all"]');
        if (extendedEnabled && reset && !matchFilterResetButtons.has(reset)) {
            matchFilterResetButtons.add(reset);
            reset.addEventListener('click', () => {
                if (!state.settings.enableExtendedMatchFilter) return;
                state.extendedMatchTeams.clear();
                renderExtendedMatchTeamList(configuration);
                clearExtendedMatchTeamSearchResults();
                syncExtendedMatchTeamSearchOwnership(state.matchTeamSearchInput);
                applyMatchTeamFiltering();
                saveExtendedMatchTeams().catch((error) => {
                    warn('Could not reset additional match teams.', error);
                });
            });
        }
        applyMatchTeamFiltering();
        observeExtendedMatchFilter(
            configuration,
            matchList?.closest('.rightCol') || matchList,
        );
    }

    function clearLayoutWidthOverrides() {
        if (!document.body) return;
        document.body.classList.remove('hltv-sp-expanded-layout');
        document.body.style.removeProperty('--hltv-sp-layout-background-width');
        document.body.style.removeProperty('--hltv-sp-layout-shell-width');
        document.body.style.removeProperty('--hltv-sp-layout-sidebar-width');
    }

    function captureLayoutWidthOverrides() {
        if (!document.body) return null;
        return {
            expanded: document.body.classList.contains('hltv-sp-expanded-layout'),
            backgroundWidth: document.body.style.getPropertyValue(
                '--hltv-sp-layout-background-width',
            ),
            shellWidth: document.body.style.getPropertyValue(
                '--hltv-sp-layout-shell-width',
            ),
            sidebarWidth: document.body.style.getPropertyValue(
                '--hltv-sp-layout-sidebar-width',
            ),
        };
    }

    function restoreLayoutWidthOverrides(snapshot) {
        if (!document.body || !snapshot) return;
        clearLayoutWidthOverrides();
        if (snapshot.backgroundWidth) {
            document.body.style.setProperty(
                '--hltv-sp-layout-background-width',
                snapshot.backgroundWidth,
            );
        }
        if (snapshot.shellWidth) {
            document.body.style.setProperty(
                '--hltv-sp-layout-shell-width',
                snapshot.shellWidth,
            );
        }
        if (snapshot.sidebarWidth) {
            document.body.style.setProperty(
                '--hltv-sp-layout-sidebar-width',
                snapshot.sidebarWidth,
            );
        }
        document.body.classList.toggle('hltv-sp-expanded-layout', snapshot.expanded);
    }

    function releaseLayoutBootstrap() {
        if (state.layoutBootstrapReleased) return;
        state.layoutBootstrapReleased = true;
        if (!capturedLayoutBootstrapRelease) return;
        try {
            capturedLayoutBootstrapRelease();
        } catch (error) {
            log('Could not release the early layout bootstrap.', error);
        }
    }

    function measuredElementWidth(element) {
        if (!(element instanceof Element)) return 0;
        const rectWidth = Number(element.getBoundingClientRect?.().width);
        if (Number.isFinite(rectWidth) && rectWidth > 0) return rectWidth;
        const computedWidth = Number.parseFloat(getComputedStyle(element).width);
        if (Number.isFinite(computedWidth) && computedWidth > 0) {
            return computedWidth + horizontalBoxExtras(element);
        }
        const offsetWidth = Number(element.offsetWidth);
        return Number.isFinite(offsetWidth) && offsetWidth > 0 ? offsetWidth : 0;
    }

    function horizontalBoxExtras(element) {
        if (!(element instanceof Element)) return 0;
        const style = getComputedStyle(element);
        return [
            style.paddingLeft,
            style.paddingRight,
            style.borderLeftWidth,
            style.borderRightWidth,
        ].reduce((total, value) => total + (Number.parseFloat(value) || 0), 0);
    }

    function getDesktopSidebarList() {
        const current = state.sidebar?.isConnected && state.sidebar.closest('.right2Col')
            ? state.sidebar
            : null;
        if (current) return current;
        const list = document.querySelector(
            '.bgPadding > .widthControl > .colCon > .right2Col .recent-activity .activitylist',
        );
        if (list) state.sidebar = list;
        return list;
    }

    function queueLayoutWidthApply(delayMs = 120) {
        window.clearTimeout(state.layoutResizeTimer);
        state.layoutResizeTimer = window.setTimeout(() => {
            state.layoutResizeTimer = null;
            if (applyLayoutWidthSetting()) cancelLayoutWidthStartupRetries();
            if (state.previewPanel?.classList.contains('hltv-sp-open')) positionThreadPreview();
        }, delayMs);
    }

    function ensureLayoutResizeHandler() {
        if (state.layoutResizeHandler) return;
        state.layoutResizeHandler = () => queueLayoutWidthApply();
        state.layoutVisibilityHandler = () => {
            if (document.hidden) return;
            queueLayoutWidthApply(0);
            scheduleLayoutWidthStartupRetries();
        };
        state.layoutPageShowHandler = () => {
            queueLayoutWidthApply(0);
            scheduleLayoutWidthStartupRetries();
        };
        window.addEventListener('resize', state.layoutResizeHandler, { passive: true });
        document.addEventListener('visibilitychange', state.layoutVisibilityHandler, { passive: true });
        window.addEventListener('pageshow', state.layoutPageShowHandler, { passive: true });
    }

    function scheduleLayoutWidthStartupRetries() {
        window.clearTimeout(state.layoutStartupTimer);
        const generation = ++state.layoutStartupGeneration;
        const preset = LAYOUT_WIDTH_PRESETS[normaliseLayoutWidthPreset(state.settings.layoutWidthPreset)];
        if (!preset || (!preset.contentExtraPx && !preset.sidebarExtraPx)) return;

        const retryDelays = [100, 400, 1200, 2500];
        let retryIndex = 0;
        const retry = () => {
            if (generation !== state.layoutStartupGeneration) return;
            state.layoutStartupTimer = null;
            const settleNoRoom = retryIndex >= retryDelays.length;
            if (applyLayoutWidthSetting(settleNoRoom)) return;
            if (settleNoRoom) return;
            state.layoutStartupTimer = window.setTimeout(retry, retryDelays[retryIndex]);
            retryIndex += 1;
        };
        state.layoutStartupTimer = window.setTimeout(retry, retryDelays[retryIndex]);
        retryIndex += 1;
    }

    function cancelLayoutWidthStartupRetries() {
        window.clearTimeout(state.layoutStartupTimer);
        state.layoutStartupTimer = null;
        state.layoutStartupGeneration += 1;
    }

    function applyLayoutWidthSetting(settleNoRoom = false) {
        if (!document.body) return false;
        ensureLayoutResizeHandler();

        const list = getDesktopSidebarList();
        if (state.sidebarListElement !== list) {
            state.sidebarListElement?.classList.remove('hltv-sp-sidebar-list');
            state.sidebarListElement = list || null;
        }
        list?.classList.add('hltv-sp-sidebar-list');

        const preset = LAYOUT_WIDTH_PRESETS[normaliseLayoutWidthPreset(state.settings.layoutWidthPreset)];
        if (!preset) return false;
        if (!preset.contentExtraPx && !preset.sidebarExtraPx) {
            clearLayoutWidthOverrides();
            releaseLayoutBootstrap();
            return true;
        }
        if (!list) return false;

        const sidebarColumn = list.closest('.right2Col');
        const columns = sidebarColumn?.parentElement;
        const shell = columns?.closest('.widthControl');
        const background = shell?.parentElement;
        const viewportWidth = Math.max(
            Number(document.documentElement?.clientWidth) || 0,
            Number(window.innerWidth) || 0,
        );
        if (!sidebarColumn
            || !columns?.matches('.colCon')
            || !background?.classList.contains('bgPadding')) return false;
        if (viewportWidth <= 0) return false;
        if (viewportWidth < 975) {
            clearLayoutWidthOverrides();
            releaseLayoutBootstrap();
            return true;
        }
        if (getComputedStyle(sidebarColumn).display === 'none') return false;

        const previousOverrides = captureLayoutWidthOverrides();
        clearLayoutWidthOverrides();
        const baseBackgroundWidth = measuredElementWidth(background);
        const baseShellWidth = measuredElementWidth(shell);
        const baseSidebarWidth = measuredElementWidth(sidebarColumn);
        if (!baseBackgroundWidth || !baseShellWidth || !baseSidebarWidth) {
            restoreLayoutWidthOverrides(previousOverrides);
            return false;
        }

        const requestedContentExtra = preset.contentExtraPx;
        const requestedSidebarExtra = preset.sidebarExtraPx;
        const requestedTotal = requestedContentExtra + requestedSidebarExtra;
        const availableExtra = Math.max(0, viewportWidth - 32 - baseBackgroundWidth);
        const scale = requestedTotal ? Math.min(1, availableExtra / requestedTotal) : 0;
        const contentExtra = Math.round(requestedContentExtra * scale);
        const sidebarExtra = Math.round(requestedSidebarExtra * scale);
        const appliedTotal = contentExtra + sidebarExtra;
        const backgroundExtras = horizontalBoxExtras(background);
        const shellExtras = horizontalBoxExtras(shell);
        if (appliedTotal < 40) {
            if (state.layoutBootstrapReleased || settleNoRoom) {
                releaseLayoutBootstrap();
                return true;
            }
            restoreLayoutWidthOverrides(previousOverrides);
            return false;
        }

        document.body.style.setProperty(
            '--hltv-sp-layout-background-width',
            `${Math.round(baseBackgroundWidth - backgroundExtras + appliedTotal)}px`,
        );
        document.body.style.setProperty(
            '--hltv-sp-layout-shell-width',
            `${Math.round(baseShellWidth - shellExtras + appliedTotal)}px`,
        );
        document.body.style.setProperty(
            '--hltv-sp-layout-sidebar-width',
            `${Math.round(baseSidebarWidth + sidebarExtra)}px`,
        );
        document.body.classList.add('hltv-sp-expanded-layout');
        releaseLayoutBootstrap();
        return true;
    }

    function getSidebar() {
        return document.querySelector(
            '.bgPadding > .widthControl > .colCon > .right2Col .recent-activity .activitylist',
        )
            || document.querySelector('.recent-activity .activitylist')
            || document.querySelector('.col-box-con .activitylist')
            || document.querySelector('.activitylist');
    }

    function waitForSidebar(timeoutMs = 15000) {
        const existingSidebar = getSidebar();
        if (existingSidebar) return Promise.resolve(existingSidebar);

        return new Promise((resolve) => {
            let settled = false;
            let timeoutId;

            const finish = (sidebar) => {
                if (settled) return;
                settled = true;
                observer.disconnect();
                window.clearTimeout(timeoutId);
                resolve(sidebar);
            };

            const observer = new MutationObserver(() => {
                const sidebar = getSidebar();
                if (sidebar) {
                    finish(sidebar);
                }
            });

            observer.observe(document.documentElement, { childList: true, subtree: true });

            timeoutId = window.setTimeout(() => finish(getSidebar()), timeoutMs);
        });
    }

    function createSortButton() {
        const existingButton = document.getElementById('hltv-sp-sort-button');
        if (hasCurrentUiVersion(existingButton)) {
            state.sortButton = existingButton;
            updateSortButton();
            return;
        }
        existingButton?.remove();

        const title = findRecentActivityTitle();
        if (!title) return;

        const button = document.createElement('button');
        button.id = 'hltv-sp-sort-button';
        stampUiVersion(button);
        button.type = 'button';
        button.addEventListener('click', cycleSortOrder);

        title.insertBefore(button, title.firstChild);
        state.sortButton = button;
        updateSortButton();
    }

    function findRecentActivityTitle() {
        const directTitle = document.querySelector('.recent-activity h1')
            || document.querySelector('.recent-activity h2')
            || document.querySelector('.recent-activity .col-box-title')
            || document.querySelector('.recent-activity .standard-box-title');

        if (directTitle) return directTitle;

        const sidebar = state.sidebar || getSidebar();
        let root = sidebar;
        for (let depth = 0; root && depth < 5; depth += 1, root = root.parentElement) {
            const candidates = root.querySelectorAll('h1, h2, h3, .col-box-title, .standard-box-title');
            for (const candidate of candidates) {
                const text = SORT_STATES.reduce(
                    (value, sortState) => value.split(sortState.icon).join(''),
                    candidate.textContent,
                ).trim();
                if (/^recent activity$/i.test(text)) return candidate;
            }
        }

        return null;
    }

    function clearPreviewContextMenuProtection({ scheduleClose = false } = {}) {
        state.previewContextMenuActive = false;
        if (state.previewContextMenuDismissHandler) {
            document.removeEventListener(
                'pointerdown',
                state.previewContextMenuDismissHandler,
                true,
            );
            document.removeEventListener(
                'keydown',
                state.previewContextMenuDismissHandler,
                true,
            );
            state.previewContextMenuDismissHandler = null;
        }
        if (scheduleClose) window.setTimeout(schedulePreviewCloseAfterInteraction, 0);
    }

    function protectThreadPreviewContextMenu() {
        if (!state.previewPanel?.classList.contains('hltv-sp-open')) return;
        state.previewContextMenuActive = true;
        window.clearTimeout(state.previewHoverTimer);
        window.clearTimeout(state.previewCloseTimer);
        if (state.previewContextMenuDismissHandler) return;
        state.previewContextMenuDismissHandler = (event) => {
            const insidePreview = event.type === 'pointerdown'
                && event.composedPath?.().includes(state.previewPanel);
            clearPreviewContextMenuProtection({ scheduleClose: !insidePreview });
        };
        document.addEventListener(
            'pointerdown',
            state.previewContextMenuDismissHandler,
            true,
        );
        document.addEventListener(
            'keydown',
            state.previewContextMenuDismissHandler,
            true,
        );
    }

    function createThreadPreviewPopup() {
        if (state.previewPanel) return;
        for (const toolbar of document.querySelectorAll('.hltv-sp-sidebar-toolbar')) toolbar.remove();
        for (const stalePanel of document.querySelectorAll('.hltv-sp-preview-panel')) {
            if (!hasCurrentUiVersion(stalePanel)) stalePanel.remove();
        }
        if (!state.settings.enableThreadPreviews) return;
        const panel = document.createElement('div');
        panel.className = 'hltv-sp-preview-panel';
        stampUiVersion(panel);
        panel.addEventListener('mouseenter', () => {
            clearPreviewContextMenuProtection();
            state.previewPointerInside = true;
            window.clearTimeout(state.previewCloseTimer);
        });
        panel.addEventListener('mouseleave', () => {
            state.previewPointerInside = false;
            scheduleThreadPreviewClose();
        });
        panel.addEventListener('focusout', () => {
            window.setTimeout(schedulePreviewCloseAfterInteraction, 0);
        });
        panel.addEventListener('input', (event) => {
            const target = event.target;
            if (target instanceof HTMLTextAreaElement && !target.value) {
                schedulePreviewCloseAfterInteraction();
            }
        });
        panel.addEventListener('pointerdown', (event) => {
            if (event.button === 2) protectThreadPreviewContextMenu();
        });
        panel.addEventListener('contextmenu', protectThreadPreviewContextMenu);
        panel.addEventListener('wheel', markPreviewThreadReadFromInteraction, { passive: true });
        panel.addEventListener('scroll', markPreviewThreadReadFromInteraction, { passive: true });
        if (!state.previewReadVisibilityHandler) {
            state.previewReadVisibilityHandler = () => {
                if (document.hidden) cancelPreviewReadDwell();
                else schedulePreviewReadDwell(state.previewReadCandidate);
            };
            document.addEventListener('visibilitychange', state.previewReadVisibilityHandler);
        }
        if (!state.previewReadBlurHandler) {
            state.previewReadBlurHandler = cancelPreviewReadDwell;
            window.addEventListener('blur', state.previewReadBlurHandler);
        }
        if (!state.previewReadFocusHandler) {
            state.previewReadFocusHandler = () => {
                schedulePreviewReadDwell(state.previewReadCandidate);
            };
            window.addEventListener('focus', state.previewReadFocusHandler);
        }
        document.body.appendChild(panel);
        state.previewPanel = panel;
    }

    function parseTimestampValue(value, now = Date.now()) {
        const text = cleanText(value);
        if (!text) return 0;

        if (/^\d{10,13}$/.test(text)) {
            const numeric = Number(text);
            const timestamp = numeric < 10_000_000_000 ? numeric * 1000 : numeric;
            return timestamp >= CONFIG.minValidTimestampMs && timestamp <= now + 300000 ? timestamp : 0;
        }

        const relative = text.match(/^(?:about\s+)?(\d+)\s*(seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|months?|mos?|mo|years?|yrs?|y)(?:\s+ago)?$/i);
        if (relative) {
            const amount = Number(relative[1]);
            const unit = relative[2].toLowerCase();
            const multiplier = unit.startsWith('s') ? 1000
                : unit === 'm' || unit.startsWith('min') ? 60000
                    : unit === 'h' || unit.startsWith('hr') || unit.startsWith('hour') ? 3600000
                        : unit === 'd' || unit.startsWith('day') ? 86400000
                            : unit === 'w' || unit.startsWith('week') ? 604800000
                                : unit === 'mo' || unit.startsWith('month') ? 2_592_000_000
                                    : 31_536_000_000;
            const timestamp = now - amount * multiplier;
            return timestamp >= CONFIG.minValidTimestampMs ? timestamp : 0;
        }
        if (/^(?:just\s+now|now)$/i.test(text)) return now;

        if (!/\d/.test(text)) return 0;
        const parsed = Date.parse(text);
        return Number.isFinite(parsed)
            && parsed >= CONFIG.minValidTimestampMs
            && parsed <= now + 300000
            ? parsed
            : 0;
    }

    function extractTimestampFromRoot(root) {
        if (!(root instanceof Element)) return 0;
        const candidates = [root, ...root.querySelectorAll('time, [datetime], [data-unix], [data-timestamp], [title]')];
        for (const candidate of candidates.slice(0, 40)) {
            const values = [
                candidate.getAttribute('data-unix'),
                candidate.getAttribute('data-timestamp'),
                candidate.getAttribute('datetime'),
                candidate.getAttribute('title'),
                candidate.tagName === 'TIME' ? candidate.textContent : '',
            ];
            for (const value of values) {
                const timestamp = parseTimestampValue(value);
                if (timestamp) return timestamp;
            }
        }
        const text = cleanText(root.textContent);
        return /(?:ago$|^(?:just\s+now|now)$|^\d+\s*(?:s|m|h|d|w|mo|y)$)/i.test(text)
            ? parseTimestampValue(text)
            : 0;
    }

    function extractForumRowActivityAt(row) {
        const activity = row.querySelector('.activity, .lastpost, .last-post, td:last-child');
        return activity ? extractTimestampFromRoot(activity) : 0;
    }

    function extractPreviewPostText(post) {
        const preferred = post.querySelector(
            '.forum-middle, .forum-post-body, .forum_post_body, .post-body, .post-body-content, .forum_post, .text-content',
        );
        const clone = (preferred || post).cloneNode(true);
        for (const unwanted of clone.querySelectorAll(
            'script, style, button, input, textarea, select, .replyNum, .threading, .forum-post-header, .forum_post_header, .forum_post_author, .post-author, .flag',
        )) unwanted.remove();
        for (const lineBreak of clone.querySelectorAll('br')) {
            lineBreak.replaceWith(clone.ownerDocument.createTextNode('\n'));
        }
        return cleanPreviewPostText(clone.textContent).slice(0, CONFIG.maxPreviewChars);
    }

    function cleanPreviewPostText(value) {
        return String(value || '')
            .replace(/\r\n?/g, '\n')
            .replace(/[^\S\n]+/g, ' ')
            .replace(/ *\n */g, '\n')
            .trim();
    }

    function parsePreviewAssetUrl(value, kind) {
        try {
            const url = new URL(String(value || ''), HLTV_ORIGIN);
            if (url.protocol !== 'https:' || url.username || url.password || url.href.length > 2048) {
                return null;
            }
            if (kind === 'gallery') {
                return url.origin === 'https://img-cdn.hltv.org'
                    && /^\/gallerypicture\/[A-Za-z0-9._~-]+\.(?:avif|gif|jpe?g|png|webp)$/i.test(url.pathname)
                    ? url
                    : null;
            }
            if (kind === 'flag') {
                return url.origin === HLTV_ORIGIN
                    && /^\/img\/static\/flags\/(?:30x20\/)?[A-Za-z0-9_-]+\.(?:gif|png|webp)$/i.test(url.pathname)
                    ? url
                    : null;
            }
            if (kind === 'flair') {
                const officialOrigin = url.origin === HLTV_ORIGIN
                    || url.origin === 'https://img-cdn.hltv.org';
                return officialOrigin
                    && /\.(?:avif|gif|jpe?g|png|svg|webp)$/i.test(url.pathname)
                    ? url
                    : null;
            }
            return null;
        } catch {
            return null;
        }
    }

    function extractPreviewImages(post, imageBudget) {
        if (!post || !imageBudget || imageBudget.remaining <= 0) return [];
        const body = post.querySelector(
            '.forum-middle, .forum-post-body, .forum_post_body, .post-body, .post-body-content, .forum_post, .text-content',
        );
        if (!body) return [];
        const images = [];
        const seen = new Set();
        for (const source of body.querySelectorAll(
            '.forumgallerypicture img.forumpicture[data-hltv-sp-inert-src]',
        )) {
            if (images.length >= CONFIG.maxPreviewImagesPerPost || imageBudget.remaining <= 0) break;
            const sourceUrl = parsePreviewAssetUrl(
                source.getAttribute('data-hltv-sp-inert-src'),
                'gallery',
            );
            if (!sourceUrl || seen.has(sourceUrl.href)) continue;
            const galleryLink = source.closest('a.thumb[href]');
            const galleryUrl = parseSameOriginUrl(galleryLink?.getAttribute('href'));
            if (!galleryUrl || !/^\/gallery\/view\/\d{1,20}\/?$/i.test(galleryUrl.pathname)) continue;
            seen.add(sourceUrl.href);
            images.push({
                src: sourceUrl.href,
                href: galleryUrl.href,
                alt: cleanText(source.getAttribute('alt')).slice(0, 200),
            });
            imageBudget.remaining -= 1;
        }
        return images;
    }

    function extractPreviewFlag(post) {
        const source = post?.querySelector(
            '.forum-topbar img.flag[data-hltv-sp-inert-src]',
        );
        const url = parsePreviewAssetUrl(
            source?.getAttribute('data-hltv-sp-inert-src'),
            'flag',
        );
        if (!url) return null;
        const name = cleanText(
            source.getAttribute('alt') || source.getAttribute('title'),
        ).slice(0, 100);
        return { src: url.href, name };
    }

    function extractPreviewFlair(post, teamLogoBudget) {
        const fanContainer = post?.querySelector('.forum-topbar .fan-con');
        const playerFlair = fanContainer?.querySelector('.love');
        const playerLink = playerFlair?.querySelector('a[href]');
        const playerUrl = parseSameOriginUrl(playerLink?.getAttribute('href'));
        const playerLabel = cleanText(playerLink?.textContent).slice(0, 100);
        if (playerUrl
            && /^\/player\/\d{1,20}(?:\/|$)/i.test(playerUrl.pathname)
            && playerLabel) {
            return {
                kind: 'player',
                href: playerUrl.href,
                label: playerLabel,
                title: cleanText(playerFlair.getAttribute('title')).slice(0, 150)
                    || 'fan of ' + playerLabel,
                logoSrc: '',
            };
        }

        const teamLink = fanContainer?.querySelector('a[href]');
        const teamUrl = parseSameOriginUrl(teamLink?.getAttribute('href'));
        if (!teamUrl || !/^\/team\/\d{1,20}(?:\/|$)/i.test(teamUrl.pathname)) return null;
        const logos = [...teamLink.querySelectorAll(
            'img.teamLogo[data-hltv-sp-inert-src]',
        )];
        const logo = logos.find((candidate) => candidate.classList.contains('night-only'))
            || logos.find((candidate) => (
                !candidate.classList.contains('day-only')
                && !candidate.classList.contains('night-only')
            ))
            || logos[0];
        const logoUrl = parsePreviewAssetUrl(
            logo?.getAttribute('data-hltv-sp-inert-src'),
            'flair',
        );
        const label = cleanText(
            logo?.getAttribute('alt') || logo?.getAttribute('title'),
        ).replace(/^fan of\s+/i, '').slice(0, 100);
        if (!logoUrl || !label) return null;
        const includeLogo = !teamLogoBudget || teamLogoBudget.remaining > 0;
        if (includeLogo && teamLogoBudget) {
            teamLogoBudget.remaining -= 1;
        }
        return {
            kind: 'team',
            href: teamUrl.href,
            label,
            title: cleanText(logo.getAttribute('title')).slice(0, 150)
                || 'fan of ' + label,
            logoSrc: includeLogo ? logoUrl.href : '',
        };
    }

    function extractPreviewUser(post, teamLogoBudget) {
        const link = findAuthorLinkInPost(post)
            || post.querySelector(':scope > a.authorAnchor[href*="/profile/"], :scope > a[href*="/profile/"]');
        const identity = link ? parseProfileIdentity(link) : null;
        const profileUrl = identity ? parseSameOriginUrl(link.getAttribute('href') || link.href) : null;
        return {
            id: identity?.id || '',
            name: identity?.name || cleanText(link?.textContent).slice(0, 100) || 'Unknown user',
            profileHref: profileUrl?.href || '',
            flag: extractPreviewFlag(post),
            flair: extractPreviewFlair(post, teamLogoBudget),
        };
    }

    function readVoteCount(button) {
        if (!(button instanceof Element)) return null;
        const rawValue = (button.classList.contains('active')
            ? button.querySelector('.slide-in')?.textContent
            : null)
            ?? button.getAttribute('data-plus-count')
            ?? button.querySelector('.slide-out')?.textContent
            ?? '';
        const match = String(rawValue).match(/-?\d+/);
        if (!match) return null;
        const count = Number(match[0]);
        return Number.isFinite(count) && Math.abs(count) <= 1_000_000 ? count : null;
    }

    function extractPreviewVote(post, expectedVote = null) {
        const button = post.querySelector('.plus-button');
        if (!button) return null;
        const identity = parseVoteEndpoint(button.getAttribute('data-url'));
        if (!identity
            || (expectedVote
                && (identity.kind !== expectedVote.kind || identity.id !== expectedVote.id))) return null;
        return {
            ...identity,
            count: readVoteCount(button),
            active: button.classList.contains('active'),
            canVote: !button.classList.contains('disable'),
        };
    }

    function makePreviewEntry(
        post,
        number = 0,
        expectedVote = null,
        imageBudget = null,
        teamLogoBudget = null,
    ) {
        if (!post) return null;
        const text = extractPreviewPostText(post);
        const images = extractPreviewImages(post, imageBudget);
        if (!text && !images.length) return null;
        const user = extractPreviewUser(post, teamLogoBudget);
        const vote = extractPreviewVote(post, expectedVote);
        const replyIdMatch = post.id?.match(/^r(\d{1,20})$/);
        return {
            author: user.name,
            userId: user.id,
            profileHref: user.profileHref,
            flag: user.flag,
            flair: user.flair,
            text,
            images,
            timestamp: extractTimestampFromRoot(post),
            upvotes: vote?.count ?? null,
            votePath: vote?.path || '',
            reactionKey: vote?.key || '',
            voteActive: Boolean(vote?.active),
            canVote: Boolean(vote?.canVote),
            voteStateFetchedAt: Date.now(),
            replyId: replyIdMatch?.[1] || '',
            shortContextId: '',
            number,
        };
    }

    function resolvePreviewForum(doc, fallbackForumId) {
        const fallback = forumById.get(fallbackForumId);
        if (fallback) return fallback;
        for (const link of doc.querySelectorAll('.forumthread a[href^="/forums/"]')) {
            const url = parseSameOriginUrl(link.getAttribute('href') || link.href);
            if (!url || /^\/forums\/threads\//i.test(url.pathname)) continue;
            const forum = forumByUrl.get(normaliseForumUrl(url.href));
            if (forum) return forum;
        }
        return null;
    }

    function extractPreviewThreadTitle(doc, fallbackTitle) {
        const exact = doc.querySelector('.forumthread > .standard-box > .forum-topbar > .topic');
        const breadcrumbLinks = [...doc.querySelectorAll(
            '.forumthread > .clearfix a[href*="/forums/threads/"], .forumthread a[href*="/forums/threads/"]',
        )];
        const breadcrumb = breadcrumbLinks[breadcrumbLinks.length - 1];
        return cleanText(
            exact?.textContent
            || breadcrumb?.textContent
            || fallbackTitle
            || doc.title,
        ).slice(0, CONFIG.maxThreadTitleChars);
    }

    function previewDocumentThreadIds(doc) {
        const ids = [];
        const addId = (value) => {
            const id = String(value || '');
            if (/^\d{1,20}$/.test(id)) ids.push(id);
        };
        const addHref = (value) => addId(threadIdFromHref(value));
        addId(doc.querySelector('.forumthread[data-thread]')?.dataset.thread);
        addId(doc.querySelector('.forum[data-forum-thread-id]')?.dataset.forumThreadId);
        addHref(
            doc.querySelector('.forumthread[data-original-overlay-location]')
                ?.dataset.originalOverlayLocation,
        );
        addHref(doc.querySelector('link[rel="canonical"][href]')?.getAttribute('href'));
        addHref(
            doc.querySelector(
                '.forumthread > .clearfix a[href*="/forums/threads/"], '
                + '.forumthread > a.last-comment-button[href*="/forums/threads/"]',
            )?.getAttribute('href'),
        );
        return [...new Set(ids)];
    }

    function previewDocumentThreadUrl(doc, threadId) {
        const candidates = [
            doc.querySelector('link[rel="canonical"][href]')?.getAttribute('href'),
            doc.querySelector(
                '.forumthread > .clearfix a[href*="/forums/threads/"], '
                + '.forumthread > a.last-comment-button[href*="/forums/threads/"]',
            )?.getAttribute('href'),
            doc.querySelector('.forumthread[data-original-overlay-location]')
                ?.dataset.originalOverlayLocation,
        ];
        for (const candidate of candidates) {
            const url = parseSameOriginUrl(candidate);
            if (url && threadIdFromHref(url.href) === threadId) return url.href;
        }
        return '';
    }

    function parseThreadPreview(doc, threadId, fallbackForumId, fallbackTitle = '', threadUrl = '') {
        const normalisedThreadId = /^\d{1,20}$/.test(String(threadId || ''))
            ? String(threadId)
            : '';
        const documentThreadIds = previewDocumentThreadIds(doc);
        if (!normalisedThreadId
            || !documentThreadIds.length
            || documentThreadIds.some((id) => id !== normalisedThreadId)) {
            throw new Error('Fetched thread content did not match the requested thread.');
        }
        const forumRoot = doc.querySelector('.forum[data-forum-thread-id]');
        const locked = Boolean(doc.querySelector('.forumthread.locked'));
        const sourceThreadId = String(forumRoot?.dataset.forumThreadId || '');
        const matchingThread = normalisedThreadId
            && (!sourceThreadId || sourceThreadId === normalisedThreadId);
        let opener = doc.querySelector('.forumthread > .standard-box');
        let rawReplies = [...doc.querySelectorAll('.forum[data-forum-thread-id] .post')];
        if (!opener) {
            const fallbackPosts = [...doc.querySelectorAll('.post')];
            opener = fallbackPosts.shift() || null;
            rawReplies = fallbackPosts;
        }
        const replies = rawReplies.map((post, index) => {
            const replyId = post.id?.match(/^r(\d{1,20})$/)?.[1] || '';
            const parentValue = post.closest(
                '.threading[data-threading-reply-parent]',
            )?.getAttribute('data-threading-reply-parent') || '';
            const parentReplyId = parentValue.match(/^r(\d{1,20})$/)?.[1] || '';
            const parsedNumber = Number(
                cleanText(post.querySelector('.replyNum')?.textContent).match(/^#(\d+)$/)?.[1],
            );
            return {
                post,
                index,
                replyId,
                parentReplyId: parentReplyId !== replyId ? parentReplyId : '',
                number: Number.isFinite(parsedNumber) ? parsedNumber : index + 1,
            };
        });
        const replyById = new Map(
            replies.filter((entry) => entry.replyId).map((entry) => [entry.replyId, entry]),
        );
        const replyDepth = (entry) => {
            let depth = 0;
            let parentId = entry.parentReplyId;
            const seen = new Set(entry.replyId ? [entry.replyId] : []);
            while (parentId && replyById.has(parentId) && depth < 20) {
                if (seen.has(parentId)) break;
                seen.add(parentId);
                depth += 1;
                parentId = replyById.get(parentId)?.parentReplyId || '';
            }
            return depth;
        };
        const imageBudget = { remaining: CONFIG.maxPreviewImages };
        const teamLogoBudget = { remaining: CONFIG.maxPreviewTeamLogos };
        const thread = makePreviewEntry(opener, 0, {
            kind: 'thread',
            id: normalisedThreadId,
        }, imageBudget, teamLogoBudget);
        const comments = replies
            .map((entry) => {
                const comment = makePreviewEntry(entry.post, entry.number, {
                    kind: 'reply',
                    id: entry.replyId,
                }, imageBudget, teamLogoBudget);
                if (!comment) return null;
                return {
                    ...comment,
                    parentReplyId: replyById.has(entry.parentReplyId)
                        ? entry.parentReplyId
                        : '',
                    parentNumber: replyById.get(entry.parentReplyId)?.number || 0,
                    threadDepth: replyDepth(entry),
                };
            })
            .filter(Boolean);
        const latestReply = replies.reduce((latest, entry) => (
            !latest || entry.number > latest.number ? entry : latest
        ), null)?.post || opener;
        const maxPostNo = replies.reduce((maximum, reply) => Math.max(maximum, reply.number), 0);
        const forum = resolvePreviewForum(doc, fallbackForumId);
        const replyTextarea = matchingThread
            ? forumRoot?.querySelector('.newreply-con:not(.newReplyBox) textarea.forum-textarea')
            : null;
        const validatedThreadUrl = parseSameOriginUrl(threadUrl);
        const threadHref = previewDocumentThreadUrl(doc, normalisedThreadId)
            || (validatedThreadUrl
            && threadIdFromHref(validatedThreadUrl.href) === normalisedThreadId
            ? validatedThreadUrl.href
            : '');
        if (thread) {
            thread.threadUrl = threadHref;
            thread.locked = locked;
        }
        for (const comment of comments) {
            comment.threadUrl = threadHref;
            comment.locked = locked;
        }
        return {
            threadId: normalisedThreadId,
            threadUrl: threadHref,
            locked,
            currentUserId: extractCurrentUserId(doc) || extractCurrentUserId(),
            forumId: forum?.id || '',
            forumLabel: forum?.label || 'Unknown forum',
            forumColor: forum ? activitySourceColor(forum.id) : CONTENT_TYPE_COLORS.unknown,
            threadTitle: extractPreviewThreadTitle(doc, fallbackTitle),
            thread,
            comments,
            replyCount: replies.length,
            maxPostNo,
            createdAt: opener ? extractTimestampFromRoot(opener) : 0,
            activityAt: latestReply ? extractTimestampFromRoot(latestReply) : 0,
            canReply: !locked && Boolean(replyTextarea),
            replyPlaceholder: cleanText(replyTextarea?.getAttribute('placeholder')).slice(0, 300),
        };
    }

    function setLocalDownvoteButtonVisual(button, active) {
        if (!(button instanceof Element)) return;
        const isActive = Boolean(active);
        const author = cleanText(button.dataset.hltvSpAuthorName) || 'this user';
        const action = isActive ? 'Remove' : 'Add';
        button.classList.toggle('hltv-sp-active', isActive);
        button.setAttribute('aria-pressed', isActive ? 'true' : 'false');
        button.setAttribute('aria-label', `${action} local downvote for ${author}`);
        button.title = `${action} local downvote for ${author}. This is private and is not sent to HLTV.`;
        button.dataset.hltvSpLocalValue = isActive ? '-1' : '0';

        if (button.classList.contains('hltv-sp-native-downvote')) {
            let sign = button.querySelector(':scope > .hltv-sp-minus-icon');
            let wrapper = button.querySelector(':scope > .slide-wrapper');
            if (!sign || !wrapper) {
                sign = document.createElement('span');
                sign.className = 'hltv-sp-minus-icon';
                sign.textContent = '-';
                sign.setAttribute('aria-hidden', 'true');
                wrapper = document.createElement('span');
                wrapper.className = 'slide-wrapper';
                const slideIn = document.createElement('span');
                slideIn.className = 'slide-in hltv-sp-downvote-count';
                slideIn.textContent = '1';
                const slideOut = document.createElement('span');
                slideOut.className = 'slide-out hltv-sp-downvote-count';
                slideOut.textContent = '0';
                wrapper.append(slideIn, slideOut);
                button.replaceChildren(sign, wrapper);
            }
            return;
        }

        let sign = button.querySelector(':scope > .hltv-sp-minus-icon');
        let count = button.querySelector(':scope > .hltv-sp-downvote-count');
        if (!sign || !count) {
            sign = document.createElement('span');
            sign.className = 'hltv-sp-minus-icon';
            sign.textContent = '-';
            sign.setAttribute('aria-hidden', 'true');
            count = document.createElement('span');
            count.className = 'hltv-sp-downvote-count';
            button.replaceChildren(sign, count);
        }
        count.textContent = isActive ? '1' : '0';
    }

    function createPreviewDownvoteButton(entry) {
        if (!state.settings.enableLocalDownvotes
            || !hasPrivateStorage()
            || !entry?.reactionKey
            || !/^\d{1,20}$/.test(entry.userId)) return null;
        const { host, root } = createPrivateUiHost({
            className: 'hltv-sp-private-ui-host hltv-sp-local-downvote hltv-sp-preview-downvote',
            styleText: PRIVATE_UI_STYLES.downvote,
            metadata: {
                reactionKey: entry.reactionKey,
                authorId: entry.userId,
                authorName: entry.author || '',
            },
        });
        host.dataset.hltvSpReactionKey = entry.reactionKey;
        host.dataset.hltvSpAuthorId = entry.userId;
        const downvote = document.createElement('button');
        downvote.type = 'button';
        downvote.className = 'hltv-sp-local-downvote hltv-sp-preview-downvote';
        downvote.dataset.hltvSpReactionKey = entry.reactionKey;
        downvote.dataset.hltvSpAuthorId = entry.userId;
        downvote.dataset.hltvSpAuthorName = entry.author;
        const active = getLocalReactionValue(entry.reactionKey) === -1;
        const pending = state.reactionActionReservations.has(entry.reactionKey)
            || state.pendingReactionActions.has(entry.reactionKey);
        setLocalDownvoteButtonVisual(downvote, active);
        downvote.setAttribute('aria-busy', pending ? 'true' : 'false');
        downvote.disabled = pending || isVoteActionBlocked(entry.reactionKey);
        downvote.addEventListener('click', (event) => {
            event.preventDefault();
            event.stopPropagation();
            handleLocalDownvote(entry, downvote)
                .catch((error) => showPreviewActionError(
                    downvote,
                    localDownvoteErrorMessage(error),
                ));
        });
        root.appendChild(downvote);
        return host;
    }

    function createPreviewActionBar(entry, preview) {
        if (!entry.reactionKey && !Number.isFinite(entry.upvotes)) return null;
        const actions = document.createElement('span');
        actions.className = 'hltv-sp-preview-actions';
        if (entry.reactionKey) actions.dataset.hltvSpReactionKey = entry.reactionKey;

        const downvote = createPreviewDownvoteButton(entry);
        if (downvote) actions.appendChild(downvote);

        if (entry.votePath && Number.isFinite(entry.upvotes)) {
            const upvote = document.createElement('button');
            upvote.type = 'button';
            upvote.className = 'hltv-sp-preview-upvote';
            upvote.classList.toggle('hltv-sp-active', Boolean(entry.voteActive));
            upvote.textContent = entry.upvotes >= 0 ? `+${entry.upvotes}` : String(entry.upvotes);
            upvote.title = entry.canVote
                ? entry.voteActive ? 'Remove your HLTV upvote' : 'Upvote on HLTV'
                : 'Log in and sync your HLTV account with Steam to upvote.';
            upvote.setAttribute('aria-label', upvote.title);
            upvote.setAttribute('aria-pressed', entry.voteActive ? 'true' : 'false');
            upvote.dataset.hltvSpVotePath = entry.votePath;
            upvote.dataset.hltvSpReactionKey = entry.reactionKey;
            upvote.dataset.hltvSpAuthorId = entry.userId;
            upvote.dataset.hltvSpCanVote = entry.canVote ? 'true' : 'false';
            upvote.dataset.plusCount = String(entry.upvotes);
            upvote.dataset.hltvSpServerCount = String(entry.upvotes);
            upvote.dataset.hltvSpServerActive = entry.voteActive ? 'true' : 'false';
            upvote.dataset.hltvSpVoteVerifiedAt = String(entry.voteStateFetchedAt || 0);
            const pending = state.reactionActionReservations.has(entry.reactionKey)
                || state.pendingReactionActions.has(entry.reactionKey);
            upvote.setAttribute('aria-busy', pending ? 'true' : 'false');
            upvote.disabled = pending
                || !previewVoteControlCanAct(upvote)
                || isVoteActionBlocked(entry.reactionKey);
            upvote.addEventListener('click', () => {
                handlePreviewVote(entry, preview, upvote)
                    .catch((error) => showPreviewActionError(upvote, actionErrorMessage(error)));
            });
            actions.appendChild(upvote);
            applyProvisionalVoteVisual(upvote, entry.reactionKey);
        }

        return actions.childElementCount ? actions : null;
    }

    function appendFormattedPreviewText(container, value) {
        const lines = String(value || '').replace(/\r\n?/g, '\n').split('\n');
        for (let index = 0; index < lines.length;) {
            if (!lines[index].startsWith('>')) {
                container.appendChild(document.createTextNode(lines[index]));
                index += 1;
                if (index < lines.length) container.appendChild(document.createTextNode('\n'));
                continue;
            }
            const quoted = [];
            while (index < lines.length && lines[index].startsWith('>')) {
                quoted.push(lines[index].slice(1).replace(/^ /, ''));
                index += 1;
            }
            const quote = document.createElement('blockquote');
            quote.className = 'hltv-sp-quote-line';
            quote.textContent = quoted.join('\n');
            container.appendChild(quote);
            if (index < lines.length) container.appendChild(document.createTextNode('\n'));
        }
    }

    function appendPreviewImages(container, entry) {
        const descriptors = Array.isArray(entry?.images)
            ? entry.images.slice(0, CONFIG.maxPreviewImagesPerPost)
            : [];
        if (!descriptors.length) return;
        const gallery = document.createElement('div');
        gallery.className = 'hltv-sp-preview-embeds';
        for (const descriptor of descriptors) {
            const sourceUrl = parsePreviewAssetUrl(descriptor?.src, 'gallery');
            const galleryUrl = parseSameOriginUrl(descriptor?.href);
            if (!sourceUrl
                || !galleryUrl
                || !/^\/gallery\/view\/\d{1,20}\/?$/i.test(galleryUrl.pathname)) continue;
            const link = document.createElement('a');
            link.className = 'hltv-sp-preview-embed-link';
            link.href = galleryUrl.href;
            link.target = '_blank';
            link.rel = 'noopener noreferrer';
            link.title = 'Open image in the HLTV gallery';
            const image = document.createElement('img');
            image.className = 'hltv-sp-preview-embed-image';
            image.alt = cleanText(descriptor.alt).slice(0, 200)
                || 'Embedded image by ' + entry.author;
            image.loading = 'lazy';
            image.decoding = 'async';
            image.referrerPolicy = 'no-referrer';
            image.src = sourceUrl.href;
            link.appendChild(image);
            gallery.appendChild(link);
        }
        if (gallery.childElementCount) container.appendChild(gallery);
    }

    function buildPreviewCommentTopology(comments) {
        const nodes = (Array.isArray(comments) ? comments : []).map((entry, index) => ({
            entry,
            index,
            parent: null,
            children: [],
            ancestorReplyIds: [],
            depth: 0,
            descendantCount: 0,
            minDescendantNumber: Number.POSITIVE_INFINITY,
            card: null,
        }));
        const replyIdCounts = new Map();
        for (const node of nodes) {
            const replyId = String(node.entry?.replyId || '');
            if (!/^[1-9]\d{0,19}$/.test(replyId)) continue;
            replyIdCounts.set(replyId, (replyIdCounts.get(replyId) || 0) + 1);
        }
        const nodeByReplyId = new Map();
        for (const node of nodes) {
            const replyId = String(node.entry?.replyId || '');
            if (replyIdCounts.get(replyId) === 1) nodeByReplyId.set(replyId, node);
        }

        const roots = [];
        for (const node of nodes) {
            const candidate = nodeByReplyId.get(String(node.entry?.parentReplyId || ''));
            const parent = candidate
                && candidate.index < node.index
                && candidate.depth < 20
                ? candidate
                : null;
            if (!parent) {
                roots.push(node);
                continue;
            }
            node.parent = parent;
            node.depth = parent.depth + 1;
            node.ancestorReplyIds = [
                ...parent.ancestorReplyIds,
                parent.entry.replyId,
            ];
            parent.children.push(node);
        }

        for (let index = nodes.length - 1; index >= 0; index -= 1) {
            const node = nodes[index];
            for (const child of node.children) {
                node.descendantCount += 1 + child.descendantCount;
                const childNumber = Number(child.entry?.number);
                if (Number.isFinite(childNumber) && childNumber > 0) {
                    node.minDescendantNumber = Math.min(
                        node.minDescendantNumber,
                        childNumber,
                    );
                }
                node.minDescendantNumber = Math.min(
                    node.minDescendantNumber,
                    child.minDescendantNumber,
                );
            }
        }

        return {
            roots,
            nodes,
            nodeByEntry: new Map(nodes.map((node) => [node.entry, node])),
            nodeByReplyId,
        };
    }

    function createPreviewPost(entry, className, label, preview, topologyNode = null) {
        const card = document.createElement('div');
        card.className = className;
        if (entry.userId) card.dataset.hltvSpAuthorId = entry.userId;
        if (entry.reactionKey) card.dataset.hltvSpReactionKey = entry.reactionKey;
        if (entry.replyId) card.dataset.hltvSpReplyId = entry.replyId;
        if (className.includes('hltv-sp-preview-comment')) {
            const depth = topologyNode
                ? topologyNode.depth
                : Math.max(0, Math.min(20, Number(entry.threadDepth) || 0));
            const parentReplyId = topologyNode
                ? topologyNode.parent?.entry.replyId || ''
                : entry.parentReplyId;
            card.dataset.hltvSpThreadDepth = String(depth);
            card.style.setProperty('--hltv-sp-thread-depth', String(Math.min(depth, 6)));
            if (parentReplyId) {
                card.dataset.hltvSpParentReplyId = parentReplyId;
            }
        }
        const meta = document.createElement('div');
        meta.className = 'hltv-sp-preview-post-meta';
        const authorMeta = document.createElement('span');
        authorMeta.className = 'hltv-sp-preview-author-meta';
        authorMeta.appendChild(document.createTextNode(label === null ? 'Original post \u00B7 ' : label));
        const parentNumber = topologyNode
            ? topologyNode.parent?.entry.number || 0
            : entry.parentNumber;
        if (label !== null && Number(parentNumber) > 0) {
            const parent = document.createElement('span');
            parent.className = 'hltv-sp-preview-parent-reference';
            parent.textContent = `reply to #${parentNumber} \u00B7 `;
            authorMeta.appendChild(parent);
        }
        const flairUrl = parseSameOriginUrl(entry.flair?.href);
        const flairLabel = cleanText(entry.flair?.label).slice(0, 100);
        if (flairUrl
            && /^\/(?:player|team)\/\d{1,20}(?:\/|$)/i.test(flairUrl.pathname)
            && flairLabel) {
            const flair = document.createElement('a');
            flair.className = 'hltv-sp-preview-user-flair';
            flair.href = flairUrl.href;
            flair.title = cleanText(entry.flair?.title).slice(0, 150)
                || 'fan of ' + flairLabel;
            const logoUrl = entry.flair?.kind === 'team'
                ? parsePreviewAssetUrl(entry.flair.logoSrc, 'flair')
                : null;
            if (logoUrl) {
                const logo = document.createElement('img');
                logo.className = 'hltv-sp-preview-user-flair-logo';
                logo.alt = '';
                logo.loading = 'lazy';
                logo.decoding = 'async';
                logo.referrerPolicy = 'no-referrer';
                logo.src = logoUrl.href;
                flair.appendChild(logo);
            } else if (entry.flair?.kind === 'player') {
                const heart = document.createElement('span');
                heart.textContent = '\u2665';
                heart.setAttribute('aria-hidden', 'true');
                flair.appendChild(heart);
            }
            const flairText = document.createElement('span');
            flairText.className = 'hltv-sp-preview-user-flair-label';
            flairText.textContent = flairLabel;
            flair.appendChild(flairText);
            authorMeta.appendChild(flair);
        }
        const flagUrl = parsePreviewAssetUrl(entry.flag?.src, 'flag');
        if (flagUrl) {
            const flag = document.createElement('img');
            const flagName = cleanText(entry.flag?.name).slice(0, 100);
            flag.className = 'hltv-sp-preview-user-flag';
            flag.alt = flagName;
            flag.title = flagName;
            flag.loading = 'lazy';
            flag.decoding = 'async';
            flag.referrerPolicy = 'no-referrer';
            flag.src = flagUrl.href;
            authorMeta.appendChild(flag);
        }
        const profileUrl = parseSameOriginUrl(entry.profileHref);
        const author = profileUrl && /^\/profile\/\d{1,20}(?:\/|$)/i.test(profileUrl.pathname)
            ? document.createElement('a')
            : document.createElement('span');
        if (author.tagName === 'A') {
            author.href = profileUrl.href;
            author.className = 'a-default';
        }
        author.dataset.hltvSpPreviewAuthor = 'true';
        const openerUserId = String(preview?.thread?.userId || '');
        const entryUserId = String(entry.userId || '');
        if (state.settings.enableOriginalPosterHighlight
            && /^[1-9]\d{0,19}$/.test(openerUserId)
            && entryUserId === openerUserId) {
            author.classList.add('hltv-sp-original-poster-author');
        }
        const renderedFlair = authorMeta.querySelector(':scope > .hltv-sp-preview-user-flair');
        author.textContent = entry.author;
        authorMeta.appendChild(author);
        if (renderedFlair) author.after(renderedFlair);
        if (state.settings.enableLocalUserScores && entry.userId) {
            author.dataset.hltvSpScoreTarget = entry.userId;
            authorMeta.appendChild(createLocalScoreBadge(entry.userId));
        }
        if (entry.userId) {
            authorMeta.appendChild(createPreviewUserTagSlot({ id: entry.userId, name: entry.author }));
        }
        if (entry.timestamp) {
            authorMeta.appendChild(document.createTextNode(' \u00B7 '));
            const previewAge = document.createElement('span');
            previewAge.className = 'hltv-sp-preview-relative-age';
            previewAge.dataset.hltvSpTimestamp = String(entry.timestamp);
            previewAge.textContent = formatRelativeAge(entry.timestamp);
            previewAge.title = new Date(entry.timestamp).toLocaleString();
            authorMeta.appendChild(previewAge);
        }
        meta.appendChild(authorMeta);
        const actions = createPreviewActionBar(entry, preview);
        if (actions) meta.appendChild(actions);
        const content = document.createElement('div');
        content.className = 'hltv-sp-preview-post-text';
        appendFormattedPreviewText(content, entry.text);
        appendPreviewImages(content, entry);
        card.append(meta, content);

        const footer = document.createElement('div');
        footer.className = 'hltv-sp-preview-post-footer';
        const status = document.createElement('span');
        status.className = 'hltv-sp-preview-action-status';
        status.setAttribute('aria-live', 'polite');
        footer.appendChild(status);
        if (preview.canReply) {
            const reply = document.createElement('button');
            reply.type = 'button';
            reply.className = 'hltv-sp-preview-reply';
            reply.textContent = 'Reply';
            reply.addEventListener('click', () => {
                activatePreviewReplyComposer(preview, entry, card);
            });
            footer.appendChild(reply);
        }
        card.appendChild(footer);
        return card;
    }

    function activatePreviewReplyComposer(preview, entry, card) {
        const panel = state.previewPanel;
        if (!panel || state.previewData !== preview) return;
        const targetReplyId = entry?.replyId || '';
        const composers = [...panel.querySelectorAll('.hltv-sp-preview-composer')];
        let composer = composers.find((candidate) => (
            candidate.dataset.hltvSpReplyId === targetReplyId
        ));

        if (!composer) {
            while (composers.length >= CONFIG.maxPreviewDraftComposers) {
                const disposableIndex = composers.findIndex((candidate) => {
                    const field = previewReplyFields.get(candidate);
                    const post = privateUiControl(candidate, '.hltv-sp-preview-composer-post');
                    return !field?.hasDraft && !post?.disabled;
                });
                if (disposableIndex < 0) break;
                const [disposable] = composers.splice(disposableIndex, 1);
                previewReplyFields.get(disposable)?.dispose();
                previewReplyFields.delete(disposable);
                const draftBinding = previewDraftBindings.get(disposable);
                if (draftBinding) detachDraftBinding(draftBinding);
                disposable.remove();
            }
            if (composers.length >= CONFIG.maxPreviewDraftComposers) {
                const active = composers.find((candidate) => !candidate.hidden);
                const surface = privateUiControl(active, '.hltv-sp-preview-composer-surface');
                const status = surface?.querySelector('.hltv-sp-preview-composer-status');
                if (status) {
                    status.classList.add('hltv-sp-error');
                    status.textContent = 'This preview already contains '
                        + CONFIG.maxPreviewDraftComposers
                        + ' saved reply drafts. Post or clear one before starting another.';
                }
                previewReplyFields.get(active)?.focus();
                return;
            }
            composer = createPreviewReplyComposer(preview, targetReplyId ? entry : null);
            if (targetReplyId && card) card.appendChild(composer);
            else placePreviewThreadComposer(composer);
        }

        for (const candidate of panel.querySelectorAll('.hltv-sp-preview-composer')) {
            candidate.hidden = candidate !== composer;
        }
        composer.hidden = false;
        composer.dataset.hltvSpActivatedAt = String(Date.now());
        const surface = privateUiControl(composer, '.hltv-sp-preview-composer-surface');
        state.previewProgrammaticScrollUntil = Date.now() + 500;
        surface?.scrollIntoView({ block: 'nearest' });
        previewReplyFields.get(composer)?.focus();
        positionThreadPreview();
    }

    function placePreviewThreadComposer(composer) {
        const panel = state.previewPanel;
        if (!(composer instanceof Element) || !panel) return;
        const originalPost = panel.querySelector(':scope > .hltv-sp-preview-thread');
        if (state.settings.replyComposerAfterOriginalPost && originalPost) {
            if (originalPost.nextElementSibling !== composer) originalPost.after(composer);
        } else if (panel.lastElementChild !== composer) {
            panel.appendChild(composer);
        }
    }

    function makeActionError(message, publicMessage = '', options = {}) {
        const error = new Error(message);
        error.name = 'ActionError';
        error.publicMessage = publicMessage || message;
        error.ambiguousOutcome = Boolean(options.ambiguousOutcome);
        return error;
    }

    function actionErrorMessage(error) {
        const message = error?.publicMessage || 'The action failed. Please try again.';
        return cleanText(message).slice(0, CONFIG.maxActionErrorChars);
    }

    function localDownvoteErrorMessage(error) {
        if (error?.publicMessage) return actionErrorMessage(error);
        return 'The local downvote could not be saved. No vote was sent to HLTV.';
    }

    let inertHtmlSanitizer = null;

    function getInertHtmlSanitizer() {
        if (inertHtmlSanitizer) return inertHtmlSanitizer;
        if (typeof Sanitizer !== 'function') {
            throw new Error('Secure HTML parsing requires Firefox 148 or newer.');
        }

        inertHtmlSanitizer = new Sanitizer({
            removeElements: [
                'applet',
                'audio',
                'base',
                'embed',
                'frame',
                'frameset',
                'iframe',
                'link',
                'meta',
                'noscript',
                'object',
                'portal',
                'script',
                'source',
                'style',
                'track',
                'video',
                {
                    name: 'svg',
                    namespace: 'http://www.w3.org/2000/svg',
                },
                {
                    name: 'math',
                    namespace: 'http://www.w3.org/1998/Math/MathML',
                },
            ],
            removeAttributes: [
                'background',
                'data',
                'imagesizes',
                'imagesrcset',
                'manifest',
                'ping',
                'poster',
                'src',
                'srcset',
                'style',
            ],
            comments: false,
        });
        return inertHtmlSanitizer;
    }

    function neutraliseInertImageAttributes(value) {
        const html = String(value ?? '');
        return html
            .replace(/(\s)srcset(\s*=)/gi, '$1data-hltv-sp-inert-srcset$2')
            .replace(/(\s)src(\s*=)/gi, '$1data-hltv-sp-inert-src$2');
    }

    function parseInertHtmlDocument(value) {
        const template = document.createElement('template');
        // Resource URLs are first moved to inert data attributes. Firefox's
        // safe HTML setter then strips executable markup and any resource
        // attributes that were not neutralised before parsing the fragment.
        template.setHTML(neutraliseInertImageAttributes(value), {
            sanitizer: getInertHtmlSanitizer(),
        });
        const fragment = template.content;
        const querySelector = fragment.querySelector.bind(fragment);
        const querySelectorAll = fragment.querySelectorAll.bind(fragment);
        const title = cleanText(querySelector('title')?.textContent || '');
        return Object.freeze({
            contentType: 'text/html',
            title,
            body: fragment,
            querySelector,
            querySelectorAll,
        });
    }

    function htmlErrorToPlainText(value) {
        const html = String(value || '').slice(0, 50_000);
        if (!html) return '';
        try {
            const doc = parseInertHtmlDocument(html);
            return cleanText(doc.body?.textContent).slice(0, CONFIG.maxActionErrorChars);
        } catch {
            return cleanText(html.replace(/<[^>]*>/g, ' ')).slice(0, CONFIG.maxActionErrorChars);
        }
    }

    function resolveReplyRedirect(value, threadId) {
        const redirectUrl = parseSameOriginUrl(value);
        if (!redirectUrl) return null;
        if (threadIdFromHref(redirectUrl.href) === String(threadId)) return redirectUrl;
        if (redirectUrl.pathname !== '/internalredirect') return null;
        const relativeUrl = redirectUrl.searchParams.get('relativeUrl');
        const destination = parseSameOriginUrl(relativeUrl);
        return destination && threadIdFromHref(destination.href) === String(threadId)
            ? destination
            : null;
    }

    function validatedThreadReferrer(value, threadId = '') {
        const url = parseSameOriginUrl(value);
        if (!url || !/^\/forums\/threads\/\d+(?:\/|$)/i.test(url.pathname)) return '';
        if (threadId && threadIdFromHref(url.href) !== String(threadId)) return '';
        url.hash = '';
        return url.href;
    }

    async function postVoteToggle(votePath, threadUrl = '') {
        const vote = parseVoteEndpoint(votePath);
        if (!vote || typeof safeFetch !== 'function') {
            throw makeActionError('Invalid vote endpoint.', 'This vote control is unavailable.');
        }
        const scope = createRequestAbortScope(CONFIG.requestTimeoutMs);
        try {
            const requestOptions = {
                method: 'POST',
                credentials: 'include',
                cache: 'no-store',
                mode: 'same-origin',
                redirect: 'error',
                signal: scope.signal,
                headers: {
                    Accept: '*/*',
                    'X-Requested-With': 'XMLHttpRequest',
                },
            };
            const referrer = validatedThreadReferrer(threadUrl);
            if (referrer) requestOptions.referrer = referrer;
            const response = await safeFetch(`${HLTV_ORIGIN}${vote.path}`, requestOptions);
            const status = Number(response.status || 0);
            if (!(status >= 200 && status < 300)) {
                const ambiguousOutcome = status === 0 || status === 408 || status >= 500;
                throw makeActionError(
                    `Vote request returned HTTP ${status}.`,
                    ambiguousOutcome
                        ? `HLTV returned HTTP ${status} after receiving the vote. It may have been applied. For safety, wait one minute and reload this page.`
                        : status === 401 || status === 403
                            ? 'HLTV rejected the vote. Check that you are logged in and Steam-synced.'
                            : status === 429
                                ? 'HLTV is rate-limiting votes. Please wait before trying again.'
                                : `HLTV rejected the vote (HTTP ${status}).`,
                    { ambiguousOutcome },
                );
            }
            if (response.url) {
                const responseUrl = parseSameOriginUrl(response.url);
                if (!responseUrl || responseUrl.pathname !== vote.path) {
                    throw makeActionError(
                        'Vote request redirected unexpectedly.',
                        'HLTV returned an unexpected response after receiving the vote. For safety, wait one minute and reload this page.',
                        { ambiguousOutcome: true },
                    );
                }
            }
            return vote;
        } catch (error) {
            if (scope.didTimeOut()) {
                throw makeActionError(
                    'Vote request timed out.',
                    'The vote timed out and may have reached HLTV. For safety, wait one minute and reload this page.',
                    { ambiguousOutcome: true },
                );
            }
            if (error?.name === 'ActionError') throw error;
            throw makeActionError(
                `Vote request failed: ${error instanceof Error ? error.message : String(error)}`,
                'The connection was lost after sending the vote. It may have reached HLTV. For safety, wait one minute and reload this page.',
                { ambiguousOutcome: true },
            );
        } finally {
            scope.cleanup();
        }
    }

    async function postForumReply({
        threadId,
        replyId = '',
        message,
        shortContextId = '',
        threadUrl = '',
    }) {
        const normalisedMessage = typeof message === 'string'
            ? message
            : String(message ?? '');
        if (!/^\d{1,20}$/.test(String(threadId || ''))
            || (replyId && !/^\d{1,20}$/.test(String(replyId)))
            || (shortContextId && !/^\d{1,20}$/.test(String(shortContextId)))
            || typeof safeFetch !== 'function') {
            throw makeActionError('Invalid reply target.', 'This reply target is unavailable.');
        }
        if (normalisedMessage.length > CONFIG.maxReplyChars) {
            throw makeActionError(
                'Reply exceeds the local size limit.',
                `Replies are limited to ${CONFIG.maxReplyChars.toLocaleString('en-US')} characters.`,
            );
        }

        const body = new URLSearchParams();
        body.set('threadId', String(threadId));
        body.set('replyId', String(replyId || ''));
        body.set('message', normalisedMessage);
        if (shortContextId) body.set('shortContextId', String(shortContextId));
        const scope = createRequestAbortScope(CONFIG.requestTimeoutMs);
        try {
            const requestOptions = {
                method: 'POST',
                body,
                credentials: 'include',
                cache: 'no-store',
                mode: 'same-origin',
                redirect: 'error',
                signal: scope.signal,
                headers: {
                    Accept: '*/*',
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'X-Requested-With': 'XMLHttpRequest',
                },
            };
            const referrer = validatedThreadReferrer(threadUrl, threadId);
            if (referrer) requestOptions.referrer = referrer;
            const response = await safeFetch(`${HLTV_ORIGIN}/forums/reply`, requestOptions);
            const status = Number(response.status || 0);
            if (!(status >= 200 && status < 300)) {
                const ambiguousOutcome = status === 0 || status === 408 || status >= 500;
                throw makeActionError(
                    `Reply request returned HTTP ${status}.`,
                    ambiguousOutcome
                        ? `HLTV returned HTTP ${status} after receiving the reply. It may have posted. For safety, wait one minute and reload this page.`
                        : status === 401 || status === 403
                            ? 'HLTV rejected the reply. Check that you are logged in.'
                            : status === 429
                                ? 'HLTV is rate-limiting replies. Please wait before trying again.'
                                : `HLTV rejected the reply (HTTP ${status}).`,
                    { ambiguousOutcome },
                );
            }
            if (response.url) {
                const responseUrl = parseSameOriginUrl(response.url);
                if (!responseUrl || responseUrl.pathname !== '/forums/reply') {
                    throw makeActionError(
                        'Reply request redirected unexpectedly.',
                        'HLTV returned an unexpected redirect after receiving the reply. It may have posted. For safety, wait one minute and reload this page.',
                        { ambiguousOutcome: true },
                    );
                }
            }
            const text = await readBoundedUtf8Response(response, {
                label: 'Reply response',
                maxBytes: CONFIG.maxReplyResponseBytes,
                maxChars: CONFIG.maxReplyResponseChars,
                expectedContentTypes: ['application/json'],
                makeError: (message) => makeActionError(
                    message,
                    'HLTV returned an unexpected response after receiving the reply. It may have posted. For safety, wait one minute and reload this page.',
                    { ambiguousOutcome: true },
                ),
            });
            let result;
            try {
                result = JSON.parse(text);
            } catch {
                throw makeActionError(
                    'Reply response was not JSON.',
                    'HLTV returned an unexpected response after receiving the reply. It may have posted. For safety, wait one minute and reload this page.',
                    { ambiguousOutcome: true },
                );
            }
            const redirectUrl = resolveReplyRedirect(result?.redirectTo, threadId);
            if (redirectUrl) {
                return { redirectTo: redirectUrl.href };
            }
            const serverError = htmlErrorToPlainText(result?.errorMessageHtml);
            if (result?.redirectTo && !serverError) {
                throw makeActionError(
                    'HLTV returned an unsafe or invalid reply redirect.',
                    'HLTV returned an unexpected confirmation after receiving the reply. It may have posted. For safety, wait one minute and reload this page.',
                    { ambiguousOutcome: true },
                );
            }
            throw makeActionError(
                'HLTV did not confirm the reply.',
                serverError || 'HLTV did not accept the reply.',
                { ambiguousOutcome: !serverError },
            );
        } catch (error) {
            if (scope.didTimeOut()) {
                throw makeActionError(
                    'Reply request timed out.',
                    'The reply timed out and may have posted. For safety, wait one minute and reload this page.',
                    { ambiguousOutcome: true },
                );
            }
            if (error?.name === 'ActionError') throw error;
            throw makeActionError(
                `Reply request failed: ${error instanceof Error ? error.message : String(error)}`,
                'The connection was lost after sending. The reply may have posted. For safety, wait one minute and reload this page.',
                { ambiguousOutcome: true },
            );
        } finally {
            scope.cleanup();
        }
    }

    function findUsernamePrefix(textarea) {
        const cursor = Number(textarea.selectionStart);
        if (!Number.isFinite(cursor)) return null;
        const before = textarea.value.slice(0, cursor);
        const atIndex = before.lastIndexOf('@');
        if (atIndex < 0) return null;
        const prefix = before.slice(atIndex + 1);
        if (!prefix
            || prefix.length > 100
            || prefix.includes('\u2063')
            || /[\r\n]/.test(prefix)) return null;
        return {
            prefix,
            start: atIndex,
            end: cursor,
        };
    }

    async function fetchUsernameSuggestions(prefix, signal, threadUrl = '') {
        if (typeof safeFetch !== 'function') return [];
        const requestUrl = new URL('/usernameprefixsearch', HLTV_ORIGIN);
        requestUrl.searchParams.set('prefix', prefix);
        const scope = createRequestAbortScope(8000, signal);
        try {
            const requestOptions = {
                method: 'GET',
                credentials: 'include',
                cache: 'no-store',
                mode: 'same-origin',
                redirect: 'error',
                signal: scope.signal,
                headers: {
                    Accept: 'application/json,*/*;q=0.8',
                    'X-Requested-With': 'XMLHttpRequest',
                },
            };
            const referrer = validatedThreadReferrer(threadUrl);
            if (referrer) requestOptions.referrer = referrer;
            const response = await safeFetch(requestUrl.href, requestOptions);
            if (!response.ok || (response.url && !parseSameOriginUrl(response.url))) return [];
            const text = await readBoundedUtf8Response(response, {
                label: 'Username suggestion response',
                maxBytes: CONFIG.maxUsernameResponseBytes,
                maxChars: CONFIG.maxUsernameResponseChars,
                expectedContentTypes: ['application/json'],
            });
            const result = JSON.parse(text);
            if (!Array.isArray(result?.usernames)) return [];
            const names = [];
            const seen = new Set();
            for (const rawName of result.usernames) {
                const name = typeof rawName === 'string' ? rawName : '';
                if (!name
                    || name.length > 100
                    || /[\u0000-\u001f\u007f\u2063]/.test(name)
                    || seen.has(name)) continue;
                seen.add(name);
                names.push(name);
                if (names.length >= CONFIG.maxUsernameSuggestions) break;
            }
            return names;
        } catch (error) {
            if (!isAbortErrorLike(error) && !signal?.aborted) log('Username suggestions failed.', error);
            return [];
        } finally {
            scope.cleanup();
        }
    }

    function setupPreviewUsernameSuggestions(textarea, popup, threadUrl = '') {
        let timer = null;
        let controller = null;
        let generation = 0;
        let activeIndex = -1;

        const close = () => {
            generation += 1;
            window.clearTimeout(timer);
            controller?.abort();
            controller = null;
            activeIndex = -1;
            popup.classList.remove('hltv-sp-open');
            popup.replaceChildren();
        };
        const renderActiveOption = () => {
            const options = [...popup.querySelectorAll('button')];
            options.forEach((option, index) => {
                option.classList.toggle('hltv-sp-selected', index === activeIndex);
            });
        };
        const insertUsername = (name) => {
            const current = findUsernamePrefix(textarea);
            if (!current) return;
            textarea.setRangeText(`@${name}\u2063`, current.start, current.end, 'end');
            textarea.dispatchEvent(new Event('input', { bubbles: true }));
            close();
            textarea.focus();
        };
        const update = () => {
            window.clearTimeout(timer);
            controller?.abort();
            controller = null;
            const prefix = findUsernamePrefix(textarea);
            if (!prefix) {
                close();
                return;
            }
            const currentGeneration = ++generation;
            timer = window.setTimeout(async () => {
                const requestController = new AbortController();
                controller = requestController;
                const names = await fetchUsernameSuggestions(
                    prefix.prefix,
                    requestController.signal,
                    threadUrl,
                );
                if (currentGeneration !== generation
                    || requestController.signal.aborted
                    || findUsernamePrefix(textarea)?.prefix !== prefix.prefix) return;
                popup.replaceChildren();
                for (const name of names) {
                    const option = document.createElement('button');
                    option.type = 'button';
                    option.textContent = name;
                    option.addEventListener('mousedown', (event) => event.preventDefault());
                    option.addEventListener('mouseenter', () => {
                        activeIndex = names.indexOf(name);
                        renderActiveOption();
                    });
                    option.addEventListener('click', () => insertUsername(name));
                    popup.appendChild(option);
                }
                activeIndex = names.length ? 0 : -1;
                renderActiveOption();
                popup.classList.toggle('hltv-sp-open', Boolean(names.length));
                popup.style.top = `${textarea.offsetTop + textarea.offsetHeight}px`;
            }, 180);
        };

        textarea.addEventListener('input', update);
        textarea.addEventListener('click', update);
        textarea.addEventListener('keydown', (event) => {
            const options = [...popup.querySelectorAll('button')];
            if (event.key === 'Escape') {
                close();
            } else if (options.length && (event.key === 'ArrowDown' || event.key === 'ArrowUp')) {
                event.preventDefault();
                const direction = event.key === 'ArrowDown' ? 1 : -1;
                activeIndex = (activeIndex + direction + options.length) % options.length;
                renderActiveOption();
                options[activeIndex]?.scrollIntoView({ block: 'nearest' });
            } else if (options.length && event.key === 'Enter' && activeIndex >= 0) {
                event.preventDefault();
                insertUsername(options[activeIndex].textContent);
            }
        });
        textarea.addEventListener('blur', () => window.setTimeout(close, 120));
    }

    function extensionReplyFieldApi() {
        const api = globalThis.HLTV_SP_EXTENSION?.replyFields;
        return api && typeof api.create === 'function' ? api : null;
    }

    function isFirefoxExtensionEnvironment() {
        return globalThis.HLTV_SP_EXTENSION?.environment === 'firefox-extension'
            || Boolean(capturedFirefoxExtensionRuntime);
    }

    function disposePreviewReplyFields(scope = state.previewPanel) {
        if (!scope?.querySelectorAll) return;
        for (const host of scope.querySelectorAll('.hltv-sp-preview-composer')) {
            previewReplyFields.get(host)?.dispose();
            previewReplyFields.delete(host);
            const draftBinding = previewDraftBindings.get(host);
            if (draftBinding) detachDraftBinding(draftBinding);
        }
    }

    function createFallbackPreviewReplyField({
        textarea,
        suggestions,
        threadUrl,
    }) {
        setupPreviewUsernameSuggestions(textarea, suggestions, threadUrl);
        return {
            available: true,
            get hasDraft() {
                return Boolean(textarea.value);
            },
            focus() {
                textarea.focus();
            },
            setDisabled(value) {
                textarea.disabled = Boolean(value);
            },
            requestText() {
                return Promise.resolve(String(textarea.value || ''));
            },
            restoreText(value) {
                if (textarea.value) return Promise.resolve(false);
                textarea.value = String(value ?? '');
                textarea.dispatchEvent(new Event('input', { bubbles: true }));
                return Promise.resolve(true);
            },
            clear() {
                textarea.value = '';
                textarea.blur();
                suggestions.classList.remove('hltv-sp-open');
                suggestions.replaceChildren();
            },
            dispose() {},
        };
    }

    function createExtensionPreviewReplyField({
        iframe,
        preview,
        label,
        placeholder,
        onClick,
    }) {
        const api = extensionReplyFieldApi();
        if (!api) return null;
        let prefixController = null;
        const session = api.create({
            placeholder,
            label,
            onClick,
            onDraftState() {
                schedulePreviewCloseAfterInteraction();
            },
            onPrefixRequest(prefix) {
                prefixController?.abort();
                prefixController = new AbortController();
                return fetchUsernameSuggestions(
                    prefix,
                    prefixController.signal,
                    preview.threadUrl,
                );
            },
        });
        iframe.src = session.url;
        return {
            available: true,
            get hasDraft() {
                return Boolean(session.hasDraft);
            },
            focus() {
                try {
                    session.focus();
                } catch {
                    // The packaged field may still be connecting.
                }
            },
            setDisabled(value) {
                try {
                    session.setDisabled(Boolean(value));
                } catch {
                    // A disconnected field is handled on the next interaction.
                }
            },
            requestText() {
                return session.requestText();
            },
            restoreText(value) {
                return session.restoreText(value);
            },
            clear() {
                session.clear();
            },
            dispose() {
                prefixController?.abort();
                prefixController = null;
                session.dispose();
            },
        };
    }

    function createUnavailablePreviewReplyField(message) {
        return {
            available: false,
            hasDraft: false,
            focus() {},
            setDisabled() {},
            requestText() {
                return Promise.reject(new Error(message));
            },
            restoreText() {
                return Promise.reject(new Error(message));
            },
            clear() {},
            dispose() {},
        };
    }

    function savedDraftPublicError(error) {
        return cleanText(error?.publicMessage || error?.message || 'The draft could not be saved.')
            .slice(0, CONFIG.maxActionErrorChars);
    }

    function currentDraftPageTitle() {
        return cleanText(
            document.querySelector('.forumthread > .standard-box .topic')?.textContent
            || document.querySelector('h1')?.textContent
            || document.title,
        ).slice(0, CONFIG.maxThreadTitleChars);
    }

    function replyDraftDescriptorForNativeComposer(composer) {
        if (!(composer instanceof Element)) return null;
        const forum = composer.closest('.forum[data-forum-thread-id]');
        const threadId = String(forum?.getAttribute('data-forum-thread-id') || '');
        const threaded = composer.classList.contains('threading');
        const replyId = threaded ? String(composer.dataset.hltvSpNativeReplyId || '') : '';
        if (!/^\d{1,20}$/.test(threadId)
            || (threaded && !/^\d{1,20}$/.test(replyId))) return null;
        const replyNumber = replyId
            ? cleanText(document.getElementById(`r${replyId}`)?.querySelector('.replyNum')?.textContent)
            : '';
        return {
            kind: 'reply',
            accountId: extractCurrentUserId(),
            threadId,
            replyId,
            path: location.pathname,
            title: currentDraftPageTitle(),
            context: replyId
                ? `Reply to ${replyNumber || 'a comment'}`
                : 'Reply to thread',
        };
    }

    function replyDraftDescriptorForPreview(preview, entry = null) {
        const threadUrl = parseSameOriginUrl(preview?.threadUrl);
        const threadId = String(preview?.threadId || '');
        const replyId = String(entry?.replyId || '');
        if (!threadUrl
            || !/^\d{1,20}$/.test(threadId)
            || (replyId && !/^\d{1,20}$/.test(replyId))) return null;
        return {
            kind: 'reply',
            accountId: extractCurrentUserId(),
            threadId,
            replyId,
            path: threadUrl.pathname,
            title: cleanText(preview.threadTitle).slice(0, CONFIG.maxThreadTitleChars),
            context: replyId
                ? `Reply to #${Number(entry?.number) || '?'}${entry?.author ? ` · ${cleanText(entry.author).slice(0, 100)}` : ''}`
                : 'Reply to thread',
        };
    }

    function topicDraftDescriptor(form) {
        if (!(form instanceof HTMLFormElement)) return null;
        const subject = form.elements.namedItem('subject');
        const forum = form.elements.namedItem('forum');
        const body = form.elements.namedItem('topic');
        if (!(subject instanceof HTMLInputElement)
            || !(forum instanceof HTMLSelectElement)
            || !(body instanceof HTMLTextAreaElement)) return null;
        return {
            kind: 'topic',
            accountId: extractCurrentUserId(),
            path: '/forums/create-thread',
            title: cleanText(subject.value || 'Untitled topic').slice(
                0,
                CONFIG.maxThreadTitleChars,
            ),
            context: forum.selectedOptions[0]?.textContent
                ? `New topic in ${cleanText(forum.selectedOptions[0].textContent).slice(0, 100)}`
                : 'New forum topic',
            subject: subject.value,
            forumId: forum.value,
            forumLabel: cleanText(forum.selectedOptions[0]?.textContent).slice(0, 100),
            body: body.value,
        };
    }

    function savedDraftEntryForBinding(binding) {
        const descriptor = binding?.getDescriptor?.();
        const accountId = extractCurrentUserId();
        if (!descriptor || descriptor.accountId !== accountId) return null;
        if (descriptor.kind === 'reply') {
            return savedDraftForReplyTarget(
                accountId,
                descriptor.threadId,
                descriptor.replyId,
            );
        }
        if (binding.activeTopicKey) {
            const raw = safePrivateCacheGet(binding.activeTopicKey);
            const record = normaliseSavedDraftRecord(binding.activeTopicKey, raw);
            if (record?.kind === 'topic' && record.accountId === accountId) {
                return { key: binding.activeTopicKey, record };
            }
        }
        return null;
    }

    function setDraftBindingStatus(binding, message, isError = false) {
        if (!binding?.status) return;
        binding.status.classList.toggle('hltv-sp-error', Boolean(isError));
        binding.status.textContent = cleanText(message).slice(0, CONFIG.maxActionErrorChars);
    }

    function refreshDraftBinding(binding) {
        if (!binding?.host?.isConnected || binding.active === false) return;
        syncDraftControlsToNativeAction(binding);
        const descriptor = binding.getDescriptor?.();
        const accountId = extractCurrentUserId();
        const available = Boolean(
            savedDraftIntegrationEnabled()
            && descriptor
            && /^\d{1,20}$/.test(accountId)
            && descriptor.accountId === accountId,
        );
        const saved = available ? savedDraftEntryForBinding(binding) : null;
        binding.saveButton.disabled = !available;
        binding.saveButton.textContent = saved ? 'Update saved draft' : 'Save as draft';
        binding.saveButton.title = available
            ? saved ? 'Replace this saved draft with the current text.' : 'Save this draft in Firefox.'
            : 'Sign in to HLTV in the packaged Firefox extension to save drafts.';
        binding.restoreButton.hidden = !saved;
        binding.restoreButton.disabled = !saved;
        binding.restoreButton.title = saved
            ? 'Restore the saved text only if this composer is empty.'
            : '';
    }

    async function saveDraftFromBinding(binding) {
        if (!binding?.active || !savedDraftIntegrationEnabled()) {
            throw savedDraftError(
                'integration-disabled',
                'Saved-draft composer controls are disabled.',
            );
        }
        const descriptor = binding?.getDescriptor?.();
        if (!descriptor) {
            throw savedDraftError('target-unavailable', 'Choose a valid reply target first.');
        }
        const values = await binding.readValues();
        if (!binding.active || !savedDraftIntegrationEnabled()) {
            throw savedDraftError(
                'integration-disabled',
                'Saved-draft composer controls are disabled.',
            );
        }
        const result = await saveDraftRecord(
            { ...descriptor, ...values },
            binding.activeTopicKey || '',
        );
        if (descriptor.kind === 'topic') binding.activeTopicKey = result.key;
        setDraftBindingStatus(binding, 'Draft saved privately in Firefox.');
        refreshAllSavedDraftUi();
        return result;
    }

    async function restoreSavedDraftIntoBinding(binding, entry = savedDraftEntryForBinding(binding)) {
        if (!binding?.active || !savedDraftIntegrationEnabled() || !entry) return false;
        const accountId = extractCurrentUserId();
        const current = normaliseSavedDraftRecord(
            entry.key,
            safePrivateCacheGet(entry.key),
        );
        const descriptor = binding.getDescriptor?.();
        if (!current || current.accountId !== accountId || !descriptor) {
            throw savedDraftError('account-changed', 'This saved draft is no longer available.');
        }
        const applicable = current.kind === descriptor.kind && (
            current.kind === 'topic'
            || (current.threadId === descriptor.threadId && current.replyId === descriptor.replyId)
        );
        if (!applicable) {
            throw savedDraftError('target-changed', 'Open the draft’s original destination before restoring it.');
        }
        const restored = await binding.restoreValues(current);
        if (!binding.active || !savedDraftIntegrationEnabled()) return false;
        if (!restored) {
            throw savedDraftError(
                'composer-not-empty',
                'This composer already contains text or selections. Clear it before restoring the saved draft.',
            );
        }
        if (current.kind === 'topic') binding.activeTopicKey = entry.key;
        setDraftBindingStatus(binding, 'Saved draft restored.');
        refreshDraftBinding(binding);
        return true;
    }

    function bindDraftControlEvents(binding) {
        binding.active = true;
        if (binding.nativeAction) {
            const resyncNativeAppearance = () => {
                syncDraftControlsToNativeAction(binding);
            };
            binding.host.addEventListener('pointerenter', resyncNativeAppearance);
            binding.host.addEventListener('focusin', resyncNativeAppearance);
        }
        binding.saveButton.addEventListener('click', () => {
            binding.saveButton.disabled = true;
            setDraftBindingStatus(binding, 'Saving draft…');
            saveDraftFromBinding(binding).catch((error) => {
                if (!binding.active) return;
                setDraftBindingStatus(binding, savedDraftPublicError(error), true);
                refreshDraftBinding(binding);
            });
        });
        binding.restoreButton.addEventListener('click', () => {
            binding.restoreButton.disabled = true;
            restoreSavedDraftIntoBinding(binding).catch((error) => {
                if (!binding.active) return;
                setDraftBindingStatus(binding, savedDraftPublicError(error), true);
                refreshDraftBinding(binding);
            });
        });
        refreshDraftBinding(binding);
    }

    function createDraftControls(root, status = null) {
        const controls = document.createElement('div');
        controls.className = 'hltv-sp-draft-controls';
        const draftStatus = status || document.createElement('span');
        if (!status) {
            draftStatus.className = 'hltv-sp-draft-status';
            draftStatus.setAttribute('aria-live', 'polite');
        }
        const restoreButton = document.createElement('button');
        restoreButton.type = 'button';
        restoreButton.className = 'hltv-sp-restore-draft';
        restoreButton.textContent = 'Restore saved draft';
        restoreButton.hidden = true;
        const saveButton = document.createElement('button');
        saveButton.type = 'button';
        saveButton.className = 'hltv-sp-save-draft';
        saveButton.textContent = 'Save as draft';
        controls.append(saveButton, restoreButton, draftStatus);
        root.appendChild(controls);
        return { controls, status: draftStatus, restoreButton, saveButton };
    }

    function detachDraftBinding(binding) {
        if (!binding) return;
        binding.active = false;
        binding.nativeActionStyleObserver?.disconnect();
        binding.nativeActionStyleObserver = null;
        if (binding.composer) {
            nativeDraftBindings.delete(binding.composer);
            nativeDraftBindingRecords.delete(binding);
            binding.host?.remove();
            return;
        }
        if (binding.form) {
            topicDraftBindings.delete(binding.form);
            topicDraftBindingRecords.delete(binding);
            binding.host?.remove();
            return;
        }
        previewDraftBindings.delete(binding.host);
        previewDraftBindingRecords.delete(binding);
        binding.restoreButton?.remove();
        binding.saveButton?.remove();
    }

    function removeAllDraftComposerIntegrations() {
        for (const binding of [...previewDraftBindingRecords]) detachDraftBinding(binding);
        for (const binding of [...nativeDraftBindingRecords]) detachDraftBinding(binding);
        for (const binding of [...topicDraftBindingRecords]) detachDraftBinding(binding);
        for (const host of document.querySelectorAll(
            '.hltv-sp-native-draft-controls-host, .hltv-sp-topic-draft-controls-host',
        )) {
            host.remove();
        }
    }

    function previewDraftEntryForHost(host, preview = state.previewData) {
        const threadId = String(host?.dataset?.hltvSpThreadId || '');
        if (!preview || String(preview.threadId || '') !== threadId) return undefined;
        const replyId = String(host.dataset.hltvSpReplyId || '');
        if (!replyId) return null;
        return [preview.thread, ...(Array.isArray(preview.comments) ? preview.comments : [])]
            .find((entry) => String(entry?.replyId || '') === replyId);
    }

    function ensurePreviewDraftIntegration(host, previewForSetup = state.previewData) {
        if (!(host instanceof Element) || !savedDraftIntegrationEnabled()) return;
        const existing = previewDraftBindings.get(host);
        if (existing?.active) return;
        if (existing) detachDraftBinding(existing);
        const replyField = previewReplyFields.get(host);
        const surface = privateUiControl(host, '.hltv-sp-preview-composer-surface');
        const actions = surface?.querySelector('.hltv-sp-preview-composer-actions');
        const status = surface?.querySelector('.hltv-sp-preview-composer-status');
        const post = surface?.querySelector('.hltv-sp-preview-composer-post');
        if (!replyField || !actions || !status || !post) return;
        const initialEntry = previewDraftEntryForHost(host, previewForSetup);
        if (initialEntry === undefined) return;

        const restoreButton = document.createElement('button');
        restoreButton.type = 'button';
        restoreButton.className = 'hltv-sp-restore-draft';
        restoreButton.textContent = 'Restore saved draft';
        restoreButton.hidden = true;
        const saveButton = document.createElement('button');
        saveButton.type = 'button';
        saveButton.className = 'hltv-sp-save-draft';
        saveButton.textContent = 'Save as draft';
        actions.insertBefore(restoreButton, post);
        actions.insertBefore(saveButton, post);

        const binding = {
            host,
            status,
            saveButton,
            restoreButton,
            getDescriptor: () => {
                const preview = String(state.previewData?.threadId || '')
                    === String(host.dataset.hltvSpThreadId || '')
                    ? state.previewData
                    : previewForSetup;
                const entry = previewDraftEntryForHost(host, preview);
                if (entry === undefined) return null;
                return replyDraftDescriptorForPreview(preview, entry);
            },
            readValues: async () => ({ body: await replyField.requestText() }),
            restoreValues: (record) => replyField.restoreText(record.body),
            activeTopicKey: '',
        };
        previewDraftBindings.set(host, binding);
        previewDraftBindingRecords.add(binding);
        bindDraftControlEvents(binding);
    }

    function applySavedDraftSetting() {
        if (!savedDraftIntegrationEnabled()) removeAllDraftComposerIntegrations();
        else scanDraftComposerSurfaces(document);
        if (state.modalBackdrop?.classList.contains('hltv-sp-open')) {
            renderSavedDraftManager();
        }
    }

    function currentBindingForSavedDraft(entry) {
        const record = entry?.record;
        if (!record) return null;
        if (record.kind === 'reply') {
            for (const binding of previewDraftBindingRecords) {
                if (!binding.host?.isConnected) {
                    previewDraftBindingRecords.delete(binding);
                    continue;
                }
                const descriptor = binding.getDescriptor?.();
                if (descriptor?.threadId === record.threadId
                    && descriptor.replyId === record.replyId) return binding;
            }
            for (const binding of nativeDraftBindingRecords) {
                if (!binding.host?.isConnected) {
                    nativeDraftBindingRecords.delete(binding);
                    continue;
                }
                const descriptor = binding.getDescriptor?.();
                if (descriptor?.threadId === record.threadId
                    && descriptor.replyId === record.replyId) return binding;
            }
            return null;
        }
        for (const binding of topicDraftBindingRecords) {
            if (!binding.host?.isConnected) {
                topicDraftBindingRecords.delete(binding);
                continue;
            }
            return binding;
        }
        return null;
    }

    function refreshAllSavedDraftUi() {
        const accountId = extractCurrentUserId();
        const accountChanged = state.savedDraftAccountId !== accountId;
        state.savedDraftAccountId = accountId;
        for (const binding of [
            ...previewDraftBindingRecords,
            ...nativeDraftBindingRecords,
            ...topicDraftBindingRecords,
        ]) {
            if (!binding.host?.isConnected) continue;
            if (accountChanged) setDraftBindingStatus(binding, '');
            refreshDraftBinding(binding);
        }
        if (state.modalBackdrop?.classList.contains('hltv-sp-open')) {
            renderSavedDraftManager();
        }
    }

    function scheduleSavedDraftUiRefresh() {
        if (state.savedDraftRefreshTimer) return;
        state.savedDraftRefreshTimer = window.setTimeout(() => {
            state.savedDraftRefreshTimer = null;
            refreshAllSavedDraftUi();
        }, 50);
    }

    function installSavedDraftStorageListener() {
        const storage = extensionPrivateStorage();
        if (!storage
            || state.savedDraftStorageListenerId !== null
            || typeof storage.addPrefixChangeListener !== 'function') return;
        state.savedDraftStorageListenerId = storage.addPrefixChangeListener(
            SAVED_DRAFT_STORAGE_PREFIX,
            scheduleSavedDraftUiRefresh,
        );
    }

    function nodeTouchesSavedDraftAccountIdentity(node) {
        if (!(node instanceof Element)) return false;
        if (node.matches('.navbell, .navbell *, .fa-bell, #popupsettings, #popupsettings *')) {
            return true;
        }
        const selector = '.navbell [data-user], .fa-bell[data-user], '
            + '#popupsettings .nav-popup-header > a.right[href*="/profile/"], '
            + '#popupsettings .nav-popup-header a[href*="/profile/"]';
        return node.matches(selector) || Boolean(node.querySelector(selector));
    }

    function installSavedDraftIdentityObserver() {
        if (state.savedDraftIdentityObserver || !document.body || !hasSavedDraftStorage()) return;
        state.savedDraftAccountId = extractCurrentUserId();
        state.savedDraftIdentityObserver = new MutationObserver((mutations) => {
            const relevant = mutations.some((mutation) => {
                if (mutation.type === 'attributes') {
                    return nodeTouchesSavedDraftAccountIdentity(mutation.target);
                }
                return nodeTouchesSavedDraftAccountIdentity(mutation.target)
                    || [...mutation.addedNodes, ...mutation.removedNodes]
                    .some(nodeTouchesSavedDraftAccountIdentity);
            });
            if (relevant) scheduleSavedDraftUiRefresh();
        });
        state.savedDraftIdentityObserver.observe(document.body, {
            attributes: true,
            attributeFilter: ['data-user', 'href'],
            childList: true,
            subtree: true,
        });
    }

    function nativeDraftActionStyleVariable(property) {
        return `--hltv-sp-native-action-${property}`;
    }

    function safeNativeDraftActionStyleValue(value) {
        const candidate = String(value || '').trim();
        if (!candidate
            || candidate.length > 300
            || /[{};]/.test(candidate)
            || /(?:expression|image-set|url)\s*\(/i.test(candidate)) return '';
        return candidate;
    }

    function parseComputedRgb(value) {
        const match = String(value || '').match(
            /^rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:\s*[,/]\s*([\d.]+%?))?\s*\)$/i,
        );
        if (!match) return null;
        const channels = match.slice(1, 4).map((part) => Number(part));
        if (channels.some((channel) => !Number.isFinite(channel)
            || channel < 0
            || channel > 255)) return null;
        let alpha = 1;
        if (match[4]) {
            alpha = match[4].endsWith('%')
                ? Number.parseFloat(match[4]) / 100
                : Number(match[4]);
        }
        if (!Number.isFinite(alpha) || alpha < 0 || alpha > 1) return null;
        return [...channels, alpha];
    }

    function mixComputedRgb(parts, target, amount) {
        if (!parts || !target || !Number.isFinite(amount)) return '';
        const channels = parts.slice(0, 3).map((channel, index) => (
            Math.round(channel + ((target[index] - channel) * amount))
        ));
        return parts[3] < 1
            ? `rgba(${channels.join(', ')}, ${parts[3]})`
            : `rgb(${channels.join(', ')})`;
    }

    function derivedNativeDraftActionHoverStyles(background, color) {
        const backgroundParts = parseComputedRgb(background);
        const colorParts = parseComputedRgb(color);
        if (!backgroundParts || !colorParts) {
            return { background, color };
        }
        const exactThemeStyle = [
            {
                background: [67, 89, 113],
                hoverBackground: 'rgb(89, 114, 142)',
                hoverColor: 'rgb(185, 189, 191)',
            },
            {
                background: [45, 109, 163],
                hoverBackground: 'rgb(31, 85, 130)',
                hoverColor: 'rgb(255, 255, 255)',
            },
        ].find((theme) => theme.background.every(
            (channel, index) => channel === backgroundParts[index],
        ));
        if (exactThemeStyle) {
            return {
                background: exactThemeStyle.hoverBackground,
                color: exactThemeStyle.hoverColor,
            };
        }
        const textLuminance = (0.2126 * colorParts[0])
            + (0.7152 * colorParts[1])
            + (0.0722 * colorParts[2]);
        const lightTextTheme = textLuminance >= 225;
        return {
            background: mixComputedRgb(
                backgroundParts,
                lightTextTheme ? [0, 0, 0] : [255, 255, 255],
                lightTextTheme ? 0.2 : 0.13,
            ),
            color: lightTextTheme
                ? color
                : mixComputedRgb(colorParts, [255, 255, 255], 0.3),
        };
    }

    function resolveNativeDraftAction(binding) {
        const host = binding?.host;
        if (!(host instanceof HTMLElement)) return null;
        const candidate = host.previousElementSibling;
        const validCandidate = binding.composer instanceof Element
            ? candidate?.parentElement === binding.composer
                && candidate.matches('.newreply-post')
            : binding.form instanceof HTMLFormElement
                ? candidate?.parentElement === binding.form
                    && candidate.matches('button[type="submit"], input[type="submit"]')
                : false;
        if (!validCandidate) {
            return binding.nativeAction instanceof HTMLElement
                && binding.nativeAction.isConnected
                ? binding.nativeAction
                : null;
        }
        if (candidate !== binding.nativeAction) {
            binding.nativeActionStyleObserver?.disconnect();
            binding.nativeActionStyleObserver = null;
            binding.nativeAction = candidate;
            observeNativeDraftActionStyle(binding);
        }
        return candidate;
    }

    function syncDraftControlsToNativeAction(binding) {
        const host = binding?.host;
        const nativeAction = resolveNativeDraftAction(binding);
        if (!(host instanceof HTMLElement)
            || !(nativeAction instanceof HTMLElement)
            || !host.isConnected
            || !nativeAction.isConnected) return;
        let computed;
        try {
            computed = getComputedStyle(nativeAction);
        } catch {
            return;
        }
        const buttons = [binding.saveButton, binding.restoreButton]
            .filter((button) => button instanceof HTMLButtonElement);
        for (const property of NATIVE_DRAFT_ACTION_STYLE_PROPERTIES) {
            const value = safeNativeDraftActionStyleValue(
                computed.getPropertyValue(property),
            );
            const variable = nativeDraftActionStyleVariable(property);
            if (value) host.style.setProperty(variable, value);
            else host.style.removeProperty(variable);
            for (const button of buttons) {
                if (value) button.style.setProperty(property, value);
                else button.style.removeProperty(property);
            }
        }
        for (const button of buttons) {
            button.style.setProperty('appearance', 'none');
            button.style.setProperty('-webkit-appearance', 'none');
            button.style.setProperty('margin', '0px');
        }
        const verticalAlign = safeNativeDraftActionStyleValue(
            computed.getPropertyValue('vertical-align'),
        );
        host.style.verticalAlign = verticalAlign || 'baseline';
        const background = safeNativeDraftActionStyleValue(
            computed.getPropertyValue('background-color'),
        );
        const color = safeNativeDraftActionStyleValue(
            computed.getPropertyValue('color'),
        );
        const hover = derivedNativeDraftActionHoverStyles(background, color);
        if (hover.background) {
            host.style.setProperty(
                '--hltv-sp-native-action-hover-background-color',
                hover.background,
            );
        }
        if (hover.color) {
            host.style.setProperty('--hltv-sp-native-action-hover-color', hover.color);
        }
    }

    function observeNativeDraftActionStyle(binding) {
        if (!(binding?.nativeAction instanceof HTMLElement)
            || binding.nativeActionStyleObserver) return;
        binding.nativeActionStyleObserver = new MutationObserver(() => {
            syncDraftControlsToNativeAction(binding);
        });
        binding.nativeActionStyleObserver.observe(binding.nativeAction, {
            attributes: true,
            attributeFilter: ['aria-disabled', 'class', 'disabled', 'style'],
        });
    }

    function draftControlPrivateStyleText() {
        return `
            :host {
                --hltv-ui-button: #435f7a;
                --hltv-ui-button-hover: #506e8a;
                --hltv-ui-border-strong: #52677b;
                --hltv-ui-text: #929a9e;
                --hltv-sp-native-action-fallback-padding-bottom: 5px;
                --hltv-sp-native-action-fallback-padding-left: 14px;
                --hltv-sp-native-action-fallback-padding-right: 14px;
                --hltv-sp-native-action-fallback-padding-top: 5px;
                display: inline-flex;
                font-family: var(--hltv-sp-native-action-font-family, inherit);
                font-size: var(--hltv-sp-native-action-font-size, inherit);
                font-style: var(--hltv-sp-native-action-font-style, normal);
                font-weight: var(--hltv-sp-native-action-font-weight, 700);
                line-height: var(--hltv-sp-native-action-line-height, normal);
                margin-left: 6px;
                vertical-align: var(--hltv-sp-native-action-vertical-align, baseline);
            }
            :host([data-hltv-sp-native-action-kind="topic"]) {
                --hltv-sp-native-action-fallback-padding-bottom: 4px;
                --hltv-sp-native-action-fallback-padding-left: 10px;
                --hltv-sp-native-action-fallback-padding-right: 10px;
                --hltv-sp-native-action-fallback-padding-top: 4px;
            }
            ${trustedMainUiStyleText}
            .hltv-sp-draft-controls {
                display: inline-grid;
                grid-template-areas:
                    "save restore"
                    "status status";
                grid-template-columns: max-content max-content;
                justify-content: start;
                margin-top: 0;
                max-width: min(480px, 70vw);
            }
            .hltv-sp-draft-controls > .hltv-sp-save-draft,
            .hltv-sp-draft-controls > .hltv-sp-restore-draft {
                appearance: none !important;
                -webkit-appearance: none !important;
                background-color: var(
                    --hltv-sp-native-action-background-color,
                    var(--hltv-ui-button)
                ) !important;
                border-bottom-color: var(
                    --hltv-sp-native-action-border-bottom-color,
                    transparent
                ) !important;
                border-bottom-left-radius: var(
                    --hltv-sp-native-action-border-bottom-left-radius,
                    2px
                ) !important;
                border-bottom-right-radius: var(
                    --hltv-sp-native-action-border-bottom-right-radius,
                    2px
                ) !important;
                border-bottom-style: var(--hltv-sp-native-action-border-bottom-style, none) !important;
                border-bottom-width: var(--hltv-sp-native-action-border-bottom-width, 0) !important;
                border-left-color: var(
                    --hltv-sp-native-action-border-left-color,
                    transparent
                ) !important;
                border-left-style: var(--hltv-sp-native-action-border-left-style, none) !important;
                border-left-width: var(--hltv-sp-native-action-border-left-width, 0) !important;
                border-right-color: var(
                    --hltv-sp-native-action-border-right-color,
                    transparent
                ) !important;
                border-right-style: var(--hltv-sp-native-action-border-right-style, none) !important;
                border-right-width: var(--hltv-sp-native-action-border-right-width, 0) !important;
                border-top-color: var(
                    --hltv-sp-native-action-border-top-color,
                    transparent
                ) !important;
                border-top-left-radius: var(
                    --hltv-sp-native-action-border-top-left-radius,
                    2px
                ) !important;
                border-top-right-radius: var(
                    --hltv-sp-native-action-border-top-right-radius,
                    2px
                ) !important;
                border-top-style: var(--hltv-sp-native-action-border-top-style, none) !important;
                border-top-width: var(--hltv-sp-native-action-border-top-width, 0) !important;
                box-shadow: var(--hltv-sp-native-action-box-shadow, none) !important;
                box-sizing: var(--hltv-sp-native-action-box-sizing, border-box) !important;
                color: var(--hltv-sp-native-action-color, inherit) !important;
                cursor: var(--hltv-sp-native-action-cursor, pointer) !important;
                font-family: var(--hltv-sp-native-action-font-family, inherit) !important;
                font-size: var(--hltv-sp-native-action-font-size, inherit) !important;
                font-style: var(--hltv-sp-native-action-font-style, normal) !important;
                font-variant: var(--hltv-sp-native-action-font-variant, normal) !important;
                font-weight: var(--hltv-sp-native-action-font-weight, 700) !important;
                height: var(--hltv-sp-native-action-height, auto) !important;
                letter-spacing: var(--hltv-sp-native-action-letter-spacing, normal) !important;
                line-height: var(--hltv-sp-native-action-line-height, normal) !important;
                margin: 0 !important;
                min-height: var(--hltv-sp-native-action-min-height, 0) !important;
                padding-bottom: var(
                    --hltv-sp-native-action-padding-bottom,
                    var(--hltv-sp-native-action-fallback-padding-bottom)
                ) !important;
                padding-left: var(
                    --hltv-sp-native-action-padding-left,
                    var(--hltv-sp-native-action-fallback-padding-left)
                ) !important;
                padding-right: var(
                    --hltv-sp-native-action-padding-right,
                    var(--hltv-sp-native-action-fallback-padding-right)
                ) !important;
                padding-top: var(
                    --hltv-sp-native-action-padding-top,
                    var(--hltv-sp-native-action-fallback-padding-top)
                ) !important;
                text-align: var(--hltv-sp-native-action-text-align, center) !important;
                text-shadow: var(--hltv-sp-native-action-text-shadow, none) !important;
                text-transform: var(--hltv-sp-native-action-text-transform, none) !important;
                transition: var(--hltv-sp-native-action-transition, none) !important;
                vertical-align: var(--hltv-sp-native-action-vertical-align, baseline) !important;
                white-space: var(--hltv-sp-native-action-white-space, nowrap) !important;
            }
            .hltv-sp-draft-controls > .hltv-sp-save-draft:hover:not(:disabled),
            .hltv-sp-draft-controls > .hltv-sp-save-draft:focus-visible,
            .hltv-sp-draft-controls > .hltv-sp-restore-draft:hover:not(:disabled),
            .hltv-sp-draft-controls > .hltv-sp-restore-draft:focus-visible {
                background-color: var(
                    --hltv-sp-native-action-hover-background-color,
                    var(--hltv-sp-native-action-background-color, var(--hltv-ui-button-hover))
                ) !important;
                color: var(
                    --hltv-sp-native-action-hover-color,
                    var(--hltv-sp-native-action-color, #fff)
                ) !important;
            }
            .hltv-sp-draft-controls > .hltv-sp-save-draft:focus-visible,
            .hltv-sp-draft-controls > .hltv-sp-restore-draft:focus-visible {
                outline: 2px solid var(
                    --hltv-sp-native-action-hover-color,
                    var(--hltv-sp-native-action-color, #fff)
                ) !important;
                outline-offset: 2px;
            }
            .hltv-sp-draft-controls > .hltv-sp-save-draft:disabled,
            .hltv-sp-draft-controls > .hltv-sp-restore-draft:disabled {
                opacity: 0.5 !important;
            }
            .hltv-sp-save-draft {
                grid-area: save;
            }
            .hltv-sp-restore-draft {
                grid-area: restore;
            }
            .hltv-sp-draft-status {
                grid-area: status;
                min-height: 0;
            }
            .hltv-sp-draft-status:empty {
                display: none;
            }
        `;
    }

    function enhanceNativeDraftComposer(composer) {
        if (!(composer instanceof Element)
            || nativeDraftBindings.has(composer)
            || !savedDraftIntegrationEnabled()) return;
        const textarea = composer.querySelector('textarea.forum-textarea');
        if (!(textarea instanceof HTMLTextAreaElement)) return;
        for (const staleHost of composer.querySelectorAll(
            '.hltv-sp-native-draft-controls-host',
        )) {
            if (staleHost.parentElement === composer) staleHost.remove();
        }
        const { host, root } = createPrivateUiHost({
            tagName: 'div',
            className: 'hltv-sp-private-ui-host hltv-sp-native-draft-controls-host',
            styleText: draftControlPrivateStyleText(),
            metadata: { surface: 'native-reply-draft' },
        });
        stampUiVersion(host);
        host.dataset.hltvSpComponent = 'native-draft-controls';
        host.dataset.hltvSpNativeActionKind = 'reply';
        const controls = createDraftControls(root);
        const nativePost = composer.querySelector(':scope > .newreply-post');
        if (nativePost) nativePost.after(host);
        else composer.appendChild(host);
        const binding = {
            host,
            composer,
            nativeAction: nativePost,
            status: controls.status,
            saveButton: controls.saveButton,
            restoreButton: controls.restoreButton,
            getDescriptor: () => replyDraftDescriptorForNativeComposer(composer),
            readValues: () => Promise.resolve({ body: String(textarea.value || '') }),
            restoreValues: (record) => {
                if (textarea.value) return Promise.resolve(false);
                textarea.value = record.body;
                textarea.dispatchEvent(new Event('input', { bubbles: true }));
                return Promise.resolve(true);
            },
            activeTopicKey: '',
        };
        nativeDraftBindings.set(composer, binding);
        nativeDraftBindingRecords.add(binding);
        bindDraftControlEvents(binding);
        observeNativeDraftActionStyle(binding);
    }

    function enhanceTopicDraftForm(form) {
        if (!(form instanceof HTMLFormElement)
            || topicDraftBindings.has(form)
            || !savedDraftIntegrationEnabled()) return;
        const descriptor = topicDraftDescriptor(form);
        if (!descriptor) return;
        const submit = form.querySelector('button[type="submit"], input[type="submit"]');
        if (!submit) return;
        for (const staleHost of form.querySelectorAll(
            '.hltv-sp-topic-draft-controls-host',
        )) {
            if (staleHost.parentElement === form) staleHost.remove();
        }
        const { host, root } = createPrivateUiHost({
            tagName: 'div',
            className: 'hltv-sp-private-ui-host hltv-sp-topic-draft-controls-host',
            styleText: draftControlPrivateStyleText(),
            metadata: { surface: 'new-topic-draft' },
        });
        stampUiVersion(host);
        host.dataset.hltvSpComponent = 'topic-draft-controls';
        host.dataset.hltvSpNativeActionKind = 'topic';
        const controls = createDraftControls(root);
        submit.after(host);
        const subject = form.elements.namedItem('subject');
        const forum = form.elements.namedItem('forum');
        const body = form.elements.namedItem('topic');
        const initialForumId = String(forum.value || '');
        const binding = {
            host,
            form,
            nativeAction: submit,
            status: controls.status,
            saveButton: controls.saveButton,
            restoreButton: controls.restoreButton,
            getDescriptor: () => topicDraftDescriptor(form),
            readValues: () => Promise.resolve({
                subject: String(subject.value || ''),
                forumId: String(forum.value || ''),
                forumLabel: cleanText(forum.selectedOptions[0]?.textContent).slice(0, 100),
                body: String(body.value || ''),
            }),
            restoreValues: (record) => {
                if (subject.value || body.value || String(forum.value || '') !== initialForumId) {
                    return Promise.resolve(false);
                }
                const exactForumOption = [...forum.options].find((option) => (
                    option.value === record.forumId
                ));
                const matchingLabelOptions = record.forumLabel
                    ? [...forum.options].filter((option) => (
                        CURRENT_TOPIC_FORUM_IDS.has(option.value)
                        && cleanText(option.textContent) === record.forumLabel
                    ))
                    : [];
                const restoredForumId = exactForumOption?.value
                    || (matchingLabelOptions.length === 1
                        ? matchingLabelOptions[0].value
                        : '');
                if (record.forumId && !restoredForumId) return Promise.resolve(false);
                subject.value = record.subject;
                body.value = record.body;
                forum.value = restoredForumId;
                for (const input of [subject, forum, body]) {
                    input.dispatchEvent(new Event('input', { bubbles: true }));
                    input.dispatchEvent(new Event('change', { bubbles: true }));
                }
                return Promise.resolve(true);
            },
            activeTopicKey: '',
        };
        topicDraftBindings.set(form, binding);
        topicDraftBindingRecords.add(binding);
        bindDraftControlEvents(binding);
        observeNativeDraftActionStyle(binding);
    }

    function scanDraftComposerSurfaces(root = document) {
        if (!savedDraftIntegrationEnabled()) return;
        for (const host of elementsWithin(
            root,
            '.hltv-sp-preview-composer[data-hltv-sp-thread-id]',
        )) {
            ensurePreviewDraftIntegration(host);
        }
        for (const composer of elementsWithin(
            root,
            '.forum[data-forum-thread-id] .newreply-con',
        )) {
            enhanceNativeDraftComposer(composer);
        }
        if (location.pathname === '/forums/create-thread') {
            for (const form of elementsWithin(
                root,
                'form[action="/forums/create-thread"], form[action^="https://www.hltv.org/forums/create-thread"]',
            )) {
                const action = parseSameOriginUrl(form.getAttribute('action') || form.action);
                if (action?.pathname === '/forums/create-thread') enhanceTopicDraftForm(form);
            }
        }
    }

    function applyPreviewReplySubmissionState(composer, threadId) {
        if (!(composer instanceof Element)) return;
        const host = privateUiHostForNode(composer) || composer;
        const surface = privateUiControl(host, '.hltv-sp-preview-composer-surface')
            || composer;
        const replyField = previewReplyFields.get(host);
        const pending = state.pendingReplyActions.has(threadId);
        const fence = readActionFence('reply', threadId);
        const ownedPendingFence = pending
            && fence?.ownerId === state.syncSenderId
            && fence.status === 'pending';
        const otherTabPending = !ownedPendingFence && fence?.status === 'pending';
        const unconfirmed = state.unconfirmedReplyThreads.has(String(threadId || ''))
            || fence?.status === 'unconfirmed';
        const postButton = surface.querySelector('.hltv-sp-preview-composer-post');
        const status = surface.querySelector('.hltv-sp-preview-composer-status');
        replyField?.setDisabled(pending || otherTabPending || unconfirmed);
        if (postButton) {
            postButton.disabled = replyField?.available === false
                || pending
                || otherTabPending
                || unconfirmed;
            postButton.setAttribute('aria-busy', pending ? 'true' : 'false');
            postButton.setAttribute(
                'aria-disabled',
                pending || otherTabPending || unconfirmed ? 'true' : 'false',
            );
            postButton.title = unconfirmed
                ? 'A previous reply may already have posted. For safety, wait one minute and reload this page.'
                : pending || otherTabPending
                    ? 'A reply is already being posted to this thread.'
                    : '';
        }
        if (!status) return;
        if (!pending && !otherTabPending && !unconfirmed) {
            if (status.dataset.hltvSpSubmissionState) {
                delete status.dataset.hltvSpSubmissionState;
                status.classList.remove('hltv-sp-error');
                status.textContent = '';
            }
            return;
        }
        status.dataset.hltvSpSubmissionState = unconfirmed
            ? 'unconfirmed'
            : otherTabPending ? 'pending-other-tab' : 'pending';
        status.classList.toggle('hltv-sp-error', unconfirmed);
        status.textContent = unconfirmed
            ? 'The previous reply may have posted. For safety, wait one minute and reload this page.'
            : otherTabPending ? 'Another tab is posting to this thread\u2026' : 'Posting\u2026';
    }

    function syncPreviewReplySubmissionState(threadId) {
        const normalisedThreadId = String(threadId || '');
        if (!/^\d{1,20}$/.test(normalisedThreadId)) return;
        for (const composer of document.querySelectorAll(
            `.hltv-sp-preview-composer[data-hltv-sp-thread-id="${normalisedThreadId}"]`,
        )) {
            applyPreviewReplySubmissionState(composer, normalisedThreadId);
        }
    }

    function createPreviewReplyComposer(preview, entry = null) {
        const { host, root } = createPrivateUiHost({
            tagName: 'div',
            className: 'hltv-sp-private-ui-host hltv-sp-preview-composer',
            styleText: `
                :host {
                    display: block;
                }
                ${trustedMainUiStyleText}
            `,
            metadata: {
                threadId: preview.threadId,
                replyId: entry?.replyId || '',
            },
        });
        host.dataset.hltvSpThreadId = preview.threadId;
        host.dataset.hltvSpReplyId = entry?.replyId || '';
        const composer = document.createElement('div');
        composer.className = 'hltv-sp-preview-composer hltv-sp-preview-composer-surface';
        composer.dataset.hltvSpThreadId = preview.threadId;
        composer.dataset.hltvSpReplyId = entry?.replyId || '';

        const title = document.createElement('div');
        title.className = 'hltv-sp-preview-composer-title';
        title.textContent = entry?.replyId
            ? `Reply to #${entry.number} \u00B7 ${entry.author}`
            : 'Reply to thread';
        const placeholder = preview.replyPlaceholder || 'Write your comment in English.';
        let replyField;
        let fieldElement;
        if (extensionReplyFieldApi()) {
            const iframe = document.createElement('iframe');
            iframe.className = 'hltv-sp-preview-reply-frame';
            iframe.title = title.textContent;
            iframe.setAttribute('sandbox', 'allow-scripts allow-same-origin');
            iframe.setAttribute('referrerpolicy', 'no-referrer');
            try {
                replyField = createExtensionPreviewReplyField({
                    iframe,
                    preview,
                    label: title.textContent,
                    placeholder,
                    onClick() {
                        if (state.previewData !== preview || !host.isConnected
                            || host.closest('[hidden]')) return;
                        if (!state.previewLastCommentTarget?.contains(host)) {
                            clearPreviewLastCommentHighlight();
                        }
                    },
                });
                iframe.addEventListener('mouseenter', () => {
                    state.previewPointerInside = true;
                    window.clearTimeout(state.previewCloseTimer);
                });
                iframe.addEventListener('mouseleave', () => {
                    state.previewPointerInside = false;
                    scheduleThreadPreviewClose();
                });
                fieldElement = iframe;
            } catch (error) {
                warn('Private reply field could not be created.', error);
            }
        }
        if (!replyField && !isFirefoxExtensionEnvironment()) {
            const fallback = document.createElement('div');
            fallback.className = 'hltv-sp-preview-reply-fallback';
            const textarea = document.createElement('textarea');
            textarea.className = 'hltv-sp-preview-reply-textarea';
            textarea.placeholder = placeholder;
            textarea.setAttribute('aria-label', title.textContent);
            const suggestions = document.createElement('div');
            suggestions.className = 'hltv-sp-username-suggestions';
            fallback.append(textarea, suggestions);
            replyField = createFallbackPreviewReplyField({
                textarea,
                suggestions,
                threadUrl: preview.threadUrl,
            });
            fieldElement = fallback;
        }
        if (!replyField) {
            const unavailableMessage = 'The private reply field is unavailable. Reload the page to try again.';
            const unavailable = document.createElement('div');
            unavailable.className = 'hltv-sp-preview-reply-unavailable';
            unavailable.textContent = unavailableMessage;
            replyField = createUnavailablePreviewReplyField(unavailableMessage);
            fieldElement = unavailable;
        }
        const actions = document.createElement('div');
        actions.className = 'hltv-sp-preview-composer-actions';
        const status = document.createElement('span');
        status.className = 'hltv-sp-preview-composer-status';
        status.setAttribute('aria-live', 'polite');
        const post = document.createElement('button');
        post.type = 'button';
        post.className = 'hltv-sp-preview-composer-post';
        post.textContent = 'Post';
        post.addEventListener('click', async () => {
            let message;
            try {
                message = await replyField.requestText();
            } catch (error) {
                status.classList.add('hltv-sp-error');
                status.textContent = actionErrorMessage(error);
                return;
            }
            submitPreviewReply(preview, entry, message, replyField, status, post)
                .catch((error) => {
                    status.classList.add('hltv-sp-error');
                    status.textContent = actionErrorMessage(error);
                });
        });
        actions.append(status, post);
        composer.append(title, fieldElement, actions);
        root.appendChild(composer);
        previewReplyFields.set(host, replyField);
        ensurePreviewDraftIntegration(host, preview);
        applyPreviewReplySubmissionState(host, preview.threadId);
        return host;
    }

    async function submitPreviewReply(preview, entry, message, replyField, status, postButton) {
        return withCrossTabActionLock('reply', preview.threadId, () => (
            submitPreviewReplyUnlocked(
                preview,
                entry,
                message,
                replyField,
                status,
                postButton,
            )
        ));
    }

    async function submitPreviewReplyUnlocked(
        preview,
        entry,
        rawMessage,
        replyField,
        status,
        postButton,
    ) {
        const message = String(rawMessage || '');
        if (!message.trim()) {
            status.classList.add('hltv-sp-error');
            status.textContent = 'Write a reply first.';
            return;
        }
        const activeThreadId = state.previewData?.threadId;
        if (!preview.canReply || activeThreadId !== preview.threadId) {
            throw makeActionError('Preview changed before reply submission.', 'Reopen the thread preview and try again.');
        }
        if (state.pendingReplyActions.has(preview.threadId)) {
            throw makeActionError(
                'A reply submission is already pending.',
                'A reply is already being posted to this thread.',
            );
        }
        if (isReplyActionBlocked(preview.threadId)) {
            throw makeActionError(
                'A previous reply outcome is unconfirmed.',
                'The previous reply may have posted. For safety, wait one minute and reload this page.',
            );
        }

        const actionToken = createRandomId('reply');
        const submittedSavedDraft = matchingSavedReplyDraft(
            replyDraftDescriptorForPreview(preview, entry),
            message,
        );
        state.pendingReplyActions.set(preview.threadId, actionToken);
        let ambiguousOutcome = false;
        try {
            if (!await setActionFenceAndWait('reply', preview.threadId, 'pending')) {
                throw makeActionError(
                    'Could not establish the reply safety fence.',
                    'No reply was sent because duplicate-action protection could not be stored.',
                );
            }
            syncPreviewReplySubmissionState(preview.threadId);
            status.classList.remove('hltv-sp-error');
            status.textContent = 'Posting\u2026';
            await postForumReply({
                threadId: preview.threadId,
                replyId: entry?.replyId || '',
                message,
                shortContextId: entry?.shortContextId || '',
                threadUrl: preview.threadUrl,
            });
            if (submittedSavedDraft) {
                try {
                    await removeSavedDraftIfRevision(
                        submittedSavedDraft.key,
                        submittedSavedDraft.accountId,
                        submittedSavedDraft.revision,
                        message,
                    );
                } catch (error) {
                    log('Could not remove the confirmed posted reply draft.', error);
                }
            }
            state.pendingSelfReplyDiscovery.add(preview.threadId);
            replyField.clear();
            status.textContent = 'Posted. Refreshing preview\u2026';
            const activeLink = state.previewActiveLink;
            const activeTarget = threadPreviewTarget(activeLink);
            if (activeLink
                && state.previewData?.threadId === preview.threadId
                && activeTarget?.threadId === preview.threadId) {
                deleteThreadPreviewCache(preview.threadId);
                try {
                    await openThreadPreview(activeLink, { force: true });
                } catch (error) {
                    if (!isAbortErrorLike(error)) {
                        status.textContent = 'Posted. Reopen the preview to see the new reply.';
                    }
                }
            } else {
                status.textContent = 'Posted.';
            }
        } catch (error) {
            ambiguousOutcome = Boolean(error?.ambiguousOutcome);
            if (ambiguousOutcome) {
                deleteThreadPreviewCache(preview.threadId);
                state.unconfirmedReplyThreads.add(preview.threadId);
                await setActionFenceAndWait('reply', preview.threadId);
            }
            throw error;
        } finally {
            if (state.pendingReplyActions.get(preview.threadId) === actionToken) {
                const unconfirmed = state.unconfirmedReplyThreads.has(preview.threadId);
                state.pendingReplyActions.delete(preview.threadId);
                if (!unconfirmed) {
                    await clearOwnedPendingActionFenceAndWait('reply', preview.threadId);
                }
            }
            syncPreviewReplySubmissionState(preview.threadId);
            refreshActionFenceUi();
            schedulePreviewCloseAfterInteraction();
        }
    }

    function previewEntryIsCollapsed(entry, topology = state.previewCommentTopology) {
        const node = topology?.nodeByEntry.get(entry);
        return Boolean(node?.ancestorReplyIds.some((replyId) => (
            state.previewCollapsedReplyIds.has(replyId)
        )));
    }

    function findFirstUnreadPreviewEntry(preview, record, topology = state.previewCommentTopology) {
        if (!record || !Array.isArray(preview?.comments)) return null;
        const threshold = readEntryThreshold(record);
        const knownSelfPosts = new Set(record.selfPostNumbers || []);
        const currentUserId = String(preview.currentUserId || '');
        return preview.comments
            .filter((entry) => (
                entry.number > threshold
                && !knownSelfPosts.has(entry.number)
                && (!currentUserId || entry.userId !== currentUserId)
                && !shouldHideUserComment(entry.userId)
                && !previewEntryIsCollapsed(entry, topology)
            ))
            .sort((a, b) => a.number - b.number)[0] || null;
    }

    function findLastPreviewCommentNode(preview, topology = state.previewCommentTopology) {
        const hiddenTags = getHiddenUserTagSet();
        let latest = null;
        for (const entry of preview?.comments || []) {
            const node = topology?.nodeByEntry.get(entry);
            if (!node?.card?.isConnected || node.card.hidden
                || shouldHideUserComment(entry.userId, hiddenTags)) continue;
            if (!latest || entry.number > latest.entry.number) latest = node;
        }
        return latest;
    }

    function scrollPreviewToComment(preview, card) {
        const panel = state.previewPanel;
        if (state.previewData !== preview || !panel?.contains(card)
            || card.closest('[hidden]')) return;
        state.previewProgrammaticScrollUntil = Date.now() + 500;
        const top = Math.max(0, panel.scrollTop
            + card.getBoundingClientRect().top
            - panel.getBoundingClientRect().top
            - panel.clientTop - 12);
        if (typeof panel.scrollTo === 'function') {
            panel.scrollTo({ top, behavior: 'smooth' });
        } else {
            panel.scrollTop = top;
        }
    }

    function clearPreviewLastCommentHighlight() {
        state.previewLastCommentTarget?.classList.remove('hltv-sp-preview-last-comment-target');
        state.previewLastCommentTarget = null;
        state.previewLastCommentObserver?.disconnect();
        state.previewLastCommentObserver = null;
        if (state.previewLastCommentDismissHandler) {
            document.removeEventListener('click', state.previewLastCommentDismissHandler, true);
            state.previewLastCommentDismissHandler = null;
        }
    }

    function syncPreviewLastCommentHighlight() {
        const card = state.previewLastCommentTarget;
        if (card && (!card.isConnected || !state.previewPanel?.contains(card)
            || card.closest('[hidden]'))) {
            clearPreviewLastCommentHighlight();
        }
    }

    function highlightPreviewLastComment(preview, card) {
        clearPreviewLastCommentHighlight();
        const panel = state.previewPanel;
        if (state.previewData !== preview || !card?.isConnected
            || !panel?.contains(card) || card.closest('[hidden]')) return;
        state.previewLastCommentTarget = card;
        card.classList.add('hltv-sp-preview-last-comment-target');
        state.previewLastCommentDismissHandler = (event) => {
            if (event.composedPath().includes(card)) return;
            clearPreviewLastCommentHighlight();
        };
        document.addEventListener('click', state.previewLastCommentDismissHandler, true);
        state.previewLastCommentObserver = new MutationObserver(syncPreviewLastCommentHighlight);
        state.previewLastCommentObserver.observe(panel, {
            childList: true,
            subtree: true,
            attributes: true,
            attributeFilter: ['hidden'],
        });
    }

    function jumpToLastPreviewComment(preview, topology) {
        if (state.previewData !== preview) return;
        const target = findLastPreviewCommentNode(preview, topology);
        if (!target) return;
        let expanded = false;
        for (const replyId of target.ancestorReplyIds) {
            const ancestor = topology.nodeByReplyId.get(replyId);
            const controls = ancestor?.branchControls;
            if (!controls || !state.previewCollapsedReplyIds.delete(replyId)) continue;
            paintPreviewBranchControl(
                ancestor, controls.branch, controls.toggle, controls.children,
            );
            expanded = true;
        }
        if (expanded) {
            state.previewProgrammaticScrollUntil = Date.now() + 500;
            syncPreviewCommentNavigation(preview, topology);
            resetPreviewReadCandidate(preview, topology);
            positionThreadPreview();
        }
        scrollPreviewToComment(preview, target.card);
        highlightPreviewLastComment(preview, target.card);
    }

    function syncPreviewCommentNavigation(preview, topology = state.previewCommentTopology) {
        const panel = state.previewPanel;
        if (!panel || state.previewData !== preview) return;
        syncPreviewLastCommentHighlight();
        const commentsLabel = panel.querySelector('.hltv-sp-preview-comments-label');
        if (!commentsLabel) return;
        let navigation = panel.querySelector('.hltv-sp-preview-comment-navigation');
        if (!navigation) {
            navigation = document.createElement('div');
            navigation.className = 'hltv-sp-preview-comment-navigation';
            navigation.setAttribute('role', 'group');
            navigation.setAttribute('aria-label', 'Comment navigation');
            commentsLabel.before(navigation);
        }
        const lastNode = findLastPreviewCommentNode(preview, topology);
        let lastJump = navigation.querySelector('.hltv-sp-preview-last-comment-jump');
        if (lastNode) {
            if (!lastJump) {
                lastJump = document.createElement('button');
                lastJump.type = 'button';
                lastJump.className = 'hltv-sp-preview-last-comment-jump';
                lastJump.textContent = 'Last comment';
                lastJump.addEventListener('click', () => jumpToLastPreviewComment(preview, topology));
                navigation.appendChild(lastJump);
            }
            lastJump.dataset.hltvSpReplyId = lastNode.entry.replyId;
            lastJump.title = `Jump to comment #${lastNode.entry.number}`;
        } else {
            lastJump?.remove();
        }
        navigation.hidden = !lastNode;
        panel.querySelector(
            '.hltv-sp-first-unread-jump[data-hltv-sp-context="preview"]',
        )?.remove();
        for (const card of panel.querySelectorAll(
            '.hltv-sp-preview-comment.hltv-sp-first-unread',
        )) {
            card.classList.remove('hltv-sp-first-unread');
        }
        if (!state.settings.enableReadStatus) return;
        const entry = findFirstUnreadPreviewEntry(
            preview,
            state.readEntries.get(preview.threadId),
            topology,
        );
        const card = topology?.nodeByEntry.get(entry)?.card;
        if (!entry || !card || card.hidden || card.closest('[hidden]')) return;
        card.classList.add('hltv-sp-first-unread');
        const jump = document.createElement('button');
        jump.type = 'button';
        jump.className = 'hltv-sp-first-unread-jump';
        jump.dataset.hltvSpContext = 'preview';
        jump.textContent = 'Jump to first unread post';
        jump.addEventListener('click', () => {
            scrollPreviewToComment(preview, card);
        });
        navigation.prepend(jump);
        navigation.hidden = false;
    }

    function resetPreviewReadCandidate(preview, topology = state.previewCommentTopology) {
        cancelPreviewReadDwell();
        if (!preview?.threadId) {
            state.previewReadCandidate = null;
            return;
        }
        const fullSeenReplyCount = Math.max(preview.replyCount, preview.maxPostNo);
        let firstCollapsedNumber = Number.POSITIVE_INFINITY;
        for (const replyId of state.previewCollapsedReplyIds) {
            const node = topology?.nodeByReplyId.get(replyId);
            if (!node?.descendantCount) continue;
            firstCollapsedNumber = Math.min(
                firstCollapsedNumber,
                node.minDescendantNumber,
            );
        }
        const constrained = Number.isFinite(firstCollapsedNumber);
        const watermark = constrained
            ? Math.max(0, Math.min(fullSeenReplyCount, firstCollapsedNumber - 1))
            : fullSeenReplyCount;
        state.previewReadCandidate = {
            threadId: preview.threadId,
            seenReplyCount: watermark,
            maxPostNo: constrained
                ? Math.min(preview.maxPostNo, watermark)
                : preview.maxPostNo,
            marked: false,
        };
        schedulePreviewReadDwell(state.previewReadCandidate);
    }

    function preparePreviewCommentTopology(preview) {
        const topology = buildPreviewCommentTopology(preview.comments);
        const threadId = String(preview.threadId || '');
        if (state.previewCollapseThreadId !== threadId) {
            state.previewCollapsedReplyIds.clear();
            state.previewCollapseThreadId = threadId;
            state.previewRevealedNotificationReplyId = '';
        }
        const collapsibleReplyIds = new Set(topology.nodes
            .filter((node) => node.children.length && node.entry.replyId)
            .map((node) => node.entry.replyId));
        for (const replyId of state.previewCollapsedReplyIds) {
            if (!collapsibleReplyIds.has(replyId)) {
                state.previewCollapsedReplyIds.delete(replyId);
            }
        }

        const notificationReplyId = String(preview.notificationReplyId || '');
        let revealNotificationTarget = false;
        if (!notificationReplyId) {
            state.previewRevealedNotificationReplyId = '';
        } else if (state.previewRevealedNotificationReplyId !== notificationReplyId) {
            const target = topology.nodeByReplyId.get(notificationReplyId);
            for (const replyId of target?.ancestorReplyIds || []) {
                state.previewCollapsedReplyIds.delete(replyId);
            }
            state.previewRevealedNotificationReplyId = notificationReplyId;
            revealNotificationTarget = Boolean(target);
        }
        return { topology, revealNotificationTarget };
    }

    function paintPreviewBranchControl(node, branch, toggle, children) {
        const replyId = node.entry.replyId;
        const collapsed = state.previewCollapsedReplyIds.has(replyId);
        const count = node.descendantCount;
        const noun = count === 1 ? 'reply' : 'replies';
        const action = collapsed ? 'Expand' : 'Collapse';
        branch.classList.toggle('hltv-sp-collapsed', collapsed);
        children.hidden = collapsed;
        toggle.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
        toggle.setAttribute(
            'aria-label',
            `${action} ${count} ${noun} to post #${node.entry.number}`,
        );
        toggle.title = toggle.getAttribute('aria-label');
        toggle.querySelector('.hltv-sp-preview-branch-summary').textContent =
            `${count} hidden ${noun}`;
    }

    function setPreviewBranchCollapsed(
        preview,
        topology,
        node,
        branch,
        toggle,
        children,
        collapsed,
    ) {
        if (state.previewData !== preview || !node.children.length) return;
        if (collapsed) state.previewCollapsedReplyIds.add(node.entry.replyId);
        else state.previewCollapsedReplyIds.delete(node.entry.replyId);
        paintPreviewBranchControl(node, branch, toggle, children);
        state.previewProgrammaticScrollUntil = Date.now() + 500;
        syncPreviewCommentNavigation(preview, topology);
        resetPreviewReadCandidate(preview, topology);
        positionThreadPreview();
    }

    function createPreviewCommentNode(node, preview, topology, hiddenTags) {
        const wrapper = document.createElement('div');
        wrapper.className = 'hltv-sp-preview-comment-node';
        wrapper.dataset.hltvSpReplyId = node.entry.replyId;
        wrapper.dataset.hltvSpThreadDepth = String(node.depth);
        if (node.parent?.entry.replyId) {
            wrapper.dataset.hltvSpParentReplyId = node.parent.entry.replyId;
        }
        const card = createPreviewPost(
            node.entry,
            'hltv-sp-preview-comment',
            `#${node.entry.number} \u00B7 `,
            preview,
            node,
        );
        node.card = card;
        card.hidden = shouldHideUserComment(node.entry.userId, hiddenTags);
        if (node.entry.replyId === preview.notificationReplyId) {
            card.classList.add('hltv-sp-preview-notification-target');
            card.setAttribute('aria-label', `Notification reply #${node.entry.number}`);
        }
        wrapper.appendChild(card);
        if (!node.children.length) return wrapper;

        const branch = document.createElement('div');
        branch.className = 'hltv-sp-preview-branch';
        branch.style.setProperty('--hltv-sp-branch-depth', String(Math.min(node.depth, 6)));
        branch.dataset.hltvSpParentReplyId = node.entry.replyId;
        const toggle = document.createElement('button');
        toggle.type = 'button';
        toggle.className = 'hltv-sp-preview-branch-toggle';
        toggle.dataset.hltvSpParentReplyId = node.entry.replyId;
        const summary = document.createElement('span');
        summary.className = 'hltv-sp-preview-branch-summary';
        toggle.appendChild(summary);
        const children = document.createElement('div');
        children.className = 'hltv-sp-preview-branch-children';
        children.id = `hltv-sp-preview-branch-${preview.threadId}-${node.entry.replyId}`;
        children.setAttribute('role', 'group');
        children.setAttribute('aria-label', `Replies to post #${node.entry.number}`);
        toggle.setAttribute('aria-controls', children.id);
        for (const child of node.children) {
            children.appendChild(createPreviewCommentNode(
                child,
                preview,
                topology,
                hiddenTags,
            ));
        }
        toggle.addEventListener('click', () => {
            setPreviewBranchCollapsed(
                preview,
                topology,
                node,
                branch,
                toggle,
                children,
                !state.previewCollapsedReplyIds.has(node.entry.replyId),
            );
        });
        toggle.addEventListener('keydown', (event) => {
            const collapsed = state.previewCollapsedReplyIds.has(node.entry.replyId);
            if (event.key === 'ArrowLeft' && !collapsed) {
                event.preventDefault();
                setPreviewBranchCollapsed(
                    preview,
                    topology,
                    node,
                    branch,
                    toggle,
                    children,
                    true,
                );
            } else if (event.key === 'ArrowRight' && collapsed) {
                event.preventDefault();
                setPreviewBranchCollapsed(
                    preview,
                    topology,
                    node,
                    branch,
                    toggle,
                    children,
                    false,
                );
            }
        });
        branch.append(toggle, children);
        node.branchControls = { branch, toggle, children };
        paintPreviewBranchControl(node, branch, toggle, children);
        wrapper.appendChild(branch);
        return wrapper;
    }

    function saveDiscoveredOwnPreviewPosts(preview) {
        if (!preview?.threadId
            || !/^\d{1,20}$/.test(String(preview.currentUserId || ''))) return;
        const pendingDiscovery = state.pendingSelfReplyDiscovery.has(preview.threadId);
        if (!pendingDiscovery && !state.readEntries.has(preview.threadId)) return;
        const ownPostNumbers = preview.comments
            .filter((entry) => entry.userId === preview.currentUserId)
            .map((entry) => entry.number);
        if (!ownPostNumbers.length) return;
        saveKnownSelfPosts(
            preview.threadId,
            ownPostNumbers,
            {
                forcePersist: pendingDiscovery
                    || state.dirtySelfPostThreads.has(preview.threadId),
            },
        ).then((saved) => {
            if (saved && pendingDiscovery) {
                state.pendingSelfReplyDiscovery.delete(preview.threadId);
            }
        });
    }

    function renderThreadPreview(preview, loadingMessage = '') {
        const panel = state.previewPanel;
        if (!panel) return;
        clearPreviewLastCommentHighlight();
        cancelPreviewReadDwell();
        state.previewData = preview || null;
        state.previewReadCandidate = null;
        state.previewCommentTopology = null;
        disposePreviewReplyFields(panel);
        panel.replaceChildren();
        panel.scrollTop = 0;
        panel.classList.add('hltv-sp-open');
        syncPreviewActivityColors(preview);

        const heading = document.createElement('div');
        heading.className = 'hltv-sp-preview-heading';
        const title = document.createElement('span');
        if (preview?.thread) {
            const profileUrl = parseSameOriginUrl(preview.thread.profileHref);
            const author = profileUrl && /^\/profile\/\d{1,20}(?:\/|$)/i.test(profileUrl.pathname)
                ? document.createElement('a')
                : document.createElement('strong');
            if (author.tagName === 'A') {
                author.href = profileUrl.href;
                author.className = 'a-default';
            }
            author.textContent = preview.thread.author;
            title.append(document.createTextNode('THREAD BY '), author);
            if (state.settings.enableLocalUserScores && preview.thread.userId) {
                author.dataset.hltvSpScoreTarget = preview.thread.userId;
                title.appendChild(createLocalScoreBadge(preview.thread.userId));
            }
            if (preview.thread.userId) {
                title.appendChild(createPreviewUserTagSlot({
                    id: preview.thread.userId,
                    name: preview.thread.author,
                }));
            }
            const forum = document.createElement('span');
            forum.className = 'hltv-sp-preview-forum';
            forum.textContent = preview.forumLabel;
            if (state.settings.enableCustomThreadColors) {
                forum.style.color = activitySourceColor(preview.forumId);
            }
            title.appendChild(forum);
            if (preview.locked) {
                const locked = document.createElement('span');
                locked.className = 'hltv-sp-preview-locked';
                locked.textContent = 'Locked';
                locked.title = 'This thread is locked.';
                title.appendChild(locked);
            }
        } else {
            title.textContent = loadingMessage || 'Thread preview';
        }
        const close = document.createElement('button');
        close.type = 'button';
        close.textContent = '\u00D7';
        close.title = 'Close preview';
        close.addEventListener('click', () => closeThreadPreview({ force: true }));
        heading.append(title, close);
        panel.appendChild(heading);

        if (!preview) {
            const message = document.createElement('div');
            message.textContent = loadingMessage;
            panel.appendChild(message);
            positionThreadPreview();
            syncRelativeAgeTimer({ updateNow: true });
            return;
        }

        const preparedTopology = preparePreviewCommentTopology(preview);
        const { topology, revealNotificationTarget } = preparedTopology;
        state.previewCommentTopology = topology;
        saveDiscoveredOwnPreviewPosts(preview);

        if (preview.threadTitle) {
            const threadUrl = validPreviewOpenUrl(
                preview.openUrl || preview.threadUrl,
                preview.threadId,
            );
            const threadTitle = threadUrl
                ? document.createElement('a')
                : document.createElement('div');
            threadTitle.className = 'hltv-sp-preview-thread-title';
            threadTitle.textContent = preview.threadTitle;
            if (threadTitle.tagName === 'A') {
                threadTitle.href = threadUrl.href;
                threadTitle.title = 'Open thread';
            }
            panel.appendChild(threadTitle);
        }

        if (preview.thread) {
            panel.appendChild(createPreviewPost(
                preview.thread,
                'hltv-sp-preview-thread',
                null,
                preview,
            ));
        }

        const threadComposer = preview.canReply
            ? createPreviewReplyComposer(preview)
            : null;
        if (threadComposer && state.settings.replyComposerAfterOriginalPost) {
            placePreviewThreadComposer(threadComposer);
        }

        if (preview.comments.length) {
            const hiddenTags = getHiddenUserTagSet();
            const hiddenCount = preview.comments.filter((entry) => (
                shouldHideUserComment(entry.userId, hiddenTags)
            )).length;
            const visibleCount = preview.comments.length - hiddenCount;
            const commentsFragment = document.createDocumentFragment();
            const commentsLabel = document.createElement('div');
            commentsLabel.className = 'hltv-sp-preview-comments-label';
            commentsLabel.textContent = hiddenCount
                ? `Comments (${visibleCount} shown, ${hiddenCount} hidden)`
                : `Comments (${preview.replyCount})`;
            commentsFragment.appendChild(commentsLabel);
            const commentsTree = document.createElement('div');
            commentsTree.className = 'hltv-sp-preview-comments-tree';
            for (const node of topology.roots) {
                commentsTree.appendChild(createPreviewCommentNode(
                    node,
                    preview,
                    topology,
                    hiddenTags,
                ));
            }
            commentsFragment.appendChild(commentsTree);
            panel.appendChild(commentsFragment);
        }
        syncPreviewCommentNavigation(preview, topology);
        if (revealNotificationTarget) {
            const target = topology.nodeByReplyId.get(String(preview.notificationReplyId || ''));
            if (target?.card && !target.card.hidden && !target.card.closest('[hidden]')) {
                state.previewProgrammaticScrollUntil = Date.now() + 500;
                target.card.scrollIntoView({ block: 'nearest' });
            }
        }
        if (threadComposer && !state.settings.replyComposerAfterOriginalPost) {
            placePreviewThreadComposer(threadComposer);
        }
        resetPreviewReadCandidate(preview, topology);
        positionThreadPreview();
        syncRelativeAgeTimer({ updateNow: true });
    }

    function previewCacheWeight(preview) {
        if (!preview) return 0;
        const entryWeight = (entry) => String(entry?.text || '').length
            + String(entry?.flag?.src || '').length
            + String(entry?.flair?.href || '').length
            + String(entry?.flair?.logoSrc || '').length
            + (Array.isArray(entry?.images) ? entry.images : []).reduce((total, image) => (
                total
                + String(image?.src || '').length
                + String(image?.href || '').length
                + String(image?.alt || '').length
                + 200
            ), 0);
        let weight = String(preview.threadTitle || '').length
            + entryWeight(preview.thread);
        for (const comment of preview.comments || []) {
            weight += entryWeight(comment) + 200;
            if (weight > CONFIG.maxPreviewCacheChars) break;
        }
        return weight;
    }

    function cacheThreadPreview(key, preview) {
        const weight = previewCacheWeight(preview);
        state.previewCache.delete(key);
        if (weight > CONFIG.maxPreviewCacheChars) return;
        state.previewCache.set(key, { storedAt: Date.now(), preview, weight });
        let totalWeight = [...state.previewCache.values()]
            .reduce((total, entry) => total + Number(entry.weight || previewCacheWeight(entry.preview)), 0);
        while (state.previewCache.size > CONFIG.maxPreviewCacheEntries
            || totalWeight > CONFIG.maxPreviewCacheChars) {
            const oldestKey = state.previewCache.keys().next().value;
            const oldest = state.previewCache.get(oldestKey);
            totalWeight -= Number(oldest?.weight || previewCacheWeight(oldest?.preview));
            state.previewCache.delete(oldestKey);
        }
    }

    function deleteThreadPreviewCache(threadId) {
        const id = String(threadId || '');
        if (!/^[1-9]\d{0,19}$/.test(id)) return;
        const prefix = `forum-thread:${id}`;
        for (const key of state.previewCache.keys()) {
            if (key === prefix || key.startsWith(`${prefix}:`)) {
                state.previewCache.delete(key);
            }
        }
    }

    async function openThreadPreview(link, options = {}) {
        if (!state.settings.enableThreadPreviews) return;
        const target = threadPreviewTarget(link);
        const url = parseSameOriginUrl(target?.fetchUrl);
        if (!target || !url) return;
        const key = target.cacheKey;
        if (state.previewActiveLink !== link) return;
        if (state.previewCollapseThreadId !== target.threadId) {
            state.previewCollapsedReplyIds.clear();
            state.previewCollapseThreadId = target.threadId;
            state.previewCommentTopology = null;
            state.previewRevealedNotificationReplyId = '';
        }
        createThreadPreviewPopup();
        const cached = state.previewCache.get(key);
        if (!options.force && cached && cached.storedAt > Date.now() - CONFIG.previewCacheTtlMs) {
            state.previewCache.delete(key);
            state.previewCache.set(key, cached);
            renderThreadPreview({
                ...cached.preview,
                openUrl: target.openUrl,
                notificationReplyId: target.replyId,
            });
            return;
        }

        state.previewAbortController?.abort();
        const controller = new AbortController();
        state.previewAbortController = controller;
        renderThreadPreview(null, 'Loading preview\u2026');
        try {
            const doc = await fetchSameOriginDocument(url.href, {
                contentLabel: 'thread content',
                expectedSelector: '.forumthread, .post',
                requireExpectedSelector: true,
                cache: 'no-store',
                signal: controller.signal,
            });
            if (controller.signal.aborted || state.previewActiveLink !== link) return;
            const metadata = [...state.threadMetadataByKey.values()].find((entry) => (
                String(entry?.id || '') === target.threadId
                || threadIdFromHref(entry?.href) === target.threadId
            ));
            const forum = inferNativeForum(link) || forumById.get(metadata?.forumId);
            const preview = parseThreadPreview(
                doc,
                target.threadId,
                forum?.id || '',
                target.fallbackTitle,
                target.threadUrl,
            );
            cacheThreadPreview(key, preview);
            const metadataKey = linkKey(preview.threadUrl);
            if (metadataKey) {
                const previous = state.threadMetadataByKey.get(metadataKey)
                    || { key: metadataKey, href: preview.threadUrl };
                state.threadMetadataByKey.set(metadataKey, {
                    ...previous,
                    createdAt: preview.createdAt || previous.createdAt || 0,
                    activityAt: preview.activityAt || previous.activityAt || 0,
                });
            }
            renderThreadPreview({
                ...preview,
                openUrl: target.openUrl,
                notificationReplyId: target.replyId,
            });
            annotateActivityLinks();
        } catch (error) {
            if (isAbortErrorLike(error) || controller.signal.aborted) return;
            renderThreadPreview(null, 'Preview could not be loaded.');
            throw error;
        } finally {
            if (state.previewAbortController === controller) state.previewAbortController = null;
        }
    }

    async function cycleSortOrder() {
        state.settings = {
            ...state.settings,
            sortOrder: getNextSortOrder(state.settings.sortOrder),
        };

        updateSortButton();
        applySortOrder();
        try {
            await queueSortOrderSave(state.settings.sortOrder);
        } catch (error) {
            warn('Could not save sidebar sort order.', error);
        }
    }

    function updateSortButton() {
        if (!state.sortButton) return;

        const sortState = getSortState(state.settings.sortOrder);
        state.sortButton.textContent = sortState.icon;
        state.sortButton.title = sortState.title;
        state.sortButton.setAttribute('aria-label', sortState.title);
    }

    function getActivityLinks() {
        if (!state.sidebar) return [];

        return [...state.sidebar.querySelectorAll('a[href]')]
            .filter((link) => isActivityEntry(link));
    }

    function activityTrailingTextNode(link) {
        if (!(link instanceof Element)) return null;
        const nodes = [...link.childNodes];
        for (let index = nodes.length - 1; index >= 0; index -= 1) {
            const node = nodes[index];
            if (node.nodeType === Node.TEXT_NODE && cleanText(node.textContent)) return node;
        }
        return null;
    }

    function normaliseMatchTrailingCount(link, fallbackCount = 0) {
        if (!(link instanceof Element) || getActivityKind(link.href) !== 'match') return 0;
        let countElement = link.querySelector(':scope > .hltv-sp-sport-count');
        const textNode = countElement ? null : activityTrailingTextNode(link);
        const label = cleanText(countElement?.textContent || textNode?.textContent);
        const count = /^(?:\d+|\d{1,3}(?:[,\s]\d{3})+)$/.test(label)
            ? clampInteger(parseInteger(label), 0, 10_000_000, fallbackCount)
            : clampInteger(fallbackCount, 0, 10_000_000, 0);

        if (!countElement) {
            countElement = document.createElement('span');
            countElement.className = 'hltv-sp-sport-count';
            if (textNode) textNode.replaceWith(countElement);
            else link.appendChild(countElement);
        }
        countElement.textContent = String(count);
        link.dataset.hltvSpComments = String(count);
        return count;
    }

    function createSportPoolLink(source) {
        const url = parseSameOriginUrl(source.getAttribute('href') || source.href);
        const kind = getActivityKind(url?.href);
        if (!url || (kind !== 'news' && kind !== 'match')) return null;
        const topicText = cleanText(source.querySelector('.topic')?.textContent || source.textContent)
            .slice(0, CONFIG.maxThreadTitleChars);
        if (!topicText) return null;

        const link = document.createElement('a');
        link.href = url.href;
        link.className = `col-box activity a-reset hltv-sp-sport-pool ${kind === 'news' ? 'newsCat' : 'matchCat'}`;
        link.dataset.hltvSpSportPool = 'true';
        link.dataset.hltvSpSportPoolCreated = 'true';
        const topic = document.createElement('span');
        topic.className = 'topic a-default';
        topic.textContent = topicText;
        topic.title = topicText;
        const count = document.createElement('span');
        count.className = 'hltv-sp-sport-count';
        count.textContent = String(
            kind === 'match'
                ? normaliseMatchTrailingCount(source, 0)
                : extractSidebarCommentCount(source),
        );
        link.append(topic, count);
        return link;
    }

    function ensureSportPoolLayout(link) {
        if (!(link instanceof Element)) return;
        const topic = link.querySelector(':scope > .topic');
        if (topic && !topic.hasAttribute('title')) {
            topic.title = cleanText(topic.textContent);
        }
        if (getActivityKind(link.href) === 'match') {
            normaliseMatchTrailingCount(link, 0);
            return;
        }
        if (link.querySelector(':scope > .hltv-sp-sport-count')) return;
        for (const node of [...link.childNodes]) {
            if (node.nodeType !== Node.TEXT_NODE) continue;
            const countText = String(node.textContent || '').trim();
            if (!/^\d[\d,.]*$/.test(countText)) continue;
            const count = document.createElement('span');
            count.className = 'hltv-sp-sport-count';
            count.textContent = countText;
            node.replaceWith(count);
            return;
        }
    }

    function harvestSportModeActivityEntries() {
        if (!state.sidebar || !state.settings.enableCustomThreadFetching) return 0;
        const existingByKey = new Map(getActivityLinks().map((link) => [linkKey(link.href), link]));
        const additions = [];

        for (const source of document.querySelectorAll('.activitylist a.promode-only[href]')) {
            const kind = getActivityKind(source.href);
            if (kind !== 'news' && kind !== 'match') continue;
            const key = linkKey(source.href);
            if (!key) continue;
            const existing = existingByKey.get(key);
            if (existing) {
                if (existing.classList.contains('promode-only')) {
                    existing.dataset.hltvSpSportPoolWasPromode = 'true';
                }
                existing.classList.remove('promode-only');
                existing.classList.add('hltv-sp-sport-pool');
                existing.dataset.hltvSpSportPool = 'true';
                ensureSportPoolLayout(existing);
                continue;
            }
            const link = createSportPoolLink(source);
            if (!link) continue;
            ensureSportPoolLayout(link);
            existingByKey.set(key, link);
            additions.push(link);
        }

        if (additions.length) {
            suppressSidebarObserver(() => {
                const fragment = document.createDocumentFragment();
                for (const link of additions) fragment.appendChild(link);
                state.sidebar.appendChild(fragment);
            });
        }
        return additions.length;
    }

    function removeFetchedActivityRows() {
        state.fetchRunId += 1;
        state.forumFetchAbortController?.abort();
        state.forumFetchAbortController = null;
        if (!state.sidebar) return;
        suppressSidebarObserver(() => {
            for (const link of state.sidebar.querySelectorAll('a.hltv-sp-extra')) {
                link.remove();
            }
            for (const link of state.sidebar.querySelectorAll('a.hltv-sp-sport-pool')) {
                if (link.dataset.hltvSpSportPoolCreated === 'true') {
                    link.remove();
                    continue;
                }
                if (link.dataset.hltvSpSportPoolWasPromode === 'true') {
                    link.classList.add('promode-only');
                }
                link.classList.remove('hltv-sp-sport-pool');
                delete link.dataset.hltvSpSportPool;
                delete link.dataset.hltvSpSportPoolCreated;
                delete link.dataset.hltvSpSportPoolWasPromode;
            }
        });
    }

    function isActivityEntry(link) {
        const url = parseSameOriginUrl(link.getAttribute('href') || link.href);
        return Boolean(url && /^\/(?:forums\/threads|news|matches)\/\d+(?:\/|$)/i.test(url.pathname));
    }

    function linkKey(href) {
        const parsedUrl = parseSameOriginUrl(href);
        return parsedUrl ? parsedUrl.pathname.replace(/\/$/, '').toLowerCase() : '';
    }

    function threadIdFromHref(href) {
        const url = parseSameOriginUrl(href);
        return url?.pathname.match(/^\/forums\/threads\/(\d{1,20})(?:\/|$)/i)?.[1] || '';
    }

    function notificationForumPreviewTarget(link) {
        if (!(link instanceof Element)
            || !link.matches('#popupnotification .notification-popup-elm > a[href]')) {
            return null;
        }
        const notification = link.closest('.notification-popup-elm');
        const type = cleanText(notification?.querySelector('.header > span:first-child')?.textContent);
        if (type.toLocaleLowerCase() !== 'forum') return null;
        const url = parseSameOriginUrl(link.getAttribute('href') || link.href);
        if (!url || url.pathname !== '/') return null;
        const pageIds = url.searchParams.getAll('pageid');
        const threadIds = url.searchParams.getAll('threadid');
        const replyIds = url.searchParams.getAll('replyid');
        if (pageIds.length !== 1 || pageIds[0] !== '18'
            || threadIds.length !== 1 || !/^[1-9]\d{0,19}$/.test(threadIds[0])
            || replyIds.length !== 1 || !/^[1-9]\d{0,19}$/.test(replyIds[0])
            || url.hash !== `#r${replyIds[0]}`) {
            return null;
        }
        const threadId = threadIds[0];
        const replyId = replyIds[0];
        const rawTitle = cleanText(
            [...(notification?.querySelectorAll('.message .bang') || [])].at(-1)?.textContent,
        );
        const fallbackTitle = rawTitle.replace(/^["']|["']$/g, '').trim();
        return {
            threadId,
            replyId,
            fetchUrl: url.href,
            threadUrl: '',
            openUrl: url.href,
            fallbackTitle,
            cacheKey: `forum-thread:${threadId}:reply:${replyId}`,
            notification: true,
        };
    }

    function threadPreviewTarget(link) {
        const notificationTarget = notificationForumPreviewTarget(link);
        if (notificationTarget) return notificationTarget;
        if (!(link instanceof Element)) return null;
        const url = parseSameOriginUrl(link.getAttribute('href') || link.href);
        const threadId = url?.pathname.match(
            /^\/forums\/threads\/([1-9]\d{0,19})(?:\/|$)/i,
        )?.[1] || '';
        if (!url || !threadId) return null;
        return {
            threadId,
            replyId: url.hash.match(/^#r([1-9]\d{0,19})$/)?.[1] || '',
            fetchUrl: url.href,
            threadUrl: url.href,
            openUrl: url.href,
            fallbackTitle: cleanText(link.querySelector('.topic')?.textContent),
            cacheKey: `forum-thread:${threadId}`,
            notification: false,
        };
    }

    function previewHoverAnchor(link) {
        const target = threadPreviewTarget(link);
        if (!target) return null;
        return target.notification ? link : link.querySelector('.topic');
    }

    function validPreviewOpenUrl(value, expectedThreadId) {
        const url = parseSameOriginUrl(value);
        if (!url || !/^[1-9]\d{0,19}$/.test(String(expectedThreadId || ''))) return null;
        if (threadIdFromHref(url.href) === expectedThreadId) return url;
        const threadIds = url.searchParams.getAll('threadid');
        const replyIds = url.searchParams.getAll('replyid');
        if (url.pathname !== '/'
            || url.searchParams.getAll('pageid').length !== 1
            || url.searchParams.get('pageid') !== '18'
            || threadIds.length !== 1
            || threadIds[0] !== expectedThreadId
            || replyIds.length !== 1
            || !/^[1-9]\d{0,19}$/.test(replyIds[0])
            || url.hash !== `#r${replyIds[0]}`) {
            return null;
        }
        return url;
    }

    function getActivityKind(href) {
        const url = parseSameOriginUrl(href);
        if (!url) return 'unknown';
        if (/^\/forums\/threads\/\d+(?:\/|$)/i.test(url.pathname)) return 'forum';
        if (/^\/news\/\d+(?:\/|$)/i.test(url.pathname)) return 'news';
        if (/^\/matches\/\d+(?:\/|$)/i.test(url.pathname)) return 'match';
        return 'unknown';
    }

    function clearActivityColorClasses(link, { preserveMetadata = false } = {}) {
        for (const forum of FORUMS) link.classList.remove(forumClassName(forum));
        link.classList.remove(
            'hltv-sp-colored-entry',
            'hltv-sp-type-news',
            'hltv-sp-type-match',
            'hltv-sp-forum-unknown',
        );
        link.style.removeProperty('--hltv-sp-entry-color');
        if (preserveMetadata) return;
        delete link.dataset.hltvSpForumId;
        delete link.dataset.hltvSpSourceId;
        delete link.dataset.hltvSpType;
    }

    function removeCustomActivityColors(root = document) {
        for (const link of elementsWithin(root, '.activitylist a[href]')) {
            if (!isActivityEntry(link)) continue;
            clearActivityColorClasses(link, { preserveMetadata: true });
        }
        syncPreviewActivityColors();
    }

    function syncPreviewActivityColors(preview = state.previewData) {
        const panel = state.previewPanel;
        if (!panel) return;
        const enabled = Boolean(state.settings.enableCustomThreadColors);
        panel.classList.toggle('hltv-sp-preview-native-colors', !enabled);
        if (enabled) {
            const sourceId = state.previewActiveLink?.dataset.hltvSpSourceId
                || preview?.forumId
                || '';
            const color = sourceId
                ? activitySourceColor(sourceId)
                : CONTENT_TYPE_COLORS.unknown;
            panel.style.setProperty('--hltv-sp-preview-source-color', color);
            for (const label of panel.querySelectorAll('.hltv-sp-preview-forum')) {
                label.style.setProperty('color', color);
            }
            return;
        }
        panel.style.removeProperty('--hltv-sp-preview-source-color');
        for (const label of panel.querySelectorAll('.hltv-sp-preview-forum')) {
            label.style.removeProperty('color');
        }
    }

    function inferNativeForum(link) {
        if (link.classList.contains('off-topic') || link.classList.contains('offtopicCat')) {
            return forumById.get('offtopic');
        }
        const classMappings = [
            ['fantasyCat', 'fantasy'],
            ['bettingCat', 'betting'],
            ['hardwareCat', 'hardware'],
            ['bugsCat', 'bugs'],
            ['bugCat', 'bugs'],
        ];
        for (const [className, forumId] of classMappings) {
            if (link.classList.contains(className)) return forumById.get(forumId);
        }

        const title = cleanText(link.querySelector('.topic')?.getAttribute('title')).toLowerCase();
        const prefixMappings = [
            [/^off[ -]?topic\s*:/, 'offtopic'],
            [/^fantasy\s*:/, 'fantasy'],
            [/^betting\s*:/, 'betting'],
            [/^hardware(?:\s*&\s*tweaks)?\s*:/, 'hardware'],
            [/^bugs?(?:\s*&\s*suggestions)?\s*:/, 'bugs'],
            [/^(?:cs|counter-strike)\s*:/, 'counterstrike'],
        ];
        for (const [pattern, forumId] of prefixMappings) {
            if (pattern.test(title)) return forumById.get(forumId);
        }
        if (link.classList.contains('csCat')) return forumById.get('counterstrike');
        const explicit = forumById.get(link.dataset.hltvSpForumId);
        if (explicit) return explicit;
        return null;
    }

    function applyActivityColor(link, kind, metadata = null) {
        const nativeForum = kind === 'forum' ? inferNativeForum(link) : null;
        clearActivityColorClasses(link);
        link.dataset.hltvSpType = kind;

        if (!state.settings.enableCustomThreadColors) {
            if (kind === 'forum') {
                const forum = nativeForum || forumById.get(metadata?.forumId);
                if (forum) {
                    link.dataset.hltvSpForumId = forum.id;
                    link.dataset.hltvSpSourceId = forum.id;
                }
            } else if (kind === 'news') {
                link.dataset.hltvSpSourceId = 'news';
            } else if (kind === 'match') {
                link.dataset.hltvSpSourceId = 'matches';
            }
            return;
        }

        link.classList.add('hltv-sp-colored-entry');

        if (kind === 'forum') {
            const forum = nativeForum || forumById.get(metadata?.forumId);
            if (forum) {
                markForum(link, forum);
            } else {
                link.classList.add('hltv-sp-forum-unknown');
            }
        } else if (kind === 'news') {
            link.classList.add('hltv-sp-type-news');
            link.dataset.hltvSpSourceId = 'news';
            link.style.setProperty('--hltv-sp-entry-color', activitySourceColor('news'));
        } else if (kind === 'match') {
            link.classList.add('hltv-sp-type-match');
            link.dataset.hltvSpSourceId = 'matches';
            link.style.setProperty('--hltv-sp-entry-color', activitySourceColor('matches'));
        } else {
            delete link.dataset.hltvSpSourceId;
        }
    }

    function applyForumVisibilityToLink(link) {
        if (!state.settings.enableCustomThreadFetching) {
            link.classList.remove('hltv-sp-forum-hidden', 'hltv-sp-source-hidden');
            return;
        }
        const kind = getActivityKind(link.href);
        let sourceId = '';
        if (kind === 'forum') {
            sourceId = link.dataset.hltvSpForumId || inferNativeForum(link)?.id || '';
        } else if (kind === 'news') {
            sourceId = 'news';
        } else if (kind === 'match') {
            sourceId = 'matches';
        }
        const selected = state.settings.selectedForums;
        const shouldHide = sourceId
            ? !selected.includes(sourceId)
            : kind === 'forum' && FORUMS.some((forum) => !selected.includes(forum.id));
        link.classList.remove('hltv-sp-forum-hidden');
        link.classList.toggle(
            'hltv-sp-source-hidden',
            shouldHide,
        );
    }

    function applyForumVisibilityInRoot(root = document) {
        for (const link of elementsWithin(
            root,
            '.activitylist a[href*="/forums/threads/"], '
            + '.activitylist a[href*="/news/"], '
            + '.activitylist a[href*="/matches/"]',
        )) {
            applyForumVisibilityToLink(link);
        }
    }

    function formatRelativeAge(timestamp, now = Date.now()) {
        const value = Number(timestamp);
        if (!Number.isFinite(value) || value <= 0) return '';
        const seconds = Math.max(0, Math.floor((now - value) / 1000));
        if (seconds < 45) return 'now';
        if (seconds < 3600) return `${Math.floor(seconds / 60)}m`;
        if (seconds < 86400) return `${Math.floor(seconds / 3600)}h`;
        if (seconds < 604800) return `${Math.floor(seconds / 86400)}d`;
        if (seconds < 2_592_000) return `${Math.floor(seconds / 604800)}w`;
        if (seconds < 31_536_000) return `${Math.floor(seconds / 2_592_000)}mo`;
        return `${Math.floor(seconds / 31_536_000)}y`;
    }

    function updateRelativeAge(link, metadata = null) {
        const timestamp = Number(metadata?.activityAt || link.dataset.hltvSpActivityAt || 0);
        const relativeLabel = cleanText(
            metadata?.relativeAgeLabel || link.dataset.hltvSpRelativeAgeLabel || '',
        );
        let age = link.querySelector(':scope > .hltv-sp-relative-age');
        if (!timestamp && !relativeLabel) {
            age?.remove();
            return;
        }
        if (!age) {
            age = document.createElement('span');
            age.className = 'hltv-sp-relative-age';
            link.appendChild(age);
        }
        if (timestamp) {
            age.textContent = formatRelativeAge(timestamp);
            age.title = new Date(timestamp).toLocaleString();
            link.dataset.hltvSpActivityAt = String(timestamp);
            delete link.dataset.hltvSpRelativeAgeLabel;
        } else {
            age.textContent = relativeLabel;
            age.title = `HLTV reports: ${relativeLabel}`;
            link.dataset.hltvSpRelativeAgeLabel = relativeLabel;
            delete link.dataset.hltvSpActivityAt;
        }
    }

    function updateAllRelativeAges() {
        if (!state.settings.showRelativeAges) return;
        updatePostRelativeAges(document);
        updatePreviewRelativeAges();
    }

    function updatePostRelativeAges(root = document) {
        const timestamps = elementsWithin(root, [
            '.forumthread .forum-bottombar .time',
            '.forum[data-forum-thread-id] .post .forum-bottombar .time',
        ].join(', '));
        for (const time of timestamps) {
            const timestamp = Number(time.dataset.hltvSpTimestamp) || extractTimestampFromRoot(time);
            if (!timestamp) continue;
            time.dataset.hltvSpTimestamp = String(timestamp);
            let age = time.nextElementSibling;
            if (!age?.classList.contains('hltv-sp-post-relative-age')) {
                age = document.createElement('span');
                age.className = 'hltv-sp-post-relative-age';
                time.after(age);
            }
            age.textContent = `(${formatRelativeAge(timestamp)})`;
            age.title = new Date(timestamp).toLocaleString();
        }
    }

    function updatePreviewRelativeAges() {
        const panel = state.previewPanel;
        if (!panel?.classList.contains('hltv-sp-open')) return;
        for (const age of panel.querySelectorAll(
            '.hltv-sp-preview-relative-age[data-hltv-sp-timestamp]',
        )) {
            const timestamp = Number(age.dataset.hltvSpTimestamp);
            if (!Number.isFinite(timestamp) || timestamp <= 0) continue;
            age.textContent = formatRelativeAge(timestamp);
            age.title = new Date(timestamp).toLocaleString();
        }
    }

    function hasRelativeAgeTargets() {
        return Boolean(
            document.querySelector(
                '.forumthread .forum-bottombar .time, '
                + '.forum[data-forum-thread-id] .post .forum-bottombar .time',
            )
            || state.previewPanel?.classList.contains('hltv-sp-open'),
        );
    }

    function readEntryThreshold(record) {
        return record
            ? Math.max(Number(record.seenReplyCount) || 0, Number(record.maxPostNo) || 0)
            : 0;
    }

    function unreadReplyCount(record, totalComments) {
        if (!record) return 0;
        const threshold = readEntryThreshold(record);
        const comments = Math.max(0, Number(totalComments) || 0);
        const ignoredOwnPosts = normaliseSelfPostNumbers(
            record.selfPostNumbers,
            threshold,
        ).filter((number) => number <= comments).length;
        return Math.max(0, comments - threshold - ignoredOwnPosts);
    }

    function mergeSelfPostNumbersIntoReadEntry(threadId, postNumbers) {
        const normalisedThreadId = String(threadId || '');
        if (!/^\d{1,20}$/.test(normalisedThreadId)) return false;
        const previous = state.readEntries.get(normalisedThreadId) || {
            seenReplyCount: 0,
            maxPostNo: 0,
            selfPostNumbers: [],
            visitedAt: 0,
        };
        const threshold = readEntryThreshold(previous);
        const previousSelfPostNumbers = previous.selfPostNumbers || [];
        const merged = normaliseSelfPostNumbers(
            [...previousSelfPostNumbers, ...(postNumbers || [])],
            threshold,
        );
        if (merged.length === previousSelfPostNumbers.length
            && merged.every((number, index) => number === previousSelfPostNumbers[index])) {
            return false;
        }
        state.readEntries.set(normalisedThreadId, {
            ...previous,
            selfPostNumbers: merged,
            visitedAt: Math.max(previous.visitedAt || 0, Date.now()),
        });
        return true;
    }

    function saveKnownSelfPosts(
        threadId,
        postNumbers,
        { forcePersist = false } = {},
    ) {
        if (!state.settings.enableReadStatus) return Promise.resolve(false);
        const normalisedThreadId = String(threadId || '');
        const changed = mergeSelfPostNumbersIntoReadEntry(
            normalisedThreadId,
            postNumbers,
        );
        if (!changed && !forcePersist) return Promise.resolve(true);
        return saveReadState()
            .then(() => annotateActivityLinks())
            .then(() => {
                state.dirtySelfPostThreads.delete(normalisedThreadId);
                return true;
            })
            .catch((error) => {
                if (/^\d{1,20}$/.test(normalisedThreadId)) {
                    state.dirtySelfPostThreads.add(normalisedThreadId);
                }
                warn('Could not save self-authored read exclusions.', error);
                return false;
            });
    }

    function stopRelativeAgeTimer() {
        if (!state.relativeAgeTimer) return;
        window.clearInterval(state.relativeAgeTimer);
        state.relativeAgeTimer = null;
    }

    function syncRelativeAgeTimer({ updateNow = false } = {}) {
        if (!state.relativeAgeVisibilityHandler) {
            state.relativeAgeVisibilityHandler = () => {
                syncRelativeAgeTimer({ updateNow: !document.hidden });
            };
            document.addEventListener(
                'visibilitychange',
                state.relativeAgeVisibilityHandler,
            );
        }

        const shouldRun = Boolean(
            state.settings.showRelativeAges
            && !document.hidden
            && hasRelativeAgeTargets(),
        );
        if (!shouldRun) {
            stopRelativeAgeTimer();
            return;
        }
        if (updateNow) updateAllRelativeAges();
        if (state.relativeAgeTimer) return;
        state.relativeAgeTimer = window.setInterval(() => {
            if (!state.settings.showRelativeAges
                || document.hidden
                || !hasRelativeAgeTargets()) {
                syncRelativeAgeTimer();
                return;
            }
            updateAllRelativeAges();
        }, 60000);
    }

    function startRelativeAgeTimer() {
        syncRelativeAgeTimer({ updateNow: true });
    }

    function isThreadUnread(link) {
        if (!state.settings.enableReadStatus) return false;
        if (getActivityKind(link.href) !== 'forum') return false;
        const record = state.readEntries.get(threadIdFromHref(link.href));
        if (!record) return false;
        const metadata = state.threadMetadataByKey.get(linkKey(link.href));
        const comments = extractSidebarCommentCount(link);
        const unreadCount = unreadReplyCount(record, comments);
        if (unreadCount > 0) return true;
        if (comments > readEntryThreshold(record)) return false;
        return Boolean(metadata?.activityAt && metadata.activityAt > record.visitedAt);
    }

    function updateReadBadge(link) {
        if (!state.settings.enableReadStatus || getActivityKind(link.href) !== 'forum') {
            link.querySelector(':scope > .hltv-sp-read-badge')?.remove();
            return;
        }

        let host = link.querySelector(':scope > .hltv-sp-read-badge');
        let badge = privateUiControl(host, '.hltv-sp-read-badge-value');
        if (!host || !badge) {
            host?.remove();
            const privateBadge = createPrivateUiHost({
                className: 'hltv-sp-private-ui-host hltv-sp-read-badge',
                styleText: PRIVATE_UI_STYLES.read,
            });
            host = privateBadge.host;
            badge = document.createElement('span');
            badge.className = 'hltv-sp-read-badge-value';
            privateBadge.root.appendChild(badge);
        }
        link.prepend(host);

        const record = state.readEntries.get(threadIdFromHref(link.href));
        const comments = extractSidebarCommentCount(link);
        const unreadCount = unreadReplyCount(record, comments);
        const unread = Boolean(record && isThreadUnread(link));
        badge.classList.toggle('hltv-sp-untracked', !record);
        badge.classList.toggle('hltv-sp-unread', unread);
        badge.textContent = !record ? '\u2022' : unread ? (unreadCount > 99 ? '99+' : String(Math.max(1, unreadCount))) : 'read';
        badge.title = !record
            ? 'Not visited since read tracking was enabled'
            : unread
                ? `${Math.max(1, unreadCount)} unread post${Math.max(1, unreadCount) === 1 ? '' : 's'}`
                : 'Read';
    }

    function ensurePreviewHover(link) {
        for (const trigger of link.querySelectorAll(':scope > .hltv-sp-preview-trigger')) trigger.remove();
        if (!threadPreviewTarget(link)) return;
        const topic = previewHoverAnchor(link);
        syncPreviewTooltip(link);
        if (topic && topic !== link) syncPreviewTooltip(topic);
        if (!state.settings.enableThreadPreviews) {
            link.classList.remove('hltv-sp-preview-active');
            return;
        }
        if (!topic || previewHoverTargets.has(topic)) return;
        previewHoverTargets.add(topic);
        topic.dataset.hltvSpPreviewHover = 'true';
        topic.addEventListener('mouseenter', () => {
            if (state.settings.enableThreadPreviews) scheduleThreadPreview(link);
        });
        topic.addEventListener('mouseleave', scheduleThreadPreviewClose);
    }

    function scanNotificationPreviewTargets(root = document) {
        for (const link of elementsWithin(
            root,
            '#popupnotification .notification-popup-elm > a[href]',
        )) {
            ensurePreviewHover(link);
        }
    }

    function syncPreviewTooltip(element) {
        if (element.dataset.hltvSpTitleCaptured !== 'true') {
            element.dataset.hltvSpTitleCaptured = 'true';
            element.dataset.hltvSpHadTitle = element.hasAttribute('title') ? 'true' : 'false';
            element.dataset.hltvSpOriginalTitle = element.getAttribute('title') || '';
        }
        if (state.settings.enableThreadPreviews) {
            element.removeAttribute('title');
        } else if (element.dataset.hltvSpHadTitle === 'true') {
            element.setAttribute('title', element.dataset.hltvSpOriginalTitle || '');
        } else {
            element.removeAttribute('title');
        }
    }

    function scheduleThreadPreview(link) {
        if (!state.settings.enableThreadPreviews) return;
        window.clearTimeout(state.previewCloseTimer);
        if (state.previewActiveLink !== link && previewHasProtectedInteraction()) return;
        if (state.previewActiveLink === link && state.previewPanel?.classList.contains('hltv-sp-open')) {
            positionThreadPreview(link);
            return;
        }

        window.clearTimeout(state.previewHoverTimer);
        state.previewAbortController?.abort();
        state.previewActiveLink?.classList.remove('hltv-sp-preview-active');
        state.previewActiveLink = link;
        link.classList.add('hltv-sp-preview-active');
        state.previewHoverTimer = window.setTimeout(() => {
            if (state.previewActiveLink !== link) return;
            openThreadPreview(link).catch((error) => {
                if (!isAbortErrorLike(error)) warn('Thread preview failed.', error);
            });
        }, 180);
    }

    function scheduleThreadPreviewClose() {
        window.clearTimeout(state.previewCloseTimer);
        state.previewCloseTimer = window.setTimeout(closeThreadPreview, 160);
    }

    function schedulePreviewCloseAfterInteraction() {
        if (state.previewPanel?.classList.contains('hltv-sp-open')
            && !state.previewPointerInside
            && !previewHasProtectedInteraction()) {
            scheduleThreadPreviewClose();
        }
    }

    function previewHasProtectedInteraction() {
        const panel = state.previewPanel;
        if (!panel?.classList.contains('hltv-sp-open')) return false;
        if (state.previewContextMenuActive) return true;
        if (panel.contains(document.activeElement)) return true;
        if ([...panel.querySelectorAll('.hltv-sp-preview-composer')]
            .some((host) => Boolean(previewReplyFields.get(host)?.hasDraft))) return true;
        return Boolean(
            queryPrivateUiAll(panel, '.hltv-sp-preview-composer-post:disabled').length
            || panel.querySelector('[data-hltv-sp-reaction-key][aria-busy="true"]'),
        );
    }

    function previewHasHoverTarget() {
        const panel = state.previewPanel;
        const topic = previewHoverAnchor(state.previewActiveLink);
        return Boolean(
            state.previewPointerInside
            || panel?.matches(':hover')
            || topic?.matches(':hover'),
        );
    }

    function closeThreadPreview(options = {}) {
        if (!options.force
            && (previewHasProtectedInteraction() || previewHasHoverTarget())) return;
        window.clearTimeout(state.previewHoverTimer);
        window.clearTimeout(state.previewCloseTimer);
        clearPreviewContextMenuProtection();
        clearPreviewLastCommentHighlight();
        cancelPreviewReadDwell();
        state.previewAbortController?.abort();
        state.previewAbortController = null;
        state.previewActiveLink?.classList.remove('hltv-sp-preview-active');
        state.previewActiveLink = null;
        state.previewPointerInside = false;
        state.previewReadCandidate = null;
        state.previewData = null;
        state.previewCollapsedReplyIds.clear();
        state.previewCollapseThreadId = '';
        state.previewCommentTopology = null;
        state.previewRevealedNotificationReplyId = '';
        state.previewProgrammaticScrollUntil = 0;
        state.previewPanel?.classList.remove('hltv-sp-open');
        disposePreviewReplyFields(state.previewPanel);
        state.previewPanel?.replaceChildren();
        syncRelativeAgeTimer();
    }

    function cancelPreviewReadDwell() {
        window.clearTimeout(state.previewReadDwellTimer);
        state.previewReadDwellTimer = null;
        state.previewReadDwellGeneration += 1;
    }

    function schedulePreviewReadDwell(candidate = state.previewReadCandidate) {
        cancelPreviewReadDwell();
        if (!state.settings.enableReadStatus
            || document.hidden
            || !candidate?.threadId
            || candidate.marked
            || !state.previewPanel?.classList.contains('hltv-sp-open')) return;
        const generation = state.previewReadDwellGeneration;
        state.previewReadDwellTimer = window.setTimeout(() => {
            state.previewReadDwellTimer = null;
            if (generation !== state.previewReadDwellGeneration
                || document.hidden
                || state.previewReadCandidate !== candidate
                || !state.previewPanel?.classList.contains('hltv-sp-open')) return;
            markPreviewThreadRead(candidate);
        }, CONFIG.previewReadDwellMs);
    }

    function markPreviewThreadRead(candidate = state.previewReadCandidate) {
        if (!state.settings.enableReadStatus
            || !candidate?.threadId
            || candidate.marked) return;
        candidate.marked = true;
        cancelPreviewReadDwell();
        const previous = state.readEntries.get(candidate.threadId) || {
            seenReplyCount: 0,
            maxPostNo: 0,
            selfPostNumbers: [],
            visitedAt: 0,
        };
        const seenReplyCount = Math.max(previous.seenReplyCount, candidate.seenReplyCount);
        const maxPostNo = Math.max(previous.maxPostNo, candidate.maxPostNo);
        state.readEntries.set(candidate.threadId, {
            seenReplyCount,
            maxPostNo,
            selfPostNumbers: normaliseSelfPostNumbers(
                previous.selfPostNumbers,
                Math.max(seenReplyCount, maxPostNo),
            ),
            visitedAt: Date.now(),
        });
        saveReadState()
            .then(() => annotateActivityLinks())
            .catch((error) => {
                candidate.marked = false;
                warn('Could not mark previewed thread as read.', error);
                if (state.previewReadCandidate === candidate) {
                    schedulePreviewReadDwell(candidate);
                }
            });
    }

    function markPreviewThreadReadFromInteraction(event) {
        if (!event.isTrusted
            || (event.type === 'scroll' && Date.now() < state.previewProgrammaticScrollUntil)
            || !state.previewPointerInside) return;
        markPreviewThreadRead(state.previewReadCandidate);
    }

    function positionThreadPreview(link = state.previewActiveLink) {
        const panel = state.previewPanel;
        const topic = previewHoverAnchor(link);
        if (!panel || !topic) return;
        const rect = topic.getBoundingClientRect();
        const margin = 10;
        const panelWidth = Math.min(500, Math.max(120, window.innerWidth - margin * 2));
        const left = Math.min(
            window.innerWidth - panelWidth - margin,
            Math.max(margin, rect.left),
        );
        panel.style.left = `${Math.max(margin, left)}px`;
        panel.style.width = `${panelWidth}px`;
        panel.style.maxHeight = '';
        const panelHeight = panel.offsetHeight || 180;
        const gap = 6;
        const below = rect.bottom + gap;
        const availableBelow = Math.max(0, window.innerHeight - margin - below);
        const availableAbove = Math.max(0, rect.top - margin - gap);
        let top;
        if (panelHeight <= availableBelow) {
            top = below;
        } else if (panelHeight <= availableAbove) {
            top = rect.top - gap - panelHeight;
        } else {
            const useBelow = availableBelow >= availableAbove;
            const availableHeight = useBelow ? availableBelow : availableAbove;
            panel.style.maxHeight = `${Math.max(40, Math.floor(availableHeight))}px`;
            top = useBelow
                ? below
                : Math.max(margin, rect.top - gap - availableHeight);
        }
        panel.style.top = `${top}px`;
    }

    function annotateActivityLinks() {
        const links = getActivityLinks();

        for (const link of links) {
            if (!Number.isFinite(Number(link.dataset.hltvSpSequence))) {
                link.dataset.hltvSpSequence = String(state.nextSequence++);
            }

            if (!Number.isFinite(Number(link.dataset.hltvSpDefaultOrder))) {
                link.dataset.hltvSpDefaultOrder = String(state.nextDefaultOrder++);
            }

            const key = linkKey(link.getAttribute('href') || link.href);
            const metadata = state.threadMetadataByKey.get(key);
            const kind = getActivityKind(link.getAttribute('href') || link.href);
            applyActivityColor(link, kind, metadata);
            applyForumVisibilityToLink(link);

            const comments = String(kind === 'match'
                ? normaliseMatchTrailingCount(link, metadata?.comments ?? 0)
                : metadata?.comments ?? extractSidebarCommentCount(link));
            const created = String(extractCreationSortValue(link.getAttribute('href') || link.href));
            if (link.dataset.hltvSpComments !== comments) link.dataset.hltvSpComments = comments;
            if (link.dataset.hltvSpCreated !== created) link.dataset.hltvSpCreated = created;
            updateReadBadge(link);
            link.querySelector(':scope > .hltv-sp-relative-age')?.remove();
            ensurePreviewHover(link);
        }

        return links;
    }

    function captureDefaultOrder() {
        const links = annotateActivityLinks();
        links.forEach((link, index) => {
            link.dataset.hltvSpDefaultOrder = String(index);
        });
        state.nextDefaultOrder = links.length;
        state.defaultOrderCaptured = true;
    }

    function applySortOrder() {
        if (!state.sidebar) return;

        const links = annotateActivityLinks()
            .filter((link) => link.parentElement === state.sidebar);
        const sortedLinks = [...links].sort((a, b) => compareByCurrentSort(a, b));

        if (sortedLinks.every((link, index) => link === links[index])) return;

        suppressSidebarObserver(() => {
            const fragment = document.createDocumentFragment();
            for (const link of sortedLinks) {
                fragment.appendChild(link);
            }
            state.sidebar.appendChild(fragment);
        });
    }

    function compareByCurrentSort(a, b) {
        const sortOrder = state.settings.sortOrder;

        if (sortOrder === 'comments') {
            return numericDataset(b, 'hltvSpComments') - numericDataset(a, 'hltvSpComments')
                || numericDataset(b, 'hltvSpCreated') - numericDataset(a, 'hltvSpCreated')
                || numericDataset(a, 'hltvSpSequence') - numericDataset(b, 'hltvSpSequence');
        }

        if (sortOrder === 'created') {
            return numericDataset(b, 'hltvSpCreated') - numericDataset(a, 'hltvSpCreated')
                || numericDataset(a, 'hltvSpSequence') - numericDataset(b, 'hltvSpSequence');
        }

        return numericDataset(a, 'hltvSpDefaultOrder') - numericDataset(b, 'hltvSpDefaultOrder')
            || numericDataset(a, 'hltvSpSequence') - numericDataset(b, 'hltvSpSequence');
    }

    function numericDataset(element, propertyName) {
        const value = Number(element.dataset[propertyName]);
        return Number.isFinite(value) ? value : 0;
    }

    function extractSidebarCommentCount(link) {
        const directText = [...link.childNodes]
            .filter((node) => node.nodeType === Node.TEXT_NODE)
            .map((node) => node.textContent || '')
            .join(' ')
            .trim();

        const directMatch = directText.match(/([\d,.\s]+)$/);
        if (directMatch) return parseInteger(directMatch[1]);

        const fullText = (link.textContent || '').replace(/\s+/g, ' ').trim();
        const fullMatch = fullText.match(/(?:^|\s)([\d,.\s]+)$/);
        return fullMatch ? parseInteger(fullMatch[1]) : 0;
    }

    function extractCreationSortValue(href) {
        const parsedUrl = parseSameOriginUrl(href);
        const match = parsedUrl?.pathname.match(/^\/(?:forums\/threads|news|matches)\/(\d+)(?:\/|$)/i);
        return match ? Number(match[1]) : 0;
    }

    function parseInteger(value) {
        const digits = String(value || '').replace(/[^\d]/g, '');
        return digits ? Number(digits) : 0;
    }

    function suppressSidebarObserver(callback) {
        state.suppressSidebarObserver = true;
        try {
            callback();
        } finally {
            window.setTimeout(() => {
                state.suppressSidebarObserver = false;
            }, 0);
        }
    }

    function observeSidebar() {
        if (!state.sidebar || state.sidebarObserver) return;

        let sortTimer = null;
        state.sidebarObserver = new MutationObserver(() => {
            if (state.suppressSidebarObserver) return;

            if (state.settings.enableCustomThreadFetching) {
                harvestSportModeActivityEntries();
            }
            annotateActivityLinks();

            if (state.settings.sortOrder !== 'default') {
                window.clearTimeout(sortTimer);
                sortTimer = window.setTimeout(applySortOrder, 100);
            }
        });

        state.sidebarObserver.observe(state.sidebar, { childList: true });
    }

    async function refreshFetchedForumThreads() {
        if (!state.sidebar) return { failedCount: 0, addedCount: 0, updatedCount: 0 };
        if (!state.settings.enableCustomThreadFetching) {
            removeFetchedActivityRows();
            annotateActivityLinks();
            captureDefaultOrder();
            applySortOrder();
            return { failedCount: 0, addedCount: 0, updatedCount: 0, cancelled: false };
        }

        const runId = ++state.fetchRunId;
        state.forumFetchAbortController?.abort();
        const abortController = new AbortController();
        state.forumFetchAbortController = abortController;
        const { signal } = abortController;
        let addedCount = 0;
        let updatedCount = 0;
        let failedCount = 0;
        let requestIndex = 0;
        const now = Date.now();
        const cacheByForumId = new Map(state.forumCacheById);
        const availableItemsBySourceId = new Map();
        const forumsToRefresh = getForumsNeededForRefresh();
        const selectedForumIds = new Set(state.settings.selectedForums);
        const homepageSourceIds = ['news', 'matches'].filter(
            (sourceId) => selectedForumIds.has(sourceId),
        );
        const nativeThreadKeys = getNativeActivityThreadKeys();
        let forumCacheChanged = state.forumCacheNeedsPersist;

        const waitForRequestSlot = async () => {
            if (requestIndex > 0) await delay(CONFIG.fetchDelayMs, signal);
            requestIndex += 1;
            throwIfAborted(signal);
        };

        try {
            for (const forum of forumsToRefresh) {
                if (runId !== state.fetchRunId || signal.aborted) {
                    return { failedCount, addedCount, updatedCount, cancelled: true };
                }

                const cached = cacheByForumId.get(forum.id);
                try {
                    const desiredCount = selectedForumIds.has(forum.id)
                        ? state.settings.forumThreadLimits[forum.id]
                        : 0;
                    const result = await fetchForumThreadsForQuota({
                        forum,
                        cached,
                        desiredCount,
                        nativeThreadKeys,
                        now,
                        signal,
                        waitForRequestSlot,
                    });
                    if (runId !== state.fetchRunId || signal.aborted) {
                        return { failedCount, addedCount, updatedCount, cancelled: true };
                    }

                    if (result.failure) {
                        failedCount += 1;
                        warn(`Could not fetch another ${forum.label} forum page.`, result.failure);
                    }
                    if (result.pagesFetched > 0) forumCacheChanged = true;
                    const entry = result.pagesFetched > 0 || result.usedFreshCache
                        ? result.entry
                        : cached;
                    if (entry) {
                        cacheByForumId.set(forum.id, entry);
                        availableItemsBySourceId.set(forum.id, entry.threads);
                        for (const thread of entry.threads) registerThreadMetadata(thread);
                    }
                } catch (error) {
                    if (isAbortErrorLike(error) || signal.aborted) {
                        return { failedCount, addedCount, updatedCount, cancelled: true };
                    }

                    failedCount += 1;
                    warn(`Could not fetch ${forum.label}.`, error);
                    if (cached) {
                        availableItemsBySourceId.set(forum.id, cached.threads);
                        for (const thread of cached.threads) registerThreadMetadata(thread);
                    }
                }
            }

            if (homepageSourceIds.length) {
                try {
                    const homepageItems = await loadHomepageActivityItems(
                        homepageSourceIds,
                        { signal, waitForRequestSlot },
                    );
                    if (runId !== state.fetchRunId || signal.aborted) {
                        return { failedCount, addedCount, updatedCount, cancelled: true };
                    }
                    for (const sourceId of homepageSourceIds) {
                        const items = homepageItems.get(sourceId) || [];
                        availableItemsBySourceId.set(sourceId, items);
                        for (const item of items) registerThreadMetadata(item);
                    }
                } catch (error) {
                    if (isAbortErrorLike(error) || signal.aborted) {
                        return { failedCount, addedCount, updatedCount, cancelled: true };
                    }
                    const missingSourceIds = Array.isArray(error?.missingSourceIds)
                        ? error.missingSourceIds.filter((sourceId) => (
                            homepageSourceIds.includes(sourceId)
                        ))
                        : [];
                    failedCount += missingSourceIds.length || homepageSourceIds.length;
                    const cacheFallbackCutoff = Date.now() - CONFIG.forumCacheRetentionMs;
                    for (const sourceId of homepageSourceIds) {
                        const cached = state.homepageActivityCache.get(sourceId);
                        if (!cached
                            || !Number.isFinite(cached.updatedAt)
                            || cached.updatedAt < cacheFallbackCutoff
                            || cached.updatedAt > Date.now() + 300000) continue;
                        availableItemsBySourceId.set(sourceId, cached.items);
                        for (const item of cached.items) registerThreadMetadata(item);
                    }
                    warn('Could not fetch homepage News or Matches.', error);
                }
            }

            if (runId !== state.fetchRunId || signal.aborted) {
                return { failedCount, addedCount, updatedCount, cancelled: true };
            }

            if (state.defaultOrderCaptured) {
                const previousSortOrder = state.settings.sortOrder;
                state.settings.sortOrder = 'default';
                applySortOrder();
                state.settings.sortOrder = previousSortOrder;
            }

            state.forumCacheById = cacheByForumId;
            if (forumCacheChanged) {
                state.forumCacheNeedsPersist = false;
                saveForumCache(cacheByForumId).catch((error) => {
                    state.forumCacheNeedsPersist = true;
                    warn('Could not save the forum classification cache.', error);
                });
            }

            const allocatedThreads = allocateExtraThreads(availableItemsBySourceId);
            reconcileExtraForumEntries(new Set(allocatedThreads.map((thread) => thread.key)));

            for (const source of ACTIVITY_SOURCES) {
                const threads = allocatedThreads.filter((thread) => (
                    (thread.sourceId || thread.forumId) === source.id
                ));
                if (!threads.length) continue;
                const result = addThreadsToSidebar(threads, source);
                addedCount += result.addedCount;
                updatedCount += result.updatedCount;
            }

            annotateActivityLinks();
            annotateActivityColorsInRoot(document);
            captureDefaultOrder();
            applySortOrder();

            return { failedCount, addedCount, updatedCount, cancelled: false };
        } finally {
            if (state.forumFetchAbortController === abortController) {
                state.forumFetchAbortController = null;
            }
        }
    }

    function getNativeActivityThreadKeys() {
        return new Set([...document.querySelectorAll('.activitylist a[href]')]
            .filter((link) => (
                isActivityEntry(link)
                && !link.classList.contains('hltv-sp-extra')
            ))
            .map((link) => linkKey(link.href))
            .filter(Boolean));
    }

    function countEligibleExtraThreads(threads, nativeThreadKeys) {
        const seen = new Set();
        let count = 0;
        for (const thread of threads) {
            if (!thread?.key || seen.has(thread.key) || nativeThreadKeys.has(thread.key)) continue;
            seen.add(thread.key);
            count += 1;
        }
        return count;
    }

    function mergeForumThreadPages(existingThreads, nextThreads) {
        const merged = [];
        const seen = new Set();
        for (const thread of [...existingThreads, ...nextThreads]) {
            if (!thread?.key || seen.has(thread.key)) continue;
            seen.add(thread.key);
            merged.push(thread);
            if (merged.length >= CONFIG.maxCachedThreadsPerForum) break;
        }
        return merged;
    }

    function buildForumPageUrl(forum, offset) {
        const baseUrl = parseSameOriginUrl(forum.url);
        if (!baseUrl) throw new Error(`Invalid forum URL for ${forum.label}.`);
        baseUrl.pathname = baseUrl.pathname.replace(/\/$/, '');
        if (offset > 0) baseUrl.pathname += `/${offset}`;
        else baseUrl.pathname += '/';
        baseUrl.search = '';
        baseUrl.hash = '';
        return baseUrl.href;
    }

    async function fetchForumThreadsForQuota(options) {
        const {
            forum,
            cached,
            desiredCount,
            nativeThreadKeys,
            now,
            signal,
            waitForRequestSlot,
        } = options;
        const usedFreshCache = Boolean(cached && cached.updatedAt > now - CONFIG.forumCacheTtlMs);
        const entry = usedFreshCache ? {
            updatedAt: cached.updatedAt,
            threads: [...cached.threads],
            nextOffset: cached.nextOffset || 0,
            exhausted: Boolean(cached.exhausted),
        } : {
            updatedAt: 0,
            threads: [],
            nextOffset: 0,
            exhausted: false,
        };
        let pagesFetched = 0;
        let failure = null;

        while (pagesFetched < CONFIG.maxForumPagesPerRefresh) {
            const eligibleCount = countEligibleExtraThreads(entry.threads, nativeThreadKeys);
            const needsInitialPage = !usedFreshCache && pagesFetched === 0;
            if (!needsInitialPage && (entry.exhausted || eligibleCount >= desiredCount)) break;
            if (entry.nextOffset > CONFIG.maxForumOffset) break;

            try {
                await waitForRequestSlot();
                const offset = entry.nextOffset;
                const doc = await fetchForumDocument(buildForumPageUrl(forum, offset), signal);
                throwIfAborted(signal);
                const pageThreads = parseForumThreads(doc, forum);
                entry.threads = offset === 0
                    ? pageThreads
                    : mergeForumThreadPages(entry.threads, pageThreads);
                entry.updatedAt = Date.now();
                entry.nextOffset = offset + CONFIG.forumPageSize;
                entry.exhausted = pageThreads.length === 0;
                pagesFetched += 1;
            } catch (error) {
                if (isAbortErrorLike(error) || signal.aborted) throw error;
                failure = error;
                break;
            }
        }

        return { entry, pagesFetched, usedFreshCache, failure };
    }

    function getForumsNeededForRefresh() {
        const forumIds = new Set(state.settings.selectedForums);
        return FORUMS.filter((forum) => forumIds.has(forum.id));
    }

    function allocateExtraThreads(itemsBySourceId) {
        const selectedSources = state.settings.selectedForums
            .map((sourceId) => activitySourceById.get(sourceId))
            .filter(Boolean);
        if (!selectedSources.length) return [];

        const nativeKeys = getNativeActivityThreadKeys();
        const usedKeys = new Set(nativeKeys);
        const queues = new Map(selectedSources.map((source) => {
            return [source.id, itemsBySourceId.get(source.id) || []];
        }));
        const indexes = new Map(selectedSources.map((source) => [source.id, 0]));
        const counts = new Map(selectedSources.map((source) => [source.id, 0]));
        const allocated = [];

        while (true) {
            let addedThisRound = false;
            for (const source of selectedSources) {
                const sourceLimit = state.settings.forumThreadLimits[source.id]
                    || DEFAULT_FORUM_THREAD_LIMITS[source.id];
                if ((counts.get(source.id) || 0) >= sourceLimit) continue;
                const queue = queues.get(source.id) || [];
                let index = indexes.get(source.id) || 0;
                while (index < queue.length && usedKeys.has(queue[index].key)) index += 1;
                indexes.set(source.id, index + 1);
                if (index >= queue.length) continue;
                const item = queue[index];
                usedKeys.add(item.key);
                allocated.push(item);
                counts.set(source.id, (counts.get(source.id) || 0) + 1);
                addedThisRound = true;
            }
            if (!addedThisRound) break;
        }
        return allocated;
    }

    function reconcileExtraForumEntries(allocatedKeys) {
        if (!state.sidebar) return;

        suppressSidebarObserver(() => {
            for (const link of state.sidebar.querySelectorAll('a.hltv-sp-extra')) {
                if (!allocatedKeys.has(linkKey(link.href))) link.remove();
            }
        });
    }

    function parseHomepageNewsItems(doc) {
        const items = [];
        const seen = new Set();
        for (const row of doc.querySelectorAll(
            '.index .standard-list > a.newsline.article[href]',
        )) {
            const url = parseSameOriginUrl(row.getAttribute('href') || row.href);
            const id = url?.pathname.match(/^\/news\/(\d{1,20})(?:\/|$)/i)?.[1] || '';
            if (!url || !id || seen.has(id)) continue;
            const title = cleanText(
                row.querySelector('.newstext, .featured-newstext')?.textContent,
            ).slice(0, CONFIG.maxThreadTitleChars);
            if (!title) continue;
            const commentsElement = row.querySelector('.newstc > div:last-child');
            const commentsText = cleanText(commentsElement?.textContent);
            const comments = commentsElement && /\bcomments?\b/i.test(commentsText)
                ? parseInteger(commentsText)
                : null;
            const relativeAgeLabel = cleanText(
                row.querySelector('.newstc > .newsrecent')?.textContent,
            ).slice(0, 60);
            const key = linkKey(url.href);
            if (!key) continue;
            seen.add(id);
            items.push({
                key,
                href: url.href,
                title,
                comments,
                trailingText: comments === null ? '' : String(comments),
                created: Number(id),
                createdAt: 0,
                activityAt: 0,
                relativeAgeLabel,
                sourceId: 'news',
                kind: 'news',
                featured: Boolean(row.querySelector('.featured-newstext')),
            });
        }
        return items;
    }

    function findHomepageMatchList(doc) {
        const heading = doc.querySelector('h1.todaysMatches');
        if (!heading) return null;
        if (heading.nextElementSibling?.matches('.top-border-hide')) {
            return heading.nextElementSibling;
        }
        return heading.closest('aside')?.querySelector('.top-border-hide') || null;
    }

    function parseHomepageMatchItems(doc) {
        const list = findHomepageMatchList(doc);
        if (!list) return [];
        const items = [];
        const seen = new Set();
        for (const row of list.querySelectorAll('a.hotmatch-box[href]')) {
            const matchBox = row.querySelector('.teambox.match');
            if (!matchBox) continue;
            const url = parseSameOriginUrl(row.getAttribute('href') || row.href);
            const id = url?.pathname.match(/^\/matches\/(\d{1,20})(?:\/|$)/i)?.[1] || '';
            if (!url || !id || seen.has(id)) continue;
            const teams = [...matchBox.querySelectorAll('.team')]
                .map((team) => cleanText(team.textContent))
                .filter(Boolean)
                .slice(0, 2);
            if (teams.length !== 2) continue;
            const title = `${teams[0]} vs ${teams[1]}`.slice(
                0,
                CONFIG.maxThreadTitleChars,
            );
            const timeElement = matchBox.querySelector('.middleExtra');
            const timeLabel = cleanText(timeElement?.textContent).slice(0, 40);
            const scheduledAt = Number(timeElement?.getAttribute('data-unix'));
            const key = linkKey(url.href);
            if (!key) continue;
            seen.add(id);
            items.push({
                key,
                href: url.href,
                title,
                comments: 0,
                trailingText: '0',
                created: Number(id),
                createdAt: 0,
                activityAt: 0,
                scheduledAt: Number.isFinite(scheduledAt) ? scheduledAt : 0,
                relativeAgeLabel: '',
                sourceId: 'matches',
                kind: 'match',
                eventName: cleanText(row.getAttribute('title')).slice(0, 200),
                isLive: matchBox.getAttribute('filteraslive') === 'true'
                    || /^live$/i.test(timeLabel),
                isLan: matchBox.getAttribute('lan') === 'true',
                stars: clampInteger(matchBox.getAttribute('stars'), 0, 5, 0),
            });
        }
        return items;
    }

    function homepageMarkupSupportsSource(doc, sourceId) {
        if (sourceId === 'news') {
            return Boolean(doc.querySelector(
                '.index .standard-list > a.newsline.article[href]',
            ));
        }
        if (sourceId === 'matches') return Boolean(findHomepageMatchList(doc));
        return false;
    }

    function homepageMarkupSupportsSources(doc, sourceIds) {
        return sourceIds.every((sourceId) => (
            homepageMarkupSupportsSource(doc, sourceId)
        ));
    }

    async function loadHomepageActivityItems(sourceIds, options) {
        const now = Date.now();
        if (sourceIds.every((sourceId) => (
            state.homepageActivityCache.get(sourceId)?.updatedAt
            > now - CONFIG.forumCacheTtlMs
        ))) {
            return new Map(sourceIds.map((sourceId) => [
                sourceId,
                state.homepageActivityCache.get(sourceId)?.items || [],
            ]));
        }

        let doc = null;
        const currentUrl = parseSameOriginUrl(location.href);
        if (currentUrl?.pathname === '/'
            && homepageMarkupSupportsSources(document, sourceIds)) {
            doc = document;
        } else {
            await options.waitForRequestSlot();
            doc = await fetchSameOriginDocument(`${HLTV_ORIGIN}/`, {
                contentLabel: 'homepage news and matches',
                expectedSelector: '.index .standard-list > a.newsline.article[href], h1.todaysMatches',
                requireExpectedSelector: true,
                cache: 'no-store',
                signal: options.signal,
            });
        }
        throwIfAborted(options.signal);
        const itemsBySourceId = new Map();
        const missingSourceIds = [];
        if (sourceIds.includes('news')) {
            const items = parseHomepageNewsItems(doc);
            if (homepageMarkupSupportsSource(doc, 'news')) {
                itemsBySourceId.set('news', items);
            } else {
                missingSourceIds.push('news');
            }
        }
        if (sourceIds.includes('matches')) {
            const items = parseHomepageMatchItems(doc);
            if (homepageMarkupSupportsSource(doc, 'matches')) {
                itemsBySourceId.set('matches', items);
            } else {
                missingSourceIds.push('matches');
            }
        }
        const updatedAt = Date.now();
        for (const [sourceId, items] of itemsBySourceId) {
            state.homepageActivityCache.set(sourceId, { updatedAt, items });
        }
        if (itemsBySourceId.size) {
            saveHomepageActivityCache(state.homepageActivityCache).catch((error) => {
                warn('Could not save the homepage activity cache.', error);
            });
        }
        if (missingSourceIds.length) {
            const error = new Error(
                `Homepage markup was missing requested source${missingSourceIds.length === 1 ? '' : 's'}: ${missingSourceIds.join(', ')}.`,
            );
            error.missingSourceIds = missingSourceIds;
            throw error;
        }
        return itemsBySourceId;
    }

    async function fetchForumDocument(url, signal = null) {
        const expectedUrl = parseSameOriginUrl(url);
        const expectedPath = expectedUrl?.pathname.replace(/\/$/, '') || '';
        return fetchSameOriginDocument(url, {
            contentLabel: 'forum content',
            expectedSelector: '.forumthreads, a[href*="/forums/threads/"]',
            requireExpectedSelector: true,
            signal,
            validateFinalUrl: (finalUrl) => (
                finalUrl.pathname.replace(/\/$/, '') === expectedPath
            ),
            invalidFinalUrlMessage: 'Forum response did not match the requested forum page.',
        });
    }

    async function fetchSameOriginDocument(url, options = {}) {
        const requestUrl = toSameOriginRequestUrl(url);
        const timeoutMs = Number.isFinite(options.timeoutMs) ? options.timeoutMs : CONFIG.requestTimeoutMs;
        const signal = options.signal || null;

        throwIfAborted(signal);
        log('Fetching same-origin page request:', requestUrl);

        const html = await fetchTextWithFallback(requestUrl, {
            timeoutMs,
            signal,
            cache: options.cache || 'default',
            validateFinalUrl: options.validateFinalUrl,
            invalidFinalUrlMessage: options.invalidFinalUrlMessage,
        });
        return parseHtmlDocument(html, requestUrl, options);
    }

    function toSameOriginRequestUrl(url) {
        const targetUrl = parseSameOriginUrl(url);
        if (!targetUrl) {
            throw new Error('Refusing to fetch an invalid or non-HLTV URL.');
        }

        targetUrl.hash = '';
        return targetUrl.href;
    }

    function makeRequestError(message, options = {}) {
        const error = new Error(message);
        error.name = 'RequestError';
        error.status = Number.isFinite(options.status) ? options.status : 0;
        error.retryable = Boolean(options.retryable);
        error.allowXhrFallback = Boolean(options.allowXhrFallback);
        return error;
    }

    function isRetryableHttpStatus(status) {
        return status === 408 || status === 425 || status === 429 || (status >= 500 && status <= 599);
    }

    function createRequestAbortScope(timeoutMs, parentSignal = null) {
        const controller = new AbortController();
        let timedOut = false;

        const onParentAbort = () => controller.abort();
        parentSignal?.addEventListener('abort', onParentAbort, { once: true });

        const timeoutId = window.setTimeout(() => {
            timedOut = true;
            controller.abort();
        }, timeoutMs);

        return {
            signal: controller.signal,
            didTimeOut: () => timedOut,
            cleanup: () => {
                window.clearTimeout(timeoutId);
                parentSignal?.removeEventListener('abort', onParentAbort);
            },
        };
    }

    function responseHeaderValue(response, name) {
        try {
            if (typeof response?.headers?.get !== 'function') return null;
            const value = response.headers.get(name);
            return value === null || value === undefined ? null : String(value).trim();
        } catch {
            return null;
        }
    }

    function responseReadError(options, message) {
        const error = typeof options?.makeError === 'function'
            ? options.makeError(message)
            : null;
        return error instanceof Error ? error : new Error(message);
    }

    function validateResponseMetadata(response, options) {
        const label = String(options.label || 'Response');
        const maxBytes = Number(options.maxBytes);
        const contentLength = responseHeaderValue(response, 'content-length');
        if (contentLength !== null) {
            if (!/^(?:0|[1-9]\d*)$/.test(contentLength)
                || !Number.isSafeInteger(Number(contentLength))) {
                throw responseReadError(options, `${label} had an invalid Content-Length header.`);
            }
            if (Number(contentLength) > maxBytes) {
                throw responseReadError(
                    options,
                    `${label} exceeded the ${maxBytes.toLocaleString('en-US')}-byte limit.`,
                );
            }
        }

        const expected = Array.isArray(options.expectedContentTypes)
            ? options.expectedContentTypes.map((value) => String(value).toLowerCase())
            : [];
        if (!expected.length) return;
        const rawContentType = responseHeaderValue(response, 'content-type');
        if (rawContentType === null && options.allowMissingContentType === true) return;
        const mimeType = String(rawContentType || '').split(';', 1)[0].trim().toLowerCase();
        if (!expected.includes(mimeType)) {
            throw responseReadError(options, `${label} had an unexpected Content-Type.`);
        }
    }

    function utf8ByteLength(value, stopAfter = Number.POSITIVE_INFINITY) {
        const text = String(value);
        let bytes = 0;
        for (let index = 0; index < text.length; index += 1) {
            const code = text.charCodeAt(index);
            if (code <= 0x7f) bytes += 1;
            else if (code <= 0x7ff) bytes += 2;
            else if (code >= 0xd800 && code <= 0xdbff
                && text.charCodeAt(index + 1) >= 0xdc00
                && text.charCodeAt(index + 1) <= 0xdfff) {
                bytes += 4;
                index += 1;
            } else bytes += 3;
            if (bytes > stopAfter) return bytes;
        }
        return bytes;
    }

    async function cancelResponseReader(reader, reason) {
        try {
            await reader?.cancel?.(reason);
        } catch {
            // The response may already have errored or released its stream lock.
        }
    }

    async function cancelResponseBody(body, reason) {
        try {
            await body?.cancel?.(reason);
        } catch {
            // The body may already be locked, errored, or closed.
        }
    }

    async function readBoundedUtf8Response(response, options = {}) {
        const maxBytes = Number(options.maxBytes);
        const maxChars = Number(options.maxChars);
        const label = String(options.label || 'Response');
        if (!Number.isSafeInteger(maxBytes) || maxBytes <= 0
            || !Number.isSafeInteger(maxChars) || maxChars <= 0) {
            throw new TypeError('Bounded response limits must be positive safe integers.');
        }
        try {
            validateResponseMetadata(response, { ...options, label, maxBytes });
        } catch (error) {
            await cancelResponseBody(response?.body, error);
            throw error;
        }

        const body = response?.body;
        if (!body || typeof body.getReader !== 'function') {
            // Older Response-compatible test doubles do not expose a stream. The fallback is
            // still checked immediately after the only full-buffer operation they support.
            if (typeof response?.text !== 'function') {
                throw responseReadError(options, `${label} body was unavailable.`);
            }
            const text = String(await response.text());
            if (text.length > maxChars || utf8ByteLength(text, maxBytes) > maxBytes) {
                throw responseReadError(options, `${label} exceeded its safe size limit.`);
            }
            return text;
        }
        if (typeof globalThis.TextDecoder !== 'function') {
            throw responseReadError(options, `${label} could not be decoded safely.`);
        }

        const reader = body.getReader();
        const decoder = new globalThis.TextDecoder('utf-8');
        const chunks = [];
        let totalBytes = 0;
        let totalChars = 0;
        let completed = false;
        try {
            while (true) {
                const result = await reader.read();
                if (result?.done) {
                    completed = true;
                    break;
                }
                const rawChunk = result?.value;
                const chunk = rawChunk instanceof ArrayBuffer
                    ? new Uint8Array(rawChunk)
                    : ArrayBuffer.isView(rawChunk)
                        ? new Uint8Array(rawChunk.buffer, rawChunk.byteOffset, rawChunk.byteLength)
                        : null;
                if (!chunk) throw responseReadError(options, `${label} stream was invalid.`);
                totalBytes += chunk.byteLength;
                if (totalBytes > maxBytes) {
                    throw responseReadError(options, `${label} exceeded its safe size limit.`);
                }
                const decoded = decoder.decode(chunk, { stream: true });
                totalChars += decoded.length;
                if (totalChars > maxChars) {
                    throw responseReadError(options, `${label} exceeded its safe size limit.`);
                }
                chunks.push(decoded);
            }
            const tail = decoder.decode();
            totalChars += tail.length;
            if (totalChars > maxChars) {
                completed = false;
                throw responseReadError(options, `${label} exceeded its safe size limit.`);
            }
            chunks.push(tail);
            return chunks.join('');
        } catch (error) {
            if (!completed) await cancelResponseReader(reader, error);
            throw error;
        } finally {
            try {
                reader.releaseLock?.();
            } catch {
                // Ignore non-standard Response reader cleanup failures.
            }
        }
    }

    function validateHtmlText(text) {
        const value = String(text || '');
        if (value.length > CONFIG.maxHtmlChars) {
            throw makeRequestError(`Response exceeded ${CONFIG.maxHtmlChars.toLocaleString('en-US')} characters.`);
        }
        return value;
    }

    async function fetchTextWithFallback(requestUrl, options = {}) {
        try {
            return await fetchTextWithSafeFetch(requestUrl, options);
        } catch (error) {
            if (isAbortErrorLike(error) || options.signal?.aborted) throw error;
            if (!error?.allowXhrFallback) throw error;

            log(`Fetch failed for ${requestUrl}; trying isolated XMLHttpRequest.`, error);
            return fetchTextWithSafeXhr(requestUrl, options);
        }
    }

    function validateFinalHtmlResponseUrl(responseUrlValue, options = {}) {
        const hasIdentityValidator = typeof options.validateFinalUrl === 'function';
        if (!responseUrlValue) {
            if (hasIdentityValidator) {
                throw makeRequestError('HTML response did not expose its final URL.');
            }
            return null;
        }

        const finalUrl = parseSameOriginUrl(responseUrlValue);
        if (!finalUrl) {
            throw makeRequestError('Request redirected outside HLTV.org.');
        }
        if (hasIdentityValidator) {
            let matches = false;
            try {
                matches = options.validateFinalUrl(finalUrl) === true;
            } catch {
                matches = false;
            }
            if (!matches) {
                throw makeRequestError(
                    options.invalidFinalUrlMessage
                    || 'HTML response did not match the requested resource.',
                );
            }
        }
        return finalUrl;
    }

    async function fetchTextWithSafeFetch(requestUrl, options = {}) {
        const timeoutMs = Number.isFinite(options.timeoutMs) ? options.timeoutMs : CONFIG.requestTimeoutMs;
        const signal = options.signal || null;

        throwIfAborted(signal);

        if (typeof safeFetch !== 'function') {
            throw makeRequestError('Fetch is unavailable.', { allowXhrFallback: true });
        }

        const requestScope = createRequestAbortScope(timeoutMs, signal);

        try {
            const response = await safeFetch(requestUrl, {
                method: 'GET',
                credentials: 'include',
                cache: options.cache || 'default',
                mode: 'same-origin',
                redirect: 'follow',
                signal: requestScope.signal,
                headers: {
                    Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                },
            });

            const status = Number(response.status || 0);
            if (!(status >= 200 && status < 300)) {
                throw makeRequestError(`HTTP ${status}`, {
                    status,
                    retryable: isRetryableHttpStatus(status),
                });
            }

            validateFinalHtmlResponseUrl(response.url, options);

            // HLTV normally advertises HTML. Missing Content-Type is tolerated only for older
            // Response-compatible environments; any advertised type must be HTML.
            return readBoundedUtf8Response(response, {
                label: 'HTML response',
                maxBytes: CONFIG.maxHtmlBytes,
                maxChars: CONFIG.maxHtmlChars,
                expectedContentTypes: ['text/html', 'application/xhtml+xml'],
                allowMissingContentType: true,
                makeError: (message) => makeRequestError(message),
            });
        } catch (error) {
            if (signal?.aborted) throw makeAbortError();
            if (requestScope.didTimeOut()) {
                throw makeRequestError(`Request timed out after ${timeoutMs} ms.`, { retryable: true });
            }
            if (error?.name === 'RequestError') throw error;

            throw makeRequestError(
                `Fetch failed: ${error instanceof Error ? error.message : String(error)}`,
                { retryable: true, allowXhrFallback: true },
            );
        } finally {
            requestScope.cleanup();
        }
    }

    function fetchTextWithSafeXhr(requestUrl, options = {}) {
        return new Promise((resolve, reject) => {
            const timeoutMs = Number.isFinite(options.timeoutMs) ? options.timeoutMs : CONFIG.requestTimeoutMs;
            const signal = options.signal || null;

            if (typeof SafeXMLHttpRequest !== 'function') {
                reject(makeRequestError('XMLHttpRequest is unavailable.'));
                return;
            }

            if (signal && signal.aborted) {
                reject(makeAbortError());
                return;
            }

            let finished = false;
            const xhr = new SafeXMLHttpRequest();

            const cleanup = () => {
                window.clearTimeout(timeoutId);
                if (signal) signal.removeEventListener('abort', onAbort);
            };

            const finish = (error, text) => {
                if (finished) return;
                finished = true;
                cleanup();

                if (error) {
                    reject(error);
                } else {
                    resolve(text || '');
                }
            };

            const onAbort = () => {
                try {
                    xhr.abort();
                } catch {
                    // Ignore abort failures from cross-context XHR objects.
                }

                finish(makeAbortError());
            };

            const timeoutId = window.setTimeout(() => {
                try {
                    xhr.abort();
                } catch {
                    // Ignore abort failures from cross-context XHR objects.
                }

                finish(makeRequestError(`Request timed out after ${timeoutMs} ms.`, { retryable: true }));
            }, timeoutMs);

            if (signal) {
                signal.addEventListener('abort', onAbort, { once: true });
            }

            xhr.onload = () => {
                const status = Number(xhr.status || 0);
                if (!(status >= 200 && status < 300)) {
                    finish(makeRequestError(`HTTP ${status}`, {
                        status,
                        retryable: isRetryableHttpStatus(status),
                    }));
                    return;
                }

                try {
                    validateFinalHtmlResponseUrl(xhr.responseURL, options);
                } catch (error) {
                    finish(error);
                    return;
                }

                try {
                    const responseHeader = (name) => {
                        if (typeof xhr.getResponseHeader !== 'function') return '';
                        try {
                            return String(xhr.getResponseHeader(name) || '').trim();
                        } catch {
                            return '';
                        }
                    };
                    const contentType = responseHeader('Content-Type');
                    if (contentType
                        && !/^(?:text\/html|application\/xhtml\+xml)(?:\s*;|$)/i.test(contentType)) {
                        throw makeRequestError(`HTML response returned unexpected Content-Type ${contentType}.`);
                    }
                    const contentLength = responseHeader('Content-Length');
                    if (contentLength) {
                        if (!/^\d+$/.test(contentLength)) {
                            throw makeRequestError('HTML response returned an invalid Content-Length.');
                        }
                        const advertisedBytes = Number(contentLength);
                        if (!Number.isSafeInteger(advertisedBytes)
                            || advertisedBytes > CONFIG.maxHtmlBytes) {
                            throw makeRequestError(`HTML response exceeded ${CONFIG.maxHtmlBytes.toLocaleString('en-US')} bytes.`);
                        }
                    }
                    finish(null, validateHtmlText(xhr.responseText || ''));
                } catch (error) {
                    finish(error);
                }
            };

            xhr.onerror = () => finish(makeRequestError('Request failed.', { retryable: true }));
            xhr.onprogress = (event) => {
                if (event.loaded > CONFIG.maxHtmlChars) {
                    try {
                        xhr.abort();
                    } catch {
                        // Ignore abort failures.
                    }
                    finish(makeRequestError(`Response exceeded ${CONFIG.maxHtmlChars.toLocaleString('en-US')} characters.`));
                }
            };

            try {
                xhr.open('GET', requestUrl, true);
                xhr.withCredentials = true;
                xhr.setRequestHeader('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8');
                xhr.send();
            } catch (error) {
                finish(makeRequestError(
                    `XMLHttpRequest failed: ${error instanceof Error ? error.message : String(error)}`,
                    { retryable: true },
                ));
            }
        });
    }

    function parseHtmlDocument(html, url, options = {}) {
        const doc = parseInertHtmlDocument(html);
        const title = cleanText(doc.querySelector('title')?.textContent || '');
        const bodyText = cleanText(doc.body?.textContent || '').slice(0, 800);
        const contentLabel = options.contentLabel || 'page content';

        if (/just a moment|access denied|forbidden|attention required/i.test(title)
            || /cloudflare|access denied|checking your browser/i.test(bodyText)) {
            throw new Error(`Fetched protection/challenge page instead of ${contentLabel}. Page title: ${title || 'none'}.`);
        }

        if (options.expectedSelector && !doc.querySelector(options.expectedSelector)) {
            const message = `Fetched ${url}, but could not find expected ${contentLabel} markup. Page title: ${title || 'none'}.`;
            if (options.requireExpectedSelector) throw new Error(message);
            warn(message);
        }

        return doc;
    }

    function makeAbortError() {
        try {
            return new DOMException('Aborted', 'AbortError');
        } catch {
            const error = new Error('Aborted');
            error.name = 'AbortError';
            return error;
        }
    }

    function throwIfAborted(signal) {
        if (signal && signal.aborted) {
            throw makeAbortError();
        }
    }

    function isAbortErrorLike(error) {
        return Boolean(error && (error.name === 'AbortError' || error.message === 'Aborted'));
    }

    function parseForumThreads(doc, forum) {
        let rows = [...doc.querySelectorAll('.forumthreads tr.tablerow')];

        if (rows.length === 0) {
            rows = [...doc.querySelectorAll('tr')]
                .filter((row) => row.querySelector('a[href*="/forums/threads/"]'));
        }

        const seen = new Set();
        const threads = [];

        for (const row of rows) {
            const thread = parseForumThreadRow(row, forum);
            if (!thread || seen.has(thread.key)) continue;

            seen.add(thread.key);
            threads.push(thread);
            if (threads.length >= CONFIG.maxCachedThreadsPerForum) break;
        }

        return threads;
    }

    function parseForumThreadRow(row, forum) {
        const link = row.querySelector('.name a[href*="/forums/threads/"]')
            || row.querySelector('a[href*="/forums/threads/"]');

        if (!link) return null;

        const threadUrl = parseSameOriginUrl(link.getAttribute('href') || link.href);
        if (!threadUrl || !/^\/forums\/threads\/\d+(?:\/|$)/i.test(threadUrl.pathname)) return null;

        const href = threadUrl.href;
        const key = linkKey(threadUrl.href);
        const title = cleanText(link.textContent).slice(0, CONFIG.maxThreadTitleChars);
        if (!title || !key) return null;

        return {
            key,
            href,
            title,
            comments: extractForumRowReplyCount(row),
            created: extractCreationSortValue(href),
            createdAt: 0,
            activityAt: extractForumRowActivityAt(row),
            forumId: forum.id,
        };
    }

    function extractForumRowReplyCount(row) {
        const repliesElement = row.querySelector('.replies');
        if (repliesElement) return parseInteger(repliesElement.textContent);

        const cells = [...row.children].map((cell) => cleanText(cell.textContent));
        for (let index = 1; index < cells.length; index += 1) {
            if (/^[\d,.\s]+$/.test(cells[index])) {
                return parseInteger(cells[index]);
            }
        }

        return 0;
    }

    function cleanText(value) {
        return String(value || '').replace(/\s+/g, ' ').trim();
    }

    function addThreadsToSidebar(threads, source) {
        if (!state.sidebar) return { addedCount: 0, updatedCount: 0 };

        const existingLinks = new Map(getActivityLinks().map((link) => [linkKey(link.getAttribute('href') || link.href), link]));
        let addedCount = 0;
        let updatedCount = 0;

        suppressSidebarObserver(() => {
            for (const thread of threads) {
                const existingLink = existingLinks.get(thread.key);

                if (existingLink) {
                    if (source.kind === 'forum') markForum(existingLink, source);
                    else applyActivityColor(existingLink, source.kind, thread);
                    existingLink.dataset.hltvSpSourceId = source.id;
                    existingLink.dataset.hltvSpComments = String(
                        source.kind === 'match'
                            ? normaliseMatchTrailingCount(existingLink, thread.comments ?? 0)
                            : thread.comments ?? 0,
                    );
                    existingLink.dataset.hltvSpCreated = String(thread.created);
                    if (thread.relativeAgeLabel) {
                        existingLink.dataset.hltvSpRelativeAgeLabel = thread.relativeAgeLabel;
                    }
                    updatedCount += 1;
                    continue;
                }

                const link = createSidebarThreadLink(thread, source);
                state.sidebar.appendChild(link);
                existingLinks.set(thread.key, link);
                addedCount += 1;
            }
        });

        return { addedCount, updatedCount };
    }

    function createSidebarThreadLink(thread, source) {
        const threadUrl = parseSameOriginUrl(thread.href);
        const validPath = source.kind === 'forum'
            ? /^\/forums\/threads\/\d+(?:\/|$)/i.test(threadUrl?.pathname || '')
            : source.kind === 'news'
                ? /^\/news\/\d+(?:\/|$)/i.test(threadUrl?.pathname || '')
                : source.kind === 'match'
                    && /^\/matches\/\d+(?:\/|$)/i.test(threadUrl?.pathname || '');
        if (!threadUrl || !validPath) {
            throw new Error('Refusing to create a sidebar link for an invalid activity URL.');
        }

        const link = document.createElement('a');
        link.href = threadUrl.href;
        link.className = 'col-box activity a-reset hltv-sp-extra';
        if (source.kind === 'news') link.classList.add('newsCat');
        if (source.kind === 'match') link.classList.add('matchCat');
        link.title = `${source.label}: ${thread.title}`;
        link.dataset.hltvSpExtra = 'true';
        link.dataset.hltvSpSourceId = source.id;
        link.dataset.hltvSpComments = String(thread.comments ?? 0);
        link.dataset.hltvSpCreated = String(thread.created);
        link.dataset.hltvSpSequence = String(state.nextSequence++);
        if (thread.relativeAgeLabel) {
            link.dataset.hltvSpRelativeAgeLabel = thread.relativeAgeLabel;
        }

        const topic = document.createElement('span');
        topic.className = 'topic a-default';
        topic.textContent = thread.title;
        topic.title = thread.title;

        link.appendChild(topic);
        const trailingText = cleanText(
            thread.trailingText ?? (thread.comments === null ? '' : thread.comments),
        );
        if (trailingText) {
            const trailing = document.createElement('span');
            trailing.className = 'hltv-sp-sport-count';
            trailing.textContent = trailingText;
            link.appendChild(trailing);
        }

        if (source.kind === 'forum') markForum(link, source);
        else applyActivityColor(link, source.kind, thread);
        applyForumVisibilityToLink(link);
        return link;
    }

    function markForum(link, forum) {
        for (const forumToClear of FORUMS) {
            link.classList.remove(forumClassName(forumToClear));
        }

        link.dataset.hltvSpType = 'forum';
        link.dataset.hltvSpForumId = forum.id;
        link.dataset.hltvSpSourceId = forum.id;
        if (state.settings.enableCustomThreadColors) {
            link.classList.add('hltv-sp-colored-entry');
            link.classList.add(forumClassName(forum));
            link.style.setProperty('--hltv-sp-entry-color', activitySourceColor(forum.id));
        } else {
            link.classList.remove('hltv-sp-colored-entry');
            link.style.removeProperty('--hltv-sp-entry-color');
        }
    }

    function forumClassName(forum) {
        return `hltv-sp-forum-${forum.id}`;
    }

    function elementsWithin(root, selector) {
        const elements = [];
        if (root instanceof Element && root.matches(selector)) elements.push(root);
        if (root instanceof Document || root instanceof Element || root instanceof DocumentFragment) {
            elements.push(...root.querySelectorAll(selector));
        }
        return elements;
    }

    function formatQuoteLines(root = document) {
        const exactBodies = elementsWithin(root, [
            '.forumthread > .standard-box > .forum-middle',
            '.forum[data-forum-thread-id] .post > .standard-box > .forum-middle',
        ].join(', '));
        const fallbackBodies = elementsWithin(root, [
            '.post .forum-post-body',
            '.post .forum_post_body',
            '.post .post-body',
            '.post .post-body-content',
            '.post .text-content',
        ].join(', '));

        for (const body of [...new Set([...exactBodies, ...fallbackBodies])]) {
            if (body.dataset.hltvSpQuotesFormatted === 'true') continue;
            if (body.childElementCount === 0) {
                formatPlainTextQuoteBody(body);
                body.dataset.hltvSpQuotesFormatted = 'true';
                continue;
            }

            const walker = document.createTreeWalker(body, 4, {
                acceptNode(node) {
                    const parent = node.parentElement;
                    if (!parent
                        || parent.closest('.hltv-sp-quote-line')
                        || parent.closest('script, style, textarea, input, pre, code, button, select')) return 2;
                    return /^>/m.test(node.textContent || '') ? 1 : 2;
                },
            });
            const nodes = [];
            while (walker.nextNode()) nodes.push(walker.currentNode);

            for (const node of nodes) {
                const parts = String(node.textContent || '').split(/(\r?\n)/);
                if (!parts.some((part) => /^>/.test(part))) continue;
                const fragment = document.createDocumentFragment();
                for (const part of parts) {
                    const match = part.match(/^>\s?(.*)$/);
                    if (match) {
                        const quote = document.createElement('span');
                        quote.className = 'hltv-sp-quote-line';
                        quote.textContent = match[1];
                        fragment.appendChild(quote);
                    } else {
                        fragment.appendChild(document.createTextNode(part));
                    }
                }
                node.replaceWith(fragment);
            }
        }
    }

    function formatPlainTextQuoteBody(body) {
        const text = String(body.textContent || '').replace(/\r\n?/g, '\n');
        if (!text.split('\n').some((line) => line.startsWith('>'))) return;
        const lines = text.split('\n');
        const fragment = document.createDocumentFragment();
        let normalText = '';

        const flushNormal = () => {
            if (!normalText) return;
            fragment.appendChild(document.createTextNode(normalText));
            normalText = '';
        };

        for (let index = 0; index < lines.length;) {
            if (!lines[index].startsWith('>')) {
                normalText += lines[index];
                if (index < lines.length - 1) normalText += '\n';
                index += 1;
                continue;
            }

            flushNormal();
            const quotedLines = [];
            while (index < lines.length && lines[index].startsWith('>')) {
                quotedLines.push(lines[index].slice(1).replace(/^ /, ''));
                index += 1;
            }
            const quote = document.createElement('blockquote');
            quote.className = 'hltv-sp-quote-line';
            quote.textContent = quotedLines.join('\n');
            fragment.appendChild(quote);
            if (index < lines.length) normalText = '\n';
        }
        flushNormal();
        body.replaceChildren(fragment);
    }

    function parseProfileIdentity(link) {
        const url = parseSameOriginUrl(link.getAttribute('href') || link.href);
        const match = url?.pathname.match(/^\/profile\/(\d{1,20})(?:\/|$)/i);
        if (!match) return null;
        return { id: match[1], name: cleanText(link.textContent).slice(0, 100) };
    }

    function extractCurrentUserId(root = document) {
        if (!root?.querySelector) return '';
        const marker = root.querySelector('.navbell [data-user], .fa-bell[data-user]');
        const markerId = String(marker?.getAttribute('data-user') || '');
        if (/^\d{1,20}$/.test(markerId)) return markerId;

        const profileLink = root.querySelector(
            '#popupsettings .nav-popup-header > a.right[href*="/profile/"], '
            + '#popupsettings .nav-popup-header a[href*="/profile/"]',
        );
        return profileLink ? parseProfileIdentity(profileLink)?.id || '' : '';
    }

    function findAuthorLinkInPost(post) {
        if (!(post instanceof Element)) return null;
        const topbar = post.matches('.standard-box')
            ? post.querySelector(':scope > .forum-topbar')
            : post.querySelector(':scope > .standard-box > .forum-topbar, :scope > .forum-topbar');
        return topbar?.querySelector('a.authorAnchor[href*="/profile/"]')
            || topbar?.querySelector('a[href*="/profile/"]')
            || null;
    }

    function postAuthorUserId(post) {
        const link = findAuthorLinkInPost(post);
        return link ? parseProfileIdentity(link)?.id || '' : '';
    }

    function scanOriginalPosterAuthors(root = document) {
        if (!state.settings.enableOriginalPosterHighlight) {
            for (const author of elementsWithin(root, '.hltv-sp-original-poster-author')) {
                author.classList.remove('hltv-sp-original-poster-author');
            }
            return;
        }
        const threadIds = new Set();
        const addThreadId = (value) => {
            const threadId = String(value || '');
            if (/^[1-9]\d{0,19}$/.test(threadId)) threadIds.add(threadId);
        };
        for (const thread of elementsWithin(root, '.forumthread[data-thread]')) {
            addThreadId(thread.dataset.thread);
        }
        for (const forum of elementsWithin(root, '.forum[data-forum-thread-id]')) {
            addThreadId(forum.dataset.forumThreadId);
        }
        if (root instanceof Element) {
            addThreadId(root.closest('.forumthread[data-thread]')?.dataset.thread);
            addThreadId(root.closest('.forum[data-forum-thread-id]')?.dataset.forumThreadId);
        }

        for (const threadId of threadIds) {
            const threadRoot = [...document.querySelectorAll('.forumthread[data-thread]')]
                .find((candidate) => String(candidate.dataset.thread || '') === threadId);
            const opener = threadRoot?.querySelector(':scope > .standard-box') || null;
            const openerUserId = postAuthorUserId(opener);
            const validOpenerUserId = /^[1-9]\d{0,19}$/.test(openerUserId)
                ? openerUserId
                : '';
            const posts = opener ? [opener] : [];
            for (const forum of document.querySelectorAll('.forum[data-forum-thread-id]')) {
                if (String(forum.dataset.forumThreadId || '') !== threadId) continue;
                posts.push(...forum.querySelectorAll('.post'));
            }
            for (const post of posts) {
                const author = findAuthorLinkInPost(post);
                if (!author) continue;
                const authorUserId = parseProfileIdentity(author)?.id || '';
                author.classList.toggle(
                    'hltv-sp-original-poster-author',
                    Boolean(validOpenerUserId && authorUserId === validOpenerUserId),
                );
            }
        }
    }

    function syncPreviewOriginalPosterAuthors(root = state.previewPanel || document) {
        const openerUserId = String(state.previewData?.thread?.userId || '');
        const validOpenerUserId = /^[1-9]\d{0,19}$/.test(openerUserId)
            ? openerUserId
            : '';
        for (const card of elementsWithin(
            root,
            '.hltv-sp-preview-thread[data-hltv-sp-author-id], '
            + '.hltv-sp-preview-comment[data-hltv-sp-author-id]',
        )) {
            const author = card.querySelector(
                '.hltv-sp-preview-author-meta > [data-hltv-sp-preview-author="true"]',
            );
            if (!author) continue;
            author.classList.toggle(
                'hltv-sp-original-poster-author',
                Boolean(
                    state.settings.enableOriginalPosterHighlight
                    && validOpenerUserId
                    && card.dataset.hltvSpAuthorId === validOpenerUserId
                ),
            );
        }
    }

    function applyOriginalPosterHighlightSetting() {
        if (!state.settings.enableOriginalPosterHighlight) {
            for (const author of document.querySelectorAll('.hltv-sp-original-poster-author')) {
                author.classList.remove('hltv-sp-original-poster-author');
            }
            return;
        }
        scanOriginalPosterAuthors(document);
        syncPreviewOriginalPosterAuthors();
    }

    function createLocalScoreBadge(userId) {
        const normalisedUserId = String(userId || '');
        const { host, root } = createPrivateUiHost({
            className: 'hltv-sp-private-ui-host hltv-sp-user-score',
            styleText: PRIVATE_UI_STYLES.score,
            metadata: { userId: normalisedUserId },
        });
        host.dataset.hltvSpScoreUserId = normalisedUserId;
        const badge = document.createElement('span');
        badge.className = 'hltv-sp-user-score-value';
        root.appendChild(badge);
        updateLocalScoreBadge(host);
        return host;
    }

    function updateLocalScoreBadge(badge) {
        if (!(badge instanceof Element)) return;
        const host = privateUiHostForNode(badge);
        const value = privateUiControl(host, '.hltv-sp-user-score-value');
        if (!host || !value) return;
        const metadata = privateUiMetadata.get(host);
        const userId = String(metadata?.userId || host.dataset.hltvSpScoreUserId || '');
        const score = /^\d{1,20}$/.test(userId) ? state.localUserScores.get(userId) || 0 : 0;
        value.textContent = score > 0 ? `+${score}` : String(score);
        value.title = `Local score from your votes: ${score}`;
        value.classList.toggle('hltv-sp-negative', score < 0);
    }

    function isNicknameScoreTarget(link, user) {
        if (link.closest('.sort-options, .sort-headline, nav, .hltv-sp-profile-history-controls')
            || link.matches('.sort-option, [role="tab"], [role="button"]')) return false;
        if (link.matches('.authorAnchor, .username, .user-name')
            || link.closest('.forum-topbar, .latest-visitors, .hltv-sp-preview-author')) return true;
        // Ordinary nickname links have no common CSS class. Their visible nickname
        // and canonical profile slug must agree; a profile URL alone is not identity UI.
        const encodedSlug = parseSameOriginUrl(link.getAttribute('href') || link.href)?.pathname.split('/')[3] || '';
        let slug;
        try { slug = decodeURIComponent(encodedSlug); } catch { return false; }
        const identityText = (text) => String(text).normalize('NFKD').toLocaleLowerCase()
            .replace(/[^\p{L}\p{N}]/gu, '');
        return Boolean(slug) && identityText(user.name) === identityText(slug);
    }

    function scanLocalScoreTargets(root = document) {
        if (!state.settings.enableLocalUserScores || !hasPrivateStorage()) return;
        const anchors = elementsWithin(
            root,
            'a[href^="/profile/"], a[href^="https://www.hltv.org/profile/"]',
        );
        for (const link of anchors) {
            const user = parseProfileIdentity(link);
            if (!user || !user.name || !isNicknameScoreTarget(link, user)) {
                if (link.dataset.hltvSpScoreTarget) {
                    if (link.nextElementSibling?.matches('.hltv-sp-user-score')) link.nextElementSibling.remove();
                    delete link.dataset.hltvSpScoreTarget;
                }
                continue;
            }
            if (link.dataset.hltvSpScoreTarget === user.id) {
                const adjacent = link.nextElementSibling;
                if (adjacent?.matches(`.hltv-sp-user-score[data-hltv-sp-score-user-id="${user.id}"]`)
                    && privateUiControl(adjacent, '.hltv-sp-user-score-value')) {
                    updateLocalScoreBadge(adjacent);
                    continue;
                }
                if (adjacent?.matches('.hltv-sp-user-score')) adjacent.remove();
            }
            link.dataset.hltvSpScoreTarget = user.id;
            const badge = createLocalScoreBadge(user.id);
            link.after(badge);
        }

        const profileMatch = location.pathname.match(/^\/profile\/(\d{1,20})(?:\/|$)/i);
        const profileHeading = document.querySelector('.userprofile .top-info .info > .headline');
        if (profileMatch && profileHeading) {
            const userId = profileMatch[1];
            if (profileHeading.dataset.hltvSpScoreTarget !== userId
                || !profileHeading.querySelector(
                    `.hltv-sp-user-score[data-hltv-sp-score-user-id="${userId}"]`,
                )
                || !privateUiControl(
                    profileHeading.querySelector(
                        `.hltv-sp-user-score[data-hltv-sp-score-user-id="${userId}"]`,
                    ),
                    '.hltv-sp-user-score-value',
                )) {
                profileHeading.dataset.hltvSpScoreTarget = userId;
                profileHeading.querySelector('.hltv-sp-user-score')?.remove();
                profileHeading.appendChild(createLocalScoreBadge(userId));
            }
        }
    }

    function clearLocalScoreDecorations() {
        for (const badge of document.querySelectorAll('.hltv-sp-user-score')) badge.remove();
        for (const target of document.querySelectorAll('[data-hltv-sp-score-target]')) {
            delete target.dataset.hltvSpScoreTarget;
        }
        for (const downvote of document.querySelectorAll('.hltv-sp-local-downvote')) downvote.remove();
    }

    function refreshLocalReactionUi(authorId = '', reactionKey = '') {
        if (authorId && /^\d{1,20}$/.test(authorId)) {
            for (const badge of document.querySelectorAll(
                `.hltv-sp-user-score[data-hltv-sp-score-user-id="${authorId}"]`,
            )) updateLocalScoreBadge(badge);
        } else {
            for (const badge of document.querySelectorAll('.hltv-sp-user-score')) {
                updateLocalScoreBadge(badge);
            }
        }

        const downvotes = reactionKey && parseReactionKey(reactionKey)
            ? document.querySelectorAll(
                `.hltv-sp-local-downvote[data-hltv-sp-reaction-key="${reactionKey}"]`,
            )
            : document.querySelectorAll('.hltv-sp-local-downvote[data-hltv-sp-reaction-key]');
        for (const host of downvotes) {
            const button = privateUiControl(host, 'button.hltv-sp-local-downvote');
            if (!button) continue;
            const active = getLocalReactionValue(button.dataset.hltvSpReactionKey) === -1;
            setLocalDownvoteButtonVisual(button, active);
        }
        applyProvisionalVoteVisualEverywhere(reactionKey);
    }

    function resolveNormalVoteContext(button) {
        if (!(button instanceof Element) || !button.matches('.plus-button[data-url]')) return null;
        const vote = parseVoteEndpoint(button.getAttribute('data-url'));
        if (!vote) return null;
        let post = null;
        if (vote.kind === 'reply') {
            post = button.closest(`.post#r${vote.id}`);
            if (!post) return null;
        } else {
            const standardBox = button.closest('.standard-box');
            const thread = standardBox?.closest('.forumthread');
            const pageThreadId = String(thread?.dataset.thread || threadIdFromHref(location.href) || '');
            if (!standardBox || !thread || pageThreadId !== vote.id) return null;
            post = standardBox;
        }
        const authorLink = findAuthorLinkInPost(post);
        const user = authorLink ? parseProfileIdentity(authorLink) : null;
        const plusContainer = button.closest('.plus-button-container');
        if (!user || !plusContainer || !post.contains(plusContainer)) return null;
        const contextThreadId = vote.kind === 'thread'
            ? vote.id
            : String(post.closest('.forum[data-forum-thread-id]')?.dataset.forumThreadId || '');
        const threadRoot = [...document.querySelectorAll('.forumthread[data-thread]')]
            .find((candidate) => String(candidate.dataset.thread || '') === contextThreadId);
        return {
            ...vote,
            author: user.name,
            userId: user.id,
            profileHref: parseSameOriginUrl(authorLink.getAttribute('href') || authorLink.href)?.href || '',
            votePath: vote.path,
            reactionKey: vote.key,
            threadUrl: validatedThreadReferrer(location.href),
            upvotes: readVoteCount(button),
            voteActive: button.classList.contains('active'),
            canVote: !button.classList.contains('disable'),
            locked: Boolean(threadRoot?.classList.contains('locked')),
            voteStateFetchedAt: Number(button.dataset.hltvSpVoteVerifiedAt)
                || state.pageVoteStateFetchedAt,
            button,
            plusContainer,
            post,
        };
    }

    function updatePreviewVoteControlLabel(button) {
        if (!(button instanceof Element)
            || !button.classList.contains('hltv-sp-preview-upvote')) return;
        const canVote = button.dataset.hltvSpCanVote !== 'false';
        const provisional = button.classList.contains('hltv-sp-provisional-upvote');
        const active = button.classList.contains('hltv-sp-active');
        let label;
        if (provisional) {
            label = canVote
                ? 'Post this local upvote to HLTV'
                : 'Remove this local-only upvote';
        } else if (canVote) {
            label = active ? 'Remove your HLTV upvote' : 'Upvote on HLTV';
        } else if (state.settings.enableSignedOutLocalVoting && hasPrivateStorage()) {
            label = 'Add a local-only upvote';
        } else {
            label = 'Log in and sync your HLTV account with Steam to upvote.';
        }
        button.title = label;
        button.setAttribute('aria-label', label);
    }

    function previewVoteControlCanAct(button) {
        return button?.dataset.hltvSpCanVote !== 'false'
            || Boolean(state.settings.enableSignedOutLocalVoting && hasPrivateStorage());
    }

    function applyProvisionalVoteVisual(button, reactionKey) {
        if (!(button instanceof Element)) return;
        const identity = parseReactionKey(reactionKey);
        if (!identity) return;
        const provisional = Boolean(
            state.settings.enableSignedOutLocalVoting
            && hasPrivateStorage()
            && isProvisionalLocalUpvote(identity.key)
            && !state.provisionalUpvoteConversions.has(identity.key),
        );
        button.classList.toggle('hltv-sp-provisional-upvote', provisional);

        if (button.classList.contains('hltv-sp-preview-upvote')) {
            const serverActive = button.dataset.hltvSpServerActive === 'true';
            const serverCount = Number(button.dataset.hltvSpServerCount);
            if (Number.isFinite(serverCount)) {
                const displayedCount = serverCount + (provisional && !serverActive ? 1 : 0);
                button.textContent = displayedCount >= 0
                    ? `+${displayedCount}`
                    : String(displayedCount);
            }
            button.setAttribute(
                'aria-pressed',
                serverActive || provisional ? 'true' : 'false',
            );
            const pending = state.reactionActionReservations.has(identity.key)
                || state.pendingReactionActions.has(identity.key);
            button.disabled = pending
                || isVoteActionBlocked(identity.key)
                || !previewVoteControlCanAct(button);
            updatePreviewVoteControlLabel(button);
            return;
        }

        if (!button.matches('.plus-button[data-url]')) return;
        const serverActive = button.classList.contains('active');
        const baseCount = Number(button.getAttribute('data-plus-count'));
        const slideOut = button.querySelector('.slide-wrapper .slide-out');
        if (slideOut && Number.isFinite(baseCount)) {
            slideOut.textContent = String(
                baseCount + (provisional && !serverActive ? 1 : 0),
            );
        }
        button.setAttribute(
            'aria-pressed',
            serverActive || provisional ? 'true' : 'false',
        );
        button.classList.toggle(
            'hltv-sp-local-upvote-available',
            !serverActive
                && button.classList.contains('disable')
                && state.settings.enableSignedOutLocalVoting
                && hasPrivateStorage(),
        );
        if (!nativeVoteOriginalTitles.has(button)) {
            nativeVoteOriginalTitles.set(button, button.getAttribute('title'));
        }
        const localTitle = provisional
            ? button.classList.contains('disable')
                ? 'Remove this local-only upvote'
                : 'Post this local upvote to HLTV'
            : button.classList.contains('disable')
                && state.settings.enableSignedOutLocalVoting
                && hasPrivateStorage()
                ? 'Add a local-only upvote'
                : '';
        if (localTitle) {
            button.title = localTitle;
        } else {
            const originalTitle = nativeVoteOriginalTitles.get(button);
            if (originalTitle === null) button.removeAttribute('title');
            else button.setAttribute('title', originalTitle);
        }
    }

    function applyProvisionalVoteVisualEverywhere(reactionKey = '') {
        const identity = reactionKey ? parseReactionKey(reactionKey) : null;
        for (const button of document.querySelectorAll('.plus-button[data-url]')) {
            const buttonIdentity = parseVoteEndpoint(button.getAttribute('data-url'));
            if (!buttonIdentity || (identity && buttonIdentity.key !== identity.key)) continue;
            applyProvisionalVoteVisual(button, buttonIdentity.key);
        }
        for (const button of document.querySelectorAll(
            '.hltv-sp-preview-upvote[data-hltv-sp-reaction-key]',
        )) {
            const key = button.dataset.hltvSpReactionKey;
            if (identity && key !== identity.key) continue;
            applyProvisionalVoteVisual(button, key);
        }
    }

    function setVoteButtonVisual(button, active, count) {
        if (!(button instanceof Element)) return;
        button.classList.toggle('active', Boolean(active));
        button.classList.toggle('hltv-sp-active', Boolean(active));
        button.setAttribute('aria-pressed', active ? 'true' : 'false');
        if (Number.isFinite(count)) {
            if (button.classList.contains('hltv-sp-preview-upvote')) {
                button.dataset.plusCount = String(count);
                button.dataset.hltvSpServerCount = String(count);
                button.dataset.hltvSpServerActive = active ? 'true' : 'false';
                button.textContent = count >= 0 ? `+${count}` : String(count);
                updatePreviewVoteControlLabel(button);
                return;
            }

            const baseCount = active ? count - 1 : count;
            button.dataset.plusCount = String(baseCount);
            const wrapper = button.querySelector('.slide-wrapper');
            const slideOut = wrapper?.querySelector('.slide-out');
            if (slideOut) slideOut.textContent = String(baseCount);
            if (active && wrapper) {
                let slideIn = wrapper.querySelector('.slide-in');
                if (!slideIn) {
                    slideIn = document.createElement('div');
                    slideIn.className = 'slide-in';
                    wrapper.prepend(slideIn);
                }
                slideIn.textContent = String(count);
            } else {
                wrapper?.querySelector('.slide-in')?.remove();
            }
        }
    }

    function updatePreviewEntryVote(entry, votePath, active, count, verifiedAt = Date.now()) {
        if (!entry || entry.votePath !== votePath) return;
        entry.voteActive = Boolean(active);
        if (Number.isFinite(count)) entry.upvotes = count;
        entry.voteStateFetchedAt = verifiedAt;
    }

    function paintVoteStateEverywhere(votePath, active, count) {
        const identity = parseVoteEndpoint(votePath);
        if (!identity) return;
        for (const button of document.querySelectorAll('.plus-button[data-url]')) {
            if (parseVoteEndpoint(button.getAttribute('data-url'))?.key === identity.key) {
                setVoteButtonVisual(button, active, count);
                applyProvisionalVoteVisual(button, identity.key);
            }
        }
        for (const button of document.querySelectorAll('.hltv-sp-preview-upvote[data-hltv-sp-vote-path]')) {
            if (parseVoteEndpoint(button.dataset.hltvSpVotePath)?.key === identity.key) {
                setVoteButtonVisual(button, active, count);
                applyProvisionalVoteVisual(button, identity.key);
            }
        }
    }

    function updateVoteStateEverywhere(votePath, active, count, verifiedAt = Date.now()) {
        const identity = parseVoteEndpoint(votePath);
        if (!identity) return;
        paintVoteStateEverywhere(identity.path, active, count);
        for (const button of document.querySelectorAll('.plus-button[data-url]')) {
            if (parseVoteEndpoint(button.getAttribute('data-url'))?.key === identity.key) {
                button.dataset.hltvSpVoteVerifiedAt = String(verifiedAt);
            }
        }
        for (const button of document.querySelectorAll('.hltv-sp-preview-upvote[data-hltv-sp-vote-path]')) {
            if (parseVoteEndpoint(button.dataset.hltvSpVotePath)?.key === identity.key) {
                button.dataset.hltvSpVoteVerifiedAt = String(verifiedAt);
            }
        }
        const updatePreview = (preview) => {
            if (!preview) return;
            updatePreviewEntryVote(preview.thread, identity.path, active, count, verifiedAt);
            for (const entry of preview.comments || []) {
                updatePreviewEntryVote(entry, identity.path, active, count, verifiedAt);
            }
        };
        updatePreview(state.previewData);
        for (const cached of state.previewCache.values()) updatePreview(cached.preview);
    }

    function updateVoteCapabilityEverywhere(votePath, canVote) {
        const identity = parseVoteEndpoint(votePath);
        if (!identity) return;
        for (const button of document.querySelectorAll('.plus-button[data-url]')) {
            if (parseVoteEndpoint(button.getAttribute('data-url'))?.key === identity.key) {
                button.classList.toggle('disable', !canVote);
                applyProvisionalVoteVisual(button, identity.key);
            }
        }
        for (const button of document.querySelectorAll('.hltv-sp-preview-upvote[data-hltv-sp-vote-path]')) {
            if (parseVoteEndpoint(button.dataset.hltvSpVotePath)?.key !== identity.key) continue;
            button.dataset.hltvSpCanVote = canVote ? 'true' : 'false';
            button.disabled = !previewVoteControlCanAct(button)
                || isVoteActionBlocked(identity.key);
            applyProvisionalVoteVisual(button, identity.key);
        }
        const updatePreview = (preview) => {
            if (!preview) return;
            for (const entry of [preview.thread, ...(preview.comments || [])]) {
                if (entry?.votePath === identity.path) entry.canVote = Boolean(canVote);
            }
        };
        updatePreview(state.previewData);
        for (const cached of state.previewCache.values()) updatePreview(cached.preview);
    }

    function applyVoteSnapshotEverywhere(reaction, snapshot) {
        if (!reaction || !snapshot) return;
        const votePath = `/${reaction.kind}-plus-toogle/${reaction.id}`;
        updateVoteStateEverywhere(
            votePath,
            snapshot.active,
            snapshot.count,
            snapshot.verifiedAt,
        );
        updateVoteCapabilityEverywhere(votePath, snapshot.canVote);
    }

    function commitConfirmedVoteState(entry, identity, confirmed) {
        entry.voteActive = confirmed.active;
        entry.upvotes = confirmed.count;
        entry.canVote = confirmed.canVote;
        entry.voteStateFetchedAt = confirmed.verifiedAt;
        updateVoteStateEverywhere(
            identity.path,
            confirmed.active,
            confirmed.count,
            confirmed.verifiedAt,
        );
        updateVoteCapabilityEverywhere(identity.path, confirmed.canVote);
        writeVoteSnapshot(identity.key, confirmed);
    }

    async function fetchConfirmedVoteState(entry, { commit = true } = {}) {
        const identity = parseVoteEndpoint(entry?.votePath);
        const threadUrl = validatedThreadReferrer(entry?.threadUrl);
        if (!identity || !threadUrl) {
            throw makeActionError('Vote verification target is invalid.', 'This vote cannot be verified safely.');
        }
        try {
            const doc = await fetchSameOriginDocument(threadUrl, {
                contentLabel: 'thread vote state',
                expectedSelector: '.forumthread, .post',
                requireExpectedSelector: true,
                cache: 'no-store',
            });
            const button = [...doc.querySelectorAll('.plus-button[data-url]')]
                .find((candidate) => (
                    parseVoteEndpoint(candidate.getAttribute('data-url'))?.key === identity.key
                ));
            const count = readVoteCount(button);
            if (!button || !Number.isFinite(count)) {
                throw new Error('The matching vote control was not found.');
            }
            const confirmed = {
                active: button.classList.contains('active'),
                count,
                canVote: !button.classList.contains('disable'),
                verifiedAt: Date.now(),
            };
            if (commit) commitConfirmedVoteState(entry, identity, confirmed);
            return confirmed;
        } catch (error) {
            if (error?.name === 'ActionError') throw error;
            throw makeActionError(
                `Vote verification failed: ${error instanceof Error ? error.message : String(error)}`,
                'The current HLTV vote state could not be verified. For safety, wait one minute and reload this page.',
            );
        }
    }

    function voteBaselineFromEntry(entry) {
        const count = entry?.upvotes;
        const verifiedAt = Number(entry?.voteStateFetchedAt);
        const now = Date.now();
        if (typeof count !== 'number'
            || !Number.isFinite(count)
            || Math.abs(count) > 1_000_000
            || !Number.isFinite(verifiedAt)
            || verifiedAt < now - CONFIG.fastVoteBaselineMaxAgeMs
            || verifiedAt > now + 5000
            || typeof entry?.voteActive !== 'boolean'
            || typeof entry?.canVote !== 'boolean') return null;
        return {
            active: entry.voteActive,
            count,
            canVote: entry.canVote,
            verifiedAt,
        };
    }

    function invalidateVotePreviewCache(entry) {
        const threadUrl = validatedThreadReferrer(entry?.threadUrl);
        const threadId = threadIdFromHref(threadUrl);
        if (threadId) deleteThreadPreviewCache(threadId);
    }

    async function markVoteOutcomeUnconfirmed(entry) {
        if (!entry?.reactionKey) return;
        state.unconfirmedVoteKeys.add(entry.reactionKey);
        await setActionFenceAndWait('vote', entry.reactionKey);
        invalidateVotePreviewCache(entry);
    }

    async function toggleVoteAndConfirm(entry, baseline) {
        const baselineActive = Boolean(baseline?.active);
        const baselineCount = Number(baseline?.count);
        let postError = null;
        try {
            await postVoteToggle(entry.votePath, entry.threadUrl);
        } catch (error) {
            postError = error;
        }

        let confirmed;
        try {
            confirmed = await fetchConfirmedVoteState(entry);
        } catch (verificationError) {
            if (Number.isFinite(baselineCount)) {
                paintVoteStateEverywhere(entry.votePath, baselineActive, baselineCount);
            }
            await markVoteOutcomeUnconfirmed(entry);
            const error = makeActionError(
                'Vote outcome is unconfirmed.',
                'The vote may have reached HLTV, but its result could not be confirmed. For safety, wait one minute and reload this page.',
            );
            error.cause = postError || verificationError;
            throw error;
        }

        if (postError?.ambiguousOutcome) {
            await markVoteOutcomeUnconfirmed(entry);
            const error = makeActionError(
                postError.message,
                `${actionErrorMessage(postError)} The latest visible count was refreshed, but this control remains locked.`,
                { ambiguousOutcome: true },
            );
            error.confirmedVoteState = confirmed;
            error.confirmedVoteTransition = confirmed.active !== baselineActive;
            throw error;
        }
        if (postError) {
            throw makeActionError(
                postError.message,
                `${actionErrorMessage(postError)} The current HLTV vote state was refreshed.`,
            );
        }
        if (confirmed.active === baselineActive) {
            await markVoteOutcomeUnconfirmed(entry);
            throw makeActionError(
                'HLTV did not expose the expected vote transition.',
                'HLTV accepted the request, but the changed vote state could not be confirmed. For safety, wait one minute and reload this page.',
                { ambiguousOutcome: true },
            );
        }
        return confirmed;
    }

    function applyLocalReactionInMemory(reactionKey, authorId, value, options = {}) {
        const identity = parseReactionKey(reactionKey);
        if (!identity || !/^\d{1,20}$/.test(String(authorId || ''))) return;
        const previousUpdatedAt = Number(state.localReactions.get(identity.key)?.updatedAt || 0);
        const mutation = {
            authorId: String(authorId),
            value: Number(value),
            updatedAt: Math.max(
                Date.now(),
                state.localReactionResetAt + 1,
                previousUpdatedAt + 1,
            ),
            mutationId: createRandomId('unsaved-reaction'),
        };
        const next = new Map(state.localReactions);
        next.set(identity.key, mutation);
        state.localReactions = normaliseLocalReactions(
            serialiseLocalReactions(next, state.localReactionResetAt),
            state.localReactionResetAt,
        );
        if (options.provisional && mutation.value === 1) {
            state.provisionalLocalUpvotes.set(identity.key, {
                authorId: mutation.authorId,
                reactionMutationId: mutation.mutationId,
                updatedAt: mutation.updatedAt,
            });
        } else {
            state.provisionalLocalUpvotes.delete(identity.key);
        }
        rebuildLocalUserScores();
        refreshLocalReactionUi(mutation.authorId, identity.key);
    }

    async function persistLocalReactionAfterConfirmedVote(entry, value) {
        try {
            await queueLocalReactionMutation(entry.reactionKey, entry.userId, value);
        } catch (error) {
            applyLocalReactionInMemory(entry.reactionKey, entry.userId, value);
            throw makeActionError(
                `Confirmed HLTV vote changed, but local score persistence failed: ${error instanceof Error ? error.message : String(error)}`,
                'The HLTV vote changed, but its local reaction history could not be saved in this browser session.',
            );
        }
    }

    async function syncLocalReactionToConfirmedVote(entry, confirmed) {
        if (!hasPrivateStorage()
            || !/^\d{1,20}$/.test(entry?.userId)
            || !confirmed) return;
        const before = getLocalReactionValue(entry.reactionKey);
        const after = confirmed.active ? 1 : before === 1 ? 0 : before;
        if (after !== before
            || (confirmed.active && isProvisionalLocalUpvote(entry.reactionKey))) {
            await persistLocalReactionAfterConfirmedVote(entry, after);
        }
    }

    function setReactionControlsPending(reactionKey, pending) {
        const identity = parseReactionKey(reactionKey);
        if (!identity) return;
        const unconfirmed = isVoteActionBlocked(reactionKey);
        const controls = new Set(document.querySelectorAll(
            `[data-hltv-sp-reaction-key="${reactionKey}"]`,
        ));
        for (const control of [...controls]) {
            if (!privateUiRoots.has(control)) continue;
            controls.delete(control);
            const privateControl = privateUiControl(control, 'button.hltv-sp-local-downvote');
            if (privateControl) controls.add(privateControl);
        }
        for (const button of document.querySelectorAll('.plus-button[data-url]')) {
            if (parseVoteEndpoint(button.getAttribute('data-url'))?.key === identity.key) {
                controls.add(button);
            }
        }
        for (const control of controls) {
            control.classList.toggle('hltv-sp-pending', pending);
            if ('disabled' in control
                && (control.matches('.hltv-sp-local-downvote, .hltv-sp-preview-upvote'))) {
                control.disabled = pending || unconfirmed || (
                    control.matches('.hltv-sp-preview-upvote')
                    && !previewVoteControlCanAct(control)
                );
            }
            control.setAttribute('aria-busy', pending ? 'true' : 'false');
        }
    }

    async function withReactionAction(reactionKey, action, onReserved = null) {
        if (!parseReactionKey(reactionKey)) {
            throw makeActionError('Invalid reaction key.', 'This action is unavailable.');
        }
        if (state.reactionActionReservations.has(reactionKey)
            || state.pendingReactionActions.has(reactionKey)) return;
        if (state.unconfirmedVoteKeys.has(reactionKey)
            || hasActionFence('vote', reactionKey)) {
            throw makeActionError(
                'Vote state is unconfirmed.',
                'For safety, wait one minute and reload this page before changing this vote again.',
            );
        }

        const token = createRandomId('action');
        state.reactionActionReservations.set(reactionKey, token);
        setReactionControlsPending(reactionKey, true);
        try {
            if (typeof onReserved === 'function') onReserved();
            return await withCrossTabActionLock('vote', reactionKey, async () => {
                if (state.unconfirmedVoteKeys.has(reactionKey)
                    || hasActionFence('vote', reactionKey)) {
                    throw makeActionError(
                        'Vote state is unconfirmed.',
                        'For safety, wait one minute and reload this page before changing this vote again.',
                    );
                }
                state.pendingReactionActions.set(reactionKey, token);
                if (!await setActionFenceAndWait('vote', reactionKey, 'pending')) {
                    throw makeActionError(
                        'Could not establish the vote safety fence.',
                        'No vote was sent because duplicate-action protection could not be stored.',
                    );
                }
                return await action();
            });
        } finally {
            const ownsReservation = state.reactionActionReservations.get(reactionKey) === token;
            const ownsPendingAction = state.pendingReactionActions.get(reactionKey) === token;
            if (ownsReservation || ownsPendingAction) {
                const unconfirmed = state.unconfirmedVoteKeys.has(reactionKey);
                if (ownsPendingAction) state.pendingReactionActions.delete(reactionKey);
                if (!unconfirmed) {
                    await clearOwnedPendingActionFenceAndWait('vote', reactionKey);
                }
                if (ownsReservation) state.reactionActionReservations.delete(reactionKey);
                setReactionControlsPending(reactionKey, false);
                refreshActionFenceUi();
                schedulePreviewCloseAfterInteraction();
            }
        }
    }

    async function withLocalReactionAction(reactionKey, action) {
        if (!parseReactionKey(reactionKey)) {
            throw makeActionError('Invalid reaction key.', 'This action is unavailable.');
        }
        if (state.reactionActionReservations.has(reactionKey)
            || state.pendingReactionActions.has(reactionKey)) return;
        if (isVoteActionBlocked(reactionKey)) {
            throw makeActionError(
                'Vote state is pending or unconfirmed.',
                'This local score cannot change until the related HLTV vote is settled.',
            );
        }
        const token = createRandomId('local-action');
        state.reactionActionReservations.set(reactionKey, token);
        setReactionControlsPending(reactionKey, true);
        try {
            const run = async () => {
                if (state.unconfirmedVoteKeys.has(reactionKey)
                    || hasActionFence('vote', reactionKey)) {
                    throw makeActionError(
                        'Vote state is pending or unconfirmed.',
                        'This local score cannot change until the related HLTV vote is settled.',
                    );
                }
                state.pendingReactionActions.set(reactionKey, token);
                return action();
            };
            return hasCrossTabActionLocks()
                ? await withCrossTabActionLock('vote', reactionKey, run)
                : await run();
        } finally {
            const ownsReservation = state.reactionActionReservations.get(reactionKey) === token;
            const ownsPendingAction = state.pendingReactionActions.get(reactionKey) === token;
            if (ownsReservation || ownsPendingAction) {
                if (ownsPendingAction) {
                    state.pendingReactionActions.delete(reactionKey);
                }
                if (ownsReservation) {
                    state.reactionActionReservations.delete(reactionKey);
                }
                setReactionControlsPending(reactionKey, false);
                const deferredSnapshot = state.deferredVoteSnapshots.get(reactionKey);
                if (deferredSnapshot) {
                    state.deferredVoteSnapshots.delete(reactionKey);
                    applyVoteSnapshotEverywhere(
                        deferredSnapshot.reaction,
                        deferredSnapshot.snapshot,
                    );
                }
                refreshActionFenceUi();
                schedulePreviewCloseAfterInteraction();
            }
        }
    }

    function showPreviewActionError(control, message) {
        const lightControl = privateUiHostForNode(control) || control;
        const card = lightControl?.closest('.hltv-sp-preview-thread, .hltv-sp-preview-comment');
        const status = card?.querySelector(':scope > .hltv-sp-preview-post-footer .hltv-sp-preview-action-status');
        if (status) status.textContent = cleanText(message).slice(0, CONFIG.maxActionErrorChars);
    }

    function showNormalActionError(context, message) {
        const bottomBar = context?.plusContainer?.parentElement;
        if (!bottomBar) return;
        let status = bottomBar.querySelector(':scope > .hltv-sp-local-action-status');
        if (!status) {
            status = document.createElement('span');
            status.className = 'hltv-sp-local-action-status';
            status.setAttribute('aria-live', 'polite');
            bottomBar.appendChild(status);
        }
        status.textContent = cleanText(message).slice(0, CONFIG.maxActionErrorChars);
    }

    function showNativeReplyGuardError(button, message) {
        const container = button?.closest('.newreply-con');
        if (!container) return;
        let status = container.querySelector(':scope > .hltv-sp-local-action-status');
        if (!status) {
            status = document.createElement('div');
            status.className = 'hltv-sp-local-action-status';
            status.setAttribute('aria-live', 'polite');
            container.appendChild(status);
        }
        status.textContent = cleanText(message).slice(0, CONFIG.maxActionErrorChars);
    }

    function rememberNativeReplyTarget(replyTrigger) {
        const post = replyTrigger?.closest('.post');
        const forum = replyTrigger?.closest('.forum[data-forum-thread-id]');
        const composer = forum?.querySelector('.newreply-con.newReplyBox');
        const replyId = post?.id?.match(/^r(\d{1,20})$/)?.[1] || '';
        if (!composer || !replyId) return;
        composer.dataset.hltvSpNativeReplyId = replyId;
        const draftBinding = nativeDraftBindings.get(composer);
        if (draftBinding) {
            setDraftBindingStatus(draftBinding, '');
            refreshDraftBinding(draftBinding);
        }
    }

    function resolveNativeReplySubmission(button, threadId) {
        const container = button?.closest('.newreply-con');
        const textarea = container?.querySelector('textarea.forum-textarea');
        if (!container || !textarea || !/^\d{1,20}$/.test(String(threadId || ''))) return null;
        const isThreaded = container.classList.contains('threading');
        const replyId = isThreaded
            ? String(container.dataset.hltvSpNativeReplyId || '')
            : '';
        if (isThreaded && !/^\d{1,20}$/.test(replyId)) return null;
        const rawContextId = String(
            container.querySelector('.add-context-text[data-context-id]')
                ?.getAttribute('data-context-id')
            || '',
        );
        return {
            container,
            textarea,
            replyId,
            shortContextId: /^\d{1,20}$/.test(rawContextId) ? rawContextId : '',
        };
    }

    function scheduleNativeVoteHistorySync(entry) {
        if (!hasPrivateStorage()
            || !entry?.reactionKey
            || !/^\d{1,20}$/.test(entry.userId)) return;
        const baselineActive = Boolean(entry.voteActive);
        window.setTimeout(async () => {
            try {
                const confirmed = await fetchConfirmedVoteState(entry);
                if (confirmed.active !== baselineActive) {
                    await syncLocalReactionToConfirmedVote(entry, confirmed);
                }
            } catch (error) {
                log('Could not verify a native vote for background score tracking.', error);
            }
        }, 3000);
    }

    function navigateToPostedNativeReply(redirectUrl) {
        const currentUrl = parseSameOriginUrl(window.location.href);
        const isSameDocument = Boolean(
            currentUrl
            && redirectUrl
            && currentUrl.pathname === redirectUrl.pathname
            && currentUrl.search === redirectUrl.search
        );
        if (!isSameDocument) {
            window.location.assign(redirectUrl.href);
            return;
        }

        // Assigning only a new fragment is a same-document navigation, so it
        // does not make HLTV render the newly posted reply.  Preserve the
        // confirmed target and force the same full reload as HLTV's native flow.
        if (redirectUrl.hash) window.location.hash = redirectUrl.hash;
        window.location.reload();
    }

    async function submitNativeForumReply(button, threadId) {
        const submission = resolveNativeReplySubmission(button, threadId);
        if (!submission) {
            throw makeActionError(
                'The native reply target could not be resolved.',
                'No reply was sent because its target could not be verified safely.',
            );
        }
        const message = String(submission.textarea.value || '');
        if (!message.trim()) {
            throw makeActionError('The native reply is empty.', 'Write a reply first.');
        }
        const submittedSavedDraft = matchingSavedReplyDraft(
            replyDraftDescriptorForNativeComposer(submission.container),
            message,
        );

        const result = await withCrossTabActionLock('reply', threadId, async () => {
            if (state.pendingReplyActions.has(threadId) || isReplyActionBlocked(threadId)) {
                throw makeActionError(
                    'A reply action is already pending or unconfirmed.',
                    'Another reply to this thread is already being processed or may have posted.',
                );
            }
            const actionToken = createRandomId('native-reply');
            state.pendingReplyActions.set(threadId, actionToken);
            button.disabled = true;
            button.setAttribute('aria-busy', 'true');
            let unconfirmed = false;
            try {
                if (!await setActionFenceAndWait('reply', threadId, 'pending')) {
                    throw makeActionError(
                        'Could not establish the native reply safety fence.',
                        'No reply was sent because duplicate-action protection could not be stored.',
                    );
                }
                showNativeReplyGuardError(button, 'Posting\u2026');
                const response = await postForumReply({
                    threadId,
                    replyId: submission.replyId,
                    message,
                    shortContextId: submission.shortContextId,
                    threadUrl: location.href,
                });
                if (submittedSavedDraft) {
                    try {
                        await removeSavedDraftIfRevision(
                            submittedSavedDraft.key,
                            submittedSavedDraft.accountId,
                            submittedSavedDraft.revision,
                            message,
                        );
                    } catch (error) {
                        log('Could not remove the confirmed posted reply draft.', error);
                    }
                }
                submission.textarea.value = '';
                showNativeReplyGuardError(button, 'Posted. Redirecting\u2026');
                return response;
            } catch (error) {
                unconfirmed = Boolean(error?.ambiguousOutcome);
                if (unconfirmed) {
                    state.unconfirmedReplyThreads.add(threadId);
                    await setActionFenceAndWait('reply', threadId);
                }
                throw error;
            } finally {
                if (state.pendingReplyActions.get(threadId) === actionToken) {
                    state.pendingReplyActions.delete(threadId);
                    if (!unconfirmed) {
                        await clearOwnedPendingActionFenceAndWait('reply', threadId);
                    }
                }
                button.disabled = false;
                button.setAttribute('aria-busy', 'false');
                syncPreviewReplySubmissionState(threadId);
                refreshActionFenceUi();
            }
        });

        const redirectUrl = parseSameOriginUrl(result?.redirectTo);
        if (!redirectUrl || threadIdFromHref(redirectUrl.href) !== threadId) {
            throw makeActionError(
                'The confirmed native reply redirect was invalid.',
                'The reply posted, but its destination could not be opened safely. Reload the thread.',
            );
        }
        navigateToPostedNativeReply(redirectUrl);
    }

    function refreshActionFenceUi() {
        const reactionButtons = [
            ...document.querySelectorAll('.hltv-sp-preview-upvote[data-hltv-sp-reaction-key]'),
            ...queryPrivateUiAll(
                document,
                'button.hltv-sp-local-downvote[data-hltv-sp-reaction-key]',
            ),
        ];
        for (const button of reactionButtons) {
            const reactionKey = button.dataset.hltvSpReactionKey;
            const pending = state.reactionActionReservations.has(reactionKey)
                || state.pendingReactionActions.has(reactionKey);
            const blocked = isVoteActionBlocked(reactionKey);
            button.disabled = pending || blocked || (
                button.matches('.hltv-sp-preview-upvote')
                && !previewVoteControlCanAct(button)
            );
        }
        for (const button of document.querySelectorAll('.plus-button[data-url]')) {
            const reactionKey = parseVoteEndpoint(button.getAttribute('data-url'))?.key || '';
            const blocked = Boolean(reactionKey && isVoteActionBlocked(reactionKey));
            const locallyAvailable = Boolean(
                reactionKey
                && state.settings.enableSignedOutLocalVoting
                && hasPrivateStorage(),
            );
            const unavailable = button.classList.contains('disable') && !locallyAvailable;
            button.classList.toggle('hltv-sp-action-fenced', blocked);
            button.setAttribute('aria-disabled', blocked || unavailable ? 'true' : 'false');
            if (reactionKey) applyProvisionalVoteVisual(button, reactionKey);
        }
        for (const composer of document.querySelectorAll(
            '.hltv-sp-preview-composer[data-hltv-sp-thread-id]',
        )) {
            applyPreviewReplySubmissionState(
                composer,
                composer.dataset.hltvSpThreadId,
            );
        }
        const pageThreadId = threadIdFromHref(location.href);
        for (const button of document.querySelectorAll('.newreply-post')) {
            const blocked = Boolean(pageThreadId && isReplyActionBlocked(pageThreadId));
            button.classList.toggle('hltv-sp-action-fenced', blocked);
            button.setAttribute('aria-disabled', blocked ? 'true' : 'false');
        }
    }

    function handlePrivateActionCacheChange(key) {
        const normalisedKey = String(key || '');
        if (normalisedKey.startsWith(`${CONFIG.storagePrefix}actionFence.`)) {
            refreshActionFenceUi();
            return;
        }
        const snapshotPrefix = `${CONFIG.storagePrefix}voteSnapshot.`;
        if (!normalisedKey.startsWith(snapshotPrefix)) return;
        const reaction = parseReactionKey(normalisedKey.slice(snapshotPrefix.length));
        const snapshot = reaction ? readVoteSnapshot(reaction.key) : null;
        if (!reaction || !snapshot) return;
        const pendingToken = String(state.pendingReactionActions.get(reaction.key) || '');
        if (pendingToken) {
            if (pendingToken.startsWith('local-action_')) {
                const previous = state.deferredVoteSnapshots.get(reaction.key);
                if (!previous || snapshot.verifiedAt >= previous.snapshot.verifiedAt) {
                    state.deferredVoteSnapshots.set(reaction.key, { reaction, snapshot });
                }
            }
            return;
        }
        applyVoteSnapshotEverywhere(reaction, snapshot);
    }

    function installPrivateActionCacheListener() {
        const storage = extensionPrivateStorage();
        if (!storage
            || state.privateCacheListenerId !== null
            || typeof storage.addPrefixChangeListener !== 'function') return;
        state.privateCacheListenerId = storage.addPrefixChangeListener(
            CONFIG.storagePrefix,
            (key) => handlePrivateActionCacheChange(key),
        );
    }

    function installNativeMutationGuard() {
        if (state.nativeMutationGuardReady) return;
        state.nativeMutationGuardReady = true;
        installPrivateActionCacheListener();
        window.addEventListener('click', (event) => {
            const target = event.target instanceof Element ? event.target : null;
            if (target?.closest('.hltv-sp-local-downvote')) return;
            const replyTrigger = target?.closest('.reply-button');
            if (replyTrigger) {
                rememberNativeReplyTarget(replyTrigger);
                return;
            }
            const voteButton = target?.closest('.plus-button[data-url]');
            if (voteButton) {
                const context = resolveNormalVoteContext(voteButton);
                if (!context) return;
                if (!state.initialDataReady) {
                    event.preventDefault();
                    event.stopImmediatePropagation();
                    showNormalActionError(context, 'The extension is still loading. Try this vote again in a moment.');
                    return;
                }
                const blocked = isVoteActionBlocked(context.reactionKey);
                const localVoteAvailable = Boolean(
                    state.settings.enableSignedOutLocalVoting
                    && hasPrivateStorage()
                    && (!context.canVote
                        || isProvisionalLocalUpvote(context.reactionKey)),
                );
                const shouldIntercept = hasCrossTabActionLocks() || localVoteAvailable;
                if (!shouldIntercept && !blocked) {
                    scheduleNativeVoteHistorySync(context);
                    return;
                }
                event.preventDefault();
                event.stopImmediatePropagation();
                showNormalActionError(context, '');
                if (blocked) {
                    const pending = state.reactionActionReservations.has(context.reactionKey)
                        || state.pendingReactionActions.has(context.reactionKey)
                        || readActionFence('vote', context.reactionKey)?.status === 'pending';
                    showNormalActionError(
                        context,
                        pending
                            ? 'This vote is already being processed in this or another tab.'
                            : 'For safety, wait one minute and reload this page before changing this unconfirmed vote again.',
                    );
                    return;
                }
                handleVoteToggle(context, voteButton)
                    .catch((error) => showNormalActionError(context, actionErrorMessage(error)));
                return;
            }

            const replyButton = target?.closest('.newreply-post');
            const pageThreadId = threadIdFromHref(location.href);
            if (!replyButton || !pageThreadId) return;
            if (!state.initialDataReady) {
                event.preventDefault();
                event.stopImmediatePropagation();
                showNativeReplyGuardError(
                    replyButton,
                    'The extension is still loading. Try posting again in a moment.',
                );
                return;
            }
            const replyBlocked = isReplyActionBlocked(pageThreadId);
            if (replyButton.disabled && !replyBlocked) return;
            if (replyBlocked) {
                event.preventDefault();
                event.stopImmediatePropagation();
                const pending = state.pendingReplyActions.has(pageThreadId)
                    || readActionFence('reply', pageThreadId)?.status === 'pending';
                showNativeReplyGuardError(
                    replyButton,
                    pending
                        ? 'A reply to this thread is already being processed in this or another tab.'
                        : 'A reply to this thread may have posted. For safety, wait one minute and reload this page.',
                );
                return;
            }
            if (hasCrossTabActionLocks()) {
                event.preventDefault();
                event.stopImmediatePropagation();
                submitNativeForumReply(replyButton, pageThreadId)
                    .catch((error) => {
                        showNativeReplyGuardError(replyButton, actionErrorMessage(error));
                    });
                return;
            }
            if (!setActionFence('reply', pageThreadId)) {
                event.preventDefault();
                event.stopImmediatePropagation();
                showNativeReplyGuardError(
                    replyButton,
                    'No reply was sent because duplicate-action protection could not be stored.',
                );
            }
        }, true);
        refreshActionFenceUi();
    }

    async function handleVoteToggle(entry, sourceButton) {
        if (!entry?.votePath || !entry?.reactionKey) {
            throw makeActionError('Voting target is unavailable.', 'This HLTV vote control is unavailable.');
        }
        const canStoreLocalVote = Boolean(
            state.settings.enableSignedOutLocalVoting
            && hasPrivateStorage()
            && /^\d{1,20}$/.test(String(entry.userId || '')),
        );
        const provisionalAtStart = isProvisionalLocalUpvote(entry.reactionKey);
        const signedInNow = Boolean(extractCurrentUserId());
        if (!entry.canVote
            && canStoreLocalVote
            && (!signedInNow || entry.locked)) {
            return withLocalReactionAction(entry.reactionKey, async () => {
                const remove = isProvisionalLocalUpvote(entry.reactionKey);
                await queueLocalReactionMutation(
                    entry.reactionKey,
                    entry.userId,
                    remove ? 0 : 1,
                    { provisional: !remove },
                );
            });
        }

        const intendedBaselineActive = Boolean(entry.voteActive);
        const intendedBaselineCount = Number(entry.upvotes);
        const convertingProvisional = provisionalAtStart;
        let optimisticPainted = false;
        let actionStarted = false;
        if (convertingProvisional) {
            state.provisionalUpvoteConversions.add(entry.reactionKey);
        }
        try {
            return await withReactionAction(entry.reactionKey, async () => {
                if (convertingProvisional) {
                    const canonical = await readCanonicalLocalReactionState(
                        entry.reactionKey,
                    );
                    if (!canonical.provisional) {
                        throw makeActionError(
                            'The local upvote changed before conversion.',
                            'The local upvote changed in another tab, so no HLTV vote was sent.',
                        );
                    }
                }
                actionStarted = true;
                let current;
                const identity = parseVoteEndpoint(entry.votePath);
                const displayedBaseline = voteBaselineFromEntry(entry);
                const newerSnapshot = readVoteSnapshot(entry.reactionKey);
                const displayedBaselineUsable = Boolean(
                    displayedBaseline
                    && (displayedBaseline.canVote || !signedInNow),
                );
                const newerSnapshotUsable = Boolean(
                    newerSnapshot
                    && (newerSnapshot.canVote || !signedInNow),
                );
                if (!convertingProvisional
                    && displayedBaselineUsable
                    && newerSnapshotUsable
                    && newerSnapshot.verifiedAt > displayedBaseline.verifiedAt) {
                    if (identity) commitConfirmedVoteState(entry, identity, newerSnapshot);
                    await syncLocalReactionToConfirmedVote(entry, newerSnapshot);
                    if (newerSnapshot.active !== intendedBaselineActive) {
                        throw makeActionError(
                            'Vote state changed before submission.',
                            'The vote changed elsewhere, so this control was refreshed without sending anything. Review it before clicking again.',
                        );
                    }
                    current = newerSnapshot;
                } else if (!convertingProvisional && displayedBaselineUsable) {
                    current = displayedBaseline;
                } else {
                    try {
                        current = await fetchConfirmedVoteState(entry, { commit: false });
                    } catch (error) {
                        if (Number.isFinite(intendedBaselineCount)) {
                            paintVoteStateEverywhere(
                                entry.votePath,
                                intendedBaselineActive,
                                intendedBaselineCount,
                            );
                        }
                        throw makeActionError(
                            `Vote preflight failed: ${error instanceof Error ? error.message : String(error)}`,
                            'No vote was sent because the current HLTV state could not be checked.',
                        );
                    }
                }
                if (!current.canVote) {
                    if (identity) commitConfirmedVoteState(entry, identity, current);
                    if (convertingProvisional) {
                        throw makeActionError(
                            'HLTV voting is still unavailable.',
                            'The local upvote remains saved because HLTV still does not allow this account to post it.',
                        );
                    }
                    if (canStoreLocalVote) {
                        await queueLocalReactionMutation(
                            entry.reactionKey,
                            entry.userId,
                            1,
                            { provisional: true },
                        );
                        return;
                    }
                    throw makeActionError(
                        'Voting is disabled.',
                        'HLTV currently requires you to be logged in and Steam-synced to vote.',
                    );
                }
                if (convertingProvisional && current.active) {
                    if (identity) commitConfirmedVoteState(entry, identity, current);
                    await persistLocalReactionAfterConfirmedVote(entry, 1);
                    return;
                }
                if (!convertingProvisional
                    && current.active !== intendedBaselineActive) {
                    if (identity) commitConfirmedVoteState(entry, identity, current);
                    await syncLocalReactionToConfirmedVote(entry, current);
                    throw makeActionError(
                        'Vote state changed before submission.',
                        'The vote changed elsewhere, so this control was refreshed without sending anything. Review it before clicking again.',
                    );
                }
                entry.voteActive = current.active;
                entry.upvotes = current.count;
                entry.canVote = current.canVote;
                entry.voteStateFetchedAt = current.verifiedAt;
                paintVoteStateEverywhere(
                    entry.votePath,
                    !current.active,
                    current.count + (current.active ? -1 : 1),
                );
                let confirmed;
                try {
                    confirmed = await toggleVoteAndConfirm(entry, current);
                } catch (error) {
                    if (error?.confirmedVoteTransition && error.confirmedVoteState) {
                        await syncLocalReactionToConfirmedVote(entry, error.confirmedVoteState);
                    }
                    throw error;
                }
                await syncLocalReactionToConfirmedVote(entry, confirmed);
            }, () => {
                if (!Number.isFinite(intendedBaselineCount)) return;
                paintVoteStateEverywhere(
                    entry.votePath,
                    convertingProvisional ? true : !intendedBaselineActive,
                    intendedBaselineCount + (
                        convertingProvisional ? 1 : intendedBaselineActive ? -1 : 1
                    ),
                );
                optimisticPainted = true;
            });
        } catch (error) {
            if (!actionStarted && optimisticPainted) {
                paintVoteStateEverywhere(
                    entry.votePath,
                    intendedBaselineActive,
                    intendedBaselineCount,
                );
            }
            throw error;
        } finally {
            if (convertingProvisional) {
                state.provisionalUpvoteConversions.delete(entry.reactionKey);
                applyProvisionalVoteVisualEverywhere(entry.reactionKey);
            }
        }
    }

    async function handlePreviewVote(entry, preview, button) {
        if (state.previewData !== preview) {
            throw makeActionError('Preview changed before vote.', 'Reopen the thread preview and try again.');
        }
        showPreviewActionError(button, '');
        return handleVoteToggle(entry, button);
    }

    async function handleLocalDownvote(entry, sourceButton) {
        if (!state.settings.enableLocalDownvotes
            || !hasPrivateStorage()
            || !/^\d{1,20}$/.test(entry?.userId)) return;
        showPreviewActionError(sourceButton, '');
        const before = getLocalReactionValue(entry.reactionKey);
        if (before === -1) {
            return withLocalReactionAction(entry.reactionKey, () => (
                queueLocalReactionMutation(entry.reactionKey, entry.userId, 0)
            ));
        }
        if (isProvisionalLocalUpvote(entry.reactionKey)
            || !entry.voteActive) {
            return withLocalReactionAction(entry.reactionKey, () => (
                queueLocalReactionMutation(entry.reactionKey, entry.userId, -1)
            ));
        }

        const intendedBaselineCount = Number(entry.upvotes);
        let optimisticPainted = false;
        let actionStarted = false;
        try {
            return await withReactionAction(entry.reactionKey, async () => {
                actionStarted = true;
                let current;
                try {
                    current = await fetchConfirmedVoteState(entry, { commit: false });
                } catch (error) {
                    if (Number.isFinite(intendedBaselineCount)) {
                        paintVoteStateEverywhere(
                            entry.votePath,
                            true,
                            intendedBaselineCount,
                        );
                    }
                    throw makeActionError(
                        `Vote preflight failed: ${error instanceof Error ? error.message : String(error)}`,
                        'The local downvote was not added because the existing HLTV upvote could not be checked.',
                    );
                }
                const identity = parseVoteEndpoint(entry.votePath);
                if (!identity) {
                    throw makeActionError(
                        'Vote target is invalid.',
                        'The existing HLTV upvote could not be removed safely.',
                    );
                }
                if (!current.active) {
                    commitConfirmedVoteState(entry, identity, current);
                    await persistLocalReactionAfterConfirmedVote(entry, -1);
                    return;
                }
                if (!current.canVote) {
                    commitConfirmedVoteState(entry, identity, current);
                    throw makeActionError(
                        'The active HLTV upvote cannot be removed.',
                        'The local downvote was not added because the existing HLTV upvote could not be removed.',
                    );
                }
                entry.voteActive = current.active;
                entry.upvotes = current.count;
                entry.canVote = current.canVote;
                entry.voteStateFetchedAt = current.verifiedAt;
                paintVoteStateEverywhere(
                    entry.votePath,
                    false,
                    current.count - 1,
                );
                let confirmed;
                try {
                    confirmed = await toggleVoteAndConfirm(entry, current);
                } catch (error) {
                    if (error?.confirmedVoteTransition
                        && error.confirmedVoteState
                        && !error.confirmedVoteState.active) {
                        await persistLocalReactionAfterConfirmedVote(entry, -1);
                    }
                    throw error;
                }
                if (confirmed.active) {
                    throw makeActionError(
                        'HLTV upvote removal was not confirmed.',
                        'The local downvote was not added because the existing HLTV upvote remains active.',
                    );
                }
                await persistLocalReactionAfterConfirmedVote(entry, -1);
            }, () => {
                if (!Number.isFinite(intendedBaselineCount)) return;
                paintVoteStateEverywhere(
                    entry.votePath,
                    false,
                    Math.max(-1_000_000, intendedBaselineCount - 1),
                );
                optimisticPainted = true;
            });
        } catch (error) {
            if (!actionStarted && optimisticPainted) {
                paintVoteStateEverywhere(
                    entry.votePath,
                    true,
                    intendedBaselineCount,
                );
            }
            throw error;
        }
    }

    function scanNormalVoteControls(root = document) {
        if (!hasPrivateStorage()) return;
        if (!state.settings.enableLocalDownvotes) {
            for (const button of elementsWithin(root, '.plus-button[data-url]')) {
                const identity = parseVoteEndpoint(button.getAttribute('data-url'));
                if (identity) applyProvisionalVoteVisual(button, identity.key);
            }
            return;
        }
        for (const button of elementsWithin(root, '.plus-button[data-url]')) {
            const context = resolveNormalVoteContext(button);
            if (!context) continue;
            button.dataset.hltvSpReactionKey = context.reactionKey;
            button.dataset.hltvSpAuthorId = context.userId;

            let host = context.plusContainer.previousElementSibling;
            let downvote = privateUiControl(host, 'button.hltv-sp-local-downvote');
            if (!host?.matches(
                `.hltv-sp-local-downvote[data-hltv-sp-reaction-key="${context.reactionKey}"]`,
            ) || !downvote) {
                if (host?.matches('.hltv-sp-local-downvote')) host.remove();
                const privateDownvote = createPrivateUiHost({
                    className: 'hltv-sp-private-ui-host hltv-sp-local-downvote hltv-sp-native-downvote',
                    styleText: PRIVATE_UI_STYLES.downvote,
                    metadata: {
                        reactionKey: context.reactionKey,
                        authorId: context.userId,
                        authorName: context.author,
                    },
                });
                host = privateDownvote.host;
                host.dataset.hltvSpReactionKey = context.reactionKey;
                host.dataset.hltvSpAuthorId = context.userId;
                downvote = document.createElement('button');
                downvote.type = 'button';
                downvote.className = 'hltv-sp-local-downvote hltv-sp-native-downvote';
                downvote.dataset.hltvSpReactionKey = context.reactionKey;
                downvote.dataset.hltvSpAuthorId = context.userId;
                downvote.dataset.hltvSpAuthorName = context.author;
                downvote.addEventListener('click', (event) => {
                    event.preventDefault();
                    event.stopPropagation();
                    const current = resolveNormalVoteContext(button);
                    if (!current) return;
                    showNormalActionError(current, '');
                    handleLocalDownvote(current, downvote)
                        .catch((error) => showNormalActionError(
                            current,
                            localDownvoteErrorMessage(error),
                        ));
                });
                privateDownvote.root.appendChild(downvote);
                context.plusContainer.before(host);
            }
            const metadata = privateUiMetadata.get(host);
            if (metadata) metadata.authorName = context.author;
            downvote.dataset.hltvSpAuthorName = context.author;
            const active = getLocalReactionValue(context.reactionKey) === -1;
            setLocalDownvoteButtonVisual(downvote, active);
            applyProvisionalVoteVisual(button, context.reactionKey);
        }
    }

    function syncOpenPreviewLocalScoreControls() {
        const panel = state.previewPanel;
        const preview = state.previewData;
        if (!panel || !preview || !panel.classList.contains('hltv-sp-open')) return;
        if (state.settings.enableLocalUserScores) scanLocalScoreTargets(panel);
        if (!state.settings.enableLocalDownvotes) return;
        const entries = new Map(
            [preview.thread, ...(preview.comments || [])]
                .filter((entry) => entry?.reactionKey)
                .map((entry) => [entry.reactionKey, entry]),
        );
        for (const card of panel.querySelectorAll(
            '.hltv-sp-preview-thread[data-hltv-sp-reaction-key],'
            + ' .hltv-sp-preview-comment[data-hltv-sp-reaction-key]',
        )) {
            const entry = entries.get(card.dataset.hltvSpReactionKey);
            const actions = card.querySelector(
                ':scope > .hltv-sp-preview-post-meta > .hltv-sp-preview-actions',
            );
            if (!entry || !actions || actions.querySelector('.hltv-sp-local-downvote')) continue;
            const downvote = createPreviewDownvoteButton(entry);
            if (downvote) actions.prepend(downvote);
        }
    }

    function applyLocalScoreSetting() {
        clearLocalScoreDecorations();
        if (hasPrivateStorage()) {
            if (state.settings.enableLocalUserScores) scanLocalScoreTargets(document);
            if (state.settings.enableLocalDownvotes) scanNormalVoteControls(document);
        }
        applyProvisionalVoteVisualEverywhere();
        if (state.previewData && state.previewPanel?.classList.contains('hltv-sp-open')) {
            syncOpenPreviewLocalScoreControls();
        }
    }

    function profileActionStateFromDocument(doc, expectedUserId = '') {
        const button = doc?.querySelector(
            '.block-user button[name="BlockButton"], '
            + '.block-user button[name="UnblockButton"]',
        );
        const actionName = button?.getAttribute('name') || '';
        if (actionName !== 'BlockButton' && actionName !== 'UnblockButton') return null;
        const canonical = doc.querySelector('link[rel="canonical"]')?.getAttribute('href');
        if (canonical && expectedUserId) {
            const canonicalUserId = parseProfileActionUrl(canonical)?.userId || '';
            if (canonicalUserId && canonicalUserId !== expectedUserId) return null;
        }
        return {
            actionName,
            blocked: actionName === 'UnblockButton',
        };
    }

    function parseProfileActionUrl(value) {
        const url = parseSameOriginUrl(value);
        const match = url?.pathname.match(
            /^\/profile\/(\d{1,20})(?:\/[^/]+)?\/?$/i,
        );
        if (!url || !match) return null;
        url.search = '';
        url.hash = '';
        return {
            url,
            userId: match[1],
        };
    }

    function clearPageBlockedUserIndicators(userId = '') {
        const expectedId = String(userId || '');
        for (const indicator of document.querySelectorAll(
            '.hltv-sp-blocked-user-indicator[data-hltv-sp-user-id]',
        )) {
            if (!expectedId || indicator.dataset.hltvSpUserId === expectedId) {
                indicator.remove();
            }
        }
        for (const link of document.querySelectorAll(
            'a.hltv-sp-page-blocked-user[data-hltv-sp-blocked-user-id]',
        )) {
            if (expectedId && link.dataset.hltvSpBlockedUserId !== expectedId) continue;
            blockedUserIndicatorByLink.delete(link);
            link.classList.remove('hltv-sp-page-blocked-user');
            delete link.dataset.hltvSpBlockedUserId;
        }
    }

    function scanPageBlockedUserIndicators(root = document) {
        if (!state.pageBlockedUserIds.size) return;
        for (const link of elementsWithin(root, 'a[href]')) {
            const profile = parseProfileActionUrl(link.getAttribute('href') || link.href);
            if (!profile || !state.pageBlockedUserIds.has(profile.userId)) continue;
            link.classList.add('hltv-sp-page-blocked-user');
            link.dataset.hltvSpBlockedUserId = profile.userId;
            const existing = blockedUserIndicatorByLink.get(link);
            if (existing?.isConnected && existing.dataset.hltvSpUserId === profile.userId) continue;
            const indicator = document.createElement('span');
            indicator.className = 'hltv-sp-blocked-user-indicator';
            indicator.dataset.hltvSpUserId = profile.userId;
            indicator.textContent = 'Blocked';
            indicator.title = 'Blocked for this page session';
            indicator.setAttribute('aria-label', `${cleanText(link.textContent) || 'User'} is blocked`);
            link.insertAdjacentElement('afterend', indicator);
            blockedUserIndicatorByLink.set(link, indicator);
        }
    }

    function updatePageBlockedUserState(userId, blocked) {
        const id = String(userId || '');
        if (!/^\d{1,20}$/.test(id)) return;
        if (blocked) {
            state.pageBlockedUserIds.add(id);
            scanPageBlockedUserIndicators(document);
            return;
        }
        state.pageBlockedUserIds.delete(id);
        clearPageBlockedUserIndicators(id);
    }

    function profileContextTarget(event) {
        const path = typeof event?.composedPath === 'function'
            ? event.composedPath()
            : [event?.target];
        for (const node of path) {
            if (!(node instanceof Element)) continue;
            const link = node.matches('a[href]')
                ? node
                : node.closest('a[href]');
            if (!link) continue;
            const profile = parseProfileActionUrl(link.getAttribute('href') || link.href);
            if (!profile) continue;
            return {
                link,
                url: profile.url,
                userId: profile.userId,
                username: cleanText(link.textContent).slice(0, 100)
                    || `User ${profile.userId}`,
            };
        }
        return null;
    }

    async function fetchProfileActionState(profileUrl, userId, signal) {
        const doc = await fetchSameOriginDocument(profileUrl.href, {
            contentLabel: 'profile block controls',
            expectedSelector: '.block-user',
            requireExpectedSelector: true,
            cache: 'no-store',
            signal,
        });
        const actionState = profileActionStateFromDocument(doc, userId);
        if (!actionState) {
            throw new Error('HLTV did not expose a block control for this profile.');
        }
        return actionState;
    }

    async function submitProfileAction(profileUrl, userId, actionName, signal) {
        if (actionName !== 'BlockButton' && actionName !== 'UnblockButton') {
            throw new Error('Invalid profile action.');
        }
        if (typeof safeFetch !== 'function') {
            throw new Error('This browser does not expose the required request API.');
        }
        throwIfAborted(signal);
        const requestScope = createRequestAbortScope(CONFIG.requestTimeoutMs, signal);
        try {
            const response = await safeFetch(profileUrl.href, {
                method: 'POST',
                credentials: 'include',
                cache: 'no-store',
                mode: 'same-origin',
                redirect: 'follow',
                referrer: profileUrl.href,
                signal: requestScope.signal,
                headers: {
                    Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `${actionName}=`,
            });
            const status = Number(response.status || 0);
            if (!(status >= 200 && status < 300)) {
                throw makeRequestError(`HTTP ${status}`, {
                    status,
                    retryable: isRetryableHttpStatus(status),
                });
            }
            const finalProfile = parseProfileActionUrl(response.url || profileUrl.href);
            if (!finalProfile || finalProfile.userId !== userId) {
                throw new Error('HLTV redirected the block action away from the selected profile.');
            }
            // As above, only header-less legacy Response shims may omit Content-Type.
            const html = await readBoundedUtf8Response(response, {
                label: 'Profile response',
                maxBytes: CONFIG.maxHtmlBytes,
                maxChars: CONFIG.maxHtmlChars,
                expectedContentTypes: ['text/html', 'application/xhtml+xml'],
                allowMissingContentType: true,
            });
            const doc = parseHtmlDocument(html, finalProfile.url.href, {
                contentLabel: 'profile block controls',
                expectedSelector: '.block-user',
                requireExpectedSelector: true,
            });
            const confirmed = profileActionStateFromDocument(doc, userId);
            const expectedActionName = actionName === 'BlockButton'
                ? 'UnblockButton'
                : 'BlockButton';
            if (!confirmed || confirmed.actionName !== expectedActionName) {
                throw new Error('HLTV did not confirm the requested block-state change.');
            }
            return confirmed;
        } catch (error) {
            if (signal?.aborted) throw makeAbortError();
            if (requestScope.didTimeOut()) {
                throw new Error(`The block request timed out after ${CONFIG.requestTimeoutMs} ms.`);
            }
            throw error;
        } finally {
            requestScope.cleanup();
        }
    }

    function closeUsernameBlockMenu() {
        state.blockMenuGeneration += 1;
        state.blockMenuAbortController?.abort();
        state.blockMenuAbortController = null;
        state.blockMenuHost?.remove();
        state.blockMenuHost = null;
    }

    function positionUsernameBlockMenu(host, clientX, clientY) {
        const margin = 8;
        const width = Math.max(180, Number(host.offsetWidth) || 180);
        const height = Math.max(72, Number(host.offsetHeight) || 72);
        const left = Math.max(
            margin,
            Math.min(Number(clientX) || margin, window.innerWidth - width - margin),
        );
        const top = Math.max(
            margin,
            Math.min(Number(clientY) || margin, window.innerHeight - height - margin),
        );
        host.style.left = `${left}px`;
        host.style.top = `${top}px`;
    }

    async function openUsernameBlockMenu(target, clientX, clientY) {
        closeUsernameBlockMenu();
        if (!state.settings.enableUsernameBlocking || !document.body) return;

        const generation = ++state.blockMenuGeneration;
        const controller = new AbortController();
        state.blockMenuAbortController = controller;
        const { host, root } = createPrivateUiHost({
            tagName: 'div',
            className: 'hltv-sp-private-ui-host hltv-sp-block-menu-host',
            styleText: PRIVATE_UI_STYLES.blockMenu,
        });
        host.dataset.hltvSpBlockUserId = target.userId;

        const menu = document.createElement('div');
        menu.className = 'hltv-sp-block-menu';
        menu.setAttribute('role', 'menu');

        const title = document.createElement('div');
        title.className = 'hltv-sp-block-menu-title';
        title.textContent = target.username;
        title.title = target.username;

        const profileLink = document.createElement('a');
        profileLink.href = target.url.href;
        profileLink.target = '_blank';
        profileLink.rel = 'noopener noreferrer';
        profileLink.textContent = 'Open profile in new tab';
        profileLink.setAttribute('role', 'menuitem');

        const actionButton = document.createElement('button');
        actionButton.type = 'button';
        actionButton.disabled = true;
        actionButton.textContent = 'Checking block status...';
        actionButton.setAttribute('role', 'menuitem');

        const status = document.createElement('div');
        status.className = 'hltv-sp-block-menu-status';
        status.setAttribute('aria-live', 'polite');

        menu.append(title, profileLink, actionButton, status);
        root.appendChild(menu);
        document.body.appendChild(host);
        state.blockMenuHost = host;
        positionUsernameBlockMenu(host, clientX, clientY);

        try {
            let actionState = await fetchProfileActionState(
                target.url,
                target.userId,
                controller.signal,
            );
            if (controller.signal.aborted
                || generation !== state.blockMenuGeneration
                || state.blockMenuHost !== host) return;

            const renderActionState = () => {
                actionButton.textContent = actionState.blocked ? 'Unblock user' : 'Block user';
                actionButton.disabled = false;
                status.textContent = '';
                status.classList.remove('hltv-sp-error');
                positionUsernameBlockMenu(host, clientX, clientY);
            };
            renderActionState();

            actionButton.addEventListener('click', async () => {
                if (actionButton.disabled || controller.signal.aborted) return;
                actionButton.disabled = true;
                status.textContent = actionState.blocked
                    ? 'Unblocking user...'
                    : 'Blocking user...';
                status.classList.remove('hltv-sp-error');
                try {
                    actionState = await withCrossTabActionLock(
                        'block',
                        target.userId,
                        () => submitProfileAction(
                            target.url,
                            target.userId,
                            actionState.actionName,
                            controller.signal,
                        ),
                    );
                    if (controller.signal.aborted
                        || generation !== state.blockMenuGeneration
                        || state.blockMenuHost !== host) return;
                    status.textContent = actionState.blocked
                        ? 'User blocked.'
                        : 'User unblocked.';
                    updatePageBlockedUserState(target.userId, actionState.blocked);
                    actionButton.textContent = actionState.blocked
                        ? 'Unblock user'
                        : 'Block user';
                    actionButton.disabled = false;
                } catch (error) {
                    if (isAbortErrorLike(error) || controller.signal.aborted) return;
                    status.textContent = error?.userMessage
                        || 'The block action failed. Please try again.';
                    status.classList.add('hltv-sp-error');
                    actionButton.disabled = false;
                }
                positionUsernameBlockMenu(host, clientX, clientY);
            });
        } catch (error) {
            if (isAbortErrorLike(error) || controller.signal.aborted) return;
            actionButton.textContent = 'Block user unavailable';
            actionButton.disabled = true;
            status.textContent = 'Could not load HLTV block status. Make sure you are signed in.';
            status.classList.add('hltv-sp-error');
            positionUsernameBlockMenu(host, clientX, clientY);
        }
    }

    function applyUsernameBlockingSetting() {
        if (!state.settings.enableUsernameBlocking) {
            closeUsernameBlockMenu();
            if (state.blockContextMenuHandler) {
                document.removeEventListener(
                    'contextmenu',
                    state.blockContextMenuHandler,
                    true,
                );
                state.blockContextMenuHandler = null;
            }
            if (state.blockDismissHandler) {
                document.removeEventListener('pointerdown', state.blockDismissHandler, true);
                document.removeEventListener('keydown', state.blockDismissHandler, true);
                document.removeEventListener('scroll', state.blockDismissHandler, true);
                window.removeEventListener('resize', state.blockDismissHandler);
                window.removeEventListener('blur', state.blockDismissHandler);
                state.blockDismissHandler = null;
            }
            return;
        }

        if (!state.blockContextMenuHandler) {
            state.blockContextMenuHandler = (event) => {
                const target = profileContextTarget(event);
                if (!target) return;
                event.preventDefault();
                event.stopPropagation();
                openUsernameBlockMenu(target, event.clientX, event.clientY)
                    .catch((error) => warn('Could not open the username block menu.', error));
            };
            document.addEventListener('contextmenu', state.blockContextMenuHandler, true);
        }
        if (!state.blockDismissHandler) {
            state.blockDismissHandler = (event) => {
                if (!state.blockMenuHost) return;
                if (event.type === 'pointerdown'
                    && event.composedPath?.().includes(state.blockMenuHost)) return;
                if (event.type === 'keydown' && event.key !== 'Escape') return;
                closeUsernameBlockMenu();
            };
            document.addEventListener('pointerdown', state.blockDismissHandler, true);
            document.addEventListener('keydown', state.blockDismissHandler, true);
            document.addEventListener('scroll', state.blockDismissHandler, true);
            window.addEventListener('resize', state.blockDismissHandler, { passive: true });
            window.addEventListener('blur', state.blockDismissHandler);
        }
    }

    function isCanonicalThreadAuthorLink(link) {
        const topbar = link.closest('.forum-topbar');
        if (!topbar) return false;
        const container = topbar.closest('.forumthread > .standard-box, .forum[data-forum-thread-id] .post');
        if (!container) return false;
        return findAuthorLinkInPost(container) === link;
    }

    function compactUserTag(tag) {
        if (tag.length <= CONFIG.maxVisibleUserTagChars) return tag;
        return `${tag.slice(0, CONFIG.maxVisibleUserTagChars - 1).trimEnd()}\u2026`;
    }

    function createUserTagControl(user) {
        if (!state.settings.enableUserTags || !hasPrivateStorage()) return null;
        const entry = state.userTags.get(user.id);
        const { host, root } = createPrivateUiHost({
            className: 'hltv-sp-private-ui-host hltv-sp-user-tag-control',
            styleText: PRIVATE_UI_STYLES.tag,
            metadata: { user: { id: user.id, name: user.name || '' } },
        });
        const control = document.createElement('span');
        control.className = entry ? 'hltv-sp-user-tag-value' : 'hltv-sp-tag-button-value';
        control.textContent = entry ? compactUserTag(entry.tag) : '\u270E';
        control.title = entry ? entry.tag : `Add local tag for ${user.name || `user ${user.id}`}`;
        control.setAttribute('role', 'button');
        control.setAttribute('tabindex', '0');
        control.setAttribute('aria-label', entry
            ? `Edit local tag for ${user.name || `user ${user.id}`}: ${entry.tag}`
            : `Add local tag for ${user.name || `user ${user.id}`}`);
        const edit = (event) => {
            event.preventDefault();
            event.stopPropagation();
            editUserTag(user).catch((error) => warn('Could not save local user tag.', error));
        };
        control.addEventListener('click', edit);
        control.addEventListener('keydown', (event) => {
            if (event.key === 'Enter' || event.key === ' ') edit(event);
        });
        root.appendChild(control);
        return host;
    }

    function createPreviewUserTagSlot(user) {
        const slot = document.createElement('span');
        slot.className = 'hltv-sp-preview-tag-slot';
        slot.dataset.hltvSpUserId = user.id || '';
        slot.dataset.hltvSpUserName = user.name || '';
        renderPreviewUserTagSlot(slot);
        return slot;
    }

    function renderPreviewUserTagSlot(slot) {
        if (!(slot instanceof Element)) return;
        slot.replaceChildren();
        if (!state.settings.enableUserTags) return;
        const user = {
            id: String(slot.dataset.hltvSpUserId || ''),
            name: cleanText(slot.dataset.hltvSpUserName).slice(0, 100),
        };
        if (!/^\d{1,20}$/.test(user.id)) return;
        const control = createUserTagControl(user);
        if (control) slot.appendChild(control);
    }

    function scanUserTagTargets(root = document) {
        if (!state.settings.enableUserTags || !hasPrivateStorage()) return;
        const anchors = elementsWithin(root, [
            '.forumthread > .standard-box > .forum-topbar > a[href*="/profile/"]',
            '.forum[data-forum-thread-id] .post > .standard-box > .forum-topbar > a[href*="/profile/"]',
        ].join(', '));
        for (const link of new Set(anchors)) {
            if (!isCanonicalThreadAuthorLink(link)) continue;
            const user = parseProfileIdentity(link);
            if (!user) continue;
            if (link.dataset.hltvSpTagTarget === user.id) continue;
            link.dataset.hltvSpTagTarget = user.id;
            const control = createUserTagControl(user);
            if (control) {
                const score = link.nextElementSibling?.matches(
                    `.hltv-sp-user-score[data-hltv-sp-score-user-id="${user.id}"]`,
                )
                    ? link.nextElementSibling
                    : null;
                if (score) score.after(control);
                else link.after(control);
            }
        }
    }

    function getHiddenUserTagSet() {
        const tags = state.settings.enableUserTags
            ? normaliseHiddenUserTags(state.settings.hiddenUserTags)
            : [];
        const signature = JSON.stringify(tags);
        if (signature !== state.hiddenUserTagSignature) {
            state.hiddenUserTagSignature = signature;
            state.hiddenUserTagSet = new Set(tags);
        }
        return state.hiddenUserTagSet;
    }

    function shouldHideUserComment(userId, hiddenTags = getHiddenUserTagSet()) {
        const tag = state.userTags.get(String(userId || ''))?.tag;
        return Boolean(tag && hiddenTags.has(tag));
    }

    function applyUserTagCommentVisibility(root = document) {
        const hiddenTags = getHiddenUserTagSet();
        const posts = elementsWithin(root, '.forum[data-forum-thread-id] .post');
        for (const post of posts) {
            const authorLink = findAuthorLinkInPost(post);
            const user = authorLink ? parseProfileIdentity(authorLink) : null;
            post.classList.toggle(
                'hltv-sp-tag-hidden-comment',
                Boolean(user && shouldHideUserComment(user.id, hiddenTags)),
            );
        }
    }

    function clearUserTagDecorations() {
        for (const element of document.querySelectorAll('.hltv-sp-user-tagged')) {
            element.classList.remove('hltv-sp-user-tagged');
        }
        for (const control of document.querySelectorAll(
            '.hltv-sp-user-tag-control, .hltv-sp-user-tag, .hltv-sp-tag-button',
        )) {
            control.remove();
        }
        for (const link of document.querySelectorAll('[data-hltv-sp-tag-target]')) {
            delete link.dataset.hltvSpTagTarget;
        }
    }

    function refreshPreviewUserTagUi() {
        const panel = state.previewPanel;
        if (!panel?.classList.contains('hltv-sp-open') || !state.previewData) return;
        for (const slot of panel.querySelectorAll('.hltv-sp-preview-tag-slot')) {
            renderPreviewUserTagSlot(slot);
        }
        const hiddenTags = getHiddenUserTagSet();
        let hiddenCount = 0;
        let visibleCount = 0;
        for (const card of panel.querySelectorAll('.hltv-sp-preview-comment[data-hltv-sp-author-id]')) {
            const hidden = shouldHideUserComment(card.dataset.hltvSpAuthorId, hiddenTags);
            card.hidden = hidden;
            if (hidden) hiddenCount += 1;
            else visibleCount += 1;
        }
        const label = panel.querySelector('.hltv-sp-preview-comments-label');
        if (label) {
            label.textContent = hiddenCount
                ? `Comments (${visibleCount} shown, ${hiddenCount} hidden)`
                : `Comments (${state.previewData.replyCount})`;
        }
        syncPreviewCommentNavigation(state.previewData, state.previewCommentTopology);
    }

    function refreshUserTagHighlights() {
        clearUserTagDecorations();
        scanUserTagTargets(document);
        applyUserTagCommentVisibility(document);
        state.readTrackingPostCount = -1;
        setupCurrentThreadReadTracking();
        refreshPreviewUserTagUi();
    }

    function applyUserTagSetting() {
        clearUserTagDecorations();
        if (state.settings.enableUserTags) scanUserTagTargets(document);
        applyUserTagCommentVisibility(document);
        state.readTrackingPostCount = -1;
        setupCurrentThreadReadTracking();
        refreshPreviewUserTagUi();
    }

    async function editUserTag(user) {
        if (!safePrompt || !hasPrivateStorage() || !state.settings.enableUserTags) return;
        const beforePrompt = normaliseUserTags(await privateStorageGet(STORAGE_KEYS.userTags, null));
        const existing = beforePrompt.get(user.id)?.tag || '';
        const response = safePrompt(
            `Local tag for ${user.name || `user ${user.id}`} (maximum ${CONFIG.maxUserTagChars} characters):`,
            existing,
        );
        if (response === null) return;
        const tag = normaliseUserTag(response);

        // Merge after the prompt so edits made in another tab are not overwritten.
        const latest = normaliseUserTags(await privateStorageGet(STORAGE_KEYS.userTags, null));
        if (!tag) {
            latest.delete(user.id);
        } else {
            if (!latest.has(user.id) && latest.size >= CONFIG.maxUserTags) {
                warn(`Local user tags are limited to ${CONFIG.maxUserTags} entries.`);
                return;
            }
            latest.set(user.id, {
                name: user.name,
                tag,
                updatedAt: Date.now(),
            });
        }
        state.userTags = latest;
        await saveUserTags();
        refreshUserTagHighlights();
    }

    function getForumReplyRecords() {
        const opener = document.querySelector('.forumthread > .standard-box');
        let posts = [...document.querySelectorAll('.forum[data-forum-thread-id] .post')];
        if (!opener && posts.length === 0) posts = [...document.querySelectorAll('.post')].slice(1);
        return posts.map((post, index) => {
            const replyText = cleanText(post.querySelector('.replyNum')?.textContent);
            const match = replyText.match(/^#(\d+)$/);
            return { post, number: match ? Number(match[1]) : index + 1 };
        }).filter((record) => Number.isFinite(record.number) && record.number > 0);
    }

    function findFirstUnreadPost(replyRecords, record, currentUserId = '') {
        if (!record || !replyRecords.length) return null;
        const threshold = readEntryThreshold(record);
        const knownSelfPosts = new Set(record.selfPostNumbers || []);
        return replyRecords
            .filter((reply) => (
                reply.number > threshold
                && !reply.post.classList.contains('hltv-sp-tag-hidden-comment')
                && !knownSelfPosts.has(reply.number)
                && (!currentUserId || postAuthorUserId(reply.post) !== currentUserId)
            ))
            .sort((a, b) => a.number - b.number)[0]?.post || null;
    }

    function queueThreadReadSave(threadId) {
        if (!state.settings.enableReadStatus) return;
        window.clearTimeout(state.readSaveTimer);
        if (state.readVisibilityHandler) {
            document.removeEventListener('visibilitychange', state.readVisibilityHandler);
            state.readVisibilityHandler = null;
        }

        const saveVisibleSnapshot = () => {
            if (!state.settings.enableReadStatus) return;
            if (document.hidden) {
                state.readVisibilityHandler = () => {
                    if (document.hidden) return;
                    document.removeEventListener('visibilitychange', state.readVisibilityHandler);
                    state.readVisibilityHandler = null;
                    state.readSaveTimer = window.setTimeout(saveVisibleSnapshot, 2000);
                };
                document.addEventListener('visibilitychange', state.readVisibilityHandler);
                return;
            }

            const replies = getForumReplyRecords();
            const previous = state.readEntries.get(threadId) || {
                seenReplyCount: 0,
                maxPostNo: 0,
                selfPostNumbers: [],
                visitedAt: 0,
            };
            const visibleMaxPostNo = replies.reduce((maximum, reply) => Math.max(maximum, reply.number), 0);
            const seenReplyCount = Math.max(
                previous.seenReplyCount,
                replies.length,
                visibleMaxPostNo,
            );
            const maxPostNo = Math.max(previous.maxPostNo, visibleMaxPostNo);
            state.readEntries.set(threadId, {
                seenReplyCount,
                maxPostNo,
                selfPostNumbers: normaliseSelfPostNumbers(
                    previous.selfPostNumbers,
                    Math.max(seenReplyCount, maxPostNo),
                ),
                visitedAt: Date.now(),
            });
            saveReadState()
                .then(() => {
                    annotateActivityLinks();
                })
                .catch((error) => warn('Could not save thread read state.', error));
        };

        state.readSaveTimer = window.setTimeout(saveVisibleSnapshot, 2000);
    }

    function setupCurrentThreadReadTracking() {
        if (!state.settings.enableReadStatus) return;
        const url = parseSameOriginUrl(location.href);
        if (!url || !/^\/forums\/threads\/\d+(?:\/|$)/i.test(url.pathname)) return;
        const threadId = threadIdFromHref(url.href);
        const opener = document.querySelector('.forumthread > .standard-box');
        let replyCount = document.querySelectorAll(
            '.forum[data-forum-thread-id] .post',
        ).length;
        if (!opener && replyCount === 0) {
            replyCount = Math.max(0, document.querySelectorAll('.post').length - 1);
        }
        if (!opener && replyCount === 0) return;
        if (state.readTrackingKey === threadId
            && state.readTrackingPostCount === replyCount) return;
        const replies = getForumReplyRecords();
        state.readTrackingKey = threadId;
        state.readTrackingPostCount = replyCount;

        for (const reply of replies) reply.post.classList.remove('hltv-sp-first-unread');
        document.querySelector(
            '.hltv-sp-first-unread-jump[data-hltv-sp-context="page"]',
        )?.remove();
        const currentUserId = extractCurrentUserId();
        let previous = state.readEntries.get(threadId);
        if (previous && currentUserId) {
            const selfPostNumbers = replies
                .filter((reply) => postAuthorUserId(reply.post) === currentUserId)
                .map((reply) => reply.number);
            saveKnownSelfPosts(threadId, selfPostNumbers);
            previous = state.readEntries.get(threadId);
        }
        const firstUnread = findFirstUnreadPost(replies, previous, currentUserId);
        if (firstUnread) {
            firstUnread.classList.add('hltv-sp-first-unread');
            const jump = document.createElement('button');
            jump.type = 'button';
            jump.className = 'hltv-sp-first-unread-jump';
            jump.dataset.hltvSpContext = 'page';
            jump.textContent = 'Jump to first unread post';
            jump.addEventListener('click', () => firstUnread.scrollIntoView({ block: 'start', behavior: 'smooth' }));
            const insertionTarget = opener || replies[0]?.post;
            insertionTarget?.parentElement?.insertBefore(jump, insertionTarget);
        }
        queueThreadReadSave(threadId);
    }

    function annotateActivityColorsInRoot(root = document) {
        for (const link of elementsWithin(root, '.activitylist a[href]')) {
            if (!isActivityEntry(link)) continue;
            const metadata = state.threadMetadataByKey.get(linkKey(link.href));
            const kind = getActivityKind(link.href);
            applyActivityColor(link, kind, metadata);
            applyForumVisibilityToLink(link);
            if (kind === 'forum') ensurePreviewHover(link);
        }
        if (!state.settings.enableCustomThreadColors) removeCustomActivityColors(root);
    }

    function scanContentEnhancementRoot(root = document) {
        annotateActivityColorsInRoot(root);
        scanNotificationPreviewTargets(root);
        scanDraftComposerSurfaces(root);
        formatQuoteLines(root);
        scanOriginalPosterAuthors(root);
        scanUserTagTargets(root);
        scanPageBlockedUserIndicators(root);
        scanLocalScoreTargets(root);
        scanNormalVoteControls(root);
        applyUserTagCommentVisibility(root);
        if (state.settings.showRelativeAges) updatePostRelativeAges(root);
    }

    function scanContentEnhancements(root = document) {
        scanContentEnhancementRoot(root);
        if (state.sidebar && state.settings.enableCustomThreadFetching) {
            harvestSportModeActivityEntries();
        }
        applyReplyComposerPlacement();
        applyPostNewTopicPlacement();
        applyExtendedMatchFilterSetting();
        setupCurrentThreadReadTracking();
        syncRelativeAgeTimer();
    }

    const NATIVE_ENHANCEMENT_DECORATION_CLASSES = new Set([
        'hltv-sp-action-fenced',
        'hltv-sp-colored-entry',
        'hltv-sp-extra-team-match',
        'hltv-sp-first-unread',
        'hltv-sp-fixed',
        'hltv-sp-forum-hidden',
        'hltv-sp-forum-unknown',
        'hltv-sp-header-cog-reserved',
        'hltv-sp-local-upvote-available',
        'hltv-sp-original-poster-author',
        'hltv-sp-post-new-topic-top',
        'hltv-sp-page-blocked-user',
        'hltv-sp-preview-active',
        'hltv-sp-provisional-upvote',
        'hltv-sp-relocated-reply-composer',
        'hltv-sp-selected',
        'hltv-sp-sidebar-list',
        'hltv-sp-source-hidden',
        'hltv-sp-sport-pool',
        'hltv-sp-tag-hidden-comment',
        'hltv-sp-team-filter-hidden',
        'hltv-sp-type-match',
        'hltv-sp-type-news',
        'hltv-sp-unread',
        'hltv-sp-untracked',
        'hltv-sp-user-tagged',
    ]);

    function isNativeEnhancementDecorationClass(className) {
        return NATIVE_ENHANCEMENT_DECORATION_CLASSES.has(className)
            || FORUMS.some((forum) => className === forumClassName(forum));
    }

    function isExtensionOwnedContentElement(element) {
        if (!(element instanceof Element)) return false;
        for (
            let current = element;
            current && current !== document.body && current !== document.documentElement;
            current = current.parentElement
        ) {
            const extensionClassNames = [...current.classList].filter(
                (className) => className.startsWith('hltv-sp-')
                    || className.startsWith('hltv-v2-'),
            );
            if (String(current.id || '').startsWith('hltv-sp-')
                || String(current.id || '').startsWith('hltv-v2-')
                || extensionClassNames.some((className) => (
                    className.startsWith('hltv-v2-')
                    || !isNativeEnhancementDecorationClass(className)
                ))
                || current.hasAttribute('data-hltv-v2-managed-column')
                || current.hasAttribute('data-hltv-v2-column-id')
                || current.hasAttribute('data-hltv-v2-original-index')
                || current.classList.contains('tmKprRangeCol')
                || current.hasAttribute('data-hltv-win-adjusted-col')) {
                return true;
            }
        }
        return false;
    }

    function elementTouchesSelector(element, selector) {
        if (!(element instanceof Element)) return false;
        return element.matches(selector) || Boolean(element.querySelector(selector));
    }

    function addPendingContentRoot(root) {
        if (!(root instanceof Element)) return;
        let covered = false;
        for (const pendingRoot of state.pendingContentRoots) {
            if (pendingRoot.contains(root)) {
                covered = true;
                break;
            }
            if (root.contains(pendingRoot)) state.pendingContentRoots.delete(pendingRoot);
        }
        if (!covered) state.pendingContentRoots.add(root);
    }

    function queueContentGlobalTasksForElement(element) {
        if (!(element instanceof Element)) return;
        if (state.sidebar && elementTouchesSelector(
            element,
            '.activitylist a.promode-only[href]',
        )) {
            state.pendingContentGlobalTasks.add('sport-activity');
        }
        if (state.settings.replyComposerAfterOriginalPost && elementTouchesSelector(
            element,
            '.newreply-con, .forumthread, .forum[data-forum-thread-id]',
        )) {
            state.pendingContentGlobalTasks.add('reply-composer');
        }
        if (state.settings.movePostNewTopicToTop && elementTouchesSelector(
            element,
            'a.button.colbutton.no-promode[href="/forums/create-thread"], '
            + 'a.button.colbutton.no-promode[href^="https://www.hltv.org/forums/create-thread"], '
            + '.recent-activity, .right2Col > .col-box-con',
        )) {
            state.pendingContentGlobalTasks.add('post-new-topic');
        }
        if ((state.settings.enableExtendedMatchFilter
            || state.settings.strictSelectedTeamMatches) && elementTouchesSelector(
            element,
            '.match-filter-configuration, h1.todaysMatches, '
            + 'a.hotmatch-box[href], .col-box-con.result-box, '
            + '.hotmatch-star-selected, .hotmatch-star-unselected, '
            + '.toploginbar-match-filter-enabled, '
            + '.toploginbar-match-filter-disabled',
        )) {
            state.pendingContentGlobalTasks.add('match-filter');
        }
        const fallbackPostChanged = /^\/forums\/threads\/\d+(?:\/|$)/i.test(
            location.pathname,
        )
            && !document.querySelector('.forum[data-forum-thread-id]')
            && elementTouchesSelector(element, '.post');
        if (state.settings.enableReadStatus && (
            elementTouchesSelector(
                element,
                '.forumthread > .standard-box, .forum[data-forum-thread-id] .post',
            )
            || fallbackPostChanged
        )) {
            state.pendingContentGlobalTasks.add('read-tracking');
        }
        if (state.settings.showRelativeAges && elementTouchesSelector(
            element,
            '.forumthread .forum-bottombar .time, '
            + '.forum[data-forum-thread-id] .post .forum-bottombar .time',
        )) {
            state.pendingContentGlobalTasks.add('relative-ages');
        }
    }

    function runPendingContentGlobalTasks(tasks) {
        if (tasks.has('sport-activity') && state.settings.enableCustomThreadFetching) {
            harvestSportModeActivityEntries();
        }
        if (tasks.has('reply-composer')) applyReplyComposerPlacement();
        if (tasks.has('post-new-topic')) applyPostNewTopicPlacement();
        if (tasks.has('match-filter')) applyExtendedMatchFilterSetting();
        if (tasks.has('read-tracking')) setupCurrentThreadReadTracking();
        if (tasks.has('relative-ages')) {
            syncRelativeAgeTimer({ updateNow: true });
        }
    }

    function observeContentEnhancements() {
        scanContentEnhancements(document);
        if (state.contentObserver || !document.body) return;
        state.contentObserver = new MutationObserver((mutations) => {
            for (const mutation of mutations) {
                for (const node of [...mutation.addedNodes, ...mutation.removedNodes]) {
                    if (!(node instanceof Element)) continue;
                    if (isExtensionOwnedContentElement(node)) continue;
                    if (node.isConnected) addPendingContentRoot(node);
                    queueContentGlobalTasksForElement(node);
                }
            }
            if ((!state.pendingContentRoots.size && !state.pendingContentGlobalTasks.size)
                || state.contentObserverTimer) return;
            state.contentObserverTimer = window.setTimeout(() => {
                state.contentObserverTimer = null;
                const roots = [...state.pendingContentRoots];
                const tasks = new Set(state.pendingContentGlobalTasks);
                state.pendingContentRoots.clear();
                state.pendingContentGlobalTasks.clear();
                for (const root of roots) {
                    if (root.isConnected) scanContentEnhancementRoot(root);
                }
                runPendingContentGlobalTasks(tasks);
            }, 100);
        });
        state.contentObserver.observe(document.body, { childList: true, subtree: true });
    }

    async function emitSyncPulse(kinds) {
        const allowed = new Set(['settings', 'readState', 'notes', 'reactions', 'matchTeams']);
        const changed = [...new Set(kinds)].filter((kind) => allowed.has(kind));
        if (!changed.length || !hasPrivateStorage()) return;
        if (state.syncApplyDepth > 0) {
            for (const kind of changed) state.deferredSyncPulseKinds.add(kind);
            return;
        }
        try {
            await privateStorageSet(STORAGE_KEYS.syncPulse, {
                schema: 1,
                senderId: state.syncSenderId,
                nonce: createRandomId('sync'),
                changed,
                at: Date.now(),
            });
        } catch (error) {
            log('Could not emit cross-tab sync notification.', error);
        }
    }

    async function addStorageChangeListener(key, callback) {
        try {
            if (typeof GM !== 'undefined' && typeof GM.addValueChangeListener === 'function') {
                return await GM.addValueChangeListener(key, callback);
            }
            if (typeof GM_addValueChangeListener === 'function') {
                return GM_addValueChangeListener(key, callback);
            }
        } catch (error) {
            log('Could not enable cross-tab storage synchronization.', error);
        }
        return null;
    }

    function queueRemoteSync(kinds) {
        if (!featureRuntimeEnabled) {
            if (kinds.includes('settings')) {
                applyRemoteSync(new Set(['settings']))
                    .catch((error) => warn('Settings synchronization failed.', error));
            }
            return;
        }
        for (const kind of kinds) state.pendingRemoteSyncKinds.add(kind);
        if (state.remoteSyncTimer) return;
        state.remoteSyncTimer = window.setTimeout(() => {
            state.remoteSyncTimer = null;
            const pending = new Set(state.pendingRemoteSyncKinds);
            state.pendingRemoteSyncKinds.clear();
            applyRemoteSync(pending).catch((error) => warn('Cross-tab synchronization failed.', error));
        }, 80);
    }

    async function setupCrossTabSync() {
        if (!hasPrivateStorage() || state.syncListenerId !== null) return;
        state.syncListenerId = await addStorageChangeListener(
            STORAGE_KEYS.syncPulse,
            (_name, _oldValue, newValue) => {
                if (!newValue || newValue.schema !== 1 || newValue.senderId === state.syncSenderId) return;
                const at = Number(newValue.at);
                if (!Number.isFinite(at) || Math.abs(Date.now() - at) > 300000) return;
                const allowed = new Set(['settings', 'readState', 'notes', 'reactions', 'matchTeams']);
                const kinds = Array.isArray(newValue.changed)
                    ? newValue.changed.filter((kind) => allowed.has(kind))
                    : [];
                if (kinds.length) queueRemoteSync(kinds);
            },
        );
    }

    function settingsNeedForumRefresh(previous, next) {
        if (previous.enableCustomThreadFetching !== next.enableCustomThreadFetching) return true;
        if (previous.selectedForums.length !== next.selectedForums.length
            || previous.selectedForums.some((id, index) => id !== next.selectedForums[index])) return true;
        return ACTIVITY_SOURCES.some((source) => (
            previous.forumThreadLimits[source.id] !== next.forumThreadLimits[source.id]
        ));
    }

    function refreshSettingsAfterRemoteSync() {
        if (state.modalSettingsDirty
            && state.modalBackdrop?.classList.contains('hltv-sp-open')
            && !state.modalSettingsSaving) {
            state.modalSettingsExternalChange = true;
            setModalStatus('Settings changed elsewhere. Cancel and reopen this form before saving.');
        } else if (!state.modalSettingsSaving) {
            refreshSettingsModal();
        }
    }

    async function applyRemoteSync(kinds) {
        if (!featureRuntimeEnabled) {
            if (kinds.has('settings')) {
                state.settings = await loadSettings();
                refreshSettingsAfterRemoteSync();
            }
            return;
        }
        let emitReactionRepairPulse = false;
        state.syncApplyDepth += 1;
        try {
            if (kinds.has('settings')) {
                const previous = state.settings;
                state.settings = await loadSettings();
                applyBooleanEnhancements();
                updateSortButton();
                applySortOrder();
                refreshSettingsAfterRemoteSync();
                syncOptionalModules();
                if (state.sidebar && settingsNeedForumRefresh(previous, state.settings)) {
                    refreshFetchedForumThreadsInBackground();
                }
            }
            if (kinds.has('readState')) {
                const remoteReadState = normaliseReadState(
                    await privateStorageGet(STORAGE_KEYS.readState, null),
                );
                state.readEntries = mergeReadStateMaps(state.readEntries, remoteReadState);
                annotateActivityLinks();
            }
            if (kinds.has('notes')) {
                state.userTags = normaliseUserTags(
                    await privateStorageGet(STORAGE_KEYS.userTags, null),
                );
                refreshUserTagHighlights();
            }
            if (kinds.has('matchTeams')) {
                state.extendedMatchTeams = normaliseExtendedMatchTeams(
                    await storageGet(STORAGE_KEYS.extendedMatchTeams, null),
                );
                applyExtendedMatchFilterSetting();
            }
            if (kinds.has('reactions')) {
                state.reactionSavePromise = state.reactionSavePromise
                    .catch(() => undefined)
                    .then(() => withLocalReactionStorageLock(async () => {
                        const [remoteValue, remoteProvisionalValue] = await Promise.all([
                            privateStorageGetStrict(STORAGE_KEYS.localReactions),
                            privateStorageGetStrict(STORAGE_KEYS.provisionalLocalUpvotes),
                        ]);
                        const merged = mergeLocalReactionRecord(
                            remoteValue,
                            state.localReactions,
                            state.localReactionResetAt,
                        );
                        const remoteReactions = normaliseLocalReactions(
                            remoteValue,
                            merged.resetAt,
                        );
                        if (remoteValue?.schema !== 2
                            || localReactionResetAtFromRecord(remoteValue) !== merged.resetAt
                            || !localReactionMapsEqual(remoteReactions, merged.reactions)) {
                            await privateStorageSet(
                                STORAGE_KEYS.localReactions,
                                serialiseLocalReactions(merged.reactions, merged.resetAt),
                            );
                            emitReactionRepairPulse = true;
                        }
                        state.localReactionResetAt = merged.resetAt;
                        state.localReactions = merged.reactions;
                        state.provisionalLocalUpvotes = normaliseProvisionalLocalUpvotes(
                            remoteProvisionalValue,
                            merged.reactions,
                        );
                    }));
                await state.reactionSavePromise;
                rebuildLocalUserScores();
                if (state.settings.enableLocalUserScores
                    || state.settings.enableLocalDownvotes
                    || state.settings.enableSignedOutLocalVoting) {
                    if (state.settings.enableLocalUserScores) scanLocalScoreTargets(document);
                    if (state.settings.enableLocalDownvotes) scanNormalVoteControls(document);
                    refreshLocalReactionUi();
                }
            }
        } finally {
            state.syncApplyDepth = Math.max(0, state.syncApplyDepth - 1);
            if (emitReactionRepairPulse) state.deferredSyncPulseKinds.add('reactions');
            if (state.syncApplyDepth === 0 && state.deferredSyncPulseKinds.size) {
                const deferredKinds = [...state.deferredSyncPulseKinds];
                state.deferredSyncPulseKinds.clear();
                await emitSyncPulse(deferredKinds);
            }
        }
    }

    // Integrated from: HLTV: Win-adjusted player ratings
    // Original GreasyFork page: https://greasyfork.org/en/scripts/576401-hltv-win-adjusted-player-ratings
    // Original license: GPL-3.0-or-later
    const WinAdjustedRatings = (() => {
        const TABLE_SELECTOR = 'table.stats-table.player-ratings-table';

        const CONTROL_ROW_ID = 'hltv-win-adjusted-ratings-controls';
        const BUTTON_ID = 'hltv-win-adjusted-ratings-button';
        const CLEAR_CACHE_BUTTON_ID = 'hltv-win-adjusted-ratings-clear-cache-button';
        const AUTO_ID = 'hltv-win-adjusted-ratings-auto';
        const STATUS_ID = 'hltv-win-adjusted-ratings-status';
        const CACHE_AGE_ID = 'hltv-win-adjusted-ratings-cache-age';
        const STYLE_ID = 'hltv-win-adjusted-ratings-style';

        const BUTTON_TEXT = 'Fetch win-adjusted ratings';
        const STOP_BUTTON_TEXT = 'Stop fetching';
        const CLEAR_CACHE_TEXT = 'Clear cache';

        const CACHE_STORAGE_PREFIX = `${CONFIG.storagePrefix}warCacheV1.`;
        const CACHE_RETENTION_MS = 30 * 24 * 60 * 60 * 1000;
        const CACHE_FUTURE_SKEW_MS = 5 * 60 * 1000;
        const MAX_CACHE_ENTRIES = 1500;

        const ADJUSTED_COL_MARKER = 'data-hltv-win-adjusted-col';

        // WAR team pages are fetched one at a time. The first attempt for each
        // new team starts after the same fixed 500 ms gap used elsewhere.
        // A failed retryable team request gets another attempt after 3 seconds,
        // then one final attempt after another 5 seconds.
        const WAR_BASE_REQUEST_GAP_MS = CONFIG.fetchDelayMs;
        const WAR_RETRY_DELAYS_MS = Object.freeze([3000, 5000]);
        const WAR_MAX_FETCH_ATTEMPTS = WAR_RETRY_DELAYS_MS.length + 1;
        const WAR_RENDER_BATCH_SIZE = 3;

        let cachePrunePromise = null;
        let activeFetchAbortController = null;
        let setupObserver = null;
        let controlsGeneration = 0;
        let controlsHost = null;
        let controlsRefs = null;
        let trustedControlStyleText = '';

        function isAllowedPage() {
            return location.origin === HLTV_ORIGIN && location.pathname === '/stats/players';
        }


        function onReady(fn) {
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', fn, { once: true });
            } else {
                fn();
            }
        }

        function makeAbortError() {
            try {
                return new DOMException('Aborted', 'AbortError');
            } catch (_error) {
                const error = new Error('Aborted');
                error.name = 'AbortError';
                return error;
            }
        }

        function isAbortError(error) {
            return Boolean(error && (error.name === 'AbortError' || error.message === 'Aborted'));
        }

        function sleep(ms, signal) {
            return new Promise((resolve, reject) => {
                if (signal && signal.aborted) {
                    reject(makeAbortError());
                    return;
                }

                const timeoutId = window.setTimeout(() => {
                    if (signal) {
                        signal.removeEventListener('abort', onAbort);
                    }
                    resolve();
                }, ms);

                function onAbort() {
                    window.clearTimeout(timeoutId);
                    reject(makeAbortError());
                }

                if (signal) {
                    signal.addEventListener('abort', onAbort, {
                        once: true
                    });
                }
            });
        }

        function getPageCacheKey() {
            const url = new URL(location.href);
            url.hash = '';
            const removableKeys = [];
            url.searchParams.forEach((_value, key) => {
                if (/^(?:utm_.+|fbclid|gclid|dclid|ref)$/i.test(key)) {
                    removableKeys.push(key);
                }
            });
            for (const key of removableKeys) {
                url.searchParams.delete(key);
            }
            url.searchParams.sort();
            return url.href;
        }

        function makeCacheKey(pageKey, teamKey) {
            return JSON.stringify([pageKey, teamKey]);
        }

        function cachePageStoragePrefix(pageKey) {
            return `${CACHE_STORAGE_PREFIX}${encodeURIComponent(pageKey)}.`;
        }

        function cacheEntryStorageKey(pageKey, teamKey) {
            return `${cachePageStoragePrefix(pageKey)}${encodeURIComponent(teamKey)}`;
        }

        function injectStyles() {
            const style = document.createElement('style');
            style.id = STYLE_ID;
            style.textContent = `
              #${CONTROL_ROW_ID}-surface {
                display: flex;
                align-items: center;
                flex-wrap: wrap;
                column-gap: 10px;
                row-gap: 4px;
                margin: 6px 0 10px 0;
                padding: 7px 8px;
                box-sizing: border-box;
                isolation: isolate;
                pointer-events: auto;
                position: relative;
                z-index: 1;
              }

              #${BUTTON_ID},
              #${CLEAR_CACHE_BUTTON_ID} {
                cursor: pointer;
                padding: 4px 8px;
                border: 1px solid rgba(128, 128, 128, 0.55);
                border-radius: 2px;
                background: rgba(128, 128, 128, 0.12);
                color: inherit;
                font: inherit;
                line-height: 1.2;
                pointer-events: auto;
                position: relative;
                z-index: 2;
              }

              #${BUTTON_ID}:disabled,
              #${CLEAR_CACHE_BUTTON_ID}:disabled,
              #${BUTTON_ID}.hltv-wa-busy,
              #${CLEAR_CACHE_BUTTON_ID}.hltv-wa-busy {
                cursor: default;
                opacity: 0.65;
              }

              #${BUTTON_ID}.hltv-wa-busy:not(:disabled) {
                cursor: pointer;
                opacity: 1;
              }

              .hltv-wa-auto-label {
                display: inline-flex;
                align-items: center;
                gap: 4px;
                cursor: pointer;
                user-select: none;
                white-space: nowrap;
              }

              .hltv-wa-auto-label input {
                margin: 0;
              }

              #${CACHE_AGE_ID} {
                display: inline-block;
                font-size: 11px;
                opacity: 0.8;
                vertical-align: middle;
                white-space: nowrap;
              }

              #${STATUS_ID} {
                display: block;
                flex: 0 0 100%;
                width: 100%;
                margin-top: 2px;
                font-size: 11px;
                opacity: 0.8;
                vertical-align: middle;
              }

              .hltv-win-adjusted-rating-header {
                cursor: pointer;
                text-align: center !important;
                vertical-align: middle !important;
                white-space: nowrap;
              }
            `;
            trustedControlStyleText = style.textContent;
            if (document.getElementById(STYLE_ID)) return;
            document.head.appendChild(style);
        }

        function normalizeText(value) {
            return String(value || '').replace(/\s+/g, ' ').trim();
        }

        function parseNumber(value) {
            const cleaned = String(value || '')
                .replace(/,/g, '')
                .replace(/[^\d.+-]/g, '');

            const parsed = Number.parseFloat(cleaned);
            return Number.isFinite(parsed) ? parsed : NaN;
        }

        function average(values) {
            if (!values.length) return NaN;
            return values.reduce((sum, value) => sum + value, 0) / values.length;
        }

        function slope(yValues, xValues) {
            if (yValues.length !== xValues.length || yValues.length < 2) return NaN;

            const xMean = average(xValues);
            const yMean = average(yValues);

            let numerator = 0;
            let denominator = 0;

            for (let i = 0; i < xValues.length; i++) {
                const xDiff = xValues[i] - xMean;
                const yDiff = yValues[i] - yMean;

                numerator += xDiff * yDiff;
                denominator += xDiff * xDiff;
            }

            if (denominator === 0) return NaN;
            return numerator / denominator;
        }

        function getAutoRunPreference() {
            return Boolean(state.settings.winAdjustedAutoRun);
        }

        async function setAutoRunPreference(value) {
            const enabled = Boolean(value);
            await storageSet('winAdjustedAutoRun', enabled);
            state.settings = { ...state.settings, winAdjustedAutoRun: enabled };
        }

        async function cacheGetPageEntries(pageKey) {
            return privateCacheEntriesByPrefix(cachePageStoragePrefix(pageKey))
                .map(([, entry]) => entry);
        }

        async function pruneExpiredCacheEntries() {
            const cached = privateCacheEntriesByPrefix(CACHE_STORAGE_PREFIX);
            const valid = [];
            const invalidKeys = [];
            for (const [key, entry] of cached) {
                if (!isValidCacheEntry(entry, entry?.pageKey, entry?.teamKey)
                    || key !== cacheEntryStorageKey(entry.pageKey, entry.teamKey)) {
                    invalidKeys.push(key);
                } else {
                    valid.push([key, entry]);
                }
            }
            valid.sort((first, second) => second[1].updatedAt - first[1].updatedAt);
            invalidKeys.push(...valid.slice(MAX_CACHE_ENTRIES).map(([key]) => key));
            await privateCacheRemoveMany(invalidKeys);
        }

        function pruneExpiredCacheEntriesOnce() {
            if (!cachePrunePromise) {
                cachePrunePromise = pruneExpiredCacheEntries().catch((error) => {
                    log('WAR cache pruning failed.', error);
                });
            }
            return cachePrunePromise;
        }

        async function cachePut(entry) {
            if (!isValidCacheEntry(entry, entry.pageKey, entry.teamKey)) {
                throw new Error('Refusing to write an invalid WAR cache entry.');
            }

            await privateCacheSetAndWait(
                cacheEntryStorageKey(entry.pageKey, entry.teamKey),
                entry,
            );
        }

        async function cacheClearPage(pageKey) {
            const keys = privateCacheEntriesByPrefix(cachePageStoragePrefix(pageKey))
                .map(([key]) => key);
            await privateCacheRemoveMany(keys);
        }

        function isValidCacheEntry(entry, pageKey, teamKey = null) {
            const baseValid = Boolean(
                entry &&
                typeof entry.cacheKey === 'string' &&
                typeof entry.pageKey === 'string' &&
                typeof entry.teamKey === 'string' &&
                Number.isFinite(entry.winPct) &&
                Number.isFinite(entry.updatedAt)
            );

            if (!baseValid) return false;
            if (typeof pageKey === 'string' && entry.pageKey !== pageKey) return false;
            if (typeof teamKey === 'string' && entry.teamKey !== teamKey) return false;
            if (entry.cacheKey !== makeCacheKey(entry.pageKey, entry.teamKey)) return false;
            if (entry.winPct < 0 || entry.winPct > 1) return false;

            const now = Date.now();
            if (entry.updatedAt < now - CACHE_RETENTION_MS || entry.updatedAt > now + CACHE_FUTURE_SKEW_MS) return false;

            const pageUrl = parseSameOriginUrl(entry.pageKey);
            if (!pageUrl || pageUrl.pathname !== '/stats/players') return false;

            const teamUrl = parseTeamStatsUrl(entry.teamUrl || entry.teamKey);
            if (!teamUrl || `${teamUrl.pathname}${teamUrl.search}` !== entry.teamKey) return false;

            return true;
        }

        async function getCacheEntries(teamKeys, pageKey) {
            const entries = new Map();

            if (!teamKeys.length) {
                return {
                    entries,
                    error: null
                };
            }

            try {
                await pruneExpiredCacheEntriesOnce();
                const requestedTeamKeys = new Set(teamKeys);
                const results = await cacheGetPageEntries(pageKey);

                for (const entry of results) {
                    if (requestedTeamKeys.has(entry?.teamKey)
                        && isValidCacheEntry(entry, pageKey, entry.teamKey)) {
                        entries.set(entry.teamKey, entry);
                    }
                }

                return {
                    entries,
                    error: null
                };
            } catch (error) {
                warn('WAR cache read failed.', error);

                return {
                    entries,
                    error
                };
            }
        }

        function formatAge(ms) {
            if (!Number.isFinite(ms)) return '?';

            const safeMs = Math.max(0, ms);
            const seconds = Math.floor(safeMs / 1000);

            if (seconds < 60) return `${seconds}s`;

            const minutes = Math.floor(seconds / 60);
            if (minutes < 60) return `${minutes}m`;

            const hours = Math.floor(minutes / 60);
            if (hours < 48) return `${hours}h ${minutes % 60}m`;

            const days = Math.floor(hours / 24);
            return `${days}d ${hours % 24}h`;
        }

        function setCacheAgeInfo(cacheAgeElement, teamKeys, cacheEntriesByKey, cacheError) {
            if (!cacheAgeElement) return;

            if (cacheError) {
                cacheAgeElement.textContent = 'Cache age: storage unavailable';
                cacheAgeElement.title = String(cacheError.message || cacheError);
                return;
            }

            if (!teamKeys || !teamKeys.length) {
                cacheAgeElement.textContent = 'Cache age: n/a';
                cacheAgeElement.title = 'No one-team rows found on this page.';
                return;
            }

            const pageKey = getPageCacheKey();
            const cachedEntries = teamKeys
                .map((teamKey) => cacheEntriesByKey.get(teamKey))
                .filter((entry) => isValidCacheEntry(entry, pageKey, entry?.teamKey));

            if (!cachedEntries.length) {
                cacheAgeElement.textContent = `Cache age: none (0/${teamKeys.length} teams)`;
                cacheAgeElement.title = 'No cached team win percentages for this exact stats URL.';
                return;
            }

            const now = Date.now();
            const oldestAge = Math.max(...cachedEntries.map((entry) => now - entry.updatedAt));
            const newestAge = Math.min(...cachedEntries.map((entry) => now - entry.updatedAt));
            const coverage = `${cachedEntries.length}/${teamKeys.length} teams`;

            cacheAgeElement.textContent = `Cache age: ${formatAge(oldestAge)} (${coverage})`;
            cacheAgeElement.title = [
                'Extension-private cache scoped to this exact stats URL.',
                `Stats URL: ${pageKey}`,
                `Oldest cached team: ${formatAge(oldestAge)}`,
                `Newest cached team: ${formatAge(newestAge)}`,
                `Coverage: ${coverage}`,
                'Page load uses cached values when available.',
                'Manual fetch re-fetches fresh values and updates only this URL cache.'
            ].join('\n');
        }

        function findTable() {
            return document.querySelector(TABLE_SELECTOR);
        }

        function findControlsAnchor() {
            return document.querySelector('.stats-top-menu');
        }

        function findRatingColumnIndex(table) {
            const headers = Array.from(table.querySelectorAll('thead th'));
            const isNativeRating = (header) => (
                !header.hasAttribute(ADJUSTED_COL_MARKER)
                && !header.closest(`[${ADJUSTED_COL_MARKER}]`)
            );

            const byClass = headers.findIndex((header) => (
                isNativeRating(header) && header.classList.contains('ratingCol')
            ));
            if (byClass !== -1) return byClass;

            return headers.findIndex((header) => (
                isNativeRating(header)
                && normalizeText(header.textContent).startsWith('Rating')
            ));
        }

        function removeExistingAdjustedColumn(table) {
            const existingHeaders = Array.from(table.querySelectorAll(`thead th[${ADJUSTED_COL_MARKER}]`));

            const headerIndexes = existingHeaders
                .map((header) => Array.from(header.parentElement.children).indexOf(header))
                .filter((index) => index >= 0)
                .sort((a, b) => b - a);

            existingHeaders.forEach((header) => header.remove());

            const rows = Array.from(table.querySelectorAll('tbody tr'));

            for (const row of rows) {
                for (const index of headerIndexes) {
                    if (row.children[index]) {
                        row.children[index].remove();
                    }
                }
            }
        }

        function sortWarColumn(table, adjustedColumnIndex, direction) {
            const tbody = table.querySelector('tbody');
            if (!tbody) return;

            const rows = Array.from(tbody.querySelectorAll('tr')).map((row, originalIndex) => {
                const cell = row.children[adjustedColumnIndex];
                const value = cell ? Number.parseFloat(cell.getAttribute('data-sort')) : NaN;

                return {
                    row,
                    value,
                    valid: Number.isFinite(value),
                    originalIndex
                };
            });

            rows.sort((a, b) => {
                if (a.valid !== b.valid) return a.valid ? -1 : 1;
                if (!a.valid && !b.valid) return a.originalIndex - b.originalIndex;
                if (a.value === b.value) return a.originalIndex - b.originalIndex;

                return direction === 'asc' ? a.value - b.value : b.value - a.value;
            });

            const currentRows = Array.from(tbody.children);
            if (rows.every((item, index) => item.row === currentRows[index])) return;

            const fragment = document.createDocumentFragment();
            for (const item of rows) fragment.appendChild(item.row);
            tbody.appendChild(fragment);
        }

        function maybeResortWarColumn(table, adjustedColumnIndex) {
            const header = table.querySelector(`thead th[${ADJUSTED_COL_MARKER}]`);
            if (!header) return;

            const direction = header.getAttribute('data-hltv-wa-sort');
            if (direction === 'asc' || direction === 'desc') {
                sortWarColumn(table, adjustedColumnIndex, direction);
            }
        }

        function insertAdjustedColumn(table, ratingColumnIndex) {
            const headerRow = table.querySelector('thead tr');
            if (!headerRow) throw new Error('Could not find table header row.');

            const ratingHeader = headerRow.children[ratingColumnIndex];
            if (!ratingHeader) throw new Error('Could not find Rating header cell.');

            const adjustedHeader = document.createElement('th');
            adjustedHeader.setAttribute(ADJUSTED_COL_MARKER, '1');
            adjustedHeader.setAttribute('role', 'columnheader');
            adjustedHeader.setAttribute('data-sort-method', 'number');
            adjustedHeader.setAttribute('aria-sort', 'none');
            adjustedHeader.className = 'ratingCol hltv-win-adjusted-rating-header';
            adjustedHeader.textContent = 'WAR';
            adjustedHeader.title = 'Win-adjusted Rating. Click to sort. Values may be cached or provisional while fetching.';

            const adjustedColumnIndex = ratingColumnIndex + 1;

            adjustedHeader.addEventListener('click', (event) => {
                event.preventDefault();
                event.stopPropagation();

                const currentDirection = adjustedHeader.getAttribute('data-hltv-wa-sort') || 'none';
                const nextDirection = currentDirection === 'desc' ? 'asc' : 'desc';

                adjustedHeader.setAttribute('data-hltv-wa-sort', nextDirection);
                adjustedHeader.setAttribute('aria-sort', nextDirection === 'asc' ? 'ascending' : 'descending');

                sortWarColumn(table, adjustedColumnIndex, nextDirection);
            });

            ratingHeader.insertAdjacentElement('afterend', adjustedHeader);

            const rows = Array.from(table.querySelectorAll('tbody tr'));

            for (const row of rows) {
                const ratingCell = row.children[ratingColumnIndex];

                const adjustedCell = document.createElement('td');
                adjustedCell.setAttribute(ADJUSTED_COL_MARKER, '1');
                adjustedCell.className = 'ratingCol ratingNeutral hltv-win-adjusted-rating-cell';
                adjustedCell.textContent = '...';
                adjustedCell.title = 'Waiting for team win percentage.';

                if (ratingCell) {
                    ratingCell.insertAdjacentElement('afterend', adjustedCell);
                } else {
                    row.appendChild(adjustedCell);
                }
            }

            return adjustedColumnIndex;
        }

        function getUniqueTeamLinks(row) {
            const teamCell = row.querySelector('td.teamCol');
            if (!teamCell) return [];

            const links = Array.from(teamCell.querySelectorAll('a[href*="/stats/teams/"]'));

            const seen = new Set();
            const unique = [];

            for (const link of links) {
                const href = link.getAttribute('href');
                if (!href) continue;

                const url = parseTeamStatsUrl(href);
                if (!url) continue;

                const key = url.pathname + url.search;

                if (!seen.has(key)) {
                    seen.add(key);
                    unique.push({
                        href: url.href,
                        key
                    });
                }
            }

            return unique;
        }

        function collectCurrentTeamKeys() {
            const table = findTable();
            const teamUrlByKey = new Map();

            if (!table) {
                return {
                    teamKeys: [],
                    teamUrlByKey
                };
            }

            const rows = Array.from(table.querySelectorAll('tbody tr'));

            for (const row of rows) {
                const teamLinks = getUniqueTeamLinks(row);

                if (teamLinks.length !== 1) continue;

                const team = teamLinks[0];
                if (!teamUrlByKey.has(team.key)) {
                    teamUrlByKey.set(team.key, team.href);
                }
            }

            return {
                teamKeys: Array.from(teamUrlByKey.keys()),
                teamUrlByKey
            };
        }

        async function refreshCacheAgeInfo(cacheAgeElement) {
            if (!cacheAgeElement) return;

            const { teamKeys } = collectCurrentTeamKeys();

            if (!teamKeys.length) {
                setCacheAgeInfo(cacheAgeElement, teamKeys, new Map(), null);
                return;
            }

            cacheAgeElement.textContent = 'Cache age: checking...';
            cacheAgeElement.title = '';

            const cacheRead = await getCacheEntries(teamKeys, getPageCacheKey());
            setCacheAgeInfo(cacheAgeElement, teamKeys, cacheRead.entries, cacheRead.error);
        }

        function collectRows(table, ratingColumnIndex, adjustedColumnIndex) {
            const rows = Array.from(table.querySelectorAll('tbody tr'));

            return rows.map((row) => {
                const ratingCell = row.children[ratingColumnIndex];
                const adjustedCell = row.children[adjustedColumnIndex];
                const teamLinks = getUniqueTeamLinks(row);
                const ratingSource = ratingCell ? ratingCell.getAttribute('data-sort') || ratingCell.textContent : '';
                const rating = parseNumber(ratingSource);

                return {
                    row,
                    ratingCell,
                    adjustedCell,
                    teamLinks,
                    rating,
                    teamWinPct: NaN,
                    teamWinPctSource: '',
                    cacheUpdatedAt: NaN,
                    freshFetchFailed: false
                };
            });
        }

        function extractTeamWinPctFromDocument(doc) {
            const labels = Array.from(doc.querySelectorAll('.small-label-below'));

            const winLossLabel = labels.find((label) => {
                return normalizeText(label.textContent).toLowerCase() === 'wins / draws / losses';
            });

            if (!winLossLabel) {
                throw new Error('Could not find "Wins / draws / losses" on team page.');
            }

            const box =
                winLossLabel.closest('.col.standard-box, .standard-box, .col') ||
                winLossLabel.parentElement;

            if (!box) {
                throw new Error('Could not find team overview box.');
            }

            const recordNode = box.querySelector('.large-strong');

            if (!recordNode) {
                throw new Error('Could not find W / D / L value.');
            }

            const recordText = normalizeText(recordNode.textContent);
            const match = recordText.match(/([\d,]+)\s*\/\s*([\d,]+)\s*\/\s*([\d,]+)/);

            if (!match) {
                throw new Error(`Could not parse W / D / L value: "${recordText}"`);
            }

            const wins = Number.parseInt(match[1].replace(/,/g, ''), 10);
            const draws = Number.parseInt(match[2].replace(/,/g, ''), 10);
            const losses = Number.parseInt(match[3].replace(/,/g, ''), 10);

            if (![wins, draws, losses].every(Number.isFinite)) {
                throw new Error(`Invalid W / D / L value: "${recordText}"`);
            }

            const total = wins + draws + losses;

            if (total <= 0) {
                throw new Error(`No maps in W / D / L value: "${recordText}"`);
            }

            return wins / total;
        }

        function makeTeamFetchError(message, status = 0, retryable = false) {
            const error = new Error(message);
            error.name = 'TeamFetchError';
            error.status = Number.isFinite(status) ? status : 0;
            error.retryable = Boolean(retryable);
            return error;
        }

        async function fetchTeamWinPctOnce(teamUrl, signal) {
            const targetUrl = parseTeamStatsUrl(teamUrl);
            if (!targetUrl) {
                throw makeTeamFetchError('Refusing to fetch an invalid team stats URL.');
            }
            const expectedTeamId = targetUrl.pathname.match(
                /^\/stats\/teams\/(\d+)(?:\/|$)/i,
            )?.[1] || '';

            const requestUrl = toSameOriginRequestUrl(targetUrl.href);
            let html;

            try {
                html = await fetchTextWithFallback(requestUrl, {
                    timeoutMs: CONFIG.requestTimeoutMs,
                    signal,
                    cache: 'no-store',
                    validateFinalUrl: (finalUrl) => {
                        const finalTeamUrl = parseTeamStatsUrl(finalUrl.href);
                        return finalTeamUrl?.pathname.match(
                            /^\/stats\/teams\/(\d+)(?:\/|$)/i,
                        )?.[1] === expectedTeamId;
                    },
                    invalidFinalUrlMessage: 'Team response did not match the requested team.',
                });
            } catch (error) {
                if (isAbortError(error) || signal?.aborted) throw error;
                throw makeTeamFetchError(
                    error instanceof Error ? error.message : String(error),
                    Number(error?.status || 0),
                    Boolean(error?.retryable),
                );
            }

            let doc;
            try {
                doc = parseHtmlDocument(html, requestUrl, {
                    contentLabel: 'team stats page',
                    expectedSelector: '.small-label-below, .large-strong',
                    requireExpectedSelector: true,
                });
            } catch (error) {
                const message = String(error && error.message ? error.message : error);
                if (/protection\/challenge page|just a moment|checking your browser|cloudflare|access denied/i.test(message)) {
                    throw makeTeamFetchError(
                        `HLTV protection page returned while fetching ${requestUrl}`,
                        0,
                        true,
                    );
                }
                throw error;
            }

            return extractTeamWinPctFromDocument(doc);
        }

        async function fetchTeamWinPctWithRetry(teamUrl, signal, onRetry) {
            let lastError = null;

            for (let attempt = 1; attempt <= WAR_MAX_FETCH_ATTEMPTS; attempt++) {
                if (signal && signal.aborted) throw makeAbortError();

                try {
                    return {
                        winPct: await fetchTeamWinPctOnce(teamUrl, signal),
                        attempts: attempt
                    };
                } catch (error) {
                    if (isAbortError(error) || (signal && signal.aborted)) throw error;

                    lastError = error instanceof Error ? error : new Error(String(error));

                    if (attempt >= WAR_MAX_FETCH_ATTEMPTS || !lastError.retryable) break;

                    const waitMs = WAR_RETRY_DELAYS_MS[attempt - 1];

                    warn(
                        `WAR team fetch attempt ${attempt}/${WAR_MAX_FETCH_ATTEMPTS} failed; retrying in ${waitMs} ms.`,
                        lastError,
                    );

                    if (typeof onRetry === 'function') {
                        onRetry({
                            completedAttempt: attempt,
                            nextAttempt: attempt + 1,
                            waitMs,
                            error: lastError
                        });
                    }

                    await sleep(waitMs, signal);
                }
            }

            throw lastError || new Error('Team fetch failed.');
        }

        async function fetchTeamsWithDelay(teamKeys, teamUrlByKey, hooks, signal) {
            const results = new Map();
            let stopped = false;

            for (let i = 0; i < teamKeys.length; i++) {
                const teamKey = teamKeys[i];
                const teamUrl = teamUrlByKey.get(teamKey);

                if (signal && signal.aborted) {
                    stopped = true;
                    break;
                }

                if (i > 0) {
                    if (hooks && hooks.onProgress) {
                        hooks.onProgress({
                            done: i,
                            total: teamKeys.length,
                            phase: 'waiting',
                            teamKey,
                            waitMs: WAR_BASE_REQUEST_GAP_MS
                        });
                    }

                    try {
                        await sleep(WAR_BASE_REQUEST_GAP_MS, signal);
                    } catch (error) {
                        if (isAbortError(error)) {
                            stopped = true;
                            break;
                        }

                        throw error;
                    }
                }

                if (signal && signal.aborted) {
                    stopped = true;
                    break;
                }

                if (hooks && hooks.onProgress) {
                    hooks.onProgress({
                        done: i,
                        total: teamKeys.length,
                        phase: 'fetching',
                        teamKey,
                        attempt: 1
                    });
                }

                let result;

                try {
                    const fetched = await fetchTeamWinPctWithRetry(teamUrl, signal, (retry) => {
                        if (hooks && hooks.onProgress) {
                            hooks.onProgress({
                                done: i,
                                total: teamKeys.length,
                                phase: 'retrying',
                                teamKey,
                                ...retry
                            });
                        }
                    });

                    result = {
                        ok: true,
                        winPct: fetched.winPct,
                        attempts: fetched.attempts
                    };
                } catch (error) {
                    if (isAbortError(error) || (signal && signal.aborted)) {
                        stopped = true;
                        break;
                    }

                    result = {
                        ok: false,
                        error,
                        attempts: WAR_MAX_FETCH_ATTEMPTS
                    };
                    warn(
                        `WAR team fetch failed after ${WAR_MAX_FETCH_ATTEMPTS} attempts.`,
                        error,
                    );
                }

                results.set(teamKey, result);

                if (hooks && hooks.onResult) {
                    await hooks.onResult(teamKey, result, i + 1, teamKeys.length);
                }
            }

            return {
                results,
                stopped
            };
        }

        function setFetchRunBusy(button, isBusy) {
            const fetchButton = button || controlsRefs?.button;
            const clearButton = controlsRefs?.clearCacheButton;

            if (fetchButton) {
                fetchButton.classList.toggle('hltv-wa-busy', isBusy);
                fetchButton.disabled = false;
                fetchButton.dataset.busy = isBusy ? '1' : '0';
                fetchButton.textContent = isBusy ? STOP_BUTTON_TEXT : BUTTON_TEXT;
                fetchButton.title = isBusy
                    ? 'Stop the current fetch run. Cached and fetched values already loaded will stay visible.'
                    : 'Re-fetch fresh team pages with up to three attempts per team and update WAR cache for this exact stats URL.';
            }

            if (clearButton) {
                clearButton.classList.toggle('hltv-wa-busy', isBusy);
                clearButton.disabled = isBusy;
            }
        }

        function setClearCacheBusy(button, isBusy) {
            const fetchButton = controlsRefs?.button;
            const clearButton = button || controlsRefs?.clearCacheButton;

            if (fetchButton) {
                fetchButton.classList.toggle('hltv-wa-busy', isBusy);
                fetchButton.disabled = isBusy;
            }

            if (clearButton) {
                clearButton.classList.toggle('hltv-wa-busy', isBusy);
                clearButton.disabled = isBusy;
                clearButton.dataset.busy = isBusy ? '1' : '0';
            }
        }

        function stopActiveFetch(statusElement) {
            if (activeFetchAbortController && !activeFetchAbortController.signal.aborted) {
                activeFetchAbortController.abort();
                setStatus(statusElement, 'Stopping fetch...');
            }
        }

        function setStatus(statusElement, text) {
            if (!statusElement) return;
            statusElement.textContent = text || '';
        }

        function setAdjustedCellQuestion(rowData, reason) {
            if (!rowData.adjustedCell) return;

            rowData.adjustedCell.textContent = '?';
            rowData.adjustedCell.removeAttribute('data-sort');
            rowData.adjustedCell.title = reason || 'Could not calculate WAR.';
            rowData.adjustedCell.className = 'ratingCol ratingNeutral hltv-win-adjusted-rating-cell';
        }

        function setAdjustedCellWaiting(rowData, reason) {
            if (!rowData.adjustedCell) return;

            rowData.adjustedCell.textContent = '...';
            rowData.adjustedCell.removeAttribute('data-sort');
            rowData.adjustedCell.title = reason || 'Waiting for enough data to calculate WAR.';
            rowData.adjustedCell.className = 'ratingCol ratingNeutral hltv-win-adjusted-rating-cell';
        }

        function ratingClassForValue(value) {
            if (value >= 1.05) return 'ratingPositive';
            if (value <= 0.95) return 'ratingNegative';
            return 'ratingNeutral';
        }

        function describeTeamWinPctSource(rowData) {
            if (rowData.teamWinPctSource === 'fresh') {
                return 'TeamWinPct source: fresh fetch.';
            }

            if (rowData.teamWinPctSource === 'cache') {
                const age = Number.isFinite(rowData.cacheUpdatedAt)
                    ? formatAge(Date.now() - rowData.cacheUpdatedAt)
                    : '?';

                if (rowData.freshFetchFailed) {
                    return `TeamWinPct source: extension-private cache for this exact stats URL, because fresh fetch failed. Cache age: ${age}.`;
                }

                return `TeamWinPct source: extension-private cache for this exact stats URL. Cache age: ${age}.`;
            }

            return 'TeamWinPct source: unknown.';
        }

        function setAdjustedCellValue(rowData, value, betaWin, avgWinPct, isFinal) {
            if (!rowData.adjustedCell) return;

            rowData.adjustedCell.textContent = value.toFixed(2);
            rowData.adjustedCell.setAttribute('data-sort', String(value));
            rowData.adjustedCell.setAttribute('data-sort-method', 'number');
            rowData.adjustedCell.className = `ratingCol ${ratingClassForValue(value)} hltv-win-adjusted-rating-cell`;

            const titleParts = [
                isFinal ? 'WAR: final for current data.' : 'WAR: provisional until all team pages are fetched.',
                describeTeamWinPctSource(rowData),
                `Rating: ${rowData.rating.toFixed(2)}`,
                `TeamWinPct: ${rowData.teamWinPct.toFixed(4)}`,
                `Average TeamWinPct: ${avgWinPct.toFixed(4)}`,
                `Beta win: ${betaWin.toFixed(6)}`,
                'Formula: Rating - beta_win * (TeamWinPct - average_TeamWinPct)'
            ];

            rowData.adjustedCell.title = titleParts.join('\n');
        }

        function renderWarCells(singleTeamRows, isFinal) {
            const computableRows = singleTeamRows.filter((rowData) => {
                return Number.isFinite(rowData.rating) && Number.isFinite(rowData.teamWinPct);
            });

            if (computableRows.length < 2) {
                for (const rowData of computableRows) {
                    if (isFinal) {
                        setAdjustedCellQuestion(rowData, 'Need at least two valid one-team rows.');
                    } else {
                        setAdjustedCellWaiting(rowData, 'Team win percentage fetched. Waiting for at least two valid rows.');
                    }
                }

                return {
                    ok: false,
                    computedCount: 0,
                    reason: 'Need at least two valid one-team rows.'
                };
            }

            const ratings = computableRows.map((rowData) => rowData.rating);
            const teamWinPcts = computableRows.map((rowData) => rowData.teamWinPct);

            const betaWin = slope(ratings, teamWinPcts);
            const avgWinPct = average(teamWinPcts);

            if (!Number.isFinite(betaWin)) {
                for (const rowData of computableRows) {
                    if (isFinal) {
                        setAdjustedCellQuestion(
                            rowData,
                            'Could not estimate beta_win. Team win percentages may be identical.'
                        );
                    } else {
                        setAdjustedCellWaiting(
                            rowData,
                            'Team win percentage fetched. Waiting for varied team win percentages to estimate beta_win.'
                        );
                    }
                }

                return {
                    ok: false,
                    computedCount: 0,
                    reason: 'Could not estimate beta_win. Team win percentages may be identical.'
                };
            }

            for (const rowData of computableRows) {
                const adjustedRating = rowData.rating - betaWin * (rowData.teamWinPct - avgWinPct);
                setAdjustedCellValue(rowData, adjustedRating, betaWin, avgWinPct, isFinal);
            }

            return {
                ok: true,
                computedCount: computableRows.length,
                betaWin,
                avgWinPct
            };
        }

        function countOkResults(fetchResults) {
            let count = 0;

            for (const result of fetchResults.values()) {
                if (result.ok) count++;
            }

            return count;
        }

        function countFreshFailedCacheFallback(fetchResults, cacheEntriesByKey) {
            let count = 0;
            const pageKey = getPageCacheKey();

            for (const [teamKey, result] of fetchResults.entries()) {
                if (!result.ok && isValidCacheEntry(cacheEntriesByKey.get(teamKey), pageKey)) {
                    count++;
                }
            }

            return count;
        }

        function applyCachedWarmStart(singleTeamRows, rowsByTeamKey, cacheEntriesByKey) {
            for (const [teamKey, entry] of cacheEntriesByKey.entries()) {
                const affectedRows = rowsByTeamKey.get(teamKey) || [];

                for (const rowData of affectedRows) {
                    rowData.teamWinPct = entry.winPct;
                    rowData.teamWinPctSource = 'cache';
                    rowData.cacheUpdatedAt = entry.updatedAt;
                    rowData.freshFetchFailed = false;
                }
            }

            return singleTeamRows.some((rowData) => Number.isFinite(rowData.teamWinPct));
        }

        function buildRunState(table, ratingColumnIndex, adjustedColumnIndex) {
            const rowDataList = collectRows(table, ratingColumnIndex, adjustedColumnIndex);

            const singleTeamRows = rowDataList.filter((rowData) => {
                if (rowData.teamLinks.length !== 1) {
                    setAdjustedCellQuestion(rowData, 'Player has zero teams or multiple teams.');
                    return false;
                }

                if (!Number.isFinite(rowData.rating)) {
                    setAdjustedCellQuestion(rowData, 'Could not parse player rating.');
                    return false;
                }

                return true;
            });

            const teamUrlByKey = new Map();
            const rowsByTeamKey = new Map();

            for (const rowData of singleTeamRows) {
                const team = rowData.teamLinks[0];

                if (!teamUrlByKey.has(team.key)) {
                    teamUrlByKey.set(team.key, team.href);
                }

                if (!rowsByTeamKey.has(team.key)) {
                    rowsByTeamKey.set(team.key, []);
                }

                rowsByTeamKey.get(team.key).push(rowData);
            }

            return {
                rowDataList,
                singleTeamRows,
                teamUrlByKey,
                rowsByTeamKey,
                teamKeys: Array.from(teamUrlByKey.keys())
            };
        }

        async function loadCachedWarOnPage(statusElement, cacheAgeElement, generation) {
            const table = findTable();
            const pageKey = getPageCacheKey();

            if (!table) {
                setStatus(statusElement, 'No stats table found.');
                return {
                    loaded: false,
                    reason: 'No stats table found.'
                };
            }

            removeExistingAdjustedColumn(table);
            const ratingColumnIndex = findRatingColumnIndex(table);

            if (ratingColumnIndex === -1) {
                setStatus(statusElement, 'No Rating column found.');
                return {
                    loaded: false,
                    reason: 'No Rating column found.'
                };
            }
            let adjustedColumnIndex = insertAdjustedColumn(table, ratingColumnIndex);

            const { teamKeys } = collectCurrentTeamKeys();
            if (!teamKeys.length) {
                setCacheAgeInfo(cacheAgeElement, teamKeys, new Map(), null);
                setStatus(statusElement, 'No valid one-team rows.');
                return {
                    loaded: false,
                    reason: 'No valid one-team rows.'
                };
            }

            const cacheRead = await getCacheEntries(teamKeys, pageKey);
            if (generation !== controlsGeneration || !table.isConnected) {
                return { loaded: false, reason: 'Controls changed while cache was loading.' };
            }

            const cacheEntriesByKey = cacheRead.entries;

            setCacheAgeInfo(cacheAgeElement, teamKeys, cacheEntriesByKey, cacheRead.error);

            if (cacheRead.error) {
                setStatus(statusElement, 'Cache storage unavailable.');
                return {
                    loaded: false,
                    reason: 'Cache storage unavailable.'
                };
            }

            if (cacheEntriesByKey.size === 0) {
                setStatus(statusElement, '');
                return {
                    loaded: false,
                    reason: 'No cache for this exact stats URL.'
                };
            }

            // The stats-table module may have applied a saved column order while
            // cached WAR data was being read. Reinsert beside the current Rating column
            // so the row indexes used by the WAR calculation remain accurate.
            removeExistingAdjustedColumn(table);
            const currentRatingColumnIndex = findRatingColumnIndex(table);
            if (currentRatingColumnIndex === -1) {
                setStatus(statusElement, 'No Rating column found.');
                return { loaded: false, reason: 'No Rating column found.' };
            }
            adjustedColumnIndex = insertAdjustedColumn(table, currentRatingColumnIndex);

            const runState = buildRunState(table, currentRatingColumnIndex, adjustedColumnIndex);

            if (!runState.teamKeys.length) {
                removeExistingAdjustedColumn(table);
                setStatus(statusElement, 'No valid one-team rows.');
                return {
                    loaded: false,
                    reason: 'No valid one-team rows.'
                };
            }

            applyCachedWarmStart(runState.singleTeamRows, runState.rowsByTeamKey, cacheEntriesByKey);

            for (const rowData of runState.singleTeamRows) {
                if (!Number.isFinite(rowData.teamWinPct)) {
                    setAdjustedCellQuestion(rowData, 'No cached team win percentage for this exact stats URL.');
                }
            }

            const estimate = renderWarCells(runState.singleTeamRows, true);
            maybeResortWarColumn(table, adjustedColumnIndex);

            if (!estimate.ok) {
                setStatus(statusElement, `Cache loaded for this URL, but WAR not computed. ${estimate.reason}`);
                return {
                    loaded: false,
                    reason: estimate.reason
                };
            }

            setStatus(
                statusElement,
                `Loaded cached WAR for this URL. Rows=${estimate.computedCount}, beta=${estimate.betaWin.toFixed(4)}, avg win=${(estimate.avgWinPct * 100).toFixed(1)}%.`
            );

            return {
                loaded: true,
                estimate
            };
        }

        function markRowsNotFetchedAfterStop(singleTeamRows) {
            for (const rowData of singleTeamRows) {
                if (!Number.isFinite(rowData.teamWinPct)) {
                    setAdjustedCellQuestion(rowData, 'Fetching stopped before this team win percentage was loaded.');
                }
            }
        }

        async function runWinAdjustedRatings(button, statusElement, cacheAgeElement) {
            if (button.dataset.busy === '1') return;

            const pageKey = getPageCacheKey();
            const abortController = new AbortController();
            activeFetchAbortController = abortController;

            setFetchRunBusy(button, true);
            setStatus(statusElement, 'Preparing...');

            try {
                const table = findTable();

                if (!table) {
                    setStatus(statusElement, 'No stats table found.');
                    return;
                }

                removeExistingAdjustedColumn(table);

                const ratingColumnIndex = findRatingColumnIndex(table);

                if (ratingColumnIndex === -1) {
                    setStatus(statusElement, 'No Rating column found.');
                    return;
                }

                const adjustedColumnIndex = insertAdjustedColumn(table, ratingColumnIndex);
                const state = buildRunState(table, ratingColumnIndex, adjustedColumnIndex);

                if (!state.teamKeys.length) {
                    setStatus(statusElement, 'No valid one-team rows.');
                    setCacheAgeInfo(cacheAgeElement, state.teamKeys, new Map(), null);
                    return;
                }

                setStatus(statusElement, 'Reading extension-private cache for this exact stats URL...');

                const cacheRead = await getCacheEntries(state.teamKeys, pageKey);
                const cacheEntriesByKey = cacheRead.entries;
                let cacheDbError = cacheRead.error;

                setCacheAgeInfo(cacheAgeElement, state.teamKeys, cacheEntriesByKey, cacheDbError);

                if (cacheEntriesByKey.size > 0) {
                    await applyCachedWarmStart(state.singleTeamRows, state.rowsByTeamKey, cacheEntriesByKey);
                    const cacheEstimate = renderWarCells(state.singleTeamRows, false);
                    maybeResortWarColumn(table, adjustedColumnIndex);

                    if (cacheEstimate.ok) {
                        setStatus(
                            statusElement,
                            `Loaded cached WAR for this URL for ${cacheEstimate.computedCount} rows. Re-fetching teams...`
                        );
                    } else {
                        setStatus(statusElement, `Loaded cache for this URL. ${cacheEstimate.reason} Re-fetching teams...`);
                    }
                } else {
                    setStatus(statusElement, `No cache for this URL. Fetching teams 0/${state.teamKeys.length}...`);
                }

                const fetchOrder = state.teamKeys
                    .map((teamKey, originalIndex) => ({
                        teamKey,
                        originalIndex,
                        cached: isValidCacheEntry(cacheEntriesByKey.get(teamKey), pageKey)
                    }))
                    .sort((a, b) => Number(a.cached) - Number(b.cached) || a.originalIndex - b.originalIndex)
                    .map((item) => item.teamKey);

                const fetchOutcome = await fetchTeamsWithDelay(fetchOrder, state.teamUrlByKey, {
                    onProgress: ({ done, total, phase, waitMs, nextAttempt }) => {
                        if (phase === 'waiting') {
                            setStatus(statusElement, `Waiting ${waitMs}ms before next team request... ${done}/${total}`);
                        } else if (phase === 'retrying') {
                            setStatus(
                                statusElement,
                                `Team request failed; retry ${nextAttempt}/${WAR_MAX_FETCH_ATTEMPTS} in ${(waitMs / 1000).toFixed(1)}s... ${done}/${total}`
                            );
                        } else if (phase === 'fetching') {
                            setStatus(statusElement, `Fetching teams ${done + 1}/${total}...`);
                        }
                    },
                    onResult: async (teamKey, result, done, total) => {
                        const affectedRows = state.rowsByTeamKey.get(teamKey) || [];
                        const teamUrl = state.teamUrlByKey.get(teamKey);

                        if (result.ok && Number.isFinite(result.winPct)) {
                            const cacheEntry = {
                                cacheKey: makeCacheKey(pageKey, teamKey),
                                pageKey,
                                teamKey,
                                teamUrl,
                                winPct: result.winPct,
                                updatedAt: Date.now()
                            };

                            for (const rowData of affectedRows) {
                                rowData.teamWinPct = result.winPct;
                                rowData.teamWinPctSource = 'fresh';
                                rowData.cacheUpdatedAt = cacheEntry.updatedAt;
                                rowData.freshFetchFailed = false;
                            }

                            try {
                                await cachePut(cacheEntry);
                                cacheEntriesByKey.set(teamKey, cacheEntry);
                                cacheDbError = null;
                            } catch (error) {
                                cacheDbError = error;
                                warn('WAR cache write failed.', error);
                            }
                        } else {
                            const cacheEntry = cacheEntriesByKey.get(teamKey);

                            if (isValidCacheEntry(cacheEntry, pageKey)) {
                                for (const rowData of affectedRows) {
                                    rowData.teamWinPct = cacheEntry.winPct;
                                    rowData.teamWinPctSource = 'cache';
                                    rowData.cacheUpdatedAt = cacheEntry.updatedAt;
                                    rowData.freshFetchFailed = true;
                                }
                            } else {
                                for (const rowData of affectedRows) {
                                    setAdjustedCellQuestion(rowData, 'Could not fetch or parse team win percentage, and no cache exists for this exact stats URL.');
                                }
                            }
                        }

                        const shouldRenderBatch = done === total || done % WAR_RENDER_BATCH_SIZE === 0;
                        if (!shouldRenderBatch) {
                            setStatus(statusElement, `Fetched teams ${done}/${total}. Updating WAR in batches...`);
                            return;
                        }

                        setCacheAgeInfo(cacheAgeElement, state.teamKeys, cacheEntriesByKey, cacheDbError);

                        const estimate = renderWarCells(state.singleTeamRows, false);
                        maybeResortWarColumn(table, adjustedColumnIndex);

                        if (estimate.ok) {
                            setStatus(
                                statusElement,
                                `Fetched teams ${done}/${total}. Provisional WAR for ${estimate.computedCount} rows.`
                            );
                        } else {
                            setStatus(statusElement, `Fetched teams ${done}/${total}. ${estimate.reason}`);
                        }
                    }
                }, abortController.signal);

                const fetchResults = fetchOutcome.results;

                if (fetchOutcome.stopped || abortController.signal.aborted) {
                    markRowsNotFetchedAfterStop(state.singleTeamRows);

                    const partialEstimate = renderWarCells(state.singleTeamRows, true);
                    maybeResortWarColumn(table, adjustedColumnIndex);
                    setCacheAgeInfo(cacheAgeElement, state.teamKeys, cacheEntriesByKey, cacheDbError);

                    const freshOk = countOkResults(fetchResults);
                    const cacheFallback = countFreshFailedCacheFallback(fetchResults, cacheEntriesByKey);
                    const notFetched = state.teamKeys.length - fetchResults.size;

                    if (partialEstimate.ok) {
                        setStatus(
                            statusElement,
                            `Stopped. Partial WAR shown. beta=${partialEstimate.betaWin.toFixed(4)}, avg win=${(partialEstimate.avgWinPct * 100).toFixed(1)}%, fresh ok=${freshOk}/${state.teamKeys.length}, cache fallback=${cacheFallback}, not fetched=${notFetched}.`
                        );
                    } else {
                        setStatus(
                            statusElement,
                            `Stopped. ${partialEstimate.reason} Fresh ok=${freshOk}/${state.teamKeys.length}, cache fallback=${cacheFallback}, not fetched=${notFetched}.`
                        );
                    }

                    return;
                }

                const finalEstimate = renderWarCells(state.singleTeamRows, true);
                maybeResortWarColumn(table, adjustedColumnIndex);
                setCacheAgeInfo(cacheAgeElement, state.teamKeys, cacheEntriesByKey, cacheDbError);

                const freshOk = countOkResults(fetchResults);
                const cacheFallback = countFreshFailedCacheFallback(fetchResults, cacheEntriesByKey);
                const failedNoCache = state.teamKeys.length - freshOk - cacheFallback;

                if (!finalEstimate.ok) {
                    setStatus(
                        statusElement,
                        `Done. ${finalEstimate.reason} Fresh ok=${freshOk}/${state.teamKeys.length}, cache fallback=${cacheFallback}, failed=${failedNoCache}.`
                    );
                    return;
                }

                setStatus(
                    statusElement,
                    `Done. beta=${finalEstimate.betaWin.toFixed(4)}, avg win=${(finalEstimate.avgWinPct * 100).toFixed(1)}%, fresh ok=${freshOk}/${state.teamKeys.length}, cache fallback=${cacheFallback}, failed=${failedNoCache}.`
                );
            } catch (error) {
                if (isAbortError(error) || abortController.signal.aborted) {
                    setStatus(statusElement, 'Stopped.');
                } else {
                    warn('WAR calculation failed.', error);
                    setStatus(statusElement, 'Failed. See console.');
                }
            } finally {
                if (activeFetchAbortController === abortController) {
                    activeFetchAbortController = null;
                }

                setFetchRunBusy(button, false);
            }
        }

        async function clearCacheAndWarColumn(button, statusElement, cacheAgeElement) {
            if (button.dataset.busy === '1') return;

            const pageKey = getPageCacheKey();

            setClearCacheBusy(button, true);
            setStatus(statusElement, 'Clearing cache for this exact stats URL...');

            try {
                await cacheClearPage(pageKey);

                const table = findTable();
                if (table) {
                    removeExistingAdjustedColumn(table);
                    const ratingColumnIndex = findRatingColumnIndex(table);
                    if (ratingColumnIndex !== -1 && state.settings.enableWinAdjustedRatings) {
                        insertAdjustedColumn(table, ratingColumnIndex);
                    }
                }

                await refreshCacheAgeInfo(cacheAgeElement);

                setStatus(statusElement, 'Cache cleared for this URL. WAR values reset.');
            } catch (error) {
                warn('WAR cache clear failed.', error);
                setStatus(statusElement, 'Cache clear failed. See console.');
            } finally {
                setClearCacheBusy(button, false);
            }
        }

        function createControls() {
            injectStyles();

            const privateControls = createPrivateUiHost({
                tagName: 'div',
                className: 'standard-box hltv-sp-private-ui-host hltv-wa-controls-host',
                styleText: `
                    :host {
                        display: block !important;
                        isolation: isolate;
                        pointer-events: auto !important;
                        position: relative !important;
                        z-index: 20 !important;
                    }
                    ${trustedControlStyleText}
                `,
            });
            privateControls.host.id = CONTROL_ROW_ID;
            const wrapper = document.createElement('div');
            wrapper.id = `${CONTROL_ROW_ID}-surface`;
            wrapper.className = 'hltv-wa-controls';

            const button = document.createElement('button');
            button.id = BUTTON_ID;
            button.type = 'button';
            button.textContent = BUTTON_TEXT;
            button.title = 'Re-fetch fresh team pages with up to three attempts per team and update WAR cache for this exact stats URL.';

            const clearCacheButton = document.createElement('button');
            clearCacheButton.id = CLEAR_CACHE_BUTTON_ID;
            clearCacheButton.type = 'button';
            clearCacheButton.textContent = CLEAR_CACHE_TEXT;
            clearCacheButton.title = 'Clear the extension-private WAR cache for this exact stats URL and reset the WAR values.';

            const checkbox = document.createElement('input');
            checkbox.id = AUTO_ID;
            checkbox.type = 'checkbox';
            checkbox.checked = getAutoRunPreference();

            const autoLabel = document.createElement('label');
            autoLabel.className = 'hltv-wa-auto-label';
            autoLabel.title = 'When checked, re-fetch WAR automatically on page load.';
            autoLabel.appendChild(checkbox);
            autoLabel.appendChild(document.createTextNode('Auto re-fetch'));

            const cacheAgeElement = document.createElement('span');
            cacheAgeElement.id = CACHE_AGE_ID;
            cacheAgeElement.textContent = 'Cache age: checking...';

            const statusElement = document.createElement('span');
            statusElement.id = STATUS_ID;

            button.addEventListener('click', async () => {
                if (button.dataset.busy === '1') {
                    stopActiveFetch(statusElement);
                    return;
                }

                controlsGeneration += 1;
                await runWinAdjustedRatings(button, statusElement, cacheAgeElement);
            });

            clearCacheButton.addEventListener('click', async () => {
                controlsGeneration += 1;
                await clearCacheAndWarColumn(clearCacheButton, statusElement, cacheAgeElement);
            });

            checkbox.addEventListener('change', async () => {
                const requestedValue = checkbox.checked;
                checkbox.disabled = true;
                try {
                    await setAutoRunPreference(requestedValue);
                    setStatus(
                        statusElement,
                        requestedValue
                            ? 'Auto re-fetch enabled for future page loads.'
                            : 'Auto re-fetch disabled.'
                    );
                } catch (error) {
                    checkbox.checked = !requestedValue;
                    warn('WAR auto re-fetch setting save failed.', error);
                    setStatus(statusElement, 'Could not save auto re-fetch setting.');
                } finally {
                    checkbox.disabled = false;
                }
            });

            wrapper.appendChild(button);
            wrapper.appendChild(clearCacheButton);
            wrapper.appendChild(autoLabel);
            wrapper.appendChild(cacheAgeElement);
            wrapper.appendChild(statusElement);
            privateControls.root.appendChild(wrapper);

            return {
                host: privateControls.host,
                wrapper,
                button,
                clearCacheButton,
                checkbox,
                cacheAgeElement,
                statusElement
            };
        }

        function injectControls() {
            if (!isAllowedPage()) return true;
            if (controlsHost?.isConnected) {
                if (controlsRefs?.button?.dataset.busy !== '1') {
                    controlsRefs.button.disabled = false;
                }
                if (controlsRefs?.clearCacheButton?.dataset.busy !== '1') {
                    controlsRefs.clearCacheButton.disabled = false;
                }
                return true;
            }
            if (controlsHost
                && activeFetchAbortController
                && !activeFetchAbortController.signal.aborted) {
                activeFetchAbortController.abort();
            }
            document.getElementById(CONTROL_ROW_ID)?.remove();

            const table = findTable();
            const anchor = findControlsAnchor();

            if (!anchor && !table) return false;

            const controls = createControls();
            controlsHost = controls.host;
            controlsRefs = controls;
            const generation = ++controlsGeneration;

            if (anchor) {
                anchor.insertAdjacentElement('afterend', controls.host);
            } else {
                table.insertAdjacentElement('beforebegin', controls.host);
            }

            controls.button.disabled = false;
            controls.clearCacheButton.disabled = false;

            const cachedLoadPromise = loadCachedWarOnPage(
                controls.statusElement,
                controls.cacheAgeElement,
                generation,
            ).catch((error) => {
                if (generation !== controlsGeneration || !controls.host.isConnected) return;
                warn('Cached WAR load failed.', error);
                controls.cacheAgeElement.textContent = 'Cache age: storage unavailable';
                controls.cacheAgeElement.title = String(error.message || error);
                controls.statusElement.textContent = 'Cached WAR load failed. See console.';
            });

            cachedLoadPromise.then(() => {
                if (generation === controlsGeneration
                    && controls.host.isConnected
                    && state.settings.enableWinAdjustedRatings
                    && controls.checkbox.checked) {
                    window.setTimeout(() => {
                        if (generation === controlsGeneration && controls.host.isConnected) {
                            runWinAdjustedRatings(controls.button, controls.statusElement, controls.cacheAgeElement);
                        }
                    }, 0);
                }
            });

            return true;
        }

        function setup() {
            if (!isAllowedPage() || !state.settings.enableWinAdjustedRatings) return;
            if (!document.body) return;

            injectControls();
            if (setupObserver) return;

            const observerForSetup = new MutationObserver(() => {
                if (!controlsHost?.isConnected) injectControls();
            });
            setupObserver = observerForSetup;

            observerForSetup.observe(document.body, {
                childList: true,
                subtree: true
            });
        }

        function teardown() {
            controlsGeneration += 1;

            if (activeFetchAbortController && !activeFetchAbortController.signal.aborted) {
                activeFetchAbortController.abort();
            }

            if (setupObserver) {
                setupObserver.disconnect();
                setupObserver = null;
            }

            controlsHost?.remove();
            controlsHost = null;
            controlsRefs = null;
            document.getElementById(CONTROL_ROW_ID)?.remove();

            const style = document.getElementById(STYLE_ID);
            if (style) style.remove();

            const table = findTable();
            if (table) removeExistingAdjustedColumn(table);
        }

        function sync() {
            if (isAllowedPage() && state.settings.enableWinAdjustedRatings) {
                onReady(setup);
            } else {
                teardown();
            }
        }

        return {
            sync,
            teardown
        };
    })();

    try {
        Object.defineProperty(globalThis, 'HLTV_SP_WIN_ADJUSTED_RATINGS', {
            value: Object.freeze({
                setEnabled(enabled) {
                    state.settings.enableWinAdjustedRatings = enabled === true;
                    WinAdjustedRatings.sync();
                },
                sync: WinAdjustedRatings.sync,
            }),
            configurable: false,
            enumerable: false,
            writable: false,
        });
    } catch {
        // The WAR selector still persists its choice if extension globals are blocked.
    }

    const WarColumnPreferenceSync = (() => {
        const KEYS = Object.freeze([
            'enableStatsColumnChooser',
            'statsOptionalColumnsV2',
        ]);
        let listenerIds = [];
        let timer = null;
        let generation = 0;

        async function applyLatest(expectedGeneration) {
            const [rawMaster, rawColumns] = await Promise.all([
                storageGet(
                    'enableStatsColumnChooser',
                    state.settings.enableStatsColumnChooser,
                ),
                storageGet(
                    'statsOptionalColumnsV2',
                    state.settings.statsOptionalColumnsV2,
                ),
            ]);
            if (expectedGeneration !== generation) return;
            const enableStatsColumnChooser = toBoolean(
                rawMaster,
                DEFAULT_SETTINGS.enableStatsColumnChooser,
            );
            const statsOptionalColumnsV2 = normaliseStatsOptionalColumns(rawColumns);
            state.settings = {
                ...state.settings,
                enableStatsColumnChooser,
                statsOptionalColumnsV2,
                enableWinAdjustedRatings: enableStatsColumnChooser
                    && statsOptionalColumnsV2.ranking.includes('war'),
            };
            WinAdjustedRatings.sync();
        }

        function queue() {
            generation += 1;
            const expectedGeneration = generation;
            if (timer !== null) window.clearTimeout(timer);
            timer = window.setTimeout(() => {
                timer = null;
                applyLatest(expectedGeneration).catch((error) => {
                    log('Could not synchronize the WAR column preference.', error);
                });
            }, 0);
        }

        async function setup() {
            if (listenerIds.length || !hasPrivateStorage()) return;
            listenerIds = (await Promise.all(
                KEYS.map((key) => addStorageChangeListener(key, queue)),
            )).filter((id) => id !== null && id !== undefined);
        }

        return { setup };
    })();

    const FullMapNames = (() => {
        const STYLE_ID = 'hltvSpFullMapNamesStyle';
        const OBSERVER_DEBOUNCE_MS = 60;
        const FULL_MAP_NAMES = Object.freeze({
            anc: 'Ancient',
            anb: 'Anubis',
            cch: 'Cache',
            d2: 'Dust2',
            inf: 'Inferno',
            mrg: 'Mirage',
            nuke: 'Nuke',
            cbl: 'Cobblestone',
            ovp: 'Overpass',
            season: 'Season',
            trn: 'Train',
            tcn: 'Tuscan',
            vtg: 'Vertigo',
        });

        let observer = null;
        let debounceTimer = null;
        let active = false;

        function isMatchHistoryPage() {
            return location.origin === HLTV_ORIGIN
                && /^\/stats\/players\/matches\/\d+(?:\/|$)/.test(location.pathname);
        }

        function isEnabled() {
            return Boolean(state.settings.showFullMapNames) && isMatchHistoryPage();
        }

        function findMatchesTable() {
            const direct = document.querySelector('table.stats-matches-table')
                || document.querySelector('table.stats-table.stats-matches-table')
                || document.querySelector(
                    'table.stats-table.sortable-table.stats-matches-table',
                );
            if (direct) return direct;

            return [...document.querySelectorAll('table.stats-table')].find((table) => {
                const headerText = cleanText(
                    table.querySelector('thead tr')?.textContent || '',
                );
                return /\bK\s*-\s*D\b/i.test(headerText)
                    && /\bDate\b/i.test(headerText)
                    && /\bMap\b/i.test(headerText)
                    && table.querySelector(
                        'tbody a[href*="/stats/matches/mapstatsid/"]',
                    );
            }) || null;
        }

        function updateFullMapNames(table) {
            let changed = false;
            for (const cell of table.querySelectorAll('td.statsMapPlayed')) {
                if (cell.childElementCount > 0) continue;

                const currentText = cleanText(cell.textContent || '');
                const storedCode = String(cell.dataset.hltvSpMapCode || '');
                const storedName = FULL_MAP_NAMES[storedCode.toLowerCase()] || '';
                let code = storedCode;

                if (!code || (currentText !== code && currentText !== storedName)) {
                    const currentCode = currentText.toLowerCase();
                    if (!Object.hasOwn(FULL_MAP_NAMES, currentCode)) {
                        if (storedCode) {
                            delete cell.dataset.hltvSpMapCode;
                            cell.classList.remove('hltv-sp-full-map-name');
                        }
                        continue;
                    }
                    code = currentCode;
                }

                const fullName = FULL_MAP_NAMES[code.toLowerCase()];
                if (!fullName) continue;
                if (cell.dataset.hltvSpMapCode !== code) {
                    cell.dataset.hltvSpMapCode = code;
                    changed = true;
                }
                if (!cell.classList.contains('hltv-sp-full-map-name')) {
                    cell.classList.add('hltv-sp-full-map-name');
                    changed = true;
                }
                if (currentText !== fullName) {
                    cell.textContent = fullName;
                    changed = true;
                }
            }
            return changed;
        }

        function restoreMapCodes() {
            for (const cell of document.querySelectorAll(
                'td.statsMapPlayed[data-hltv-sp-map-code]',
            )) {
                const code = String(cell.dataset.hltvSpMapCode || '');
                if (code && cleanText(cell.textContent || '') !== code) {
                    cell.textContent = code;
                }
                delete cell.dataset.hltvSpMapCode;
                cell.classList.remove('hltv-sp-full-map-name');
            }
        }

        function ensureStyle() {
            if (document.getElementById(STYLE_ID)) return;
            const style = document.createElement('style');
            style.id = STYLE_ID;
            style.textContent = `
                td.statsMapPlayed.hltv-sp-full-map-name {
                    white-space: nowrap !important;
                }
            `;
            document.head.appendChild(style);
        }

        function patch() {
            if (!isEnabled()) return false;
            const table = findMatchesTable();
            if (!table) return false;
            ensureStyle();
            return updateFullMapNames(table);
        }

        function runPatchSafely(context) {
            try {
                return patch();
            } catch (error) {
                warn(`Full map-name patch failed during ${context}.`, error);
                return false;
            }
        }

        function startObserver() {
            if (observer || !document.documentElement) return;
            observer = new MutationObserver((mutations) => {
                const mayAffectTable = mutations.some((mutation) => {
                    const target = mutation.target.nodeType === Node.ELEMENT_NODE
                        ? mutation.target
                        : mutation.target.parentElement;
                    if (target?.closest('.hltv-sp-full-map-name')) return false;
                    if (target?.closest('table.stats-table')) return true;
                    return [...mutation.addedNodes].some((node) => (
                        node.nodeType === Node.ELEMENT_NODE
                        && (
                            node.matches?.('table.stats-table')
                            || node.querySelector?.('table.stats-table')
                        )
                    ));
                });
                if (!mayAffectTable) return;
                window.clearTimeout(debounceTimer);
                debounceTimer = window.setTimeout(() => {
                    if (isEnabled()) runPatchSafely('observer update');
                }, OBSERVER_DEBOUNCE_MS);
            });
            observer.observe(document.documentElement, {
                childList: true,
                subtree: true,
            });
        }

        function setup() {
            if (!isEnabled()) return;
            if (!active) {
                active = true;
                startObserver();
            }
            runPatchSafely('initial setup');
        }

        function teardown() {
            active = false;
            if (debounceTimer) {
                window.clearTimeout(debounceTimer);
                debounceTimer = null;
            }
            observer?.disconnect();
            observer = null;
            restoreMapCodes();
            document.getElementById(STYLE_ID)?.remove();
        }

        function sync() {
            if (isEnabled()) runWhenDocumentReady(setup);
            else teardown();
        }

        return { sync, teardown };
    })();


    async function main() {
        await ensurePrivateStorageReady();
        const styleClaim = injectStyles();
        if (!featureRuntimeEnabled) {
            if (hasCompleteCurrentUi()) return;
            state.settings = await loadSettings();
            createSettingsModal();
            createCogwheel();
            styleClaim.style.dataset.hltvSpRuntimeState = 'settings-only';
            await setupCrossTabSync();
            return;
        }
        if (styleClaim.created) {
            removeManagedUi();
        } else {
            if (hasCompleteCurrentUi()) return;
            const startedAt = Number(styleClaim.style.dataset.hltvSpStartedAt);
            const recentlyStarted = styleClaim.style.dataset.hltvSpRuntimeState === 'starting'
                && Number.isFinite(startedAt)
                && Date.now() - startedAt < 30000;
            if (recentlyStarted) return;

            removeManagedUi();
            styleClaim.style.dataset.hltvSpRuntimeState = 'starting';
            styleClaim.style.dataset.hltvSpStartedAt = String(Date.now());
        }

        sweepTransientActionStorage();
        installSavedDraftStorageListener();
        installSavedDraftIdentityObserver();
        installNativeMutationGuard();
        const [settings, forumCache] = await Promise.all([loadSettings(), loadFeatureData()]);
        state.settings = settings;
        state.forumCacheById = forumCache;
        state.initialDataReady = true;
        applyBooleanEnhancements();

        createSettingsModal();
        createCogwheel();
        styleClaim.style.dataset.hltvSpRuntimeState = 'ui-ready';
        document.documentElement.dataset.hltvSpVersion = SCRIPT_VERSION;
        console.info(`[HLTV Enhancements] v${SCRIPT_VERSION} active.`);
        syncOptionalModules();
        observeContentEnhancements();
        setupCrossTabSync().catch((error) => log('Cross-tab synchronization is unavailable.', error));
        WarColumnPreferenceSync.setup().catch((error) => {
            log('WAR column preference synchronization is unavailable.', error);
        });

        state.sidebar = await waitForSidebar();
        if (!state.sidebar) {
            warn('Could not find HLTV recent activity sidebar.');
            return;
        }

        applyBooleanEnhancements();
        if (state.settings.enableCustomThreadFetching) harvestSportModeActivityEntries();
        annotateActivityLinks();
        captureDefaultOrder();
        createSortButton();
        createThreadPreviewPopup();
        observeSidebar();
        startRelativeAgeTimer();

        const result = await refreshFetchedForumThreads();
        if (result.failedCount > 0) {
            warn(`${result.failedCount} selected activity-source fetch failed.`);
        }
    }

    runWhenDocumentReady(() => {
        main().catch((error) => warn('Script initialisation failed.', error));
    });
})();
