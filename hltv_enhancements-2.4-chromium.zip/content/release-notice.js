// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Plennhar

(async () => {
    'use strict';

    if (globalThis.HLTV_EXTENSION_GATE
        && !await globalThis.HLTV_EXTENSION_GATE.ready) return;

    // Keep the version and its user-facing notes together. The integration test
    // compares this release with the manifest so a version bump needs new notes.
    const RELEASE = Object.freeze({
        version: '2.4',
        notes: Object.freeze([
            'Search authored threads and forum posts directly on a profile, and load more history when needed.',
            'Profile history sort links no longer receive local user-score badges.',
            'Disable all enhancements from the first checkbox in settings. Save, then manually reload HLTV tabs to apply the change.',
            'Match predictions offer Market + stats, Stats only and Market-estimated modes, with an adjustable market weight for the blend, cached weekly HLTV rankings, and analysis of maps and vetoes.',
            'Expanded player comparisons include the new role statistics, side filters and shared role baselines.',
        ]),
    });
    const BOOT_KEY = '__HLTV_SP_RELEASE_NOTICE_BOOTED__';
    if (globalThis[BOOT_KEY]) return;
    globalThis[BOOT_KEY] = true;

    const NOTICE_ID = 'hltv-sp-release-notice';
    const STYLE_ID = 'hltv-sp-release-notice-style';
    const STORAGE_KEY = `releaseNoticeDismissed:${RELEASE.version}`;
    const storage = globalThis.browser?.storage;
    let dismissed = false;
    let notice = null;
    let readFailed = false;
    let spacer = null;
    let resizeObserver = null;
    let layout = null;

    function rememberProperty(node, property) {
        const style = node.style;
        return { node, hadStyleAttribute: node.hasAttribute('style'),
            style, property, value: style.getPropertyValue(property),
            priority: style.getPropertyPriority(property), writtenValue: null, writtenPriority: null };
    }

    function writeProperty(saved, value) {
        if (saved.superseded) return;
        if (saved.writtenValue !== null
            && (saved.style.getPropertyValue(saved.property) !== saved.writtenValue
                || saved.style.getPropertyPriority(saved.property) !== saved.writtenPriority)) {
            saved.superseded = true;
            return;
        }
        saved.style.setProperty(saved.property, value, 'important');
        saved.writtenValue = saved.style.getPropertyValue(saved.property);
        saved.writtenPriority = saved.style.getPropertyPriority(saved.property);
    }

    function restoreProperty(saved) {
        // Preserve another feature's later changes rather than replacing them.
        if (saved.superseded || saved.style.getPropertyValue(saved.property) !== saved.writtenValue
            || saved.style.getPropertyPriority(saved.property) !== saved.writtenPriority) return;
        if (saved.value) saved.style.setProperty(saved.property, saved.value, saved.priority);
        else saved.style.removeProperty(saved.property);
        if (!saved.hadStyleAttribute && !saved.style.cssText) saved.node.removeAttribute('style');
    }

    function updateLayout() {
        if (!notice || !layout) return;
        const height = Math.ceil(notice.getBoundingClientRect().height);
        spacer.style.height = `${height}px`;
        for (const header of layout.headers) writeProperty(header, `${height}px`);
        writeProperty(layout.sticky, `calc(${layout.stickyBaseline} + ${height}px)`);
    }

    function reserveLayout() {
        // These are HLTV's observed fixed top:0 desktop and smartphone bars.
        // navcon is their static child and must retain its native positioning.
        const headers = [...document.querySelectorAll('.navbar, .navbar-smartphone')]
            .filter((header) => getComputedStyle(header).position === 'fixed');
        const root = document.documentElement;
        const rootComputed = getComputedStyle(root);
        const headerComputed = headers.length ? getComputedStyle(headers[0]) : null;
        const stickyBaseline = rootComputed.getPropertyValue('--sticky-containers-offset').trim()
            || headerComputed?.getPropertyValue('--sticky-containers-offset').trim()
            || rootComputed.getPropertyValue('--navbar-height-gt-smartphone').trim()
            || headerComputed?.getPropertyValue('--navbar-height-gt-smartphone').trim();
        layout = {
            headers: headers.map((header) => rememberProperty(header, 'top')),
            sticky: rememberProperty(root, '--sticky-containers-offset'),
            stickyBaseline: stickyBaseline || '40px',
        };
        spacer = element('div');
        spacer.id = `${NOTICE_ID}-spacer`;
        spacer.setAttribute('aria-hidden', 'true');
        notice.after(spacer);
        updateLayout();
        if (typeof ResizeObserver === 'function') {
            resizeObserver = new ResizeObserver(updateLayout);
            resizeObserver.observe(notice);
        }
        window.addEventListener('resize', updateLayout);
    }

    function releaseLayout() {
        resizeObserver?.disconnect();
        resizeObserver = null;
        window.removeEventListener('resize', updateLayout);
        if (layout) {
            for (const header of layout.headers) restoreProperty(header);
            restoreProperty(layout.sticky);
            layout = null;
        }
        spacer?.remove();
        spacer = null;
        document.getElementById(STYLE_ID)?.remove();
    }

    function hideNotice() {
        dismissed = true;
        releaseLayout();
        notice?.remove();
        notice = null;
        storage?.onChanged?.removeListener(onStorageChanged);
    }

    function onStorageChanged(changes, areaName) {
        if (areaName === 'local' && changes[STORAGE_KEY]?.newValue === true) hideNotice();
    }

    function element(tag, text) {
        const node = document.createElement(tag);
        if (text) node.textContent = text;
        return node;
    }

    function showNotice() {
        if (dismissed || notice || !document.body) return;
        const style = element('style');
        style.id = STYLE_ID;
        style.textContent = `
            #${NOTICE_ID} {
                position: fixed; top: 0; left: 0; z-index: 2147483646;
                box-sizing: border-box;
                width: 100%;
                max-height: calc(100dvh - var(--navbar-height-gt-smartphone, 40px));
                overflow-y: auto;
                background: #263849;
                color: #edf4fa;
                border-bottom: 1px solid #5d7d9b;
                font: 13px/1.5 Arial, sans-serif;
            }
            #${NOTICE_ID} .hltv-sp-release-row {
                display: flex; align-items: stretch;
                position: sticky; top: 0; z-index: 1; background: #263849;
            }
            #${NOTICE_ID} button {
                appearance: none; border: 0; border-radius: 0; margin: 0;
                background: transparent; color: inherit; font: inherit;
                cursor: pointer; min-height: 36px;
            }
            #${NOTICE_ID} button:focus-visible { outline: 2px solid #b8ddff; outline-offset: -3px; }
            #${NOTICE_ID} .hltv-sp-release-toggle { flex: 1; text-align: left; padding: 8px 16px; }
            #${NOTICE_ID} .hltv-sp-release-close { flex: 0 0 40px; font-size: 23px; padding: 0 8px; }
            #${NOTICE_ID} button:hover { background: #354d63; }
            #${NOTICE_ID} .hltv-sp-release-notes { margin: 0; padding: 0 24px 12px 36px; }
            #${NOTICE_ID} .hltv-sp-release-notes[hidden] { display: none !important; }
            #${NOTICE_ID} li { margin: 4px 0; }
            #${NOTICE_ID} .hltv-sp-release-status { margin: 0; padding: 0 16px 8px; }
            #${NOTICE_ID} .hltv-sp-release-status:empty { display: none; }
        `;
        if (!document.getElementById(STYLE_ID)) (document.head || document.documentElement).appendChild(style);
        notice = element('section');
        notice.id = NOTICE_ID;
        notice.dataset.version = RELEASE.version;
        notice.setAttribute('aria-label', `HLTV Enhancements ${RELEASE.version} update`);
        const row = element('div');
        row.className = 'hltv-sp-release-row';
        const toggle = element('button', `HLTV Enhancements ${RELEASE.version} — What’s new`);
        toggle.type = 'button';
        toggle.className = 'hltv-sp-release-toggle';
        toggle.setAttribute('aria-expanded', 'false');
        toggle.setAttribute('aria-controls', `${NOTICE_ID}-notes`);
        const close = element('button', '×');
        close.type = 'button';
        close.className = 'hltv-sp-release-close';
        close.setAttribute('aria-label', 'Dismiss version notice');
        const notes = element('ul');
        notes.id = `${NOTICE_ID}-notes`;
        notes.className = 'hltv-sp-release-notes';
        notes.hidden = true;
        for (const text of RELEASE.notes) notes.appendChild(element('li', text));
        const status = element('p');
        status.className = 'hltv-sp-release-status';
        status.setAttribute('role', 'status');
        if (readFailed) status.textContent = 'Could not read your saved dismissal. You can still close this notice to try saving it.';
        toggle.addEventListener('click', () => {
            notes.hidden = !notes.hidden;
            toggle.setAttribute('aria-expanded', String(!notes.hidden));
        });
        close.addEventListener('click', async () => {
            if (close.disabled) return;
            close.disabled = true;
            status.textContent = '';
            try {
                if (!storage?.local) throw new Error('Extension storage unavailable');
                await storage.local.set({ [STORAGE_KEY]: true });
                hideNotice();
            } catch {
                close.disabled = false;
                status.textContent = 'Could not save your dismissal. Please try again.';
            }
        });
        row.append(toggle, close);
        notice.append(row, notes, status);
        document.body.prepend(notice);
        reserveLayout();
    }

    async function boot() {
        storage?.onChanged?.addListener(onStorageChanged);
        try {
            if (!storage?.local) throw new Error('Extension storage unavailable');
            const values = await storage.local.get(STORAGE_KEY);
            if (values[STORAGE_KEY] === true) hideNotice();
        } catch {
            readFailed = true;
        }
        showNotice();
    }

    if (document.body) void boot();
    else document.addEventListener('DOMContentLoaded', () => void boot(), { once: true });
})();
