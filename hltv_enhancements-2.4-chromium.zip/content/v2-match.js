// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Plennhar

(async () => {
    'use strict';

    if (globalThis.HLTV_EXTENSION_GATE
        && !await globalThis.HLTV_EXTENSION_GATE.ready) return;

    const MODULE_NAME = 'HLTV match-page enhancements';
    const MODULE_API_NAME = 'HLTV_V2_MATCH';
    const STYLE_ID = 'hltv-v2-match-style';
    const DESKTOP_MEDIA_QUERY = '(min-width: 768px)';
    const HEADER_UPDATE_THROTTLE_MS = 120;
    const MAX_DATASET_ATTRIBUTE_LENGTH = 131_072;
    const MAX_PLAYERS_PER_TEAM = 12;
    const MAX_PLAYER_ID_LENGTH = 20;
    const MAX_DISPLAY_TEXT_LENGTH = 80;
    const MAX_URL_LENGTH = 2_048;
    const METRIC_SELECTION_KEY = 'matchPlayerPrimaryMetrics';
    const DEFAULT_PLAYER_METRIC_KEYS = Object.freeze(['rating', 'kpr']);
    const STORAGE_DEFAULTS = Object.freeze({
        enableStickyMatchHeader: true,
        enableMatchPlayerFormOverlays: true,
        [METRIC_SELECTION_KEY]: DEFAULT_PLAYER_METRIC_KEYS,
        matchPlayerPrimaryMetric1: 'rating',
        matchPlayerPrimaryMetric2: 'kpr',
    });

    const BOOLEAN_SETTING_KEYS = Object.freeze([
        'enableStickyMatchHeader',
        'enableMatchPlayerFormOverlays',
    ]);
    const METRIC_SETTING_KEYS = Object.freeze([
        METRIC_SELECTION_KEY,
        'matchPlayerPrimaryMetric1',
        'matchPlayerPrimaryMetric2',
    ]);
    const RELEVANT_SETTING_KEYS = new Set([
        ...BOOLEAN_SETTING_KEYS,
        ...METRIC_SETTING_KEYS,
    ]);

    const PLAYER_METRICS = Object.freeze([
        Object.freeze({
            key: 'rating',
            label: 'Rating',
            compactLabel: 'RTG',
            formattedKey: 'rating',
            numericKey: 'numericRating',
            digits: 2,
        }),
        Object.freeze({
            key: 'kpr',
            label: 'KPR',
            formattedKey: 'kpr',
            numericKey: 'numericKpr',
            digits: 2,
        }),
        Object.freeze({
            key: 'dpr',
            label: 'DPR',
            formattedKey: 'dpr',
            numericKey: 'numericDpr',
            digits: 2,
        }),
        Object.freeze({
            key: 'kast',
            label: 'KAST',
            formattedKey: 'kast',
            numericKey: 'numericKast',
            digits: 1,
            percent: true,
        }),
        Object.freeze({
            key: 'adr',
            label: 'ADR',
            formattedKey: 'adr',
            numericKey: 'numericAdr',
            digits: 1,
        }),
        Object.freeze({
            key: 'multiKillRating',
            label: 'Multi-kill',
            compactLabel: 'MK',
            formattedKey: 'multiKillRating',
            numericKey: 'numericMultiKillRating',
            digits: 2,
        }),
        Object.freeze({
            key: 'roundSwing',
            label: 'Round Swing',
            compactLabel: 'Swing',
            formattedKey: 'roundSwing',
            numericKey: 'numericRoundSwing',
            digits: 2,
            percent: true,
            signed: true,
        }),
    ]);
    const PLAYER_METRIC_BY_KEY = new Map(
        PLAYER_METRICS.map((metric) => [metric.key, metric]),
    );
    const METRIC_ALIASES = new Map([
        ['rating', 'rating'],
        ['kpr', 'kpr'],
        ['killsperround', 'kpr'],
        ['dpr', 'dpr'],
        ['deathsperround', 'dpr'],
        ['kast', 'kast'],
        ['multikill', 'multiKillRating'],
        ['multikillrating', 'multiKillRating'],
        ['roundswing', 'roundSwing'],
        ['adr', 'adr'],
        ['averagedamageperround', 'adr'],
    ]);

    const state = {
        settings: { ...STORAGE_DEFAULTS },
        usesMetricSelection: false,
        destroyed: false,
        initialised: false,
        syncTimer: 0,
        styleElement: null,
        desktopMedia: null,
        desktopMediaHandler: null,
        storageChangeHandler: null,
        sticky: null,
        player: null,
    };

    const extensionApi = globalThis.browser;
    if (!extensionApi?.storage?.local
        || typeof extensionApi.storage.local.get !== 'function'
        || typeof extensionApi.storage.local.set !== 'function'
        || !extensionApi?.storage?.onChanged
        || typeof extensionApi.storage.onChanged.addListener !== 'function') {
        return;
    }

    function hasOwn(object, key) {
        return Object.prototype.hasOwnProperty.call(object, key);
    }

    function clamp(value, minimum, maximum) {
        return Math.min(maximum, Math.max(minimum, value));
    }

    function boundedText(value, maximumLength = MAX_DISPLAY_TEXT_LENGTH) {
        return String(value ?? '').replace(/\s+/g, ' ').trim().slice(0, maximumLength);
    }

    function normalisedName(value) {
        return boundedText(value, MAX_DISPLAY_TEXT_LENGTH).toLocaleLowerCase();
    }

    function parseFiniteNumber(value) {
        const parsed = Number.parseFloat(String(value ?? '').replace(',', '.'));
        return Number.isFinite(parsed) ? parsed : null;
    }

    function parseInteger(value) {
        const text = String(value ?? '').trim();
        if (!/^\d{1,6}$/.test(text)) return null;
        const parsed = Number.parseInt(text, 10);
        return Number.isSafeInteger(parsed) ? parsed : null;
    }

    function createElement(tagName, className = '', text = '') {
        const element = document.createElement(tagName);
        if (className) element.className = className;
        if (text !== '') element.textContent = text;
        return element;
    }

    function directChildrenWithClass(parent, className) {
        if (!(parent instanceof Element)) return [];
        return [...parent.children].filter((child) => child.classList.contains(className));
    }

    function safeSameOriginHref(value, expectedPathPrefix) {
        const raw = String(value ?? '');
        if (!raw || raw.length > MAX_URL_LENGTH) return '';
        try {
            const url = new URL(raw, location.href);
            if (url.origin !== location.origin || url.protocol !== 'https:') return '';
            if (expectedPathPrefix && !url.pathname.startsWith(expectedPathPrefix)) return '';
            return `${url.pathname}${url.search}${url.hash}`;
        } catch {
            return '';
        }
    }

    function normaliseMetricKey(value, fallbackKey) {
        const alias = String(value ?? '')
            .replace(/[^a-z0-9]/gi, '')
            .toLocaleLowerCase();
        return METRIC_ALIASES.get(alias) || fallbackKey;
    }

    function normaliseMetricSelection(value, legacyFirst, legacySecond) {
        const legacy = [legacyFirst, legacySecond]
            .map((entry, index) => normaliseMetricKey(
                entry,
                DEFAULT_PLAYER_METRIC_KEYS[index],
            ));
        const source = Array.isArray(value) ? value.slice(0, PLAYER_METRICS.length) : legacy;
        const selected = [];
        for (const rawKey of source) {
            const key = normaliseMetricKey(rawKey, '');
            if (key && !selected.includes(key)) selected.push(key);
        }
        return selected.length ? selected : [...DEFAULT_PLAYER_METRIC_KEYS];
    }

    function selectedPrimaryMetrics() {
        return normaliseMetricSelection(
            state.settings[METRIC_SELECTION_KEY],
            state.settings.matchPlayerPrimaryMetric1,
            state.settings.matchPlayerPrimaryMetric2,
        ).map((key) => PLAYER_METRIC_BY_KEY.get(key));
    }

    function normaliseSettings(stored) {
        const next = { ...STORAGE_DEFAULTS };
        for (const key of BOOLEAN_SETTING_KEYS) {
            if (typeof stored?.[key] === 'boolean') next[key] = stored[key];
        }
        next.matchPlayerPrimaryMetric1 = normaliseMetricKey(
            stored?.matchPlayerPrimaryMetric1,
            STORAGE_DEFAULTS.matchPlayerPrimaryMetric1,
        );
        next.matchPlayerPrimaryMetric2 = normaliseMetricKey(
            stored?.matchPlayerPrimaryMetric2,
            STORAGE_DEFAULTS.matchPlayerPrimaryMetric2,
        );
        next[METRIC_SELECTION_KEY] = normaliseMetricSelection(
            stored?.[METRIC_SELECTION_KEY],
            next.matchPlayerPrimaryMetric1,
            next.matchPlayerPrimaryMetric2,
        );
        return next;
    }

    function isMatchPageRoute() {
        return /^\/matches\/\d{1,20}(?:\/|$)/.test(location.pathname);
    }

    function getMatchPage() {
        if (!isMatchPageRoute()) return null;
        return document.querySelector('.match-page[data-match-page], .match-page');
    }

    function installStyle() {
        if (state.styleElement?.isConnected) return;
        const existing = document.getElementById(STYLE_ID);
        if (existing) {
            state.styleElement = existing;
            return;
        }
        const style = document.createElement('style');
        style.id = STYLE_ID;
        style.textContent = `
            button[class^="hltv-v2-match-"],
            button[class*=" hltv-v2-match-"],
            [class^="hltv-v2-match-"] button,
            [class*=" hltv-v2-match-"] button {
                cursor: pointer;
            }

            .hltv-v2-match-sticky[hidden],
            .hltv-v2-match-player-popover[hidden] {
                display: none !important;
            }

            .hltv-v2-match-sticky {
                position: fixed;
                top: var(--sticky-containers-offset, var(--navbar-height-gt-smartphone, 40px));
                /* Stay above match content but below HLTV's main-menu popups. */
                z-index: 90;
                box-sizing: border-box;
                display: grid;
                grid-template-columns: minmax(100px, 1fr) minmax(180px, 1.4fr) minmax(100px, 1fr);
                align-items: center;
                gap: 10px;
                min-height: 54px;
                padding: 6px 10px;
                border: 1px solid #435467;
                border-top: 2px solid #87a3bf;
                background: #2d3844;
                color: #d8dde2;
                box-shadow: 0 4px 12px rgba(0, 0, 0, .35);
            }

            .hltv-v2-match-sticky-team {
                min-width: 0;
                display: flex;
                align-items: center;
                gap: 7px;
                color: inherit;
                text-decoration: none;
            }

            .hltv-v2-match-sticky-team:last-child {
                flex-direction: row-reverse;
                text-align: right;
            }

            .hltv-v2-match-sticky-team-name {
                color: #87a3bf;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                font-weight: 700;
            }

            .hltv-v2-match-sticky-team-score {
                flex: 0 0 auto;
                color: #fff;
                font-size: 16px;
                font-weight: 700;
            }

            .hltv-v2-match-sticky-center {
                min-width: 0;
                text-align: center;
                line-height: 1.35;
            }

            .hltv-v2-match-sticky-status {
                color: #fff;
                font-weight: 700;
            }

            .hltv-v2-match-sticky-status-live {
                color: #ff5b63;
            }

            .hltv-v2-match-sticky-detail,
            .hltv-v2-match-sticky-meta {
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }

            .hltv-v2-match-sticky-meta {
                color: #929a9e;
                font-size: 11px;
            }

            .hltv-v2-match-sticky-event {
                color: inherit;
                text-decoration: none;
            }

            .hltv-v2-match-sticky-event:hover,
            .hltv-v2-match-sticky-event:focus-visible {
                color: #87a3bf;
                text-decoration: underline;
            }

            .hltv-v2-match-player-config {
                position: relative;
                z-index: 20;
                display: flex;
                justify-content: flex-end;
                margin: -2px 0 6px;
            }

            .hltv-v2-match-player-config-trigger,
            .hltv-v2-match-player-config-action {
                min-height: 25px;
                border: 1px solid #435467;
                border-radius: 2px;
                background: #2d3844;
                color: #d8dde2;
                font: inherit;
                font-size: 10px;
            }

            .hltv-v2-match-player-config-trigger {
                padding: 3px 8px;
            }

            .hltv-v2-match-player-config-trigger:hover,
            .hltv-v2-match-player-config-trigger:focus-visible,
            .hltv-v2-match-player-config-action:hover,
            .hltv-v2-match-player-config-action:focus-visible {
                border-color: #87a3bf;
                outline: 1px solid #87a3bf;
                outline-offset: 0;
            }

            .hltv-v2-match-player-config-panel {
                position: absolute;
                top: calc(100% + 4px);
                right: 0;
                box-sizing: border-box;
                width: min(270px, calc(100vw - 20px));
                padding: 10px;
                border: 1px solid #435467;
                border-top: 2px solid #87a3bf;
                border-radius: 2px;
                background: #202a34;
                color: #d8dde2;
                box-shadow: 0 6px 18px rgba(0, 0, 0, .45);
            }

            .hltv-v2-match-player-config-panel[hidden] {
                display: none !important;
            }

            .hltv-v2-match-player-config-title {
                margin-bottom: 2px;
                color: #87a3bf;
                font-size: 11px;
                font-weight: 700;
            }

            .hltv-v2-match-player-config-description {
                margin-bottom: 8px;
                color: #929a9e;
                font-size: 10px;
                line-height: 1.35;
            }

            .hltv-v2-match-player-config-options {
                display: grid;
                grid-template-columns: repeat(2, minmax(0, 1fr));
                gap: 5px 10px;
            }

            .hltv-v2-match-player-config-option {
                display: flex;
                align-items: center;
                gap: 5px;
                min-width: 0;
                font-size: 10px;
            }

            .hltv-v2-match-player-config-option input {
                accent-color: #87a3bf;
                margin: 0;
            }

            .hltv-v2-match-player-config-error {
                margin-top: 7px;
                color: #ff8b8b;
                font-size: 10px;
            }

            .hltv-v2-match-player-config-error[hidden] {
                display: none !important;
            }

            .hltv-v2-match-player-config-actions {
                display: flex;
                justify-content: flex-end;
                gap: 6px;
                margin-top: 9px;
            }

            .hltv-v2-match-player-config-action {
                padding: 3px 8px;
            }

            .hltv-v2-match-player-config-action-primary {
                background: #435f7a;
                color: #fff;
                font-weight: 700;
            }

            .hltv-v2-match-player-anchor {
                position: relative;
            }

            .hltv-v2-match-player-primary {
                position: absolute;
                z-index: 5;
                right: 3px;
                bottom: 3px;
                display: flex;
                flex-direction: column;
                align-items: flex-end;
                gap: 1px;
                max-width: calc(100% - 6px);
                padding: 2px 3px;
                border: 1px solid #435467;
                border-radius: 2px;
                background: rgba(32, 42, 52, .96);
                color: #d8dde2;
                font: inherit;
                font-size: 10px;
                line-height: 1.2;
                cursor: pointer;
            }

            .hltv-v2-match-player-primary:focus-visible {
                outline: 2px solid #87a3bf;
                outline-offset: 1px;
            }

            .hltv-v2-match-player-primary-metrics {
                display: flex;
                flex-direction: column;
                align-items: flex-end;
                gap: 1px;
                max-width: 100%;
            }

            .hltv-v2-match-player-primary-many {
                width: calc(100% - 6px);
                align-items: stretch;
            }

            .hltv-v2-match-player-primary-many .hltv-v2-match-player-primary-metrics {
                display: grid;
                grid-template-columns: repeat(2, minmax(0, 1fr));
                gap: 1px 5px;
                width: 100%;
            }

            .hltv-v2-match-player-primary-metric {
                display: flex;
                justify-content: flex-end;
                gap: 2px;
                min-width: 0;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }

            .hltv-v2-match-player-primary-many .hltv-v2-match-player-primary-metric {
                font-size: 9px;
            }

            .hltv-v2-match-player-primary-label {
                color: #929a9e;
            }

            .hltv-v2-match-player-primary-value {
                color: #fff;
                font-weight: 700;
            }

            .hltv-v2-match-player-primary-period {
                color: #929a9e;
                font-size: 8px;
                font-weight: 600;
                line-height: 1.1;
                white-space: nowrap;
                align-self: flex-end;
            }

            .hltv-v2-match-player-popover {
                position: fixed;
                z-index: 1200;
                box-sizing: border-box;
                width: min(240px, calc(100vw - 16px));
                padding: 9px;
                border: 1px solid #435467;
                border-top: 2px solid #87a3bf;
                border-radius: 2px;
                background: #202a34;
                color: #d8dde2;
                box-shadow: 0 5px 16px rgba(0, 0, 0, .45);
                font-size: 11px;
            }

            .hltv-v2-match-player-popover-title {
                margin-bottom: 2px;
                color: #87a3bf;
                font-weight: 700;
            }

            .hltv-v2-match-player-popover-period {
                margin-bottom: 7px;
                color: #929a9e;
                font-size: 10px;
            }

            .hltv-v2-match-player-popover-row {
                display: flex;
                justify-content: space-between;
                gap: 10px;
                padding: 2px 0;
                border-top: 1px solid rgba(67, 84, 103, .55);
            }
            .hltv-v2-match-player-popover-empty {
                padding-top: 2px;
                color: #929a9e;
                font-size: 10px;
                line-height: 1.35;
            }

            .hltv-v2-match-player-popover-value {
                color: #fff;
                font-weight: 700;
            }

            @media (max-width: 767px) {
                .hltv-v2-match-sticky {
                    display: none !important;
                }
            }
        `;
        (document.head || document.documentElement)?.appendChild(style);
        state.styleElement = style;
    }

    function removeStyleIfUnused() {
        if (state.settings.enableStickyMatchHeader
            || state.settings.enableMatchPlayerFormOverlays) return;
        state.styleElement?.remove();
        state.styleElement = null;
    }

    function extractHeaderTeams(teamsBox) {
        const containers = [...teamsBox.children].filter((child) => (
            child.classList.contains('team') || child.classList.contains('noteam')
        )).slice(0, 2);
        while (containers.length < 2) containers.push(null);
        return containers.map((container) => {
            const rawName = boundedText(container?.querySelector('.teamName')?.textContent);
            const link = container?.querySelector('a[href]');
            const scoreElement = container?.querySelector('.won, .lost');
            return {
                name: rawName || 'TBD',
                href: safeSameOriginHref(link?.getAttribute('href'), '/team/'),
                score: parseInteger(scoreElement?.textContent),
                winner: Boolean(scoreElement?.classList.contains('won')),
            };
        });
    }

    function extractSeriesScore(matchPage, teams) {
        const score = [0, 0];
        const teamNames = teams.map((team) => normalisedName(team.name));
        for (const result of matchPage.querySelectorAll('.maps .mapholder .results.played')) {
            const winner = result.querySelector('.results-left.won, .results-right.won');
            if (!winner) continue;
            const winnerName = normalisedName(
                winner.querySelector('.results-teamname')?.textContent,
            );
            let teamIndex = teamNames.indexOf(winnerName);
            if (teamIndex < 0) {
                teamIndex = winner.classList.contains('results-right') ? 1 : 0;
            }
            score[teamIndex] += 1;
        }
        return score;
    }

    function extractCurrentLiveMap(matchPage, teams) {
        const scoreboard = matchPage.querySelector('.scoreboard');
        if (!scoreboard) return null;
        const currentRoundText = boundedText(
            scoreboard.querySelector('.currentRoundText')?.textContent,
            100,
        );
        const roundMatch = currentRoundText.match(/^(\d{1,3})\s*-\s*(.+)$/);
        const round = roundMatch ? parseInteger(roundMatch[1]) : null;
        let mapName = roundMatch ? boundedText(roundMatch[2], 40) : '';
        if (!mapName) {
            const incompleteMap = [...matchPage.querySelectorAll('.maps .mapholder')]
                .find((mapholder) => (
                    !mapholder.querySelector('.results.played')
                    && boundedText(mapholder.querySelector('.mapname')?.textContent) !== 'TBA'
                ));
            mapName = boundedText(incompleteMap?.querySelector('.mapname')?.textContent, 40);
        }

        const sideScores = [
            parseInteger(scoreboard.querySelector('.ctScore')?.textContent),
            parseInteger(scoreboard.querySelector('.tScore')?.textContent),
        ];
        const scoreboardTeamNames = [...scoreboard.querySelectorAll('table.team thead .teamName')]
            .slice(0, 2)
            .map((element) => normalisedName(element.textContent));
        const headerTeamNames = teams.map((team) => normalisedName(team.name));
        const teamScores = [null, null];
        scoreboardTeamNames.forEach((name, sideIndex) => {
            const teamIndex = headerTeamNames.indexOf(name);
            if (teamIndex >= 0) teamScores[teamIndex] = sideScores[sideIndex];
        });

        return {
            mapName,
            round,
            teamScores,
            clock: boundedText(scoreboard.querySelector('.timeText')?.textContent, 40),
        };
    }

    function extractMatchHeaderData(matchPage) {
        const teamsBox = directChildrenWithClass(matchPage, 'teamsBox')[0]
            || matchPage.querySelector('.teamsBox');
        if (!teamsBox) return null;
        const teams = extractHeaderTeams(teamsBox);
        const center = directChildrenWithClass(teamsBox, 'timeAndEvent')[0]
            || teamsBox.querySelector('.timeAndEvent');
        const countdown = center?.querySelector('.countdown');
        const statusText = boundedText(countdown?.textContent, 60);
        const hasTbd = directChildrenWithClass(teamsBox, 'noteam').length > 0;
        const live = Boolean(countdown?.classList.contains('countdown-live'))
            || statusText.toLocaleUpperCase() === 'LIVE';
        const finished = !live && (
            teams.some((team) => team.score !== null)
            || /^(?:match over|finished)$/i.test(statusText)
        );
        const stateName = hasTbd ? 'tbd' : live ? 'live' : finished ? 'finished' : 'scheduled';
        const formatText = boundedText(
            matchPage.querySelector('.veto-box .preformatted-text')?.textContent
                ?.split(/\r?\n/)[0],
            60,
        );
        const eventElement = center?.querySelector('.event');
        const eventLink = eventElement?.closest('a[href]')
            || eventElement?.querySelector('a[href]');
        const base = {
            stateName,
            teams,
            title: boundedText(center?.querySelector(':scope > .text')?.textContent, 100),
            time: boundedText(center?.querySelector('.time')?.textContent, 20),
            date: boundedText(center?.querySelector('.date')?.textContent, 50),
            event: boundedText(eventElement?.textContent, 100),
            eventHref: safeSameOriginHref(
                eventLink?.getAttribute('href'),
                '/events/',
            ),
            status: statusText,
            format: formatText,
            seriesScore: null,
            currentMap: null,
        };
        if (live) {
            base.seriesScore = extractSeriesScore(matchPage, teams);
            base.currentMap = extractCurrentLiveMap(matchPage, teams);
        } else if (finished) {
            base.seriesScore = teams.map((team) => team.score);
        }
        return base;
    }

    function appendTeamContent(container, team, score) {
        const name = createElement('span', 'hltv-v2-match-sticky-team-name', team.name);
        container.appendChild(name);
        if (score !== null && score !== undefined) {
            container.appendChild(createElement(
                'span',
                'hltv-v2-match-sticky-team-score',
                String(score),
            ));
        }
    }

    function createStickyTeam(team, score) {
        if (team.href) {
            const link = createElement('a', 'hltv-v2-match-sticky-team');
            link.href = team.href;
            appendTeamContent(link, team, score);
            return link;
        }
        const container = createElement('div', 'hltv-v2-match-sticky-team');
        appendTeamContent(container, team, score);
        return container;
    }

    function renderStickyHeader(matchPage) {
        if (!state.sticky?.header) return;
        const data = extractMatchHeaderData(matchPage);
        if (!data) return;
        const signature = JSON.stringify(data);
        if (signature === state.sticky.signature) return;
        state.sticky.signature = signature;

        const teamScores = data.seriesScore || data.teams.map((team) => team.score);
        const left = createStickyTeam(data.teams[0], teamScores?.[0]);
        const right = createStickyTeam(data.teams[1], teamScores?.[1]);
        const center = createElement('div', 'hltv-v2-match-sticky-center');
        const status = createElement('div', 'hltv-v2-match-sticky-status');
        if (data.stateName === 'live') {
            status.textContent = 'LIVE';
            status.classList.add('hltv-v2-match-sticky-status-live');
        } else if (data.stateName === 'finished') {
            status.textContent = data.status || 'Match over';
        } else if (data.stateName === 'tbd') {
            status.textContent = data.title || data.status || 'Teams to be determined';
        } else {
            status.textContent = data.status || [data.time, data.date].filter(Boolean).join(' · ');
        }
        center.appendChild(status);

        if (data.stateName === 'tbd' && data.status && data.status !== data.title) {
            center.appendChild(createElement(
                'div',
                'hltv-v2-match-sticky-detail',
                data.status,
            ));
        }

        if (data.stateName === 'live') {
            const seriesText = data.seriesScore
                ? `Series ${data.seriesScore[0]}–${data.seriesScore[1]}`
                : 'Series live';
            const parts = [seriesText];
            if (data.currentMap?.mapName) parts.push(data.currentMap.mapName);
            if (data.currentMap?.round !== null && data.currentMap?.round !== undefined) {
                parts.push(`R${data.currentMap.round}`);
            }
            if (data.currentMap?.teamScores?.every((score) => score !== null)) {
                parts.push(
                    `${data.teams[0].name} ${data.currentMap.teamScores[0]}–`
                    + `${data.currentMap.teamScores[1]} ${data.teams[1].name}`,
                );
            } else if (data.currentMap?.clock) {
                parts.push(data.currentMap.clock);
            }
            center.appendChild(createElement(
                'div',
                'hltv-v2-match-sticky-detail',
                parts.join(' · '),
            ));
        }

        const metaParts = [];
        if (data.event) {
            if (data.eventHref) {
                const eventLink = createElement(
                    'a',
                    'hltv-v2-match-sticky-event',
                    data.event,
                );
                eventLink.href = data.eventHref;
                metaParts.push(eventLink);
            } else {
                metaParts.push(document.createTextNode(data.event));
            }
        }
        if (data.format) metaParts.push(document.createTextNode(data.format));
        if (data.stateName !== 'live' && data.stateName !== 'finished') {
            const schedule = [data.time, data.date].filter(Boolean).join(' · ');
            if (schedule) metaParts.push(document.createTextNode(schedule));
        }
        const meta = createElement('div', 'hltv-v2-match-sticky-meta');
        metaParts.forEach((part, index) => {
            if (index > 0) meta.appendChild(document.createTextNode(' · '));
            meta.appendChild(part);
        });
        center.appendChild(meta);
        state.sticky.header.replaceChildren(left, center, right);
        state.sticky.header.dataset.matchState = data.stateName;
    }

    function alignStickyHeader() {
        const sticky = state.sticky;
        if (!sticky?.header || !sticky.matchPage?.isConnected) return;
        const rectangle = sticky.matchPage.getBoundingClientRect();
        if (Number.isFinite(rectangle.left) && Number.isFinite(rectangle.width)
            && rectangle.width > 0) {
            sticky.header.style.left = `${Math.round(rectangle.left)}px`;
            sticky.header.style.width = `${Math.round(rectangle.width)}px`;
        } else {
            sticky.header.style.left = '0px';
            sticky.header.style.width = '100%';
        }
    }

    function mutationTouchesStickyData(mutation) {
        const target = mutation.target.nodeType === Node.ELEMENT_NODE
            ? mutation.target
            : mutation.target.parentElement;
        if (target?.closest('.teamsBox, .maps, .scoreboard')) return true;
        for (const node of mutation.addedNodes) {
            if (!(node instanceof Element)) continue;
            if (node.matches('.teamsBox, .maps, .scoreboard')
                || node.querySelector('.teamsBox, .maps, .scoreboard')) return true;
        }
        return false;
    }

    function scheduleStickyUpdate() {
        const sticky = state.sticky;
        if (!sticky || sticky.updateTimer) return;
        sticky.updateTimer = globalThis.setTimeout(() => {
            if (!state.sticky || state.sticky !== sticky) return;
            sticky.updateTimer = 0;
            renderStickyHeader(sticky.matchPage);
            alignStickyHeader();
        }, HEADER_UPDATE_THROTTLE_MS);
    }

    function setupStickyHeader(matchPage) {
        if (state.sticky?.matchPage === matchPage) {
            renderStickyHeader(matchPage);
            return;
        }
        cleanupStickyHeader();
        installStyle();

        const teamsBox = directChildrenWithClass(matchPage, 'teamsBox')[0]
            || matchPage.querySelector('.teamsBox');
        if (!teamsBox) return;
        const header = createElement('section', 'hltv-v2-match-sticky');
        header.hidden = true;
        header.setAttribute('aria-label', 'Compact match status');
        document.body.appendChild(header);

        const sticky = {
            matchPage,
            teamsBox,
            header,
            signature: '',
            intersectionObserver: null,
            mutationObserver: null,
            resizeObserver: null,
            updateTimer: 0,
            frame: 0,
            scrollHandler: null,
            resizeHandler: null,
        };
        state.sticky = sticky;
        renderStickyHeader(matchPage);
        alignStickyHeader();

        if (typeof globalThis.IntersectionObserver === 'function') {
            sticky.intersectionObserver = new IntersectionObserver((entries) => {
                if (state.sticky !== sticky) return;
                const entry = entries.find((candidate) => candidate.target === teamsBox);
                if (!entry) return;
                header.hidden = entry.isIntersecting;
                if (!header.hidden) alignStickyHeader();
            }, { threshold: [0, 0.01] });
            sticky.intersectionObserver.observe(teamsBox);
        } else {
            sticky.scrollHandler = () => {
                if (sticky.frame) return;
                sticky.frame = globalThis.requestAnimationFrame(() => {
                    sticky.frame = 0;
                    const rectangle = teamsBox.getBoundingClientRect();
                    header.hidden = rectangle.bottom > 40;
                    if (!header.hidden) alignStickyHeader();
                });
            };
            globalThis.addEventListener('scroll', sticky.scrollHandler, { passive: true });
            sticky.scrollHandler();
        }

        sticky.mutationObserver = new MutationObserver((mutations) => {
            if (mutations.some(mutationTouchesStickyData)) scheduleStickyUpdate();
        });
        sticky.mutationObserver.observe(matchPage, {
            childList: true,
            characterData: true,
            subtree: true,
        });

        sticky.resizeHandler = () => alignStickyHeader();
        globalThis.addEventListener('resize', sticky.resizeHandler, { passive: true });
        if (typeof globalThis.ResizeObserver === 'function') {
            sticky.resizeObserver = new ResizeObserver(() => alignStickyHeader());
            sticky.resizeObserver.observe(matchPage);
        }
    }

    function cleanupStickyHeader() {
        const sticky = state.sticky;
        if (!sticky) return;
        if (sticky.updateTimer) globalThis.clearTimeout(sticky.updateTimer);
        if (sticky.frame) globalThis.cancelAnimationFrame(sticky.frame);
        sticky.intersectionObserver?.disconnect();
        sticky.mutationObserver?.disconnect();
        sticky.resizeObserver?.disconnect();
        if (sticky.scrollHandler) globalThis.removeEventListener('scroll', sticky.scrollHandler);
        if (sticky.resizeHandler) globalThis.removeEventListener('resize', sticky.resizeHandler);
        sticky.header.remove();
        state.sticky = null;
    }

    function parsePlayerDatasetAttribute(container, attributeName) {
        const raw = container?.getAttribute(attributeName) || '';
        if (!raw || raw.length > MAX_DATASET_ATTRIBUTE_LENGTH) return new Map();
        let parsed;
        try {
            parsed = JSON.parse(raw);
        } catch {
            return new Map();
        }
        if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return new Map();
        const players = new Map();
        for (const [rawId, value] of Object.entries(parsed).slice(0, MAX_PLAYERS_PER_TEAM)) {
            const playerId = String(rawId);
            if (!/^\d+$/.test(playerId)
                || playerId.length > MAX_PLAYER_ID_LENGTH
                || !value
                || typeof value !== 'object'
                || Array.isArray(value)) continue;
            const player = {
                playerId,
                nickname: boundedText(value.nickname || `Player ${playerId}`, 50),
            };
            for (const metric of PLAYER_METRICS) {
                const numericValue = Number(value[metric.numericKey]);
                if (Number.isFinite(numericValue)) player[metric.numericKey] = numericValue;
                const formatted = boundedText(value[metric.formattedKey], 20);
                if (/^[+\-]?\d+(?:\.\d+)?%?$/.test(formatted)) {
                    player[metric.formattedKey] = formatted;
                }
            }
            players.set(playerId, player);
        }
        return players;
    }

    function parseInlinePlayerDatasets(matchPage) {
        const container = matchPage.querySelector(
            '.lineups-compare-container[data-team1-players-data][data-team2-players-data]',
        );
        if (!container) return { teams: [new Map(), new Map()], players: new Map() };
        const teams = [
            parsePlayerDatasetAttribute(container, 'data-team1-players-data'),
            parsePlayerDatasetAttribute(container, 'data-team2-players-data'),
        ];
        const players = new Map();
        for (const team of teams) {
            for (const [playerId, player] of team) {
                if (players.size >= MAX_PLAYERS_PER_TEAM * 2) break;
                players.set(playerId, player);
            }
        }
        return { teams, players };
    }

    function formatMetricValue(player, metric) {
        const formatted = boundedText(player?.[metric.formattedKey], 20);
        if (/^[+\-]?\d+(?:\.\d+)?%?$/.test(formatted)) return formatted;
        const numericValue = Number(player?.[metric.numericKey]);
        if (!Number.isFinite(numericValue)) return '—';
        let displayValue = numericValue;
        if (metric.percent && Math.abs(displayValue) <= 1) displayValue *= 100;
        const prefix = metric.signed && displayValue > 0 ? '+' : '';
        return `${prefix}${displayValue.toFixed(metric.digits)}${metric.percent ? '%' : ''}`;
    }

    function createPrimaryMetricElement(player, metric, compact = false) {
        const wrapper = createElement('span', 'hltv-v2-match-player-primary-metric');
        const label = compact && metric.compactLabel ? metric.compactLabel : metric.label;
        if (label !== metric.label) wrapper.title = metric.label;
        wrapper.appendChild(createElement(
            'span',
            'hltv-v2-match-player-primary-label',
            `${label} `,
        ));
        wrapper.appendChild(createElement(
            'span',
            'hltv-v2-match-player-primary-value',
            formatMetricValue(player, metric),
        ));
        return wrapper;
    }

    function ensurePlayerPopover() {
        if (state.player?.popover?.isConnected) return state.player.popover;
        const popover = createElement('div', 'hltv-v2-match-player-popover');
        popover.hidden = true;
        popover.setAttribute('role', 'tooltip');
        document.body.appendChild(popover);
        state.player.popover = popover;
        return popover;
    }

    function positionPlayerPopover(button, popover) {
        const rectangle = button.getBoundingClientRect();
        const viewportWidth = Math.max(document.documentElement.clientWidth, globalThis.innerWidth || 0);
        const viewportHeight = Math.max(document.documentElement.clientHeight, globalThis.innerHeight || 0);
        const width = popover.offsetWidth || 240;
        const height = popover.offsetHeight || 220;
        const left = clamp(rectangle.left, 8, Math.max(8, viewportWidth - width - 8));
        let top = rectangle.bottom + 6;
        if (top + height > viewportHeight - 8) top = Math.max(8, rectangle.top - height - 6);
        popover.style.left = `${Math.round(left)}px`;
        popover.style.top = `${Math.round(top)}px`;
    }

    function hidePlayerPopover(button = null) {
        const playerState = state.player;
        if (!playerState?.popover) return;
        playerState.popover.hidden = true;
        if (button) button.setAttribute('aria-expanded', 'false');
        if (playerState.activeButton && playerState.activeButton !== button) {
            playerState.activeButton.setAttribute('aria-expanded', 'false');
        }
        playerState.activeButton = null;
    }

    function showPlayerPopover(button, player, primaryMetrics) {
        const popover = ensurePlayerPopover();
        const title = createElement(
            'div',
            'hltv-v2-match-player-popover-title',
            player.nickname,
        );
        const period = createElement(
            'div',
            'hltv-v2-match-player-popover-period',
            'Past 3 months',
        );
        const primaryKeys = new Set(primaryMetrics.map((metric) => metric.key));
        const rows = PLAYER_METRICS
            .filter((metric) => !primaryKeys.has(metric.key))
            .map((metric) => {
                const row = createElement('div', 'hltv-v2-match-player-popover-row');
                row.appendChild(createElement('span', '', metric.label));
                row.appendChild(createElement(
                    'span',
                    'hltv-v2-match-player-popover-value',
                    formatMetricValue(player, metric),
                ));
                return row;
            });
        if (!rows.length) {
            rows.push(createElement(
                'div',
                'hltv-v2-match-player-popover-empty',
                'All available statistics are shown on the card.',
            ));
        }
        popover.replaceChildren(title, period, ...rows);

        popover.hidden = false;
        button.setAttribute('aria-expanded', 'true');
        if (state.player.activeButton && state.player.activeButton !== button) {
            state.player.activeButton.setAttribute('aria-expanded', 'false');
        }
        state.player.activeButton = button;
        positionPlayerPopover(button, popover);
    }

    function metricSelectionStoragePayload(value) {
        const keys = normaliseMetricSelection(
            value,
            state.settings.matchPlayerPrimaryMetric1,
            state.settings.matchPlayerPrimaryMetric2,
        );
        const fallbackSecond = keys[0] === 'rating' ? 'kpr' : 'rating';
        return {
            [METRIC_SELECTION_KEY]: keys,
            matchPlayerPrimaryMetric1: keys[0],
            matchPlayerPrimaryMetric2: keys[1] || fallbackSecond,
        };
    }

    function selectedMetricKeysFrom(container) {
        const checked = new Set(
            [...container.querySelectorAll('input[data-match-player-metric]:checked')]
                .map((input) => input.value),
        );
        return PLAYER_METRICS
            .map((metric) => metric.key)
            .filter((key) => checked.has(key));
    }

    function setPlayerConfigOpen(playerState, open) {
        const config = playerState?.config;
        if (!config) return;
        const opening = Boolean(open);
        if (opening) {
            const selected = new Set(selectedPrimaryMetrics().map((metric) => metric.key));
            for (const input of config.panel.querySelectorAll(
                'input[data-match-player-metric]',
            )) {
                input.checked = selected.has(input.value);
            }
            config.apply.disabled = selected.size === 0;
            config.error.textContent = 'Choose at least one statistic.';
            config.error.hidden = true;
        }
        config.panel.hidden = !opening;
        config.trigger.setAttribute('aria-expanded', opening ? 'true' : 'false');
    }

    function setupPlayerMetricConfig(matchPage, playerState) {
        const lineups = matchPage.querySelector('.lineups')
            || matchPage.querySelector('.lineups-compare-container')?.parentElement;
        if (!lineups?.parentElement) return;

        const root = createElement('div', 'hltv-v2-match-player-config');
        const trigger = createElement(
            'button',
            'hltv-v2-match-player-config-trigger',
            'Lineup stats',
        );
        trigger.type = 'button';
        trigger.title = 'Choose statistics shown on player cards';
        trigger.setAttribute('aria-haspopup', 'dialog');
        trigger.setAttribute('aria-expanded', 'false');

        const panel = createElement('div', 'hltv-v2-match-player-config-panel');
        panel.id = 'hltv-v2-match-player-config-panel';
        panel.hidden = true;
        panel.setAttribute('role', 'dialog');
        panel.setAttribute('aria-label', 'Configure lineup player statistics');
        trigger.setAttribute('aria-controls', panel.id);
        panel.append(
            createElement(
                'div',
                'hltv-v2-match-player-config-title',
                'Player-card statistics',
            ),
            createElement(
                'div',
                'hltv-v2-match-player-config-description',
                'Choose one or more Past 3 months statistics to keep visible.',
            ),
        );

        const options = createElement('div', 'hltv-v2-match-player-config-options');
        options.setAttribute('role', 'group');
        options.setAttribute('aria-label', 'Visible player statistics');
        const selected = new Set(selectedPrimaryMetrics().map((metric) => metric.key));
        for (const metric of PLAYER_METRICS) {
            const label = createElement('label', 'hltv-v2-match-player-config-option');
            const input = document.createElement('input');
            input.type = 'checkbox';
            input.value = metric.key;
            input.checked = selected.has(metric.key);
            input.dataset.matchPlayerMetric = metric.key;
            label.append(input, document.createTextNode(metric.label));
            options.appendChild(label);
        }

        const error = createElement(
            'div',
            'hltv-v2-match-player-config-error',
            'Choose at least one statistic.',
        );
        error.hidden = true;
        error.setAttribute('role', 'status');

        const actions = createElement('div', 'hltv-v2-match-player-config-actions');
        const cancel = createElement(
            'button',
            'hltv-v2-match-player-config-action',
            'Cancel',
        );
        cancel.type = 'button';
        const apply = createElement(
            'button',
            'hltv-v2-match-player-config-action hltv-v2-match-player-config-action-primary',
            'Apply',
        );
        apply.type = 'button';
        actions.append(cancel, apply);
        panel.append(options, error, actions);
        root.append(trigger, panel);
        lineups.before(root);

        const config = {
            root,
            trigger,
            panel,
            error,
            apply,
            outsideHandler: null,
            keyHandler: null,
        };
        playerState.config = config;

        const validate = () => {
            const valid = selectedMetricKeysFrom(panel).length > 0;
            apply.disabled = !valid;
            error.textContent = 'Choose at least one statistic.';
            error.hidden = valid;
        };
        options.addEventListener('change', validate);
        trigger.addEventListener('click', (event) => {
            event.stopPropagation();
            setPlayerConfigOpen(playerState, panel.hidden);
            if (!panel.hidden) panel.querySelector('input')?.focus();
        });
        panel.addEventListener('click', (event) => event.stopPropagation());
        cancel.addEventListener('click', () => {
            setPlayerConfigOpen(playerState, false);
            trigger.focus();
        });
        apply.addEventListener('click', async () => {
            const keys = selectedMetricKeysFrom(panel);
            if (!keys.length) {
                validate();
                return;
            }
            apply.disabled = true;
            apply.setAttribute('aria-busy', 'true');
            try {
                await extensionApi.storage.local.set(metricSelectionStoragePayload(keys));
                setPlayerConfigOpen(playerState, false);
            } catch {
                error.textContent = 'The selection could not be saved.';
                error.hidden = false;
                apply.disabled = false;
            } finally {
                apply.removeAttribute('aria-busy');
            }
        });
        config.outsideHandler = (event) => {
            if (!panel.hidden && !root.contains(event.target)) {
                setPlayerConfigOpen(playerState, false);
            }
        };
        config.keyHandler = (event) => {
            if (event.key !== 'Escape' || panel.hidden) return;
            event.preventDefault();
            setPlayerConfigOpen(playerState, false);
            trigger.focus();
        };
        document.addEventListener('pointerdown', config.outsideHandler);
        document.addEventListener('keydown', config.keyHandler);
    }

    function preferredPlayerCards(matchPage) {
        const imageCards = [...matchPage.querySelectorAll(
            '.lineups .lineup .player-image .player-compare[data-player-id]',
        )];
        const candidates = imageCards.length
            ? imageCards
            : [...matchPage.querySelectorAll('.lineups .lineup .player-compare[data-player-id]')];
        const seen = new Set();
        return candidates.filter((card) => {
            const playerId = String(card.dataset.playerId || '');
            if (!/^\d+$/.test(playerId)
                || playerId.length > MAX_PLAYER_ID_LENGTH
                || seen.has(playerId)
                || seen.size >= MAX_PLAYERS_PER_TEAM * 2) return false;
            seen.add(playerId);
            return true;
        });
    }

    function setupPlayerOverlays(matchPage) {
        cleanupPlayerOverlays();
        installStyle();
        const datasets = parseInlinePlayerDatasets(matchPage);
        if (!datasets.players.size) return;
        const playerState = {
            matchPage,
            datasets,
            popover: null,
            activeButton: null,
            buttons: [],
            cards: [],
            config: null,
        };
        state.player = playerState;
        const primaryMetrics = selectedPrimaryMetrics();
        const compact = primaryMetrics.length > 2;
        const remainingMetricCount = PLAYER_METRICS.length - primaryMetrics.length;

        for (const card of preferredPlayerCards(matchPage)) {
            const player = datasets.players.get(String(card.dataset.playerId || ''));
            if (!player) continue;
            const button = createElement('button', 'hltv-v2-match-player-primary');
            if (compact) button.classList.add('hltv-v2-match-player-primary-many');
            button.type = 'button';
            button.setAttribute('aria-expanded', 'false');
            button.setAttribute(
                'aria-label',
                `${player.nickname}, past 3 months: ${primaryMetrics.map((metric) => (
                    `${metric.label} ${formatMetricValue(player, metric)}`
                )).join(', ')}. ${remainingMetricCount
                    ? 'Focus for all other metrics.'
                    : 'All available metrics are shown.'}`,
            );
            const metricList = createElement(
                'span',
                'hltv-v2-match-player-primary-metrics',
            );
            metricList.append(...primaryMetrics.map((metric) => (
                createPrimaryMetricElement(player, metric, compact)
            )));
            button.append(
                createElement(
                    'span',
                    'hltv-v2-match-player-primary-period',
                    'Past 3 months',
                ),
                metricList,
            );
            const show = () => showPlayerPopover(button, player, primaryMetrics);
            const hide = () => hidePlayerPopover(button);
            button.addEventListener('mouseenter', show);
            button.addEventListener('mouseleave', hide);
            button.addEventListener('focus', show);
            button.addEventListener('blur', hide);
            button.addEventListener('keydown', (event) => {
                if (event.key === 'Escape') {
                    hide();
                    button.blur();
                }
            });
            button.addEventListener('click', (event) => event.stopPropagation());
            button.addEventListener('mousedown', (event) => event.stopPropagation());
            card.classList.add('hltv-v2-match-player-anchor');
            card.appendChild(button);
            playerState.buttons.push(button);
            playerState.cards.push(card);
        }
        if (!playerState.buttons.length) {
            cleanupPlayerOverlays();
            return;
        }
        setupPlayerMetricConfig(matchPage, playerState);
    }

    function cleanupPlayerOverlays() {
        const playerState = state.player;
        if (!playerState) return;
        for (const button of playerState.buttons) button.remove();
        for (const card of playerState.cards) card.classList.remove('hltv-v2-match-player-anchor');
        if (playerState.config?.outsideHandler) {
            document.removeEventListener('pointerdown', playerState.config.outsideHandler);
        }
        if (playerState.config?.keyHandler) {
            document.removeEventListener('keydown', playerState.config.keyHandler);
        }
        playerState.config?.root.remove();
        playerState.popover?.remove();
        state.player = null;
    }

    function desktopLayoutMatches() {
        return state.desktopMedia ? state.desktopMedia.matches : true;
    }

    function sync() {
        state.syncTimer = 0;
        if (state.destroyed) return;
        const matchPage = getMatchPage();
        if (!matchPage) {
            cleanupStickyHeader();
            cleanupPlayerOverlays();
            removeStyleIfUnused();
            return;
        }

        if (state.settings.enableStickyMatchHeader && desktopLayoutMatches()) {
            setupStickyHeader(matchPage);
        } else {
            cleanupStickyHeader();
        }
        if (state.settings.enableMatchPlayerFormOverlays) {
            setupPlayerOverlays(matchPage);
        } else {
            cleanupPlayerOverlays();
        }
        removeStyleIfUnused();
    }

    function scheduleSync() {
        if (state.destroyed || state.syncTimer) return;
        state.syncTimer = globalThis.setTimeout(sync, 0);
    }

    function handleStorageChanges(changes, areaName) {
        if (areaName !== 'local' || !changes || typeof changes !== 'object') return;
        let changed = false;
        let legacyMetricChanged = false;
        let metricSelectionChanged = false;
        const next = { ...state.settings };
        for (const [key, change] of Object.entries(changes)) {
            if (!RELEVANT_SETTING_KEYS.has(key)) continue;
            const value = hasOwn(change || {}, 'newValue')
                ? change.newValue
                : STORAGE_DEFAULTS[key];
            if (BOOLEAN_SETTING_KEYS.includes(key)) {
                next[key] = typeof value === 'boolean' ? value : STORAGE_DEFAULTS[key];
            } else if (key === METRIC_SELECTION_KEY) {
                next[key] = normaliseMetricSelection(
                    value,
                    next.matchPlayerPrimaryMetric1,
                    next.matchPlayerPrimaryMetric2,
                );
                state.usesMetricSelection = Array.isArray(value);
                metricSelectionChanged = true;
            } else {
                next[key] = normaliseMetricKey(value, STORAGE_DEFAULTS[key]);
                if (!state.usesMetricSelection) legacyMetricChanged = true;
            }
            changed = true;
        }
        if (!changed) return;
        if (legacyMetricChanged && !metricSelectionChanged) {
            next[METRIC_SELECTION_KEY] = normaliseMetricSelection(
                null,
                next.matchPlayerPrimaryMetric1,
                next.matchPlayerPrimaryMetric2,
            );
        }
        state.settings = next;
        scheduleSync();
    }

    function destroy() {
        if (state.destroyed) return;
        state.destroyed = true;
        if (state.syncTimer) globalThis.clearTimeout(state.syncTimer);
        cleanupStickyHeader();
        cleanupPlayerOverlays();
        state.styleElement?.remove();
        state.styleElement = null;
        if (state.storageChangeHandler) {
            extensionApi.storage.onChanged.removeListener?.(state.storageChangeHandler);
        }
        if (state.desktopMedia && state.desktopMediaHandler) {
            if (typeof state.desktopMedia.removeEventListener === 'function') {
                state.desktopMedia.removeEventListener('change', state.desktopMediaHandler);
            } else {
                state.desktopMedia.removeListener?.(state.desktopMediaHandler);
            }
        }
    }

    function whenDocumentReady() {
        if (document.readyState !== 'loading') return Promise.resolve();
        return new Promise((resolve) => {
            document.addEventListener('DOMContentLoaded', resolve, { once: true });
        });
    }

    async function initialise() {
        await whenDocumentReady();
        if (state.destroyed) return;
        let stored = {};
        try {
            stored = await extensionApi.storage.local.get(Object.keys(STORAGE_DEFAULTS));
        } catch (error) {
            console.warn(`[${MODULE_NAME}] Settings could not be loaded; features remain off.`, error);
        }
        state.settings = normaliseSettings(stored);
        state.storageChangeHandler = handleStorageChanges;
        state.usesMetricSelection = Array.isArray(stored?.[METRIC_SELECTION_KEY]);
        extensionApi.storage.onChanged.addListener(state.storageChangeHandler);
        if (typeof globalThis.matchMedia === 'function') {
            state.desktopMedia = globalThis.matchMedia(DESKTOP_MEDIA_QUERY);
            state.desktopMediaHandler = scheduleSync;
            if (typeof state.desktopMedia.addEventListener === 'function') {
                state.desktopMedia.addEventListener('change', state.desktopMediaHandler);
            } else {
                state.desktopMedia.addListener?.(state.desktopMediaHandler);
            }
        }
        state.initialised = true;
        sync();
    }

    const ready = initialise();
    const api = Object.freeze({
        ready,
        destroy,
    });
    try {
        Object.defineProperty(globalThis, MODULE_API_NAME, {
            configurable: true,
            enumerable: false,
            writable: false,
            value: api,
        });
    } catch {
        // A prior content-script instance owns the namespace; this instance remains isolated.
    }
    globalThis.addEventListener('pagehide', destroy, { once: true });
})();
