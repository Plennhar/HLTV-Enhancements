// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Plennhar

(async () => {
    'use strict';

    if (globalThis.HLTV_EXTENSION_GATE
        && !await globalThis.HLTV_EXTENSION_GATE.ready) return;

    const extensionApi = globalThis.browser;
    const ENABLED_KEY = 'enableDiagnosticLogging';
    const LOG_KEY = 'debugLogV1';
    const MAX_ENTRIES = 500;
    const MAX_BYTES = 256 * 1024;
    const RETENTION_MS = 7 * 24 * 60 * 60 * 1000;
    const FLUSH_DELAY_MS = 1000;
    const MAX_MESSAGE_CHARS = 240;
    const MAX_STACK_FRAMES = 8;
    const LEVELS = new Set(['debug', 'info', 'warn', 'error']);
    const EVENT_CATEGORIES = Object.freeze([
        [/diagnostic/i, 'diagnostics'],
        [/setting/i, 'settings'],
        [/storage|cache|private extension data/i, 'storage'],
        [/action lock|action fence|lease/i, 'action-lock'],
        [/reaction|vote|upvote|downvote/i, 'reaction'],
        [/reply|composer/i, 'reply'],
        [/thread preview/i, 'thread-preview'],
        [/fetch|request|xmlhttprequest/i, 'request'],
        [/forum|sidebar|activity|homepage/i, 'activity'],
        [/username|user tag|block menu/i, 'user-action'],
        [/read state|mark previewed|self-authored/i, 'read-state'],
        [/match team|match filter|additional team/i, 'match-filter'],
        [/layout/i, 'layout'],
        [/win-adjusted|\bwar\b/i, 'war'],
        [/\bkpr\b/i, 'kpr'],
        [/cross-tab|sync/i, 'sync'],
        [/export|local data action/i, 'export'],
        [/initiali[sz]|module/i, 'module'],
    ]);

    if (!extensionApi?.storage?.local
        || typeof extensionApi.storage.local.get !== 'function'
        || typeof extensionApi.storage.local.set !== 'function'
        || !extensionApi.storage.onChanged) return;

    let enabled = false;
    let ready = false;
    let flushTimer = 0;
    let flushPromise = Promise.resolve();
    const pending = [];

    function routeClass(pathname = globalThis.location?.pathname || '/') {
        const path = String(pathname || '/');
        if (path === '/') return 'home';
        if (/^\/forums\/create-thread\/?$/.test(path)) return 'forum-create';
        if (/^\/forums\/threads\/\d+(?:\/|$)/.test(path)) return 'thread';
        if (/^\/forums(?:\/|$)/.test(path)) return 'forum';
        if (/^\/stats\/players\/matches\/\d+(?:\/|$)/.test(path)) {
            return 'stats-player-matches';
        }
        if (/^\/stats\/players(?:\/|$)/.test(path)) return 'stats-players';
        if (/^\/stats(?:\/|$)/.test(path)) return 'stats';
        if (/^\/profile\/\d+(?:\/|$)/.test(path)) return 'profile';
        if (/^\/matches(?:\/|$)/.test(path)) return 'matches';
        if (/^\/news(?:\/|$)/.test(path)) return 'news';
        return 'other';
    }

    function scrubText(value) {
        let text = String(value || '');
        try {
            text = text.normalize('NFKC');
        } catch {
            // Normalization is a hardening aid, not a logging requirement.
        }
        return text
            .replace(/[\u0000-\u001f\u007f]/g, ' ')
            .replace(/\b(?:https?|moz-extension|chrome-extension):\/\/[^\s)]+/gi, '[url]')
            .replace(/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi, '[email]')
            .replace(/\b(?:\d{1,3}\.){3}\d{1,3}\b/g, '[ip]')
            .replace(/\b[0-9a-f]{8}-[0-9a-f-]{27,}\b/gi, '[id]')
            .replace(/\b[A-Za-z0-9_-]{32,}\b/g, '[token]')
            .replace(/\b\d{3,}\b/g, '#')
            .replace(/\s+/g, ' ')
            .trim()
            .slice(0, MAX_MESSAGE_CHARS);
    }

    function safeEventName(value) {
        const text = String(value || '').slice(0, 500);
        const category = EVENT_CATEGORIES.find(([pattern]) => pattern.test(text))?.[1];
        return category ? `extension-${category}` : 'extension-event';
    }

    function extensionStackFrames(error) {
        if (typeof error?.stack !== 'string') return [];
        const frames = [];
        for (const line of error.stack.split('\n')) {
            const match = line.match(
                /(?:(?:moz-extension|chrome-extension):\/\/[^/]+\/)?((?:content|background|popup|ui)\/[A-Za-z0-9._/-]+\.js):(\d+):(\d+)/,
            );
            if (!match) continue;
            frames.push(`${match[1]}:${match[2]}:${match[3]}`);
            if (frames.length >= MAX_STACK_FRAMES) break;
        }
        return frames;
    }

    function safeError(error) {
        if (!error || (typeof error !== 'object' && typeof error !== 'function')) {
            return null;
        }
        const name = /^[A-Za-z][A-Za-z0-9_.-]{0,79}$/.test(String(error.name || ''))
            ? String(error.name)
            : 'Error';
        const code = /^[A-Za-z0-9_.:-]{1,80}$/.test(String(error.code || ''))
            ? String(error.code)
            : '';
        const stack = Array.isArray(error.stack)
            ? error.stack
                .filter((frame) => /^(?:content|background|popup|ui)\/[A-Za-z0-9._/-]+\.js:\d+:\d+$/.test(String(frame)))
                .slice(0, MAX_STACK_FRAMES)
                .map(String)
            : extensionStackFrames(error);
        return {
            name,
            ...(code ? { code } : {}),
            ...(stack.length ? { stack } : {}),
        };
    }

    function validTimestamp(value, now = Date.now()) {
        const timestamp = Number(value);
        return Number.isFinite(timestamp)
            && timestamp >= now - RETENTION_MS
            && timestamp <= now + 60_000
            ? Math.trunc(timestamp)
            : 0;
    }

    function normaliseEntry(value, now = Date.now()) {
        if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
        const at = validTimestamp(value.at, now);
        const level = LEVELS.has(value.level) ? value.level : '';
        const event = safeEventName(value.event);
        const route = /^[a-z][a-z-]{0,39}$/.test(String(value.route || ''))
            ? String(value.route)
            : 'other';
        const count = Math.max(1, Math.min(10_000, Math.trunc(Number(value.count) || 1)));
        if (!at || !level || !event) return null;
        const error = safeError(value.error);
        return { at, level, event, route, count, ...(error ? { error } : {}) };
    }

    function normaliseRecord(value, now = Date.now()) {
        const source = value?.schema === 1 && Array.isArray(value.entries)
            ? value.entries
            : [];
        const entries = [];
        for (const rawEntry of source.slice(-MAX_ENTRIES * 2)) {
            const entry = normaliseEntry(rawEntry, now);
            if (entry) entries.push(entry);
        }
        return entries.slice(-MAX_ENTRIES);
    }

    function sameEntry(first, second) {
        return first?.level === second?.level
            && first?.event === second?.event
            && first?.route === second?.route
            && JSON.stringify(first?.error || null) === JSON.stringify(second?.error || null);
    }

    function mergeEntries(storedEntries, queuedEntries) {
        const merged = [...storedEntries];
        for (const entry of queuedEntries) {
            const previous = merged[merged.length - 1];
            if (sameEntry(previous, entry) && entry.at - previous.at <= 10_000) {
                previous.at = entry.at;
                previous.count = Math.min(10_000, previous.count + entry.count);
            } else {
                merged.push(entry);
            }
        }
        return merged.slice(-MAX_ENTRIES);
    }

    function fitToByteLimit(entries) {
        const bounded = entries.slice(-MAX_ENTRIES);
        while (bounded.length) {
            const record = { schema: 1, updatedAt: Date.now(), entries: bounded };
            if (new Blob([JSON.stringify(record)]).size <= MAX_BYTES) return record;
            bounded.shift();
        }
        return { schema: 1, updatedAt: Date.now(), entries: [] };
    }

    async function flushNow(force = false) {
        if ((!enabled && !force) || !pending.length) return;
        const batch = pending.splice(0, pending.length);
        try {
            const stored = await extensionApi.storage.local.get(LOG_KEY);
            const merged = mergeEntries(
                normaliseRecord(stored?.[LOG_KEY]),
                batch.map((entry) => normaliseEntry(entry)).filter(Boolean),
            );
            await extensionApi.storage.local.set({ [LOG_KEY]: fitToByteLimit(merged) });
        } catch (error) {
            console.warn('[HLTV Enhancements] Diagnostic log write failed.', error);
        }
    }

    function queueFlush() {
        if (flushTimer) return;
        flushTimer = globalThis.setTimeout(() => {
            flushTimer = 0;
            flushPromise = flushPromise.then(() => flushNow());
        }, FLUSH_DELAY_MS);
    }

    function record(level, event, error = null) {
        if (!ready || !enabled || !LEVELS.has(level)) return false;
        const entry = normaliseEntry({
            at: Date.now(),
            level,
            event: safeEventName(event),
            route: routeClass(),
            count: 1,
            error: safeError(error),
        });
        if (!entry) return false;
        pending.push(entry);
        if (pending.length > 100) pending.splice(0, pending.length - 100);
        queueFlush();
        return true;
    }

    async function initialise() {
        try {
            const stored = await extensionApi.storage.local.get([ENABLED_KEY, LOG_KEY]);
            enabled = stored?.[ENABLED_KEY] === true;
            if (stored?.[LOG_KEY]) {
                const entries = normaliseRecord(stored[LOG_KEY]);
                const currentEntries = Array.isArray(stored[LOG_KEY]?.entries)
                    ? stored[LOG_KEY].entries
                    : [];
                if (stored[LOG_KEY]?.schema !== 1
                    || JSON.stringify(entries) !== JSON.stringify(currentEntries)
                    || new Blob([JSON.stringify(stored[LOG_KEY])]).size > MAX_BYTES) {
                    await extensionApi.storage.local.set({ [LOG_KEY]: fitToByteLimit(entries) });
                }
            }
        } catch {
            enabled = false;
        } finally {
            ready = true;
        }
    }

    extensionApi.storage.onChanged.addListener((changes, areaName) => {
        if (areaName !== 'local' || !Object.hasOwn(changes || {}, ENABLED_KEY)) return;
        const nextEnabled = changes[ENABLED_KEY]?.newValue === true;
        if (!nextEnabled && enabled) {
            flushPromise = flushPromise.then(() => flushNow(true));
        }
        enabled = nextEnabled;
        if (enabled) record('info', 'diagnostics-enabled');
    });

    globalThis.addEventListener('pagehide', () => {
        if (flushTimer) {
            globalThis.clearTimeout(flushTimer);
            flushTimer = 0;
        }
        flushPromise = flushPromise.then(() => flushNow(true));
    });

    const readyPromise = initialise();
    const api = Object.freeze({
        ready: () => readyPromise,
        record,
        routeClass,
        scrubText,
        normaliseEventName: safeEventName,
        constants: Object.freeze({
            enabledKey: ENABLED_KEY,
            logKey: LOG_KEY,
            maxEntries: MAX_ENTRIES,
            maxBytes: MAX_BYTES,
            retentionMs: RETENTION_MS,
        }),
    });

    Object.defineProperty(globalThis, 'HLTV_SP_DIAGNOSTICS', {
        configurable: false,
        enumerable: false,
        writable: false,
        value: api,
    });
})();
