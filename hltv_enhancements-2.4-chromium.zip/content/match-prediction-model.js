// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Plennhar

// Pure, bounded parsers and deterministic inference. This module performs no I/O.
(() => {
    'use strict';

    const MODEL_VERSION = 'lineup-map-1';
    const CONFIG = Object.freeze({
        modelVersion: MODEL_VERSION,
        lineupWeight: 0.60,
        mapWeight: 0.30,
        vrsWeight: 0.10,
        ratingSlope: Math.log(1.5) / 0.10,
        recentShare: 5 / 12,
        recentPriorMaps: 10,
        mapPriorWins: 4,
        mapPriorMaps: 8,
        minimumPlayers: 3,
        minimumMapSamples: 5,
        habitPriorOpportunities: 8,
        firstHabitUniformShare: 0.20,
        habitWeight: 0.60,
        utilityTemperature: 0.75,
        maximumPlayers: 30,
        maximumMaps: 9,
        maximumScenarios: 3,
    });
    const clip = (value, low, high) => Math.min(high, Math.max(low, value));
    const finite = (value) => typeof value === 'number' && Number.isFinite(value) ? value : null;
    const number = (value) => {
        if (typeof value === 'number') return finite(value);
        let numericText = String(value ?? '').trim().replace(/(?<=\d)[\s\u00a0\u202f]+(?=\d)/g, '');
        if (!numericText || /^(?:-|—|n\/?a)$/i.test(numericText)) return null;
        // HLTV points use three-digit grouping; decimal odds can use a comma.
        if (!numericText.includes('.')) numericText = numericText.replace(/,(\d{1,2})(?!\d)/g, '.$1');
        numericText = numericText.replace(/,/g, '');
        const match = /[-+]?\d+(?:\.\d+)?/.exec(numericText);
        return match ? finite(Number(match[0])) : null;
    };
    const text = (value, limit = 100) => String(value ?? '').replace(/\s+/g, ' ').trim().slice(0, limit);
    const key = (value) => text(value).toLowerCase().replace(/[^a-z0-9]/g, '');
    const id = (value) => /^\d{1,20}$/.test(String(value ?? '')) ? String(value) : '';
    const sigmoid = (value) => 1 / (1 + Math.exp(-value));
    const logit = (value) => Math.log(clip(value, 1e-9, 1 - 1e-9) / (1 - clip(value, 1e-9, 1 - 1e-9)));
    const percent = (value) => {
        const parsed = number(value);
        if (parsed === null) return null;
        const result = typeof value === 'string' && value.includes('%') ? parsed / 100 : parsed;
        return result >= 0 && result <= 1 ? result : null;
    };
    const count = (value) => {
        const result = number(value);
        return Number.isSafeInteger(result) && result >= 0 && result <= 100000 ? result : null;
    };
    const rating = (value) => {
        const result = number(value);
        return result !== null && result >= 0 && result <= 5 ? result : null;
    };
    const url = (value) => {
        try {
            const result = new URL(String(value ?? ''), 'https://www.hltv.org/');
            return result.protocol === 'https:' && result.hostname === 'www.hltv.org'
                && !result.username && !result.password ? result : null;
        } catch { return null; }
    };
    const plain = (value) => JSON.parse(JSON.stringify(value));

    function parameterEntries(searchParams) {
        const entries = [];
        searchParams.forEach((value, key) => entries.push([key, value]));
        return entries;
    }

    function playerDataset(raw, teamId, declaredVersion) {
        if (typeof raw !== 'string' || raw.length > 128 * 1024) return [];
        try {
            const parsed = JSON.parse(raw);
            if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return [];
            const seen = new Set();
            return Object.entries(parsed).slice(0, CONFIG.maximumPlayers).flatMap(([entryId, player]) => {
                if (!player || typeof player !== 'object') return [];
                const playerId = id(player.playerId ?? entryId);
                if (!playerId || seen.has(playerId) || (id(player.teamId) && id(player.teamId) !== teamId)) return [];
                seen.add(playerId);
                // The recognized current widget has both Rating 3 components. A generic
                // "Rating" label alone never establishes version compatibility.
                const currentAdapter = Object.hasOwn(player, 'numericRoundSwing')
                    && Object.hasOwn(player, 'numericMultiKillRating');
                const explicitVersion = text(player.ratingVersion || declaredVersion);
                const ratingVersion = explicitVersion || (currentAdapter ? '3.0' : null);
                return [{ playerId, nickname: text(player.nickname), rating: rating(player.numericRating),
                    ratingVersion, ratingAdapter: explicitVersion ? 'explicit' : currentAdapter ? 'match-widget-r3' : 'unknown' }];
            });
        } catch { return []; }
    }

    function extractCoreMaps(document, lineups, observedAt) {
        const headers = [...document.querySelectorAll('.map-stats-infobox-header .team a[href]')];
        const coreSources = [0, 1].map((index) => {
            const source = url(headers[index]?.getAttribute('href'));
            return source ? { href: source.href, startDate: source.searchParams.get('startDate'),
                endDate: source.searchParams.get('endDate'), minimumPlayers: Number(source.searchParams.get('minLineupMatch')),
                playerIds: source.searchParams.getAll('lineup') } : null;
        });
        const today = new Date(observedAt).toISOString().slice(0, 10);
        const validDate = (value) => /^\d{4}-\d{2}-\d{2}$/.test(value || '') && Number.isFinite(Date.parse(value))
            && new Date(value).toISOString().slice(0, 10) === value;
        const sameWindow = coreSources.every((source) => source && validDate(source.startDate) && validDate(source.endDate)
            && source.startDate < source.endDate && source.endDate <= today)
            && coreSources[0].startDate === coreSources[1].startDate && coreSources[0].endDate === coreSources[1].endDate;
        const coreVerified = [0, 1].map((index) => {
            const source = url(headers[index]?.getAttribute('href'));
            const ids = source?.searchParams.getAll('lineup') || [];
            const current = (lineups[index] || []).map((player) => player.playerId);
            return sameWindow && source?.pathname === '/stats/lineup/maps' && source.searchParams.get('minLineupMatch') === '3'
                && current.length === 5 && ids.length === 5 && new Set(ids).size === 5
                && current.every((playerId) => ids.includes(playerId));
        });
        const chartNames = (document.querySelector('svg[data-spider-chart]')?.getAttribute('data-spider-chart') || '').split(',').map((name) => key(name));
        const result = new Map();
        for (const row of [...document.querySelectorAll('.map-stats-infobox-maps[data-mapname]')].slice(0, 90)) {
            const name = text(row.querySelector('.mapname')?.textContent || row.dataset.mapname);
            const mapKey = key(name);
            if (!mapKey) continue;
            const entry = result.get(mapKey) || { name, teams: [{}, {}], coreMinimumPlayers: 3 };
            const type = row.closest('[map-stats-infobox]')?.getAttribute('map-stats-infobox') || 'wins';
            const sides = [...row.querySelectorAll('.map-stats-infobox-stats')].slice(0, 2);
            sides.forEach((side, index) => {
                const sideText = text(side.textContent + ' ' + [...side.querySelectorAll('[title]')].map((node) => node.getAttribute('title')).join(' '), 1000);
                let value = percent(side.querySelector('.map-stats-infobox-winpercentage')?.textContent);
                const maps = count(/(\d+)\s+maps?\b/i.exec(sideText)?.[1]);
                const opportunities = count(/(\d+)\s+(?:possibilit(?:y|ies)|opportunities)\b/i.exec(sideText)?.[1]);
                if (/win/i.test(type)) {
                    const overlay = document.querySelector('[data-spider-tab-toggle-value="wins"]');
                    const precisionValues = (overlay?.getAttribute(`data-spider-overlay${index + 1}`) || '').split(',').map(number);
                    const precision = precisionValues[chartNames.indexOf(mapKey)];
                    // Overlay percentages use the chart's 0..1 scale. Do not let an
                    // overlay zero fabricate a rate hidden by the native minimum sample.
                    if (value !== null && precision !== null && Number.isFinite(precision)
                        && precision >= 0 && precision <= 1 && Math.abs(precision - value) <= 0.00501) value = precision;
                    entry.teams[index].winRate = coreVerified[index] ? value : null;
                    entry.teams[index].coreVerified = coreVerified[index];
                    entry.teams[index].sourceRecord = coreSources[index];
                    entry.teams[index].maps = maps;
                } else if (/pick/i.test(type)) {
                    entry.teams[index].pick = value;
                    entry.teams[index].pickOpportunities = opportunities;
                } else if (/ban/i.test(type)) {
                    entry.teams[index].ban = value;
                    entry.teams[index].banOpportunities = opportunities;
                }
            });
            result.set(mapKey, entry);
        }
        return [...result.values()].sort((a, b) => Number(chartNames.includes(key(b.name))) - Number(chartNames.includes(key(a.name)))).slice(0, CONFIG.maximumMaps);
    }

    function extractVeto(document, teams) {
        const actions = [];
        const boxes = [...document.querySelectorAll('.veto-box .preformatted-text')];
        for (const box of boxes) {
            const lines = [...box.childNodes].map((node) => node.nodeName === 'BR' ? '\n' : node.textContent).join('').split('\n');
            for (const line of lines) {
                const match = /^\s*(\d+)\.\s+(.+?)\s+(removed|picked)\s+([a-z0-9 _-]+)\s*$/i.exec(line);
                if (!match) continue;
                const actor = teams.findIndex((team) => key(team.name) === key(match[2]));
                if (actor < 0) continue;
                actions.push({ step: Number(match[1]) - 1, actor, type: match[3].toLowerCase() === 'picked' ? 'pick' : 'ban', map: text(match[4]) });
            }
        }
        return actions.slice(0, 6);
    }

    function extractMatchPageData(document, identity) {
        const root = document.querySelector('.match-page');
        if (!root || !identity || identity.teams?.length !== 2) return null;
        const formatText = text([...root.querySelectorAll('.veto-box .preformatted-text')].map((node) => node.textContent).join(' '), 1000);
        const bestOf = Number(/\bBest of\s+([135])\b/i.exec(formatText)?.[1]) || null;
        const lineupsRoot = root.querySelector('.lineups-compare-container');
        const rosterBoxes = [...root.querySelectorAll('.lineups .lineup')].slice(0, 2);
        const lineups = [0, 1].map((index) => {
            const dataset = playerDataset(lineupsRoot?.dataset[`team${index + 1}PlayersData`], identity.teams[index].id, lineupsRoot?.dataset.ratingVersion);
            const announcedIds = [...(rosterBoxes[index]?.querySelectorAll('.player-image .player-compare[data-player-id]') || [])]
                .map((node) => id(node.getAttribute('data-player-id'))).filter(Boolean);
            const uniqueIds = [...new Set(announcedIds)];
            if (uniqueIds.length === 5) return uniqueIds.map((playerId) => dataset.find((player) => player.playerId === playerId)
                || { playerId, nickname: '', rating: null, ratingVersion: null, ratingAdapter: 'missing' });
            // The current widget's exact five-entry dataset is an alternate roster
            // source. Never choose the first five out of a historical/mixed dataset.
            return uniqueIds.length === 0 && dataset.length === 5 ? dataset : [];
        });
        const vrsRoot = root.querySelector('.vrs-forecast-container .vrs-forecast-left-numbers');
        const vrs = [...(vrsRoot?.querySelectorAll(':scope > .vrs-forecast-numbers-wrapper') || [])].slice(0, 2).map((node) => ({
            points: number(node.querySelector('.vrs-forecast-points')?.textContent),
            rank: number(node.querySelector('.vrs-forecast-ranking')?.textContent),
        }));
        const advantage = [0, 0];
        for (let index = 0; index < 2; index += 1) {
            const teamName = identity.teams[index].name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            const advantageMatch = new RegExp(`${teamName}\\s+(?:has|have|starts? with|will have)\\s+(?:a\\s+)?([12])(?:[-:]0)?\\s+map advantage`, 'i').exec(formatText);
            if (advantageMatch) advantage[index] = Number(advantageMatch[1]);
        }
        // Keep one bounded overflow holder so a sixth named map cannot disappear
        // before validation. Default holders represent awarded, rather than played, maps.
        const mapNames = [...root.querySelectorAll('.maps .mapholder .mapname')].slice(0, 6)
            .map((node) => text(node.textContent));
        const actualSlots = (advantage.some(Boolean) ? mapNames.filter((name) => !/^default$/i.test(name)) : mapNames)
            .map((name) => /^(?:tba|tbd|-|default|unknown)$/i.test(name) ? null : name);
        const maps = extractCoreMaps(root, lineups, Number.isFinite(identity.observedAt) ? identity.observedAt : Date.now());
        const chartPool = (root.querySelector('svg[data-spider-chart]')?.getAttribute('data-spider-chart') || '')
            .split(',').map((name) => text(name)).filter(Boolean);
        const verifiedPool = chartPool.length === 7 && new Set(chartPool.map(key)).size === 7
            && chartPool.every((name) => maps.some((map) => key(map.name) === key(name)));
        const analytics = url(root.querySelector('a.matchpage-analytics-center-container[href]')?.getAttribute('href'));
        return { ...plain(identity), bestOf, formatText, isLive: identity.phase !== 'scheduled',
            analyticsHref: analytics?.href || '', vrs, lineups, maps,
            mapPool: verifiedPool ? chartPool : [],
            mapPoolSource: verifiedPool ? 'match-core-widget' : 'unknown',
            mapSlots: actualSlots, officialMaps: actualSlots.filter(Boolean),
            vetoActions: extractVeto(root, identity.teams), advantage, bookmakers: [] };
    }

    function extractAnalyticsPageData(document) {
        const header = document.querySelector('.analytics-header');
        if (!header) return null;
        const back = [...header.querySelectorAll('a[href]')].map((anchor) => url(anchor.getAttribute('href')))
            .find((entry) => /^\/matches\/\d+(?:\/|$)/.test(entry?.pathname || ''));
        const teams = [...header.querySelectorAll('.team .team-name')].slice(0, 2)
            .map((node) => text(node.querySelector('.name')?.textContent || node.textContent));
        const timestamps = [...header.querySelectorAll('[data-unix]')].map((node) => number(node.getAttribute('data-unix'))).filter(Number.isSafeInteger);
        const maps = [];
        const rows = [...document.querySelectorAll('#maps > table.table-container.gtSmartphone-only tbody tr')];
        for (let index = 0; index + 1 < rows.length && maps.length < CONFIG.maximumMaps; index += 1) {
            const mapCell = rows[index].querySelector('td[rowspan="2"]');
            const name = text(mapCell?.querySelector('.analytics-map-name')?.textContent);
            if (!name) continue;
            maps.push({ name, teams: [rows[index], rows[index + 1]].map((row) => ({
                teamName: text(row.querySelector('.maps-team-name')?.textContent),
                firstPick: percent(row.querySelector('.analytics-map-stats-pick-percentage')?.textContent),
                firstBan: percent(row.querySelector('.analytics-map-stats-ban-percentage')?.textContent),
                winRate: percent(row.querySelector('.analytics-map-stats-win-percentage')?.textContent),
                maps: count(row.querySelector('.analytics-map-stats-played')?.textContent),
            })) });
            index += 1;
        }
        return { matchId: /^\/matches\/(\d+)/.exec(back?.pathname || '')?.[1] || '', teams,
            timestamp: timestamps[0] ?? null, maps, bookmakers: [] };
    }

    function extractTeamPlayerPageData(document, source = {}) {
        const context = [...document.querySelectorAll('.context-item-name[href]')].map((node) => url(node.getAttribute('href')))
            .find((entry) => /^\/stats\/teams\/\d+(?:\/|$)/.test(entry?.pathname || ''));
        const selectedTeam = [...document.querySelectorAll('a.stats-top-menu-item-link.selected[href]')]
            .map((node) => url(node.getAttribute('href'))).find((entry) => /^\/stats\/teams\/players\/\d+(?:\/|$)/.test(entry?.pathname || ''));
        const teamId = /^\/stats\/teams\/(\d+)/.exec(context?.pathname || '')?.[1]
            || /^\/stats\/teams\/players\/(\d+)/.exec(selectedTeam?.pathname || '')?.[1] || '';
        if (!teamId || teamId !== id(source.teamId)) throw new Error('Team player statistics identity does not match.');
        const startDate = text(source.window?.startDate || source.startDate);
        const endDate = text(source.window?.endDate || source.endDate);
        const selectedFilter = (selector) => {
            const selected = document.querySelector(`${selector} option[selected]`);
            return url(selected?.getAttribute('data-link'));
        };
        const timeFilter = selectedFilter('.stats-sub-navigation-simple-filter-time');
        const versionFilter = selectedFilter('.stats-sub-navigation-simple-filter-version');
        const expectedPath = url(source.href)?.pathname || selectedTeam?.pathname;
        const matchesSource = (candidate) => candidate && candidate.pathname === expectedPath
            && /^\/stats\/teams\/players\/(\d+)(?:\/|$)/.exec(candidate.pathname)?.[1] === teamId
            && candidate.searchParams.get('startDate') === startDate
            && candidate.searchParams.get('endDate') === endDate
            && candidate.searchParams.get('csVersion') === 'CS2'
            && parameterEntries(candidate.searchParams).every(([name]) => ['startDate', 'endDate', 'csVersion'].includes(name))
            && ['startDate', 'endDate', 'csVersion'].every((name) => candidate.searchParams.getAll(name).length === 1);
        const conflictingForm = [...document.querySelectorAll('input[name], select[name]')].some((node) => {
            const name = node.getAttribute('name');
            // Native blank date editors are unapplied; selected links still prove the active window.
            if (node.matches('input.filter-date') && ['startDate', 'endDate'].includes(name)
                && node.type === 'text' && node.value === '' && node.form === null) return false;
            const expected = { startDate, endDate, csVersion: 'CS2' }[name];
            return expected !== undefined && node.value !== expected;
        });
        const conflictingFilter = [...document.querySelectorAll('select[class*="stats-sub-navigation-simple-filter-"] option[selected][data-link]')]
            .some((node) => !matchesSource(url(node.getAttribute('data-link'))));
        if (conflictingForm || conflictingFilter || !/^\d{4}-\d{2}-\d{2}$/.test(startDate) || !/^\d{4}-\d{2}-\d{2}$/.test(endDate)
            || !matchesSource(timeFilter) || !matchesSource(versionFilter) || !matchesSource(selectedTeam)) {
            throw new Error('Team player statistics date or CS2 filters do not match.');
        }
        const tables = [...document.querySelectorAll('table.stats-table')].filter((candidate) => {
            const headers = [...candidate.querySelectorAll('thead th')].map((node) => text(node.textContent));
            return headers.some((value) => /^Player$/i.test(value)) && headers.some((value) => /Rating\s*3\.0/i.test(value))
                && headers.some((value) => /^Maps?$/i.test(value))
                && headers.some((value) => /^Rounds?$/i.test(value));
        });
        if (!tables.length) throw new Error('Rating 3.0 player table is unavailable.');
        const seen = new Set();
        const players = [];
        let remainingRows = CONFIG.maximumPlayers;
        // Announced stand-ins may appear under Historical players. Each compatible
        // table has its own column layout; all tables share one bounded row budget.
        for (const table of tables) {
            if (remainingRows <= 0) break;
            const headers = [...table.querySelectorAll('thead th')].map((node) => text(node.textContent));
            const mapsColumn = headers.findIndex((value) => /^Maps?$/i.test(value));
            const roundsColumn = headers.findIndex((value) => /^Rounds?$/i.test(value));
            const ratingColumn = headers.findIndex((value) => /Rating\s*3\.0/i.test(value));
            for (const row of [...table.querySelectorAll('tbody tr')].slice(0, remainingRows)) {
                remainingRows -= 1;
                const anchor = [...row.querySelectorAll('a[href]')].find((node) => /^\/stats\/players\/\d+(?:\/|$)/.test(url(node.getAttribute('href'))?.pathname || ''));
                const playerId = /^\/stats\/players\/(\d+)/.exec(url(anchor?.getAttribute('href'))?.pathname || '')?.[1] || '';
                const cells = [...row.querySelectorAll(':scope > td')];
                const value = rating(cells[ratingColumn]?.textContent);
                const maps = count(cells[mapsColumn]?.textContent);
                const rounds = count(cells[roundsColumn]?.textContent);
                if (!playerId || seen.has(playerId) || value === null || !maps || !rounds) continue;
                seen.add(playerId);
                players.push({ playerId, nickname: text(anchor.textContent), rating: value, maps, rounds, ratingVersion: '3.0' });
            }
        }
        return { teamId, ratingVersion: '3.0', startDate, endDate,
            window: 'last-calendar-month', players };
    }

    function normalizePredictionInputs(rawMatch, rawAnalytics, rawTeamPlayers = [], sourceRecords = []) {
        if (!rawMatch || rawMatch.teams?.length !== 2) throw new Error('Prediction match data is incomplete.');
        if (rawAnalytics) {
            if (String(rawAnalytics.matchId) !== String(rawMatch.matchId)
                || rawAnalytics.teams?.length !== 2
                || rawAnalytics.teams.some((team, index) => key(typeof team === 'string' ? team : team.name) !== key(rawMatch.teams[index].name))
                || !Number.isFinite(rawAnalytics.timestamp)
                || Math.abs(rawAnalytics.timestamp - rawMatch.timestamp) > 60000) {
                throw new Error('Analytics match identity does not match.');
            }
        }
        const lineups = [0, 1].map((index) => {
            const teamId = id(rawMatch.teams[index].id);
            const month = (Array.isArray(rawTeamPlayers) ? rawTeamPlayers : []).find((entry) => entry && id(entry.teamId) === teamId);
            const seen = new Set();
            return (rawMatch.lineups?.[index] || []).slice(0, CONFIG.maximumPlayers).flatMap((player) => {
                const playerId = id(player.playerId);
                if (!playerId || seen.has(playerId)) return [];
                seen.add(playerId);
                const monthly = month?.players?.find((entry) => id(entry.playerId) === playerId);
                return [{ playerId, nickname: text(player.nickname || monthly?.nickname || `Player ${playerId}`), rating: rating(player.rating),
                    ratingVersion: text(player.ratingVersion) || null, ratingAdapter: text(player.ratingAdapter),
                    monthRating: rating(monthly?.rating), monthMaps: count(monthly?.maps), monthRounds: count(monthly?.rounds),
                    monthRatingVersion: text(monthly?.ratingVersion || month?.ratingVersion) || null }];
            }).slice(0, 5);
        });
        const seenMaps = new Set();
        const rawMaps = [...(rawMatch.maps || [])];
        for (const analyticsMap of rawAnalytics?.maps || []) {
            if (!rawMaps.some((entry) => key(entry.name) === key(analyticsMap.name))) rawMaps.push({ name: analyticsMap.name, teams: [{}, {}] });
        }
        const eligibleNames = new Set([...(rawMatch.mapPool || []), ...(rawMatch.mapSlots || rawMatch.officialMaps || [])].filter(Boolean).map(key));
        rawMaps.sort((a, b) => Number(eligibleNames.has(key(b.name))) - Number(eligibleNames.has(key(a.name))));
        const maps = rawMaps.slice(0, CONFIG.maximumMaps).flatMap((entry) => {
            const name = text(entry.name);
            if (!key(name) || seenMaps.has(key(name))) return [];
            seenMaps.add(key(name));
            const analyticsMap = rawAnalytics?.maps?.find((candidate) => key(candidate.name) === key(name));
            return [{ name, coreMinimumPlayers: 3, teams: [0, 1].map((index) => {
                const core = entry.teams?.[index] || {};
                const candidate = analyticsMap?.teams?.[index] || {};
                const first = key(candidate.teamName) === key(rawMatch.teams[index].name) ? candidate : {};
                const useCore = mapRate(core).available;
                const sample = useCore ? core : mapRate(first).available ? first : core;
                return { source: useCore ? 'lineup-core' : sample === first ? 'analytics-team' : 'unknown',
                    sourceRecord: useCore ? plain(core.sourceRecord || null) : sample === first
                        ? { kind: 'analytics-team', matchId: String(rawMatch.matchId) } : null,
                    maps: count(sample.maps), wins: count(sample.wins), draws: count(sample.draws) ?? 0,
                    winRate: percent(sample.winRate), pick: percent(core.pick), ban: percent(core.ban),
                    pickOpportunities: count(core.pickOpportunities), banOpportunities: count(core.banOpportunities),
                    firstPick: percent(first.firstPick ?? first.pick), firstBan: percent(first.firstBan ?? first.ban) };
            }) }];
        });
        const mapPool = [...new Set((rawMatch.mapPool || []).map((name) => text(name)).filter(Boolean))].slice(0, CONFIG.maximumMaps);
        const bestOf = [1, 3, 5].includes(rawMatch.bestOf) ? rawMatch.bestOf : null;
        const advantage = [0, 1].map((index) => rawMatch.advantage?.[index] == null ? 0 : count(rawMatch.advantage[index]));
        const slots = rawMatch.mapSlots || rawMatch.officialMaps || [];
        return { modelVersion: MODEL_VERSION, matchId: String(rawMatch.matchId), teams: plain(rawMatch.teams),
            timestamp: rawMatch.timestamp, bestOf, formatText: text(rawMatch.formatText, 1000),
            vrs: [0, 1].map((index) => ({ points: number(rawMatch.vrs?.[index]?.points), rank: number(rawMatch.vrs?.[index]?.rank) })),
            lineups, maps, mapPool, mapPoolSource: text(rawMatch.mapPoolSource) || 'unknown',
            mapSlots: slots.slice(0, 5).map((name) => name ? text(name) : null),
            officialMaps: slots.filter(Boolean).map((name) => text(name)), advantage,
            vetoActions: (rawMatch.vetoActions || []).slice(0, 6).map((action) => ({ step: count(action.step), actor: action.actor, type: action.type, map: text(action.map) })),
            bookmakers: plain(rawAnalytics?.bookmakers?.length ? rawAnalytics.bookmakers : rawMatch.bookmakers || []),
            bookmakerSource: rawAnalytics?.bookmakers?.length ? 'analytics' : 'match',
            sourceRecords: plain(Array.isArray(sourceRecords) ? sourceRecords : []).slice(0, 3) };
    }

    function lineupExpert(inputs) {
        const players = [0, 1].map((index) => Array.from({ length: 5 }, (_, playerIndex) => {
            const player = inputs.lineups?.[index]?.[playerIndex] || {};
            const baseline = player.ratingVersion === '3.0' ? rating(player.rating) : null;
            const monthly = player.monthRatingVersion === '3.0' ? rating(player.monthRating) : null;
            const sample = count(player.monthMaps) || 0;
            const shrink = sample / (sample + CONFIG.recentPriorMaps);
            const monthlyUsable = monthly !== null && sample > 0;
            const effective = baseline !== null
                ? baseline + (monthlyUsable ? CONFIG.recentShare * shrink * (monthly - baseline) : 0)
                : monthlyUsable ? 1 + shrink * (monthly - 1) : 1;
            return { playerId: id(player.playerId), nickname: text(player.nickname), baselineRating: baseline,
                monthlyRating: monthlyUsable ? monthly : null, monthlyMaps: sample,
                monthlyRounds: count(player.monthRounds), shrink, effectiveRating: effective,
                available: baseline !== null || monthlyUsable, baselineSampleUnknown: baseline !== null };
        }));
        const observed = players.map((team) => team.filter((player) => player.available).length);
        const available = observed.every((value) => value >= CONFIG.minimumPlayers);
        const means = players.map((team) => team.reduce((sum, player) => sum + player.effectiveRating, 0) / 5);
        const z = available ? CONFIG.ratingSlope * (means[0] - means[1]) : 0;
        return { available, probability: sigmoid(z), z, means, observed, players,
            monthlyObserved: players.map((team) => team.filter((player) => player.monthlyRating !== null).length) };
    }

    function vrsExpert(inputs) {
        const points = [0, 1].map((index) => number(inputs.vrs?.[index]?.points));
        const available = points.every((value) => value !== null && value > 0);
        if (!available) return { available: false, probability: 0.5, referenceSeriesProbability: 0.5, z: 0 };
        const q = Math.log(10) / 400;
        const g = 1 / Math.sqrt(1 + 3 * q * q * 75 * 75 / (Math.PI * Math.PI));
        const target = sigmoid(g * q * (points[0] - points[1]));
        let low = 0; let high = 1;
        for (let iteration = 0; iteration < 60; iteration += 1) {
            const middle = (low + high) / 2;
            if (3 * middle * middle - 2 * middle * middle * middle < target) low = middle;
            else high = middle;
        }
        const probability = (low + high) / 2;
        return { available, probability, referenceSeriesProbability: target, z: logit(probability), referenceBestOf: 3 };
    }

    function mapRate(team = {}) {
        const maps = count(team.maps);
        const wins = count(team.wins);
        const draws = count(team.draws) || 0;
        const winRate = percent(team.winRate);
        const available = maps !== null && maps >= 3 && draws <= maps
            && (wins !== null ? wins + draws <= maps : winRate !== null);
        if (!available) return { available: false, rate: 0.5, maps: maps || 0, effectiveWins: null, approximate: false };
        const effectiveWins = wins !== null ? wins + draws / 2 : winRate * maps;
        return { available, rate: (effectiveWins + CONFIG.mapPriorWins) / (maps + CONFIG.mapPriorMaps),
            maps, effectiveWins, approximate: wins === null };
    }

    function seriesDistribution(probabilities, bestOf, advantage = [0, 0]) {
        if (![1, 3, 5].includes(bestOf)) return {};
        const needed = Math.floor(bestOf / 2) + 1;
        const result = {};
        const walk = (index, a, b, mass) => {
            if (a >= needed || b >= needed) {
                const score = `${a}-${b}`;
                result[score] = (result[score] || 0) + mass;
                return;
            }
            if (index >= probabilities.length) return;
            const p = finite(probabilities[index]) === null ? 0.5 : clip(probabilities[index], 0, 1);
            walk(index + 1, a + 1, b, mass * p);
            walk(index + 1, a, b + 1, mass * (1 - p));
        };
        walk(0, advantage[0] || 0, advantage[1] || 0, 1);
        return result;
    }
    const distributionProbability = (distribution) => Object.entries(distribution).reduce((sum, [score, value]) => {
        const [a, b] = score.split('-').map(Number);
        return sum + (a > b ? value : 0);
    }, 0);

    function vetoMixture(inputs, mapModels, baseMapProbability) {
        const bestOf = inputs.bestOf;
        const advantage = inputs.advantage || [0, 0];
        const needed = Math.floor(bestOf / 2) + 1;
        if (![1, 3, 5].includes(bestOf) || advantage.some((value) => !Number.isSafeInteger(value) || value < 0 || value >= needed)
            || advantage.every((value) => value > 0)) return { available: false, reason: 'unsupported-format', distribution: {}, scenarios: [] };
        const actualCount = bestOf - advantage[0] - advantage[1];
        if ((inputs.mapSlots || []).slice(actualCount).some(Boolean) || inputs.officialMaps?.length > actualCount) {
            return { available: false, reason: 'excess-official-map', distribution: {}, scenarios: [] };
        }
        const slots = Array.from({ length: actualCount }, (_, index) => inputs.mapSlots?.[index] || null);
        const known = slots.filter(Boolean).map(key);
        if (new Set(known).size !== known.length) return { available: false, reason: 'duplicate-official-map', distribution: {}, scenarios: [] };
        const pool = inputs.mapPool || [];
        const poolKnown = pool.length === 7 && new Set(pool.map(key)).size === 7;
        const types = bestOf === 1 ? ['ban', 'ban', 'ban', 'ban', 'ban', 'ban']
            : bestOf === 3 ? ['ban', 'ban', 'pick', 'pick', 'ban', 'ban']
                : ['ban', 'ban', 'pick', 'pick', 'pick', 'pick'];
        const observed = inputs.vetoActions || [];
        if (observed.some((action) => ![0, 1].includes(action.actor) || !Number.isInteger(action.step)
            || action.step < 0 || action.step >= 6 || !['ban', 'pick'].includes(action.type) || !key(action.map))) {
            return { available: false, reason: 'unsupported-veto', distribution: {}, scenarios: [] };
        }
        const observedSteps = new Map();
        const observedMaps = new Map();
        const contradictoryVeto = observed.some((action) => {
            const mapKey = key(action.map);
            const previous = observedSteps.get(action.step);
            const previousStep = observedMaps.get(mapKey);
            observedSteps.set(action.step, action);
            observedMaps.set(mapKey, action.step);
            const pickSlot = types.slice(0, action.step).filter((type) => type === 'pick').length;
            return types[action.step] !== action.type
                || (previous && (previous.actor !== action.actor || key(previous.map) !== mapKey))
                || (previousStep !== undefined && previousStep !== action.step)
                || (poolKnown && !pool.some((name) => key(name) === mapKey))
                || (action.type === 'ban' && known.includes(mapKey))
                || (action.type === 'pick' && !advantage.some(Boolean)
                    && ((slots[pickSlot] && key(slots[pickSlot]) !== mapKey)
                        || slots.some((name, index) => index !== pickSlot && name && key(name) === mapKey)))
                || (action.type === 'pick' && known.length === actualCount && !known.includes(mapKey));
        });
        const compatibleActors = [0, 1].filter((firstActor) => observed.every((action) => action.actor === (firstActor + action.step) % 2));
        if (contradictoryVeto || !compatibleActors.length
            || (poolKnown && known.some((name) => !pool.some((map) => key(map) === name)))) {
            return { available: false, reason: 'inconsistent-veto', distribution: {}, scenarios: [] };
        }
        const probabilityFor = (name) => mapModels.find((map) => key(map.name) === key(name))?.probability ?? baseMapProbability;
        const direct = (method, reason = '') => {
            const probabilities = slots.map((name) => name ? probabilityFor(name) : baseMapProbability);
            const distribution = seriesDistribution(probabilities, bestOf, advantage);
            return { available: true, method, reason, distribution, probability: distributionProbability(distribution),
                scenarios: [{ maps: slots, probability: 1, probabilityA: distributionProbability(distribution) }],
                selectedMaps: slots.map((name, index) => ({ name, slot: index, selectionProbability: 1, probabilityA: probabilities[index] })) };
        };
        if (known.length === actualCount) return direct('official');
        if (advantage.some(Boolean)) return { available: false, reason: 'unknown-advantage-veto', distribution: {}, scenarios: [] };
        if (!poolKnown) {
            return direct('known-slots-baseline', 'map-pool-unavailable');
        }
        const leaves = [];
        function walk(remaining, picks, actions, firstActor) {
            const step = actions.length;
            if (step === 6) {
                const maps = [...picks, ...remaining];
                const distribution = seriesDistribution(maps.map(probabilityFor), bestOf);
                return { probability: distributionProbability(distribution), leaves: [{ maps, actions, distribution, mass: 1 }] };
            }
            const actor = (firstActor + step) % 2;
            const type = types[step];
            const firstForActor = !actions.some((action) => action.actor === actor && action.type === type);
            const habits = remaining.map((name) => {
                const team = mapModels.find((map) => key(map.name) === key(name))?.teams?.[actor] || {};
                if (firstForActor && finite(team[type === 'pick' ? 'firstPick' : 'firstBan']) !== null) {
                    return (1 - CONFIG.firstHabitUniformShare) * team[type === 'pick' ? 'firstPick' : 'firstBan'] + CONFIG.firstHabitUniformShare / remaining.length;
                }
                const n = count(team[`${type}Opportunities`]) || 0;
                const rate = percent(team[type]);
                return rate !== null && n > 0 ? (n * rate + CONFIG.habitPriorOpportunities / remaining.length) / (n + CONFIG.habitPriorOpportunities) : 1 / remaining.length;
            });
            const habitSum = habits.reduce((sum, value) => sum + value, 0);
            const children = remaining.map((name, index) => {
                const child = walk(remaining.filter((_, i) => i !== index), type === 'pick' ? [...picks, name] : picks,
                    [...actions, { step, actor, type, map: name }], firstActor);
                const actorUtility = (actor === 0 ? 1 : -1) * clip(logit(child.probability), -4, 4);
                const weight = Math.exp((CONFIG.habitWeight * Math.log(habits[index] / habitSum)
                    + (1 - CONFIG.habitWeight) * actorUtility) / CONFIG.utilityTemperature);
                return { child, weight };
            });
            const total = children.reduce((sum, entry) => sum + entry.weight, 0);
            return { probability: children.reduce((sum, entry) => sum + entry.child.probability * entry.weight / total, 0),
                leaves: children.flatMap(({ child, weight }) => child.leaves.map((leaf) => ({ ...leaf, mass: leaf.mass * weight / total }))) };
        }
        for (const firstActor of [0, 1]) {
            const tree = walk(pool, [], [], firstActor);
            for (const leaf of tree.leaves) {
                const compatible = slots.every((name, index) => !name || key(name) === key(leaf.maps[index]))
                    && observed.every((action) => {
                        const actual = leaf.actions[action.step];
                        return actual && actual.actor === action.actor && actual.type === action.type && key(actual.map) === key(action.map);
                    });
                if (compatible) leaves.push({ ...leaf, mass: leaf.mass / 2 });
            }
        }
        const total = leaves.reduce((sum, leaf) => sum + leaf.mass, 0);
        if (!(total > 0)) return { available: false, reason: 'inconsistent-veto', distribution: {}, scenarios: [] };
        const distribution = {}; const scenarioMap = new Map(); const selections = new Map();
        for (const leaf of leaves) {
            const mass = leaf.mass / total;
            for (const [score, value] of Object.entries(leaf.distribution)) distribution[score] = (distribution[score] || 0) + mass * value;
            const scenarioKey = leaf.maps.map(key).join('|');
            const scenario = scenarioMap.get(scenarioKey) || { maps: leaf.maps, probability: 0, probabilityA: distributionProbability(leaf.distribution) };
            scenario.probability += mass; scenarioMap.set(scenarioKey, scenario);
            leaf.maps.forEach((name, slot) => {
                const selectionKey = `${slot}:${key(name)}`;
                const selection = selections.get(selectionKey) || { name, slot, selectionProbability: 0, probabilityA: probabilityFor(name) };
                selection.selectionProbability += mass; selections.set(selectionKey, selection);
            });
        }
        const distributionMass = Object.values(distribution).reduce((sum, value) => sum + value, 0);
        for (const score of Object.keys(distribution)) distribution[score] /= distributionMass;
        const scenarios = [...scenarioMap.values()].map((entry) => ({ ...entry, probability: clip(entry.probability, 0, 1) })).sort((a, b) => b.probability - a.probability || a.maps.join('|').localeCompare(b.maps.join('|'))).slice(0, CONFIG.maximumScenarios);
        return { available: true, method: 'veto-mixture', distribution, probability: clip(distributionProbability(distribution), 0, 1),
            scenarios, selectedMaps: [...selections.values()].map((entry) => ({ ...entry, selectionProbability: clip(entry.selectionProbability, 0, 1) })), scenarioCount: scenarioMap.size, conditionedMass: total };
    }

    function calculateStructuralProbability(inputs) {
        const lineup = lineupExpert(inputs);
        const strength = vrsExpert(inputs);
        const baseZ = CONFIG.lineupWeight * lineup.z + CONFIG.vrsWeight * strength.z;
        const baseProbability = sigmoid(baseZ);
        const maps = (inputs.maps || []).slice(0, CONFIG.maximumMaps).map((entry) => {
            const rates = [0, 1].map((index) => mapRate(entry.teams?.[index]));
            const available = rates.every((rate) => rate.available);
            const mapZ = available ? logit(rates[0].rate) - logit(rates[1].rate) : 0;
            return { name: entry.name, teams: entry.teams, rates, available, mapProbability: sigmoid(mapZ),
                probability: sigmoid(baseZ + CONFIG.mapWeight * mapZ), z: mapZ };
        });
        const eligible = inputs.mapPool?.length === 7 ? new Set(inputs.mapPool.map(key))
            : new Set((inputs.mapSlots || []).filter(Boolean).map(key));
        const mapSamples = [0, 1].map((index) => maps.reduce((sum, map) => sum + (eligible.has(key(map.name)) && map.available ? map.rates[index].maps - (count(map.teams?.[index]?.draws) || 0) : 0), 0));
        const mapAvailable = mapSamples.every((sample) => sample >= CONFIG.minimumMapSamples);
        const mapSeries = vetoMixture(inputs, maps, baseProbability);
        const available = mapSeries.available && (lineup.available || mapAvailable);
        for (const map of maps) {
            map.selectionProbability = (mapSeries.selectedMaps || []).reduce((sum, selection) => sum
                + (key(selection.name) === key(map.name) ? selection.selectionProbability : 0), 0);
            map.selectionProbability = clip(map.selectionProbability, 0, 1);
        }
        const missing = [];
        if (!lineup.available) missing.push('At least three current-player ratings per team are unavailable.');
        if (!strength.available) missing.push('Opponent-strength ranking points unavailable.');
        if (!mapAvailable) missing.push('Insufficient eligible core-map samples.');
        if (lineup.monthlyObserved.some((n) => n < 5)) missing.push('Some current players lack usable last-month ratings.');
        if (mapSeries.method === 'known-slots-baseline') missing.push('Current map pool unavailable; unknown slots use the baseline.');
        const coverage = { missing, lineup: lineup.observed, monthly: lineup.monthlyObserved,
            vrs: strength.available, maps: mapSamples, coreMinimumPlayers: 3,
            mapPoolKnown: inputs.mapPool?.length === 7, vetoMethod: mapSeries.method || 'unavailable',
            limited: !strength.available || !lineup.available || !mapAvailable || mapSeries.method === 'known-slots-baseline' || lineup.monthlyObserved.some((n) => n < 5),
            sourceRecords: inputs.sourceRecords || [] };
        const diagnostics = { modelVersion: MODEL_VERSION, weights: { lineup: 0.60, map: 0.30, vrs: 0.10 },
            assumptions: ['Heuristic coefficients; no calibrated accuracy claim.', 'Player and map evidence can overlap and differ in opponent strength.',
                'Monthly team statistics and three-month player ratings can cover different team contexts.', 'VRS series-to-map conversion assumes a reference BO3.'],
            reason: !mapSeries.available ? mapSeries.reason : !available ? 'insufficient-player-and-map-samples' : '' };
        return { available, probability: available ? mapSeries.probability : null, baseProbability, baseZ,
            reliability: available ? 1 : 0, reliabilityParts: {}, strength, lineup,
            mapSeries: { ...mapSeries, maps, mapReliability: mapAvailable ? 1 : 0, vetoReliability: mapSeries.method === 'veto-mixture' || mapSeries.method === 'official' ? 1 : 0 },
            coverage, diagnostics, players: lineup.players, maps, scenarios: mapSeries.scenarios || [] };
    }

    function calculateFinalPrediction(inputs, mode = 'stats', marketCalculator = null) {
        mode = mode === 'market' ? 'market' : 'stats';
        const market = typeof marketCalculator === 'function' ? marketCalculator(inputs)
            : { available: false, probability: null, reliability: 0, accepted: [], rejected: [] };
        const structural = calculateStructuralProbability(inputs);
        return buildFinalPrediction(structural, market, mode);
    }

    function buildFinalPrediction(structural, market, mode) {
        const probability = mode === 'market' ? market.available ? market.probability : null : structural.probability;
        const winnerIndex = Number.isFinite(probability) && Math.abs(probability - 0.5) > 1e-12 ? probability > 0.5 ? 0 : 1 : null;
        const scorelineDistribution = mode === 'stats' && structural.available ? structural.mapSeries.distribution : {};
        const scores = Object.entries(scorelineDistribution).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
        const likely = scores[0];
        return { modelVersion: MODEL_VERSION, probabilityA: probability, probabilityB: Number.isFinite(probability) ? 1 - probability : null,
            winnerIndex, mode, insufficient: !Number.isFinite(probability), structuralShare: mode === 'market' ? 0 : 1,
            scorelineDistribution, likelyScoreline: likely?.[0] || '',
            quality: { score: mode === 'market' ? (market.reliability || 0) * 100 : null,
                label: mode === 'market' ? 'Market coverage' : !structural.available ? 'Unavailable' : structural.coverage.limited ? 'Limited stats' : 'Stats coverage' },
            market, structural, coverage: structural.coverage, diagnostics: structural.diagnostics,
            players: structural.players, maps: structural.maps, scenarios: structural.scenarios };
    }

    function calculatePredictionModes(inputs, marketCalculator = null) {
        const structural = calculateStructuralProbability(inputs);
        const market = typeof marketCalculator === 'function' ? marketCalculator(inputs)
            : { available: false, probability: null, reliability: 0, accepted: [], rejected: [] };
        return { stats: buildFinalPrediction(structural, market, 'stats'), market: buildFinalPrediction(structural, market, 'market') };
    }

    globalThis.HLTV_MATCH_PREDICTION_MODEL_V23 = Object.freeze({ config: CONFIG, modelVersion: MODEL_VERSION,
        extractMatchPageData, extractAnalyticsPageData, extractTeamPlayerPageData, normalizePredictionInputs,
        calculateStructuralProbability, calculateFinalPrediction, calculatePredictionModes, seriesDistribution, parseNumber: number });

    // Version 2.4 keeps the V23 implementation above available for frozen legacy
    // results and fixtures. New inference uses only the dated opponent network.
    const NETWORK_VERSION = 'market-map-1';
    const NETWORK_DEFAULTS = Object.freeze({ teamPenalty: 4, mapPenalty: 12, halfLifeDays: 60,
        iterations: 120, maximumHistoryRows: 600, maximumTeams: 5000, minimumTeamMaps: 5 });
    const dateDay = (value) => {
        if (!/^\d{4}-\d{2}-\d{2}$/.test(String(value))) return null;
        const result = Date.parse(`${value}T00:00:00Z`);
        return Number.isFinite(result) && new Date(result).toISOString().slice(0, 10) === value ? result / 86400000 : null;
    };
    const HISTORY_MAPS = new Set(['ancient', 'anubis', 'cache', 'dust2', 'inferno', 'mirage', 'nuke', 'overpass', 'train', 'vertigo', 'cobblestone', 'tuscan', 'season']);
    function historyRow(row) {
        if (!row || !id(row.mapId) || !id(row.teamA) || !id(row.teamB) || id(row.teamA) === id(row.teamB)
            || dateDay(row.date) === null || !HISTORY_MAPS.has(key(row.map))) return null;
        const scoreA = count(row.scoreA); const scoreB = count(row.scoreB);
        if (scoreA === null || scoreB === null || scoreA === scoreB || Math.max(scoreA, scoreB) < 13
            || Math.max(scoreA, scoreB) > 100 || key(row.map).length > 30) return null;
        const winner = Math.max(scoreA, scoreB); const loser = Math.min(scoreA, scoreB);
        const regulation = winner === 13 && loser <= 11;
        const overtime = winner >= 16 && (winner - 16) % 3 === 0 && loser >= winner - 4 && loser <= winner - 2;
        if (!regulation && !overtime) return null;
        return { mapId: id(row.mapId), date: row.date, teamA: id(row.teamA), teamB: id(row.teamB),
            map: text(row.map, 40), scoreA, scoreB };
    }
    function validSnapshot(snapshot) {
        return snapshot && snapshot.schemaVersion === 1 && snapshot.modelVersion === NETWORK_VERSION
            && dateDay(snapshot.trainedThrough) !== null && snapshot.teams && typeof snapshot.teams === 'object'
            && !Array.isArray(snapshot.teams) && Object.keys(snapshot.teams).length <= NETWORK_DEFAULTS.maximumTeams;
    }
    function networkParameters(options = {}) {
        const bounded = (name, low, high) => finite(options[name]) !== null && options[name] >= low && options[name] <= high
            ? options[name] : NETWORK_DEFAULTS[name];
        return { teamPenalty: bounded('teamPenalty', .1, 1000), mapPenalty: bounded('mapPenalty', .1, 1000),
            halfLifeDays: bounded('halfLifeDays', 1, 1000), iterations: Math.floor(bounded('iterations', 1, 500)) };
    }
    function copyTeam(value = {}) {
        const mapEffects = {}; const mapCounts = {};
        for (const [name, effect] of Object.entries(value.mapEffects || {}).slice(0, 20)) {
            if (key(name) && finite(effect) !== null && Math.abs(effect) <= 10) mapEffects[key(name)] = effect;
        }
        for (const [name, n] of Object.entries(value.mapCounts || {}).slice(0, 20)) if (count(n) !== null) mapCounts[key(name)] = n;
        return { strength: finite(value.strength) !== null ? clip(value.strength, -10, 10) : 0,
            mapEffects, mapsObserved: count(value.mapsObserved) || 0, mapCounts, lastSeen: dateDay(value.lastSeen) === null ? '' : value.lastSeen };
    }
    function networkMapProbability(teams, a, b, map) {
        const left = teams[a] || {}; const right = teams[b] || {}; const name = key(map);
        return sigmoid((left.strength || 0) - (right.strength || 0)
            + (left.mapEffects?.[name] || 0) - (right.mapEffects?.[name] || 0));
    }
    function fitNetwork(rawRows, options = {}, prior = null) {
        const parameters = networkParameters(options);
        const reference = dateDay(options.referenceDate);
        if (reference === null) throw new Error('Network fitting requires an explicit reference date.');
        const seen = new Set();
        const rows = (Array.isArray(rawRows) ? rawRows : []).flatMap((value) => {
            const row = historyRow(value);
            if (!row || seen.has(row.mapId) || dateDay(row.date) > reference) return [];
            seen.add(row.mapId);
            return [{ ...row, mapKey: key(row.map), weight: Math.pow(2, -(reference - dateDay(row.date)) / parameters.halfLifeDays) }];
        });
        const teams = {}; const centers = {};
        if (validSnapshot(prior)) for (const [teamId, team] of Object.entries(prior.teams)) if (id(teamId)) {
            teams[teamId] = copyTeam(team); centers[teamId] = copyTeam(team);
        }
        const targets = options.targetIds ? new Set(options.targetIds.map(id).filter(Boolean)) : null;
        for (const row of rows) for (const teamId of [row.teamA, row.teamB]) {
            if (!teams[teamId]) { teams[teamId] = copyTeam(); centers[teamId] = copyTeam(); }
            if (targets && !targets.has(teamId)) continue;
            teams[teamId].mapsObserved += 1;
            teams[teamId].mapCounts[row.mapKey] = (teams[teamId].mapCounts[row.mapKey] || 0) + 1;
            teams[teamId].lastSeen = teams[teamId].lastSeen > row.date ? teams[teamId].lastSeen : row.date;
            if (!(row.mapKey in teams[teamId].mapEffects)) teams[teamId].mapEffects[row.mapKey] = 0;
        }
        const mutable = Object.keys(teams).filter((teamId) => !targets || targets.has(teamId)).sort();
        // Damped diagonal Newton updates of the convex penalized logistic loss.
        // The 1/4 damping bounds the four nonzero coordinates in each map row.
        for (let iteration = 0; iteration < parameters.iterations; iteration += 1) {
            const gradients = {}; const diagonals = {};
            for (const teamId of mutable) {
                const team = teams[teamId]; const center = centers[teamId];
                gradients[teamId] = { strength: parameters.teamPenalty * (team.strength - center.strength), maps: {} };
                diagonals[teamId] = { strength: parameters.teamPenalty, maps: {} };
                for (const name of Object.keys(team.mapEffects)) {
                    gradients[teamId].maps[name] = parameters.mapPenalty * (team.mapEffects[name] - (center.mapEffects[name] || 0));
                    diagonals[teamId].maps[name] = parameters.mapPenalty;
                }
            }
            for (const row of rows) {
                const probability = networkMapProbability(teams, row.teamA, row.teamB, row.mapKey);
                const error = row.weight * (probability - Number(row.scoreA > row.scoreB));
                const curvature = row.weight * probability * (1 - probability);
                for (const [teamId, sign] of [[row.teamA, 1], [row.teamB, -1]]) {
                    if (!gradients[teamId]) continue;
                    gradients[teamId].strength += sign * error;
                    diagonals[teamId].strength += curvature;
                    gradients[teamId].maps[row.mapKey] += sign * error;
                    diagonals[teamId].maps[row.mapKey] += curvature;
                }
            }
            let maximumChange = 0;
            for (const teamId of mutable) {
                const delta = .25 * gradients[teamId].strength / diagonals[teamId].strength;
                teams[teamId].strength = clip(teams[teamId].strength - delta, -10, 10);
                maximumChange = Math.max(maximumChange, Math.abs(delta));
                for (const name of Object.keys(teams[teamId].mapEffects)) {
                    const change = .25 * gradients[teamId].maps[name] / diagonals[teamId].maps[name];
                    teams[teamId].mapEffects[name] = clip(teams[teamId].mapEffects[name] - change, -10, 10);
                    maximumChange = Math.max(maximumChange, Math.abs(change));
                }
            }
            if (maximumChange < 1e-8) break;
        }
        return { schemaVersion: 1, modelVersion: NETWORK_VERSION, trainedThrough: options.referenceDate,
            hyperparameters: parameters, teams, fittedMaps: rows.length };
    }
    function extractTeamHistoryPageData(document, source, preserveDuplicateRows = false) {
        const requested = url(source?.href);
        const teamId = id(source?.teamId);
        if (!requested || !teamId || !new RegExp(`^/stats/teams/matches/${teamId}/[^/]+$`).test(requested.pathname)
            || requested.searchParams.get('csVersion') !== 'CS2' || dateDay(source.window?.startDate) === null
            || dateDay(source.window?.endDate) === null || source.window.startDate > source.window.endDate) throw new Error('Invalid history source.');
        const allowed = new Set(['csVersion', 'startDate', 'endDate']);
        for (const [name] of parameterEntries(requested.searchParams)) if (!allowed.has(name) || requested.searchParams.getAll(name).length !== 1) throw new Error('Unexpected history filter.');
        if (requested.searchParams.get('startDate') !== source.window.startDate || requested.searchParams.get('endDate') !== source.window.endDate) throw new Error('History dates mismatch.');
        const matchesHistorySource = (candidate) => candidate && !candidate.hash && candidate.pathname === requested.pathname
            && ['startDate', 'endDate', 'csVersion'].every((name) => candidate.searchParams.get(name) === requested.searchParams.get(name)
                && candidate.searchParams.getAll(name).length === 1)
            && parameterEntries(candidate.searchParams).every(([name]) => allowed.has(name));
        const selected = [...document.querySelectorAll('a.stats-top-menu-item-link.selected')];
        if (selected.length !== 1 || !matchesHistorySource(url(selected[0].getAttribute('href')))) throw new Error('History source identity is unproven.');
        const versions = [...document.querySelectorAll('.stats-sub-navigation-simple-filter-version option[selected]')];
        const version = versions.length === 1 ? versions[0] : null;
        if (!version || text(version.textContent) !== 'CS2' || !matchesHistorySource(url(version.getAttribute('data-link')))) {
            throw new Error('History CS2 filter is unproven.');
        }
        const timeOptions = [...document.querySelectorAll('.stats-sub-navigation-simple-filter-time option[selected]')];
        const timeOption = timeOptions.length === 1 ? timeOptions[0] : null;
        const nativeCustomTime = timeOption && !timeOption.hasAttribute('data-link')
            && timeOption.parentElement?.matches('select.stats-sub-navigation-simple-filter-time')
            && ['startDate', 'endDate'].every((name) => {
                const controls = [...document.querySelectorAll(`input[name="${name}"], select[name="${name}"]`)];
                return controls.length === 1 && controls[0].matches('input.filter-date')
                    && controls[0].type === 'text' && !controls[0].disabled && controls[0].value === source.window[name];
            });
        if (!timeOption || (!nativeCustomTime && !matchesHistorySource(url(timeOption.getAttribute('data-link'))))) {
            throw new Error('History selected time window is unproven.');
        }
        for (const option of document.querySelectorAll('select[class*="stats-sub-navigation-simple-filter-"] option[selected], option[selected][data-link]')) {
            if (nativeCustomTime && option === timeOption) continue;
            if (!matchesHistorySource(url(option.getAttribute('data-link')))) throw new Error('History selected filter mismatch.');
        }
        const conflictingForm = [...document.querySelectorAll('input[name], select[name]')].some((node) => {
            const name = node.getAttribute('name');
            if (!nativeCustomTime && node.matches('input.filter-date') && ['startDate', 'endDate'].includes(name)
                && node.type === 'text' && node.value === '' && node.form === null) return false;
            const expected = { startDate: source.window.startDate, endDate: source.window.endDate, csVersion: 'CS2' }[name];
            return expected !== undefined && node.value !== expected;
        });
        if (conflictingForm) throw new Error('History form filters contradict source.');
        const table = [...document.querySelectorAll('table.stats-table')].find((node) => /Opponent/.test(node.textContent) && /W\/L/.test(node.textContent));
        if (!table) throw new Error('History result table is missing.');
        const tableRows = [...table.querySelectorAll('tbody tr')];
        const maps = []; const seen = new Set(); let rejectedRows = 0;
        for (const row of tableRows.slice(0, NETWORK_DEFAULTS.maximumHistoryRows)) {
            const link = row.querySelector('td.time a[href]');
            const match = /\/mapstatsid\/(\d+)\//.exec(link?.getAttribute('href') || '');
            const opponent = [...row.querySelectorAll('a[href]')].map((anchor) => /\/stats\/teams\/(\d+)\//.exec(anchor.getAttribute('href') || ''))
                .find((candidate) => candidate && candidate[1] !== teamId)?.[1];
            const date = /^(\d{2})\/(\d{2})\/(\d{2})$/.exec(text(link?.textContent));
            const score = /^(\d+)\s*-\s*(\d+)$/.exec(text(row.querySelector('.statsDetail')?.textContent));
            const parsed = historyRow({ mapId: match?.[1], teamA: teamId, teamB: opponent,
                date: date ? `20${date[3]}-${date[2]}-${date[1]}` : '', map: text(row.querySelector('.statsMapPlayed')?.textContent),
                scoreA: score ? Number(score[1]) : null, scoreB: score ? Number(score[2]) : null });
            if (!parsed || parsed.date < source.window.startDate || parsed.date > source.window.endDate) { rejectedRows += 1; continue; }
            if (preserveDuplicateRows || !seen.has(parsed.mapId)) { seen.add(parsed.mapId); maps.push(parsed); }
        }
        return { teamId, startDate: source.window.startDate, endDate: source.window.endDate, maps,
            rejectedRows, truncated: tableRows.length > NETWORK_DEFAULTS.maximumHistoryRows,
            source: requested.href, rosterScope: 'historical-team' };
    }
    function normalizeNetworkInputs(rawMatch, rawAnalytics, histories = [], sourceRecords = []) {
        const result = normalizePredictionInputs(rawMatch, rawAnalytics, [], sourceRecords);
        result.modelVersion = NETWORK_VERSION;
        result.observedAt = Number.isFinite(rawMatch.observedAt) ? rawMatch.observedAt : rawMatch.timestamp;
        result.marketWeight = finite(rawMatch.marketWeight) === null ? .5 : clip(rawMatch.marketWeight, 0, 1);
        result.histories = (Array.isArray(histories) ? histories : []).slice(0, 2).filter((history) =>
            result.teams.some((team) => id(team.id) === id(history?.teamId))).map((history) => {
            const rawRows = Array.isArray(history.maps) ? history.maps : [];
            const parsed = rawRows.slice(0, NETWORK_DEFAULTS.maximumHistoryRows).map(historyRow);
            return { teamId: id(history.teamId), startDate: history.startDate, endDate: history.endDate,
                maps: parsed.filter(Boolean), truncated: Boolean(history.truncated) || rawRows.length > NETWORK_DEFAULTS.maximumHistoryRows,
                rejectedRows: (count(history.rejectedRows) || 0) + parsed.filter((row) => !row).length + Number(!Array.isArray(history.maps)),
                rosterScope: 'historical-team' };
        });
        return result;
    }
    function marketMapProbability(probability, bestOf, advantage = [0, 0]) {
        const needed = Math.floor(bestOf / 2) + 1;
        if (finite(probability) === null || probability < 0 || probability > 1 || ![1, 3, 5].includes(bestOf)
            || !Array.isArray(advantage) || advantage.length !== 2 || advantage.some((n) => !Number.isInteger(n) || n < 0 || n >= needed)
            || advantage.every((n) => n > 0)) return null;
        let low = 0; let high = 1;
        for (let iteration = 0; iteration < 55; iteration += 1) {
            const mid = (low + high) / 2;
            if (distributionProbability(seriesDistribution(Array(bestOf).fill(mid), bestOf, advantage)) < probability) low = mid;
            else high = mid;
        }
        return (low + high) / 2;
    }
    function networkStructural(inputs) {
        const snapshot = Object.hasOwn(inputs, 'snapshot') ? inputs.snapshot : globalThis.HLTV_MATCH_PREDICTION_SNAPSHOT;
        const asOf = Number.isFinite(inputs.observedAt) ? Math.min(inputs.observedAt, inputs.timestamp) : inputs.timestamp;
        const beforeDay = Number.isFinite(asOf) ? new Date(asOf).toISOString().slice(0, 10) : '';
        const snapshotValid = validSnapshot(snapshot) && snapshot.trainedThrough < beforeDay;
        const ids = (inputs.teams || []).map((team) => id(team.id));
        const rows = []; const seen = new Set();
        for (const history of (inputs.histories || []).slice(0, 2)) {
            if (!ids.includes(id(history.teamId))) continue;
            for (const raw of (history.maps || []).slice(0, NETWORK_DEFAULTS.maximumHistoryRows)) {
                const row = historyRow(raw);
                if (!row || seen.has(row.mapId) || ![row.teamA, row.teamB].includes(id(history.teamId))
                    || row.date >= beforeDay || !snapshotValid || row.date <= snapshot.trainedThrough
                    || dateDay(row.date) < dateDay(beforeDay) - 90) continue;
                seen.add(row.mapId); rows.push(row);
            }
        }
        const referenceDate = beforeDay ? new Date(Date.parse(`${beforeDay}T00:00:00Z`) - 86400000).toISOString().slice(0, 10) : '';
        const fitted = snapshotValid ? fitNetwork(rows, { ...snapshot.hyperparameters, referenceDate, targetIds: ids }, snapshot) : null;
        const supports = ids.map((teamId) => fitted?.teams[teamId]?.mapsObserved || 0);
        const fresh = snapshotValid && dateDay(beforeDay) - dateDay(snapshot.trainedThrough) <= 90;
        const refreshRequired = snapshotValid && snapshot.trainedThrough < referenceDate;
        const completeHistories = snapshotValid && ids.every((teamId) => (inputs.histories || []).some((history) =>
            id(history.teamId) === teamId && !history.truncated && !history.rejectedRows
            && history.endDate === referenceDate && dateDay(history.startDate) !== null
            && dateDay(history.startDate) <= Math.max(dateDay(snapshot.trainedThrough) + 1, dateDay(beforeDay) - 90)));
        const available = fresh && (!refreshRequired || completeHistories) && ids.length === 2 && ids.every(Boolean)
            && supports.every((n) => n >= NETWORK_DEFAULTS.minimumTeamMaps);
        const baseProbability = available ? networkMapProbability(fitted.teams, ids[0], ids[1], '') : .5;
        const names = [...new Set([...(inputs.mapPool || []), ...(inputs.mapSlots || []).filter(Boolean), ...(inputs.maps || []).map((m) => m.name)])].slice(0, 9);
        const maps = names.map((name) => ({ name, teams: inputs.maps?.find((m) => key(m.name) === key(name))?.teams || [{}, {}],
            available, probability: available ? networkMapProbability(fitted.teams, ids[0], ids[1], name) : .5,
            sampleCounts: ids.map((teamId) => fitted?.teams[teamId]?.mapCounts[key(name)] || 0) }));
        const mapSeries = available ? vetoMixture(inputs, maps, baseProbability) : { available: false, distribution: {}, scenarios: [], reason: 'insufficient-network-history' };
        const coverage = { limited: true, missing: [], sourceRecords: inputs.sourceRecords || [], networkTeamMaps: supports,
            updateMaps: rows.length, trainedThrough: snapshotValid ? snapshot.trainedThrough : null, historySources: (inputs.histories || []).length,
            rosterScope: 'historical-team', mapPoolKnown: inputs.mapPool?.length === 7, vetoMethod: mapSeries.method || 'unavailable',
            corpusCoverage: snapshot?.provenance?.coverage || 'unknown', snapshotAgeDays: snapshotValid ? dateDay(beforeDay) - dateDay(snapshot.trainedThrough) : null };
        if (refreshRequired && !completeHistories) coverage.missing.push('Complete prior-day histories for both teams are required to refresh this snapshot.');
        if (!snapshotValid) coverage.missing.push('A compatible strictly pre-match trained snapshot is unavailable.');
        if (supports.some((n) => n < NETWORK_DEFAULTS.minimumTeamMaps)) coverage.missing.push('Insufficient historical team evidence.');
        if ((inputs.histories || []).length < 2) coverage.missing.push('Some recent team-history refreshes are unavailable.');
        if ((inputs.histories || []).some((h) => h.truncated)) coverage.missing.push('A history response exceeded the row limit.');
        if (snapshotValid && dateDay(beforeDay) - dateDay(snapshot.trainedThrough) > 90) coverage.missing.push('The snapshot predates the bounded 90-day refresh window; intermediate history is missing.');
        return { available: available && mapSeries.available, probability: available && mapSeries.available ? mapSeries.probability : null,
            baseProbability, maps, mapSeries: { ...mapSeries, maps }, scenarios: mapSeries.scenarios || [], coverage,
            diagnostics: { modelVersion: NETWORK_VERSION, assumptions: ['Regularized team and map strengths from historical opponent results.',
                'Only the two target teams update; other teams remain anchored to the dated snapshot.',
                'Historical team records do not establish current roster continuity.', 'Exact series probabilities assume conditionally independent maps.'] },
            players: [[], []] };
    }
    function networkPrediction(inputs, mode, market, structural) {
        const requestedWeight = finite(inputs.marketWeight) === null ? .5 : clip(inputs.marketWeight, 0, 1);
        const marketAvailable = market.available && finite(market.probability) !== null && market.probability >= 0 && market.probability <= 1;
        const statisticsAvailable = structural.available;
        let effectiveWeight = mode === 'market' ? 1 : requestedWeight;
        let fallback = '';
        if (mode === 'stats') {
            if (!statisticsAvailable && marketAvailable) { effectiveWeight = 1; fallback = 'market-only'; }
            else if (statisticsAvailable && !marketAvailable) { effectiveWeight = 0; fallback = 'stats-only'; }
        }
        const q = marketAvailable ? marketMapProbability(market.probability, inputs.bestOf, inputs.advantage || [0, 0]) : null;
        const maps = structural.maps.map((map) => ({ ...map, statisticalProbability: map.available ? map.probability : null, statsProbability: map.available ? map.probability : null,
            marketProbability: q, probability: effectiveWeight === 0 ? map.probability
                : q === null ? map.probability : effectiveWeight * q + (1 - effectiveWeight) * map.probability }));
        let series = structural.mapSeries;
        let probability = null;
        if (mode === 'market') probability = marketAvailable ? market.probability : null;
        else if (effectiveWeight === 1 && marketAvailable) {
            probability = market.probability;
            // A market-only score shape is an equal-map assumption. It does not
            // require a known map pool and is never labeled observed map odds.
            const distribution = q === null ? {} : seriesDistribution(Array(inputs.bestOf).fill(q), inputs.bestOf, inputs.advantage);
            series = { available: q !== null, method: 'market-equivalent-maps', distribution, probability, scenarios: [] };
        } else if (statisticsAvailable && (effectiveWeight === 0 || marketAvailable && q !== null)) {
            series = effectiveWeight === 0 ? structural.mapSeries : vetoMixture(inputs, maps,
                effectiveWeight * q + (1 - effectiveWeight) * structural.baseProbability);
            probability = series.available ? series.probability : null;
        }
        const scores = mode === 'stats' && Number.isFinite(probability) ? series.distribution || {} : {};
        const sorted = Object.entries(scores).sort((a,b) => b[1]-a[1] || a[0].localeCompare(b[0]));
        const winnerIndex = Number.isFinite(probability) && Math.abs(probability-.5)>1e-12 ? probability>.5?0:1 : null;
        return { modelVersion: NETWORK_VERSION, mode, probabilityA: probability, probabilityB: Number.isFinite(probability)?1-probability:null,
            winnerIndex, insufficient: !Number.isFinite(probability), requestedMarketWeight: requestedWeight,
            effectiveMarketWeight: effectiveWeight, structuralShare: 1-effectiveWeight, fallback,
            scorelineDistribution: scores, likelyScoreline: sorted[0]?.[0] || '', market,
            structural: { ...structural, mapSeries: { ...series, maps } }, maps, scenarios: series.scenarios || [],
            coverage: structural.coverage, diagnostics: structural.diagnostics, players: [[], []],
            quality: { score: mode==='market'?(market.reliability||0)*100:null,
                label: !Number.isFinite(probability)?'Unavailable':mode==='market'?'Market coverage':fallback?'Single-source fallback':'Limited estimate' } };
    }
    function calculateNetworkModes(inputs, marketCalculator = null) {
        const structural = networkStructural(inputs);
        const market = typeof marketCalculator === 'function' ? marketCalculator(inputs) : {available:false,probability:null,reliability:0,accepted:[],rejected:[]};
        const stats = networkPrediction(inputs, 'stats', market, structural);
        const marketResult = networkPrediction(inputs, 'market', market, structural);
        for (const map of stats.maps) map.selectionProbability = clip((stats.structural.mapSeries.selectedMaps || [])
            .reduce((sum, selection) => sum + (key(selection.name) === key(map.name) ? selection.selectionProbability : 0), 0), 0, 1);
        stats.structural = { ...stats.structural, available: !stats.insufficient, probability: stats.probabilityA,
            statisticalProbability: structural.probability, maps: stats.maps, scenarios: stats.scenarios };
        marketResult.structural = stats.structural;
        return { stats, market: marketResult };
    }
    globalThis.HLTV_MATCH_PREDICTION_MODEL_V24 = Object.freeze({ modelVersion: NETWORK_VERSION, config: NETWORK_DEFAULTS,
        extractMatchPageData, extractAnalyticsPageData, extractTeamHistoryPageData,
        normalizePredictionInputs: normalizeNetworkInputs, calculateStructuralProbability: networkStructural,
        calculatePredictionModes: calculateNetworkModes,
        calculateFinalPrediction: (inputs, mode='stats', marketCalculator=null) => calculateNetworkModes(inputs,marketCalculator)[mode==='market'?'market':'stats'],
        seriesDistribution, marketMapProbability, fitNetwork, networkMapProbability, isValidHistoryRow: (row) => Boolean(historyRow(row)), parseNumber: number });


    // Weekly ranking points anchor every match independently. Only bounded,
    // zero-centered map residuals are fitted; no learned team strength is used.
    const RANKING_VERSION = 'ranking-map-1';
    const RANKING_DEFAULTS = Object.freeze({ maximumHistoryRows: 600, historyDays: 90 });
    function rankingDay(value) {
        if (typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value)) return dateDay(value) !== null ? value : null;
        const timestamp = typeof value === 'number' ? value : Date.parse(value);
        return Number.isFinite(timestamp) && Number.isFinite(new Date(timestamp).getTime())
            ? new Date(timestamp).toISOString().slice(0, 10) : null;
    }
    function weekBefore(value) {
        if (typeof globalThis.HLTV_RANKING_SNAPSHOTS?.weekBefore === 'function') {
            try { return globalThis.HLTV_RANKING_SNAPSHOTS.weekBefore(value); } catch { return null; }
        }
        const day = rankingDay(value);
        if (!day) return null;
        const timestamp = Date.parse(`${day}T00:00:00Z`);
        const weekday = new Date(timestamp).getUTCDay();
        return new Date(timestamp - ((weekday + 6) % 7 || 7) * 86400000).toISOString().slice(0, 10);
    }
    function latestForecastDay(inputs) {
        if (!Number.isFinite(inputs?.timestamp)) return null;
        return rankingDay(Number.isFinite(inputs.observedAt) ? Math.min(inputs.observedAt, inputs.timestamp) : inputs.timestamp);
    }
    function rankingSnapshotFor(value, snapshots) {
        const required = weekBefore(value);
        if (!required || typeof globalThis.HLTV_RANKING_SNAPSHOTS?.validateSnapshot !== 'function') return null;
        const matches = (Array.isArray(snapshots) ? snapshots : []).filter((snapshot) => snapshot?.date === required
            && globalThis.HLTV_RANKING_SNAPSHOTS.validateSnapshot(snapshot));
        if (!matches.length || matches.some((snapshot) => snapshot.checksum !== matches[0].checksum
            || JSON.stringify(snapshot.teamsById) !== JSON.stringify(matches[0].teamsById))) return null;
        return matches[0];
    }
    function rankingPoints(snapshot, teamId) {
        const value = snapshot?.teamsById?.[teamId];
        return value && id(value.id) === teamId && finite(value.points) !== null && value.points >= 0 ? value.points : null;
    }
    function validRankingCalibration(value, forecastDay) {
        return Boolean(value && value.schemaVersion === 1 && value.modelVersion === RANKING_VERSION
            && text(value.version) && dateDay(value.trainedThrough) !== null && value.trainedThrough < forecastDay
            && finite(value.beta) !== null && value.beta >= 0
            && finite(value.halfLifeDays) !== null && value.halfLifeDays > 0
            && finite(value.mapPenalty) !== null && value.mapPenalty > 0
            && Number.isSafeInteger(value.iterations) && value.iterations >= 1 && value.iterations <= 500);
    }
    function rankingFitParameters(options) {
        return { halfLifeDays: finite(options.halfLifeDays) !== null && options.halfLifeDays > 0 ? options.halfLifeDays : 60,
            mapPenalty: finite(options.mapPenalty) !== null && options.mapPenalty > 0 ? options.mapPenalty : 8,
            iterations: Number.isSafeInteger(options.iterations) && options.iterations > 0 ? Math.min(options.iterations, 500) : 120 };
    }
    function uniqueRankingRows(rawRows, referenceDate) {
        const reference = dateDay(referenceDate);
        const byId = new Map(); const conflicts = new Set(); let rejectedRows = 0;
        for (const raw of Array.isArray(rawRows) ? rawRows : []) {
            const row = historyRow(raw);
            if (!row || reference === null || dateDay(row.date) > reference) { rejectedRows += 1; continue; }
            // Canonical orientation permits the same result from both histories.
            const canonical = row.teamA < row.teamB ? row : { ...row, teamA: row.teamB, teamB: row.teamA,
                scoreA: row.scoreB, scoreB: row.scoreA };
            const previous = byId.get(row.mapId);
            if (previous && (previous.teamA !== canonical.teamA || previous.teamB !== canonical.teamB
                || previous.scoreA !== canonical.scoreA || previous.scoreB !== canonical.scoreB
                || previous.date !== canonical.date || key(previous.map) !== key(canonical.map))) conflicts.add(row.mapId);
            else if (!previous) byId.set(row.mapId, canonical);
        }
        return { rows: [...byId.values()].filter((row) => !conflicts.has(row.mapId)).sort((a, b) =>
            a.date.localeCompare(b.date) || a.mapId.localeCompare(b.mapId)), conflictingRows: conflicts.size, rejectedRows };
    }
    function rankedFitRows(rawRows, snapshots, options) {
        const parameters = rankingFitParameters(options);
        const unique = uniqueRankingRows(rawRows, options.referenceDate);
        const missingWeeks = new Set(); let excludedUnrankedHistory = 0;
        const rows = [];
        for (const row of unique.rows) {
            const snapshot = rankingSnapshotFor(row.date, snapshots);
            if (!snapshot) { missingWeeks.add(weekBefore(row.date)); continue; }
            const pointsA = rankingPoints(snapshot, row.teamA); const pointsB = rankingPoints(snapshot, row.teamB);
            if (pointsA === null || pointsB === null) { excludedUnrankedHistory += 1; continue; }
            rows.push({ ...row, mapKey: key(row.map), pointDifference: (pointsA - pointsB) / 1000,
                outcome: Number(row.scoreA > row.scoreB),
                weight: Math.pow(2, -(dateDay(options.referenceDate) - dateDay(row.date)) / parameters.halfLifeDays) });
        }
        return { ...unique, rows, parameters, fittedMaps: rows.length, excludedUnrankedHistory,
            missingWeeks: [...missingWeeks].filter(Boolean).sort() };
    }
    function fitRankingBaseline(rawRows, snapshots, options = {}) {
        const fit = rankedFitRows(rawRows, snapshots, options);
        let beta = 0;
        // One-dimensional convex weighted logistic loss with the required beta>=0 constraint.
        for (let iteration = 0; iteration < fit.parameters.iterations && fit.rows.length; iteration += 1) {
            let gradient = 0; let curvature = 0;
            for (const row of fit.rows) {
                const probability = sigmoid(beta * row.pointDifference);
                gradient += row.weight * row.pointDifference * (probability - row.outcome);
                curvature += row.weight * row.pointDifference * row.pointDifference * probability * (1 - probability);
            }
            if (curvature <= 1e-12) break;
            const next = Math.max(0, beta - clip(gradient / curvature, -10, 10));
            if (Math.abs(next - beta) < 1e-10) { beta = next; break; }
            beta = next;
        }
        return { schemaVersion: 1, modelVersion: RANKING_VERSION, beta: fit.rows.length ? beta : null,
            available: fit.rows.length > 0, trainedThrough: options.referenceDate, fittedMaps: fit.fittedMaps,
            excludedUnrankedHistory: fit.excludedUnrankedHistory, missingWeeks: fit.missingWeeks,
            conflictingRows: fit.conflictingRows, rejectedRows: fit.rejectedRows };
    }
    function fitMapAdjustments(rawRows, snapshots, options = {}) {
        const fit = rankedFitRows(rawRows, snapshots, options);
        const targets = options.targetIds ? new Set(options.targetIds.map(id).filter(Boolean))
            : new Set(fit.rows.flatMap((row) => [row.teamA, row.teamB]));
        const teams = {};
        for (const teamId of [...targets].sort()) teams[teamId] = { mapEffects: {}, mapCounts: {}, mapsObserved: 0 };
        const usable = finite(options.beta) !== null && options.beta >= 0;
        const rows = usable ? fit.rows.filter((row) => targets.has(row.teamA) || targets.has(row.teamB)) : [];
        for (const row of rows) for (const teamId of [row.teamA, row.teamB]) if (targets.has(teamId)) {
            const team = teams[teamId]; team.mapsObserved += 1;
            team.mapCounts[row.mapKey] = (team.mapCounts[row.mapKey] || 0) + 1;
            team.mapEffects[row.mapKey] = 0;
        }
        for (let iteration = 0; iteration < fit.parameters.iterations; iteration += 1) {
            const gradients = {}; const diagonals = {};
            for (const [teamId, team] of Object.entries(teams)) {
                gradients[teamId] = {}; diagonals[teamId] = {};
                for (const [name, effect] of Object.entries(team.mapEffects)) {
                    gradients[teamId][name] = fit.parameters.mapPenalty * effect;
                    diagonals[teamId][name] = fit.parameters.mapPenalty;
                }
            }
            for (const row of rows) {
                const probability = sigmoid(options.beta * row.pointDifference
                    + (teams[row.teamA]?.mapEffects[row.mapKey] || 0) - (teams[row.teamB]?.mapEffects[row.mapKey] || 0));
                const error = row.weight * (probability - row.outcome);
                const curvature = row.weight * probability * (1 - probability);
                for (const [teamId, sign] of [[row.teamA, 1], [row.teamB, -1]]) if (teams[teamId]) {
                    gradients[teamId][row.mapKey] += sign * error;
                    diagonals[teamId][row.mapKey] += curvature;
                }
            }
            let maximumChange = 0;
            for (const [teamId, team] of Object.entries(teams)) for (const name of Object.keys(team.mapEffects)) {
                // At most two mutable residual coordinates per row; damping keeps
                // the simultaneous diagonal Newton steps stable and symmetric.
                const change = .5 * gradients[teamId][name] / diagonals[teamId][name];
                team.mapEffects[name] -= change; maximumChange = Math.max(maximumChange, Math.abs(change));
            }
            if (maximumChange < 1e-9) break;
        }
        return { schemaVersion: 1, modelVersion: RANKING_VERSION, trainedThrough: options.referenceDate, teams,
            fittedMaps: rows.length, excludedUnrankedHistory: fit.excludedUnrankedHistory,
            missingWeeks: fit.missingWeeks, conflictingRows: fit.conflictingRows, rejectedRows: fit.rejectedRows };
    }
    function normalizeRankingInputs(rawMatch, rawAnalytics, histories = [], sourceRecords = []) {
        return { ...normalizeNetworkInputs(rawMatch, rawAnalytics, histories, sourceRecords),
            modelVersion: RANKING_VERSION, lineups: [[], []], vrs: [] };
    }
    function rankingStructural(inputs) {
        const forecastDay = latestForecastDay(inputs);
        const before = dateDay(forecastDay);
        const referenceDate = before === null ? '' : new Date((before - 1) * 86400000).toISOString().slice(0, 10);
        const ids = (inputs.teams || []).map((team) => id(team.id));
        const calibration = Object.hasOwn(inputs, 'rankingCalibration') ? inputs.rankingCalibration : globalThis.HLTV_RANKING_CALIBRATION;
        const calibrationValid = validRankingCalibration(calibration, forecastDay);
        const snapshots = inputs.rankingSnapshots || [];
        const current = rankingSnapshotFor(forecastDay, snapshots);
        const points = ids.map((teamId) => rankingPoints(current, teamId));
        const baselineAvailable = Boolean(calibrationValid && current && ids.length === 2 && ids.every(Boolean)
            && ids[0] !== ids[1] && points.every((point) => point !== null));
        const rawRows = []; let invalidHistoryRows = 0;
        const histories = (Array.isArray(inputs.histories) ? inputs.histories : []).slice(0, 2);
        for (const history of histories) {
            const teamId = id(history.teamId);
            if (!ids.includes(teamId)) continue;
            const historyRows = (Array.isArray(history.maps) ? history.maps : []).slice(0, RANKING_DEFAULTS.maximumHistoryRows);
            for (const raw of historyRows) {
                const row = historyRow(raw);
                if (!row) { invalidHistoryRows += 1; continue; }
                if (![row.teamA, row.teamB].includes(teamId) || before === null || row.date >= forecastDay
                    || dateDay(row.date) < before - RANKING_DEFAULTS.historyDays) continue;
                rawRows.push(row);
            }
        }
        const deduplicated = uniqueRankingRows(rawRows, referenceDate);
        const fit = fitMapAdjustments(rawRows, snapshots, { ...(calibrationValid ? calibration : {}),
            referenceDate, targetIds: ids });
        const missingWeeks = new Set([...(Array.isArray(inputs.rankingCoverage?.missingWeeks) ? inputs.rankingCoverage.missingWeeks : []),
            ...fit.missingWeeks]);
        if (!current && forecastDay) missingWeeks.add(weekBefore(forecastDay));
        const completeHistories = before !== null && ids.length === 2 && ids.every((teamId) => histories.some((history) =>
            id(history.teamId) === teamId && Array.isArray(history.maps) && history.maps.length <= RANKING_DEFAULTS.maximumHistoryRows
            && !history.truncated && !history.rejectedRows && history.endDate === referenceDate
            && dateDay(history.startDate) !== null && dateDay(history.startDate) <= before - RANKING_DEFAULTS.historyDays));
        const adjustmentComplete = baselineAvailable && completeHistories && !invalidHistoryRows
            && !fit.conflictingRows && !missingWeeks.size;
        const baseProbability = baselineAvailable ? sigmoid(calibration.beta * (points[0] - points[1]) / 1000) : .5;
        const names = [...new Set([...(inputs.mapPool || []), ...(inputs.mapSlots || []).filter(Boolean),
            ...(inputs.maps || []).map((map) => map.name)])].slice(0, CONFIG.maximumMaps);
        const maps = names.map((name) => ({ name, teams: inputs.maps?.find((map) => key(map.name) === key(name))?.teams || [{}, {}],
            available: baselineAvailable,
            probability: baselineAvailable ? sigmoid(calibration.beta * (points[0] - points[1]) / 1000
                + (adjustmentComplete ? (fit.teams[ids[0]]?.mapEffects[key(name)] || 0) - (fit.teams[ids[1]]?.mapEffects[key(name)] || 0) : 0)) : .5,
            sampleCounts: ids.map((teamId) => adjustmentComplete ? fit.teams[teamId]?.mapCounts[key(name)] || 0 : 0) }));
        const mapSeries = baselineAvailable ? vetoMixture(inputs, maps, baseProbability)
            : { available: false, distribution: {}, scenarios: [], reason: 'ranking-baseline-unavailable' };
        const coverage = { limited: true, missing: [], sourceRecords: inputs.sourceRecords || [],
            rankingDate: current?.date || null, teamPoints: points, calibrationVersion: calibrationValid ? calibration.version : null,
            missingWeeks: [...missingWeeks].filter(Boolean).sort(), excludedUnrankedHistory: fit.excludedUnrankedHistory,
            historyRows: deduplicated.rows.length, adjustmentMaps: adjustmentComplete ? fit.fittedMaps : 0,
            rankingOnly: baselineAvailable && !adjustmentComplete, mapAdjustmentComplete: adjustmentComplete,
            storageError: typeof inputs.rankingCoverage?.storageError === 'string' ? inputs.rankingCoverage.storageError : null,
            attemptsStarted: count(inputs.rankingCoverage?.attemptsStarted) || 0,
            adjustmentLabel: baselineAvailable && !adjustmentComplete ? 'Ranking only—historical map adjustment pending'
                : baselineAvailable ? 'Ranking plus historical map adjustments' : 'Ranking baseline unavailable',
            historySources: histories.length, rosterScope: 'historical-team', mapPoolKnown: inputs.mapPool?.length === 7,
            vetoMethod: mapSeries.method || 'unavailable' };
        if (!calibrationValid) coverage.missing.push('A compatible strictly pre-forecast ranking calibration is unavailable.');
        if (!current) coverage.missing.push('The required prior weekly ranking snapshot is unavailable.');
        else if (points.some((point) => point === null)) coverage.missing.push('A current team is absent from the required ranking.');
        if (baselineAvailable && !adjustmentComplete) coverage.missing.push(coverage.adjustmentLabel);
        if (fit.excludedUnrankedHistory) coverage.missing.push(`${fit.excludedUnrankedHistory} historical maps excluded because a team was unranked.`);
        return { available: baselineAvailable && mapSeries.available,
            probability: baselineAvailable && mapSeries.available ? mapSeries.probability : null,
            baseProbability, maps, mapSeries: { ...mapSeries, maps }, scenarios: mapSeries.scenarios || [], coverage,
            diagnostics: { modelVersion: RANKING_VERSION, assumptions: ['Weekly HLTV ranking point differences anchor map probabilities.',
                'Map residuals use each historical map\'s strictly prior weekly ranking for both teams.',
                'Only the target teams have zero-centered, regularized map adjustments; no team-strength intercept is fitted.',
                'Historical team records do not establish current roster continuity.',
                'Exact series probabilities assume conditionally independent maps.'] }, players: [[], []] };
    }
    function calculateRankingModes(inputs, marketCalculator = null) {
        const structural = rankingStructural(inputs);
        const market = typeof marketCalculator === 'function' ? marketCalculator(inputs)
            : { available: false, probability: null, reliability: 0, accepted: [], rejected: [] };
        // The existing market-equivalent-map blend and series reconstruction are
        // shared unchanged with the archived market-map implementation.
        const stats = networkPrediction(inputs, 'stats', market, structural);
        const marketResult = networkPrediction(inputs, 'market', market, structural);
        for (const result of [stats, marketResult]) {
            result.modelVersion = RANKING_VERSION;
            if (!result.insufficient && result.mode === 'stats' && result.fallback !== 'market-only') {
                result.quality.label = structural.coverage.adjustmentLabel;
            }
        }
        for (const map of stats.maps) map.selectionProbability = clip((stats.structural.mapSeries.selectedMaps || [])
            .reduce((sum, selection) => sum + (key(selection.name) === key(map.name) ? selection.selectionProbability : 0), 0), 0, 1);
        stats.structural = { ...stats.structural, available: !stats.insufficient, probability: stats.probabilityA,
            statisticalProbability: structural.probability, maps: stats.maps, scenarios: stats.scenarios };
        marketResult.structural = stats.structural;
        return { stats, market: marketResult };
    }
    globalThis.HLTV_MATCH_PREDICTION_MODEL_RANKING = Object.freeze({ modelVersion: RANKING_VERSION, config: RANKING_DEFAULTS,
        extractMatchPageData, extractAnalyticsPageData,
        extractTeamHistoryPageData: (document, source) => extractTeamHistoryPageData(document, source, true),
        normalizePredictionInputs: normalizeRankingInputs, calculateStructuralProbability: rankingStructural,
        calculatePredictionModes: calculateRankingModes,
        calculateFinalPrediction: (inputs, mode = 'stats', marketCalculator = null) => calculateRankingModes(inputs, marketCalculator)[mode === 'market' ? 'market' : 'stats'],
        seriesDistribution, marketMapProbability, fitRankingBaseline, fitMapAdjustments,
        weekBefore, rankingSnapshotFor, latestForecastDay,
        isValidHistoryRow: (row) => Boolean(historyRow(row)), parseNumber: number });

    // Historical target results are fitted on one opposition-strength scale.
    // Own-team ranking points never enter this model, including its priors.
    const OPPONENT_VERSION = 'opponent-map-1';
    const OPPONENT_DEFAULTS = Object.freeze({ maximumHistoryRows: 600, historyDays: 90, referenceOpponentPoints: 500,
        pooledPseudoObservations: 1 });
    function validOpponentCalibration(value, forecastDay) {
        return Boolean(value && value.schemaVersion === 1 && value.modelVersion === OPPONENT_VERSION
            && text(value.version) && dateDay(forecastDay) !== null && dateDay(value.trainedThrough) !== null
            && value.trainedThrough < forecastDay && finite(value.beta) !== null && value.beta >= 0
            && finite(value.halfLifeDays) !== null && value.halfLifeDays > 0
            && finite(value.mapPenalty) !== null && value.mapPenalty > 0
            && Number.isSafeInteger(value.iterations) && value.iterations >= 1 && value.iterations <= 500);
    }
    function opponentFitRows(rawRows, snapshots, options) {
        const unique = uniqueRankingRows(rawRows, options.referenceDate);
        const parameters = rankingFitParameters(options);
        const targets = new Set((options.targetIds || unique.rows.flatMap((row) => [row.teamA, row.teamB])).map(id).filter(Boolean));
        const reference = dateDay(options.referenceDate);
        const missingWeeks = new Set(); const unrankedMaps = new Set(); const fittedMaps = new Set();
        const observations = []; const targetCounts = {}; const truncatedTargets = new Set();
        let excludedUnrankedObservations = 0;
        for (const row of unique.rows) {
            if (reference === null || dateDay(row.date) < reference + 1 - OPPONENT_DEFAULTS.historyDays) continue;
            const observedTargets = [row.teamA, row.teamB].filter((teamId) => targets.has(teamId));
            if (!observedTargets.length) continue;
            const snapshot = rankingSnapshotFor(row.date, snapshots);
            if (!snapshot) { missingWeeks.add(weekBefore(row.date)); continue; }
            for (const teamId of observedTargets) {
                // A shared head-to-head row contributes one independently anchored
                // observation for each target, with that target's opponent points.
                const opponentId = teamId === row.teamA ? row.teamB : row.teamA;
                const opponentPoints = rankingPoints(snapshot, opponentId);
                if (opponentPoints === null) {
                    unrankedMaps.add(row.mapId); excludedUnrankedObservations += 1; continue;
                }
                targetCounts[teamId] = (targetCounts[teamId] || 0) + 1;
                if (targetCounts[teamId] > OPPONENT_DEFAULTS.maximumHistoryRows) { truncatedTargets.add(teamId); continue; }
                fittedMaps.add(row.mapId);
                observations.push({ teamId, mapId: row.mapId, date: row.date, mapKey: key(row.map), opponentPoints,
                    outcome: Number(teamId === row.teamA ? row.scoreA > row.scoreB : row.scoreB > row.scoreA),
                    weight: Math.pow(2, -(reference - dateDay(row.date)) / parameters.halfLifeDays) });
            }
        }
        return { ...unique, parameters, targets, observations, fittedMaps: fittedMaps.size,
            excludedUnrankedHistory: unrankedMaps.size, excludedUnrankedObservations,
            missingWeeks: [...missingWeeks].filter(Boolean).sort(), truncatedTargets: [...truncatedTargets].sort() };
    }
    function fitOpponentCoordinate(observations, beta, initial, iterations, priorCenter, priorWeight, pseudoOpponent = null) {
        let strength = initial;
        for (let iteration = 0; iteration < iterations; iteration += 1) {
            let gradient = priorWeight * (strength - priorCenter); let curvature = priorWeight;
            if (pseudoOpponent !== null) {
                // One total pseudo-observation: half a win and half a loss versus
                // this team's weighted mean opposition. This keeps separated
                // samples finite without assigning any own-team ranking strength.
                const probability = sigmoid(strength - beta * (pseudoOpponent / 1000));
                gradient += probability - .5; curvature += probability * (1 - probability);
            }
            for (const observation of observations) {
                const probability = sigmoid(strength - beta * (observation.opponentPoints / 1000));
                gradient += observation.weight * (probability - observation.outcome);
                curvature += observation.weight * probability * (1 - probability);
            }
            if (curvature <= 1e-14) break;
            const change = clip(gradient / curvature, -5, 5);
            strength -= change;
            if (Math.abs(change) < 1e-10) break;
        }
        return strength;
    }
    function fitOpponentAbilities(rawRows, snapshots, options = {}) {
        const fit = opponentFitRows(rawRows, snapshots, options);
        const usable = finite(options.beta) !== null && options.beta >= 0
            && finite(options.halfLifeDays) !== null && options.halfLifeDays > 0
            && finite(options.mapPenalty) !== null && options.mapPenalty > 0;
        const teams = {};
        for (const teamId of [...fit.targets].sort()) {
            const observations = usable ? fit.observations.filter((row) => row.teamId === teamId) : [];
            const team = { strength: null, mapStrengths: {}, mapEffects: {}, mapCounts: {}, mapWins: {},
                mapEffectiveCounts: {}, mapWeightedWins: {}, mapAdjustedWinRates: {}, mapsObserved: observations.length,
                weightedMaps: 0, wins: 0, rawWinRate: null, adjustedWinRate: null, meanOpponentPoints: null };
            teams[teamId] = team;
            if (!observations.length) continue;
            team.weightedMaps = observations.reduce((sum, row) => sum + row.weight, 0);
            team.wins = observations.reduce((sum, row) => sum + row.outcome, 0);
            team.rawWinRate = team.wins / observations.length;
            if (!(team.weightedMaps > 0) || !Number.isFinite(team.weightedMaps)) continue;
            team.meanOpponentPoints = observations.reduce((sum, row) => sum + row.weight * row.opponentPoints, 0) / team.weightedMaps;
            const initial = options.beta * (team.meanOpponentPoints / 1000);
            team.strength = fitOpponentCoordinate(observations, options.beta, initial, fit.parameters.iterations,
                initial, 0, team.meanOpponentPoints);
            if (!Number.isFinite(team.strength)) { team.strength = null; continue; }
            team.adjustedWinRate = sigmoid(team.strength - options.beta * (OPPONENT_DEFAULTS.referenceOpponentPoints / 1000));
            for (const row of observations) {
                team.mapCounts[row.mapKey] = (team.mapCounts[row.mapKey] || 0) + 1;
                team.mapWins[row.mapKey] = (team.mapWins[row.mapKey] || 0) + row.outcome;
                team.mapEffectiveCounts[row.mapKey] = (team.mapEffectiveCounts[row.mapKey] || 0) + row.weight;
                team.mapWeightedWins[row.mapKey] = (team.mapWeightedWins[row.mapKey] || 0) + row.weight * row.outcome;
            }
            for (const name of Object.keys(team.mapCounts).sort()) {
                team.mapStrengths[name] = fitOpponentCoordinate(observations.filter((row) => row.mapKey === name),
                    options.beta, team.strength, fit.parameters.iterations, team.strength, fit.parameters.mapPenalty);
                team.mapEffects[name] = team.mapStrengths[name] - team.strength;
                team.mapAdjustedWinRates[name] = sigmoid(team.mapStrengths[name]
                    - options.beta * (OPPONENT_DEFAULTS.referenceOpponentPoints / 1000));
            }
        }
        return { schemaVersion: 1, modelVersion: OPPONENT_VERSION, trainedThrough: options.referenceDate, teams,
            available: usable && Object.values(teams).length > 0 && Object.values(teams).every((team) => finite(team.strength) !== null)
                && !fit.missingWeeks.length && !fit.conflictingRows && !fit.rejectedRows && !fit.truncatedTargets.length,
            fittedMaps: usable ? fit.fittedMaps : 0, fittedObservations: usable ? fit.observations.length : 0,
            excludedUnrankedHistory: fit.excludedUnrankedHistory, excludedUnrankedObservations: fit.excludedUnrankedObservations,
            missingWeeks: fit.missingWeeks, conflictingRows: fit.conflictingRows, rejectedRows: fit.rejectedRows,
            truncatedTargets: fit.truncatedTargets, referenceOpponentPoints: OPPONENT_DEFAULTS.referenceOpponentPoints,
            pooledPseudoObservations: OPPONENT_DEFAULTS.pooledPseudoObservations };
    }
    function normalizeOpponentInputs(rawMatch, rawAnalytics, histories = [], sourceRecords = []) {
        return { ...normalizeNetworkInputs(rawMatch, rawAnalytics, histories, sourceRecords),
            modelVersion: OPPONENT_VERSION, lineups: [[], []], vrs: [] };
    }
    function opponentStructural(inputs) {
        const forecastDay = latestForecastDay(inputs); const before = dateDay(forecastDay);
        const referenceDate = before === null ? '' : new Date((before - 1) * 86400000).toISOString().slice(0, 10);
        const ids = (inputs.teams || []).map((team) => id(team.id));
        const validTeams = ids.length === 2 && ids.every(Boolean) && ids[0] !== ids[1];
        const calibration = Object.hasOwn(inputs, 'opponentCalibration') ? inputs.opponentCalibration : globalThis.HLTV_OPPONENT_CALIBRATION;
        const calibrationValid = validOpponentCalibration(calibration, forecastDay);
        const histories = (Array.isArray(inputs.histories) ? inputs.histories : []).slice(0, 2);
        const rawRows = []; let invalidHistoryRows = 0;
        for (const history of histories) {
            const teamId = id(history.teamId);
            if (!ids.includes(teamId)) continue;
            for (const raw of (Array.isArray(history.maps) ? history.maps : []).slice(0, OPPONENT_DEFAULTS.maximumHistoryRows)) {
                const row = historyRow(raw);
                if (!row) { invalidHistoryRows += 1; continue; }
                if (![row.teamA, row.teamB].includes(teamId) || before === null || row.date >= forecastDay
                    || dateDay(row.date) < before - OPPONENT_DEFAULTS.historyDays) continue;
                rawRows.push(row);
            }
        }
        const deduplicated = uniqueRankingRows(rawRows, referenceDate);
        const fit = fitOpponentAbilities(rawRows, inputs.rankingSnapshots || [], { ...(calibrationValid ? calibration : {}),
            referenceDate, targetIds: ids });
        // Current-week transport requests are useful for caching, but only the
        // exact weeks of eligible historical maps are required for inference.
        const requiredWeeks = new Set(deduplicated.rows.map((row) => weekBefore(row.date)).filter(Boolean));
        const missingWeeks = new Set([...fit.missingWeeks,
            ...(Array.isArray(inputs.rankingCoverage?.missingWeeks) ? inputs.rankingCoverage.missingWeeks : [])
                .filter((week) => requiredWeeks.has(week))]);
        const completeHistories = before !== null && validTeams && ids.every((teamId) => histories.some((history) =>
            id(history.teamId) === teamId && Array.isArray(history.maps) && history.maps.length <= OPPONENT_DEFAULTS.maximumHistoryRows
            && !history.truncated && !history.rejectedRows && history.endDate === referenceDate
            && dateDay(history.startDate) !== null && dateDay(history.startDate) <= before - OPPONENT_DEFAULTS.historyDays));
        const storageError = typeof inputs.rankingCoverage?.storageError === 'string' ? inputs.rankingCoverage.storageError : '';
        const evidenceAvailable = calibrationValid && validTeams && completeHistories && !invalidHistoryRows
            && !fit.conflictingRows && !fit.rejectedRows && !fit.truncatedTargets.length && !missingWeeks.size
            && ids.every((teamId) => finite(fit.teams[teamId]?.strength) !== null);
        const baseProbability = evidenceAvailable ? sigmoid(fit.teams[ids[0]].strength - fit.teams[ids[1]].strength) : .5;
        const names = [...new Set([...(inputs.mapPool || []), ...(inputs.mapSlots || []).filter(Boolean),
            ...(inputs.maps || []).map((map) => map.name)])].slice(0, CONFIG.maximumMaps);
        const maps = names.map((name) => {
            const mapKey = key(name); const teams = ids.map((teamId) => fit.teams[teamId]);
            const strengths = teams.map((team) => team?.mapStrengths[mapKey] ?? team?.strength);
            return { name, teams: inputs.maps?.find((map) => key(map.name) === mapKey)?.teams || [{}, {}],
                available: evidenceAvailable, probability: evidenceAvailable ? sigmoid(strengths[0] - strengths[1]) : .5,
                sampleCounts: teams.map((team) => team?.mapCounts[mapKey] || 0),
                winCounts: teams.map((team) => team?.mapWins[mapKey] || 0),
                rawWinRates: teams.map((team) => team?.mapCounts[mapKey] ? team.mapWins[mapKey] / team.mapCounts[mapKey] : null),
                effectiveSampleCounts: teams.map((team) => team?.mapEffectiveCounts[mapKey] || 0),
                adjustedWinRates: strengths.map((strength) => evidenceAvailable ? sigmoid(strength
                    - calibration.beta * (OPPONENT_DEFAULTS.referenceOpponentPoints / 1000)) : null),
                pooledFallback: teams.map((team) => !team?.mapCounts[mapKey]) };
        });
        const mapSeries = evidenceAvailable ? vetoMixture(inputs, maps, baseProbability)
            : { available: false, distribution: {}, scenarios: [], reason: 'opponent-history-unavailable' };
        const coverage = { limited: true, missing: [], errorCodes: [], sourceRecords: inputs.sourceRecords || [],
            calibrationVersion: calibrationValid ? calibration.version : null, missingWeeks: [...missingWeeks].sort(),
            excludedUnrankedHistory: fit.excludedUnrankedHistory, excludedUnrankedObservations: fit.excludedUnrankedObservations,
            historyRows: deduplicated.rows.length, adjustmentMaps: evidenceAvailable ? fit.fittedMaps : 0,
            teamHistoryMaps: ids.map((teamId) => fit.teams[teamId]?.mapsObserved || 0),
            rankingOnly: false, mapAdjustmentComplete: Boolean(evidenceAvailable), storageError,
            rankingErrors: Array.isArray(inputs.rankingCoverage?.errors) ? inputs.rankingCoverage.errors : [],
            attemptsStarted: count(inputs.rankingCoverage?.attemptsStarted) || 0,
            adjustmentLabel: evidenceAvailable ? 'Opponent-adjusted historical map estimates' : 'Opponent-adjusted map estimates unavailable',
            historySources: histories.length, rosterScope: 'historical-team', referenceOpponentPoints: OPPONENT_DEFAULTS.referenceOpponentPoints,
            pooledPseudoObservations: OPPONENT_DEFAULTS.pooledPseudoObservations,
            mapPoolKnown: inputs.mapPool?.length === 7, vetoMethod: mapSeries.method || 'unavailable' };
        const missing = (code, message) => { coverage.errorCodes.push(code); coverage.missing.push(message); };
        if (!calibrationValid) missing('calibration-unavailable', 'A compatible strictly pre-forecast opponent calibration is unavailable.');
        if (!validTeams || before === null) missing('match-context-invalid', 'Two distinct teams and a valid forecast date are required.');
        if (!completeHistories) missing('history-incomplete', 'Complete prior-day histories for both teams are required.');
        if (invalidHistoryRows || fit.rejectedRows) missing('history-invalid', 'Historical map rows failed validation.');
        if (fit.conflictingRows) missing('history-conflict', 'Conflicting historical map IDs prevent estimation.');
        if (missingWeeks.size) missing('ranking-weeks-missing', 'Required historical opponent ranking weeks are unavailable.');
        if (storageError) missing('ranking-storage-error', storageError);
        if (ids.some((teamId) => finite(fit.teams[teamId]?.strength) === null)) missing('team-evidence-missing', 'Both teams need usable ranked-opponent map results.');
        if (fit.excludedUnrankedHistory) coverage.missing.push(`${fit.excludedUnrankedHistory} historical maps include excluded unranked-opponent observations.`);
        return { available: Boolean(evidenceAvailable && mapSeries.available),
            probability: evidenceAvailable && mapSeries.available ? mapSeries.probability : null,
            baseProbability, maps, mapSeries: { ...mapSeries, maps }, scenarios: mapSeries.scenarios || [], coverage,
            diagnostics: { modelVersion: OPPONENT_VERSION, assumptions: [
                'Only historical opponents\' strictly prior weekly HLTV points anchor historical results; own-team ranking points are unused.',
                'Pooled ability uses the same map histories with one half-win plus half-loss pseudo-observation at weighted mean opponent points.',
                'Map abilities are regularized toward that team\'s pooled ability; absent maps use pooled ability.',
                'The 500-point common reference describes adjusted win rates only and does not affect forecasts.',
                'Historical team records do not establish current roster continuity.',
                'Exact series probabilities assume conditionally independent maps.'] }, players: [[], []] };
    }
    function opponentStatsOnly(inputs, structural = opponentStructural(inputs)) {
        const market = { available: false, probability: null, reliability: 0, accepted: [], rejected: [] };
        const result = networkPrediction({ ...inputs, marketWeight: 0 }, 'stats', market, structural);
        result.modelVersion = OPPONENT_VERSION;
        result.mode = 'stats-only';
        // This is an explicit statistical choice, rather than a source fallback.
        result.fallback = '';
        if (!result.insufficient) result.quality.label = structural.coverage.adjustmentLabel;
        for (const map of result.maps) map.selectionProbability = clip((structural.mapSeries.selectedMaps || [])
            .reduce((sum, selection) => sum + (key(selection.name) === key(map.name) ? selection.selectionProbability : 0), 0), 0, 1);
        result.structural = { ...result.structural, available: !result.insufficient, probability: result.probabilityA,
            statisticalProbability: structural.probability, maps: result.maps, scenarios: result.scenarios };
        return result;
    }
    function calculateOpponentModes(inputs, marketCalculator = null) {
        const structural = opponentStructural(inputs);
        const market = typeof marketCalculator === 'function' ? marketCalculator(inputs)
            : { available: false, probability: null, reliability: 0, accepted: [], rejected: [] };
        const stats = networkPrediction(inputs, 'stats', market, structural);
        const marketResult = networkPrediction(inputs, 'market', market, structural);
        for (const result of [stats, marketResult]) {
            result.modelVersion = OPPONENT_VERSION;
            if (!result.insufficient && result.mode === 'stats' && result.fallback !== 'market-only') result.quality.label = structural.coverage.adjustmentLabel;
        }
        for (const map of stats.maps) map.selectionProbability = clip((stats.structural.mapSeries.selectedMaps || [])
            .reduce((sum, selection) => sum + (key(selection.name) === key(map.name) ? selection.selectionProbability : 0), 0), 0, 1);
        stats.structural = { ...stats.structural, available: !stats.insufficient, probability: stats.probabilityA,
            statisticalProbability: structural.probability, maps: stats.maps, scenarios: stats.scenarios };
        marketResult.structural = stats.structural;
        return { stats, market: marketResult, 'stats-only': opponentStatsOnly(inputs, structural) };
    }
    globalThis.HLTV_MATCH_PREDICTION_MODEL_OPPONENT = Object.freeze({ modelVersion: OPPONENT_VERSION, config: OPPONENT_DEFAULTS,
        extractMatchPageData, extractAnalyticsPageData,
        extractTeamHistoryPageData: (document, source) => extractTeamHistoryPageData(document, source, true),
        normalizePredictionInputs: normalizeOpponentInputs, calculateStructuralProbability: opponentStructural,
        calculatePredictionModes: calculateOpponentModes,
        calculateFinalPrediction: (inputs, mode = 'stats', marketCalculator = null) => mode === 'stats-only'
            ? opponentStatsOnly(inputs) : calculateOpponentModes(inputs, marketCalculator)[mode === 'market' ? 'market' : 'stats'],
        seriesDistribution, marketMapProbability, fitOpponentAbilities, validCalibration: validOpponentCalibration,
        weekBefore, rankingSnapshotFor, latestForecastDay,
        isValidHistoryRow: (row) => Boolean(historyRow(row)), parseNumber: number });
})();
