// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Plennhar

(async () => {
    'use strict';

    if (globalThis.HLTV_EXTENSION_GATE
        && !await globalThis.HLTV_EXTENSION_GATE.ready) return;

    const CONFIG = Object.freeze({
        moduleName: 'HLTV team Overperformance Score',
        description: 'Overperformance Score (OS) compares actual T-side round-win performance with a CT opening-duel expectation fitted from the active filtered team cohort, used here as a rough player-strength proxy.',
        interpretation: 'It may serve as a rough proxy for IGL or team-system strength, but it is not an isolated or causal measure of an IGL\'s impact.',
        globalName: 'HLTV_TEAM_PERFORMANCE_DIFFERENCE_V21',
        enableKey: 'enableTeamPerformanceDifference',
        defaultEnabled: true,
        route: /^\/stats\/teams\/ftu\/?$/,
        tableSelector: 'table.stats-table.player-ratings-table.ftu',
        sideLinkSelector: [
            '.stats-top-menu a.stats-top-menu-item-link[href*="/stats/teams/ftu"]',
            '.stats-sidebar a.sidebar-single-line-item[href*="/stats/teams/ftu"]',
        ].join(', '),
        sideParameter: 'side',
        extensionParameterPrefix: 'hltvSp',
        ctSide: 'COUNTER_TERRORIST',
        tSide: 'TERRORIST',
        minimumCalibrationTeams: 3,
        responseTimeoutMs: 12_000,
        maximumResponseBytes: 4 * 1024 * 1024,
        maximumErrorCharacters: 160,
        styleId: 'hltv-sp-performance-difference-style',
        managedAttribute: 'data-hltv-sp-performance-difference',
        percentageDigits: 1,
        neutralThreshold: 0.05,
        sanitizerRemoveElements: Object.freeze([
            'applet', 'audio', 'base', 'embed', 'frame', 'frameset', 'iframe',
            'img', 'link', 'meta', 'noscript', 'object', 'picture', 'portal',
            'script', 'source', 'style', 'track', 'video',
            { name: 'svg', namespace: 'http://www.w3.org/2000/svg' },
            { name: 'math', namespace: 'http://www.w3.org/1998/Math/MathML' },
        ]),
        sanitizerRemoveAttributes: Object.freeze([
            'background', 'data', 'imagesizes', 'imagesrcset', 'manifest',
            'ping', 'poster', 'src', 'srcset', 'style',
        ]),
    });

    const extensionApi = globalThis.browser;
    let inertSanitizer = null;
    const state = {
        enabled: CONFIG.defaultEnabled,
        destroyed: false,
        generation: 0,
        storageListener: null,
        models: new Map(),
        responseCache: new Map(),
        activeControllers: new Set(),
    };

    function boundedText(value, maximum = CONFIG.maximumErrorCharacters) {
        return String(value ?? '').replace(/\s+/g, ' ').trim().slice(0, maximum);
    }

    function parsePercentage(value) {
        const text = String(value ?? '').trim();
        if (!text || text === '-' || !/%$/.test(text)) return null;
        const parsed = Number.parseFloat(text.replace(',', '.'));
        return Number.isFinite(parsed) ? parsed : null;
    }

    function calculatePerformanceDifference(
        tRoundWinPercentage,
        ctOpeningPercentage,
        calibration,
    ) {
        if (!Number.isFinite(tRoundWinPercentage)
            || !Number.isFinite(ctOpeningPercentage)
            || !calibration?.available) {
            return null;
        }
        const expected = calibration.roundWinMean
            + calibration.openingCoefficient
                * (ctOpeningPercentage - calibration.openingMean);
        return Number.isFinite(expected) ? tRoundWinPercentage - expected : null;
    }

    function safeUrl(value, base = location.href) {
        try {
            return new URL(String(value || ''), base);
        } catch {
            return null;
        }

    }

    function teamIdFromRow(row) {
        const anchor = row.querySelector('a[href*="/stats/teams/"]');
        const url = safeUrl(anchor?.getAttribute('href'));
        if (url?.origin !== location.origin || url.protocol !== 'https:') return '';
        return /^\/stats\/teams\/(\d{1,20})(?:\/|$)/.exec(url.pathname)?.[1] || '';
    }

    function headerModel(table) {
        const rows = [...(table.tHead?.rows || [])];
        const headerRow = rows.find((row) => {
            const labels = [...row.cells].map((cell) => boundedText(cell.textContent, 40));
            return labels.includes('Team') && labels.includes('RW%') && labels.includes('OpK');
        });
        if (!headerRow) return null;
        const labels = [...headerRow.cells].map((cell) => boundedText(cell.textContent, 40));
        return {
            headerRow,
            categoryRow: rows.find((row) => row !== headerRow) || null,
            teamIndex: labels.indexOf('Team'),
            roundWinIndex: labels.indexOf('RW%'),
            openingIndex: labels.indexOf('OpK'),
        };
    }

    function supportedTables(document) {
        return [...document.querySelectorAll(CONFIG.tableSelector)]
            .map((table) => ({ table, header: headerModel(table) }))
            .filter((entry) => entry.header);
    }

    function extractSideStats(document) {
        const result = new Map();
        for (const { table, header } of supportedTables(document)) {
            for (const row of table.tBodies[0]?.rows || []) {
                const id = teamIdFromRow(row);
                if (!id) continue;
                const cells = [...row.cells];
                const previous = result.get(id) || {
                    id,
                    roundWinPercentage: null,
                    openingPercentage: null,
                };
                const roundWinPercentage = header.roundWinIndex >= 0
                    ? parsePercentage(cells[header.roundWinIndex]?.textContent)
                    : null;
                const openingPercentage = header.openingIndex >= 0
                    ? parsePercentage(cells[header.openingIndex]?.textContent)
                    : null;
                result.set(id, {
                    id,
                    roundWinPercentage: Number.isFinite(roundWinPercentage)
                        ? roundWinPercentage
                        : previous.roundWinPercentage,
                    openingPercentage: Number.isFinite(openingPercentage)
                        ? openingPercentage
                        : previous.openingPercentage,
                });
            }
        }
        return result;
    }

    function pairedCalibrationRows(tStats, ctStats) {
        if (typeof tStats?.entries !== 'function' || typeof ctStats?.get !== 'function') {
            return [];
        }
        const pairs = [];
        for (const [id, tEntry] of tStats.entries()) {
            const roundWinPercentage = tEntry?.roundWinPercentage;
            const openingPercentage = ctStats.get(id)?.openingPercentage;
            if (!Number.isFinite(roundWinPercentage) || !Number.isFinite(openingPercentage)) {
                continue;
            }
            pairs.push({
                id: String(id),
                roundWinPercentage,
                openingPercentage,
            });
        }
        return pairs.sort((first, second) => first.id.localeCompare(second.id));
    }

    function calibratePerformanceDifference(tStats, ctStats) {
        const pairs = pairedCalibrationRows(tStats, ctStats);
        if (pairs.length < CONFIG.minimumCalibrationTeams) {
            return Object.freeze({
                available: false,
                sampleSize: pairs.length,
                reason: `Dynamic calibration needs at least ${CONFIG.minimumCalibrationTeams} teams with both filtered T RW and CT OpK values (found ${pairs.length}).`,
            });
        }

        const roundWinMean = pairs.reduce(
            (sum, pair) => sum + pair.roundWinPercentage,
            0,
        ) / pairs.length;
        const openingMean = pairs.reduce(
            (sum, pair) => sum + pair.openingPercentage,
            0,
        ) / pairs.length;
        let openingSumOfSquares = 0;
        let openingSquareScale = 0;
        let crossDeviation = 0;
        for (const pair of pairs) {
            const openingDeviation = pair.openingPercentage - openingMean;
            const roundWinDeviation = pair.roundWinPercentage - roundWinMean;
            openingSumOfSquares += openingDeviation * openingDeviation;
            openingSquareScale += pair.openingPercentage * pair.openingPercentage;
            crossDeviation += openingDeviation * roundWinDeviation;
        }
        if (!(openingSumOfSquares > Number.EPSILON * Math.max(1, openingSquareScale))) {
            return Object.freeze({
                available: false,
                sampleSize: pairs.length,
                reason: 'Dynamic calibration needs variation in the filtered CT OpK values.',
            });
        }

        const openingCoefficient = crossDeviation / openingSumOfSquares;
        const intercept = roundWinMean - openingCoefficient * openingMean;
        if (![roundWinMean, openingMean, openingCoefficient, intercept].every(Number.isFinite)) {
            return Object.freeze({
                available: false,
                sampleSize: pairs.length,
                reason: 'Dynamic calibration could not be calculated from the filtered values.',
            });
        }
        return Object.freeze({
            available: true,
            sampleSize: pairs.length,
            roundWinMean,
            openingMean,
            openingCoefficient,
            intercept,
        });
    }

    function parameterEntries(searchParams) {
        const entries = [];
        searchParams.forEach((value, key) => entries.push([key, value]));
        return entries;
    }

    function sortedParameters(url, { omitSide = false, omitExtension = false } = {}) {
        return parameterEntries(url.searchParams)
            .filter(([key]) => !(
                (omitSide && key === CONFIG.sideParameter)
                || (omitExtension && key.startsWith(CONFIG.extensionParameterPrefix))
            ))
            .sort(([firstKey, firstValue], [secondKey, secondValue]) => (
                firstKey.localeCompare(secondKey) || firstValue.localeCompare(secondValue)
            ));
    }

    function validSideUrl(url, side, currentUrl) {
        return url?.origin === location.origin
            && url.protocol === 'https:'
            && CONFIG.route.test(url.pathname)
            && url.searchParams.get(CONFIG.sideParameter) === side
            && JSON.stringify(sortedParameters(url, {
                omitSide: true,
                omitExtension: true,
            })) === JSON.stringify(sortedParameters(currentUrl, {
                omitSide: true,
                omitExtension: true,
            }));
    }

    function sideUrl(side) {
        if (![CONFIG.ctSide, CONFIG.tSide].includes(side)) return null;
        const currentUrl = new URL(location.href);
        currentUrl.hash = '';
        for (const anchor of document.querySelectorAll(CONFIG.sideLinkSelector)) {
            const candidate = safeUrl(anchor.getAttribute('href'));
            if (!validSideUrl(candidate, side, currentUrl)) continue;
            candidate.hash = '';
            for (const [key] of parameterEntries(candidate.searchParams)) {
                if (key.startsWith(CONFIG.extensionParameterPrefix)) {
                    candidate.searchParams.delete(key);
                }
            }
            return candidate;
        }
        const url = new URL(currentUrl);
        for (const [key] of parameterEntries(url.searchParams)) {
            if (key.startsWith(CONFIG.extensionParameterPrefix)) url.searchParams.delete(key);
        }
        url.searchParams.set(CONFIG.sideParameter, side);
        return url;
    }

    function getInertSanitizer() {
        if (inertSanitizer) return inertSanitizer;
        if (typeof globalThis.Sanitizer !== 'function') {
            throw new Error('Secure FTU parsing requires Firefox 148 or newer.');
        }
        inertSanitizer = new globalThis.Sanitizer({
            removeElements: CONFIG.sanitizerRemoveElements,
            removeAttributes: CONFIG.sanitizerRemoveAttributes,
            comments: false,
        });
        return inertSanitizer;
    }

    function parseInertHtml(value) {
        const template = document.createElement('template');
        if (typeof template.setHTML !== 'function') {
            throw new Error('Secure FTU parsing is unavailable.');
        }
        template.setHTML(String(value ?? ''), { sanitizer: getInertSanitizer() });
        return template.content;
    }

    async function cancelReader(reader, reason) {
        try {
            await reader?.cancel?.(reason);
        } catch {
            // A failed or closed stream may reject cancellation.
        }
    }

    async function cancelBody(body, reason) {
        try {
            await body?.cancel?.(reason);
        } catch {
            // An already locked, failed, or closed body may reject cancellation.
        }
    }

    async function readBoundedHtml(response) {
        const rawLength = response.headers.get('content-length');
        if (rawLength !== null) {
            if (!/^(?:0|[1-9]\d*)$/.test(rawLength)
                || !Number.isSafeInteger(Number(rawLength))) {
                const error = new Error('HLTV returned an invalid response size.');
                await cancelBody(response.body, error);
                throw error;
            }
            if (Number(rawLength) > CONFIG.maximumResponseBytes) {
                const error = new Error('HLTV response exceeded the safe size limit.');
                await cancelBody(response.body, error);
                throw error;
            }
        }
        const body = response?.body;
        if (!body || typeof body.getReader !== 'function') {
            throw new Error('HLTV response stream was unavailable.');
        }
        const reader = body.getReader();
        const decoder = new TextDecoder('utf-8');
        const chunks = [];
        let byteCount = 0;
        let completed = false;
        try {
            while (true) {
                const result = await reader.read();
                if (result?.done) {
                    completed = true;
                    break;
                }
                const rawChunk = result?.value;
                const chunk = rawChunk instanceof ArrayBuffer
                    ? new Uint8Array(rawChunk)
                    : ArrayBuffer.isView(rawChunk)
                        ? new Uint8Array(
                            rawChunk.buffer,
                            rawChunk.byteOffset,
                            rawChunk.byteLength,
                        )
                        : null;
                if (!chunk) throw new Error('HLTV response stream was invalid.');
                byteCount += chunk.byteLength;
                if (byteCount > CONFIG.maximumResponseBytes) {
                    throw new Error('HLTV response exceeded the safe size limit.');
                }
                chunks.push(decoder.decode(chunk, { stream: true }));
            }
            chunks.push(decoder.decode());
            if (!byteCount) throw new Error('HLTV response was empty.');
            return chunks.join('');
        } catch (error) {
            await cancelReader(reader, error);
            throw error;
        } finally {
            if (!completed) await cancelReader(reader);
            try {
                reader.releaseLock?.();
            } catch {
                // Some stream implementations release their lock automatically.
            }
        }
    }

    function validateFetchedUrl(response, requestedUrl) {
        // With redirect mode "error", an implementation that withholds Response.url
        // cannot have silently followed to a different document.  The requested URL is
        // therefore the safe validation fallback.
        const finalUrl = safeUrl(response.url || requestedUrl.href, requestedUrl.href);
        return finalUrl?.origin === location.origin
            && CONFIG.route.test(finalUrl.pathname)
            && JSON.stringify(sortedParameters(finalUrl))
                === JSON.stringify(sortedParameters(requestedUrl));
    }

    function abortActiveFetches() {
        const reason = new DOMException('FTU request is no longer needed.', 'AbortError');
        for (const controller of state.activeControllers) controller.abort(reason);
        state.activeControllers.clear();
        state.responseCache.clear();
    }

    async function fetchSide(side) {
        const url = sideUrl(side);
        if (!url) throw new Error('Invalid FTU side.');
        const cacheKey = url.href;
        if (state.responseCache.has(cacheKey)) return state.responseCache.get(cacheKey);
        const pending = (async () => {
            const controller = new AbortController();
            state.activeControllers.add(controller);
            const timer = globalThis.setTimeout(() => controller.abort(), CONFIG.responseTimeoutMs);
            try {
                const response = await globalThis.fetch(url.href, {
                    method: 'GET',
                    credentials: 'include',
                    headers: { Accept: 'text/html' },
                    cache: 'no-store',
                    redirect: 'error',
                    signal: controller.signal,
                });
                if (!response.ok) throw new Error(`HLTV request failed (${response.status}).`);
                if (!validateFetchedUrl(response, url)) {
                    throw new Error('HLTV returned the wrong FTU page.');
                }
                const mediaType = String(response.headers.get('content-type') || '')
                    .split(';', 1)[0]
                    .trim()
                    .toLocaleLowerCase();
                if (mediaType && mediaType !== 'text/html' && mediaType !== 'application/xhtml+xml') {
                    throw new Error('HLTV returned an unexpected response type.');
                }
                const html = await readBoundedHtml(response);
                const parsed = parseInertHtml(html);
                const stats = extractSideStats(parsed);
                if (!stats.size) throw new Error('The requested FTU table was missing.');
                return stats;
            } finally {
                globalThis.clearTimeout(timer);
                state.activeControllers.delete(controller);
            }
        })();
        state.responseCache.set(cacheKey, pending);
        try {
            return await pending;
        } catch (error) {
            if (state.responseCache.get(cacheKey) === pending) {
                state.responseCache.delete(cacheKey);
            }
            throw error;
        }
    }

    function installStyle() {
        if (document.getElementById(CONFIG.styleId)) return;
        const style = document.createElement('style');
        style.id = CONFIG.styleId;
        style.textContent = `
            [${CONFIG.managedAttribute}="header"] { cursor:pointer !important; user-select:none; white-space:nowrap; }
            [${CONFIG.managedAttribute}="cell"] { font-variant-numeric:tabular-nums; white-space:nowrap; }
            .hltv-sp-pd-sort { margin-left:3px; color:#0878b9; font-size:9px; }
        `;
        document.head.append(style);
    }

    function rememberTable(table) {
        if (state.models.has(table)) return state.models.get(table);
        const model = {
            table,
            originalRows: [...(table.tBodies[0]?.rows || [])],
            sortDirection: '',
            header: null,
            categoryHeader: null,
            clickHandler: null,
            keyHandler: null,
        };
        state.models.set(table, model);
        return model;
    }

    function restoreRowOrder(model) {
        const body = model.table.tBodies[0];
        if (!body) return;
        for (const row of model.originalRows) if (row.parentNode === body) body.append(row);
    }

    function updateSortIndicator(model) {
        const marker = model.header?.querySelector('.hltv-sp-pd-sort');
        if (marker) marker.textContent = model.sortDirection === 'desc'
            ? '▼'
            : model.sortDirection === 'asc' ? '▲' : '';
        model.header?.setAttribute(
            'aria-sort',
            model.sortDirection === 'desc'
                ? 'descending'
                : model.sortDirection === 'asc' ? 'ascending' : 'none',
        );
    }

    function sortTable(model) {
        const body = model.table.tBodies[0];
        if (!body) return;
        if (!model.sortDirection) {
            restoreRowOrder(model);
            updateSortIndicator(model);
            return;
        }
        [...model.originalRows].sort((first, second) => {
            const firstValue = Number(first.querySelector(
                `[${CONFIG.managedAttribute}="cell"]`,
            )?.dataset.sort);
            const secondValue = Number(second.querySelector(
                `[${CONFIG.managedAttribute}="cell"]`,
            )?.dataset.sort);
            const firstMissing = !Number.isFinite(firstValue);
            const secondMissing = !Number.isFinite(secondValue);
            if (firstMissing !== secondMissing) return firstMissing ? 1 : -1;
            if (!firstMissing && firstValue !== secondValue) {
                return model.sortDirection === 'desc'
                    ? secondValue - firstValue
                    : firstValue - secondValue;
            }
            return model.originalRows.indexOf(first) - model.originalRows.indexOf(second);
        }).forEach((row) => body.append(row));
        updateSortIndicator(model);
    }

    function cycleSort(model) {
        model.sortDirection = model.sortDirection === ''
            ? 'desc'
            : model.sortDirection === 'desc' ? 'asc' : '';
        sortTable(model);
    }

    function addColumn(table) {
        const header = headerModel(table);
        if (!header) return null;
        const model = rememberTable(table);
        if (model.header?.isConnected) return model;

        if (header.categoryRow) {
            const category = document.createElement('th');
            category.colSpan = 1;
            category.textContent = '';
            category.setAttribute(CONFIG.managedAttribute, 'category');
            header.categoryRow.append(category);
            model.categoryHeader = category;
        }

        const columnHeader = document.createElement('th');
        columnHeader.className = 'center';
        columnHeader.textContent = 'OS';
        columnHeader.title = `${CONFIG.description} ${CONFIG.interpretation}`;
        columnHeader.setAttribute('role', 'columnheader');
        columnHeader.setAttribute('tabindex', '0');
        columnHeader.setAttribute('aria-sort', 'none');
        columnHeader.setAttribute(CONFIG.managedAttribute, 'header');
        const marker = document.createElement('span');
        marker.className = 'hltv-sp-pd-sort';
        marker.setAttribute('aria-hidden', 'true');
        columnHeader.append(marker);
        model.clickHandler = () => cycleSort(model);
        model.keyHandler = (event) => {
            if (event.key !== 'Enter' && event.key !== ' ') return;
            event.preventDefault();
            cycleSort(model);
        };
        columnHeader.addEventListener('click', model.clickHandler);
        columnHeader.addEventListener('keydown', model.keyHandler);
        header.headerRow.append(columnHeader);
        model.header = columnHeader;

        for (const row of table.tBodies[0]?.rows || []) {
            const cell = document.createElement('td');
            cell.className = 'center';
            cell.textContent = '-';
            cell.title = 'Overperformance Score is loading.';
            cell.setAttribute(CONFIG.managedAttribute, 'cell');
            row.append(cell);
        }
        return model;
    }

    function valueClass(value) {
        if (value > CONFIG.neutralThreshold) return 'good';
        if (value < -CONFIG.neutralThreshold) return 'bad';
        return 'average';
    }

    function populateModel(model, tStats, ctStats, calibration, errorMessage = '') {
        for (const row of model.originalRows) {
            const cell = row.querySelector(`[${CONFIG.managedAttribute}="cell"]`);
            if (!cell) continue;
            cell.classList.remove('good', 'bad', 'average');
            const teamId = teamIdFromRow(row);
            const tValue = tStats.get(teamId)?.roundWinPercentage;
            const ctValue = ctStats.get(teamId)?.openingPercentage;
            const difference = calculatePerformanceDifference(tValue, ctValue, calibration);
            if (difference === null) {
                cell.textContent = '-';
                delete cell.dataset.sort;
                const unavailableReason = errorMessage || (!calibration?.available
                    ? calibration?.reason
                    : 'This team does not have both filtered inputs.');
                cell.title = unavailableReason
                    ? `Overperformance Score unavailable: ${boundedText(unavailableReason)}`
                    : 'Overperformance Score unavailable for this team.';
                continue;
            }
            const expected = calibration.roundWinMean
                + calibration.openingCoefficient * (ctValue - calibration.openingMean);
            const rounded = Number(difference.toFixed(CONFIG.percentageDigits));
            const displayed = Object.is(rounded, -0) ? 0 : rounded;
            cell.textContent = `${displayed > 0 ? '+' : ''}${displayed.toFixed(CONFIG.percentageDigits)}`;
            cell.dataset.sort = String(difference);
            cell.classList.add(valueClass(difference));
            cell.title = `OS ${cell.textContent}: T RW ${tValue.toFixed(CONFIG.percentageDigits)}% - active-cohort expectation ${expected.toFixed(CONFIG.percentageDigits)}% from CT OpK ${ctValue.toFixed(CONFIG.percentageDigits)}%. Dynamic fit: ${calibration.sampleSize} paired teams, mean T RW ${calibration.roundWinMean.toFixed(CONFIG.percentageDigits)}%, mean CT OpK ${calibration.openingMean.toFixed(CONFIG.percentageDigits)}%, slope ${calibration.openingCoefficient.toFixed(3)}. ${CONFIG.interpretation}`;
        }
        if (model.sortDirection) sortTable(model);
    }

    function cleanup() {
        abortActiveFetches();
        for (const model of state.models.values()) {
            restoreRowOrder(model);
            if (model.header) {
                model.header.removeEventListener('click', model.clickHandler);
                model.header.removeEventListener('keydown', model.keyHandler);
            }
        }
        for (const element of document.querySelectorAll(`[${CONFIG.managedAttribute}]`)) {
            element.remove();
        }
        state.models.clear();
        document.getElementById(CONFIG.styleId)?.remove();
    }

    async function sideStats(currentSide, requestedSide, currentStats) {
        if (currentSide === requestedSide && currentStats.size) return currentStats;
        return fetchSide(requestedSide);
    }

    async function sync() {
        const generation = ++state.generation;
        if (state.destroyed || !state.enabled || !CONFIG.route.test(location.pathname)) {
            cleanup();
            return;
        }
        const tables = supportedTables(document);
        if (!tables.length) {
            cleanup();
            return;
        }
        installStyle();
        const models = tables.map(({ table }) => addColumn(table)).filter(Boolean);
        const currentSide = new URL(location.href).searchParams.get(CONFIG.sideParameter) || '';
        const currentStats = extractSideStats(document);
        try {
            const [tStats, ctStats] = await Promise.all([
                sideStats(currentSide, CONFIG.tSide, currentStats),
                sideStats(currentSide, CONFIG.ctSide, currentStats),
            ]);
            if (state.destroyed || generation !== state.generation) return;
            const calibration = calibratePerformanceDifference(tStats, ctStats);
            for (const model of models) populateModel(model, tStats, ctStats, calibration);
        } catch (error) {
            if (state.destroyed || generation !== state.generation) return;
            const message = boundedText(
                error instanceof Error ? error.message : 'side data could not be loaded',
            );
            const emptyStats = new Map();
            const unavailableCalibration = calibratePerformanceDifference(
                emptyStats,
                emptyStats,
            );
            for (const model of models) {
                populateModel(
                    model,
                    emptyStats,
                    emptyStats,
                    unavailableCalibration,
                    message,
                );
            }
        }
    }

    function handleStorageChanges(changes, areaName) {
        if (areaName !== 'local' || !Object.prototype.hasOwnProperty.call(changes || {}, CONFIG.enableKey)) {
            return;
        }
        const value = changes[CONFIG.enableKey]?.newValue;
        state.enabled = typeof value === 'boolean' ? value : CONFIG.defaultEnabled;
        void sync();
    }

    function whenReady() {
        if (document.readyState !== 'loading') return Promise.resolve();
        return new Promise((resolve) => document.addEventListener('DOMContentLoaded', resolve, {
            once: true,
        }));
    }

    async function initialise() {
        await whenReady();
        if (state.destroyed || !extensionApi?.storage?.local) return;
        try {
            const stored = await extensionApi.storage.local.get({
                [CONFIG.enableKey]: CONFIG.defaultEnabled,
            });
            state.enabled = typeof stored?.[CONFIG.enableKey] === 'boolean'
                ? stored[CONFIG.enableKey]
                : CONFIG.defaultEnabled;
        } catch {
            state.enabled = CONFIG.defaultEnabled;
        }
        state.storageListener = handleStorageChanges;
        extensionApi.storage.onChanged?.addListener?.(state.storageListener);
        await sync();
    }

    function destroy() {
        if (state.destroyed) return;
        state.destroyed = true;
        state.generation += 1;
        if (state.storageListener) {
            extensionApi.storage.onChanged?.removeListener?.(state.storageListener);
            state.storageListener = null;
        }
        cleanup();
    }

    const ready = initialise();
    const api = Object.freeze({
        ready,
        sync,
        destroy,
        config: CONFIG,
        testing: Object.freeze({
            parsePercentage,
            calculatePerformanceDifference,
            teamIdFromRow,
            headerModel,
            supportedTables,
            extractSideStats,
            pairedCalibrationRows,
            calibratePerformanceDifference,
            sideUrl,
            parseInertHtml,
            readBoundedHtml,
            validateFetchedUrl,
            valueClass,
        }),
    });
    Object.defineProperty(globalThis, CONFIG.globalName, {
        configurable: true,
        enumerable: false,
        writable: false,
        value: api,
    });
    globalThis.addEventListener('pagehide', destroy, { once: true });
})();
