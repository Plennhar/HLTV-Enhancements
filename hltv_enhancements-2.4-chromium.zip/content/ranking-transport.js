// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Plennhar

(async () => {
    'use strict';
    if (globalThis.HLTV_EXTENSION_GATE && !await globalThis.HLTV_EXTENSION_GATE.ready) return;
    if (globalThis.HLTV_RANKING_TRANSPORT) return;
    const snapshots = globalThis.HLTV_RANKING_SNAPSHOTS;
    const browser = globalThis.browser;
    const MAXIMUM_BYTES = 4 * 1024 * 1024;
    const MAXIMUM_WEEKS = 15;
    const DAY_MS = 86400000;
    // Freeze the observation window for this document, including across BFCache
    // restores and client recreation. Repeated loads cannot expand it backwards.
    const observationDay = new Date(Date.now()).toISOString().slice(0, 10);
    const ledger = { documentId: globalThis.crypto.randomUUID(), attemptsStarted: 0, sequence: 0, identity: null, slots: new Map() };
    let owner = null;
    let sanitizer = null;
    let listenerInstalled = false;
    const failure = (code) => Object.assign(new Error(code), { code });
    function identityValue(identity) {
        if (!identity || !/^[1-9]\d{0,19}$/.test(identity.matchId || '') || identity.phase !== 'scheduled'
            || !Number.isSafeInteger(identity.timestamp) || identity.timestamp <= Date.now()
            || !Array.isArray(identity.teams) || identity.teams.length !== 2
            || identity.teams.some((team) => !/^[1-9]\d{0,19}$/.test(team?.id || ''))
            || identity.teams[0].id === identity.teams[1].id) return null;
        return { matchId: identity.matchId, timestamp: identity.timestamp, teams: identity.teams.map(({ id }) => ({ id })) };
    }
    function active(currentOwner = owner, source = ledger.identity) {
        if (!source || !currentOwner || owner !== currentOwner || currentOwner.paused || currentOwner.destroyed
            || Date.now() >= source.timestamp || /^\/matches\/(\d{1,20})(?:\/|$)/.exec(location.pathname)?.[1] !== source.matchId) return false;
        try { return JSON.stringify(identityValue(currentOwner.getIdentity())) === JSON.stringify({ matchId: source.matchId, timestamp: source.timestamp, teams: source.teams }); }
        catch { return false; }
    }
    function extensionSender(sender) {
        try {
            const actual = new URL(sender?.url);
            const expected = new URL(browser.runtime.getURL(''));
            return sender.id === browser.runtime.id && !sender.tab && actual.protocol === expected.protocol && actual.host === expected.host;
        } catch { return false; }
    }
    async function cancelBody(body) { try { await body?.cancel?.(); } catch { /* Locked or closed body. */ } }
    async function readHtml(response, signal) {
        const length = response.headers.get('content-length');
        if (length !== null && (!/^(?:0|[1-9]\d*)$/.test(length) || !Number.isSafeInteger(Number(length)) || Number(length) > MAXIMUM_BYTES)) {
            await cancelBody(response.body); throw failure('RANKING_RESPONSE_TOO_LARGE');
        }
        if (!response.body?.getReader || typeof TextDecoder !== 'function') throw failure('RANKING_INVALID_RESPONSE');
        const reader = response.body.getReader();
        const decoder = new TextDecoder('utf-8');
        let html = '', bytes = 0;
        const abort = () => { void reader.cancel(signal.reason).catch(() => {}); };
        signal.addEventListener('abort', abort, { once: true });
        try {
            while (true) {
                if (signal.aborted) throw signal.reason;
                const chunk = await reader.read();
                if (signal.aborted) throw signal.reason;
                if (chunk.done) break;
                if (!ArrayBuffer.isView(chunk.value)) throw failure('RANKING_INVALID_RESPONSE');
                bytes += chunk.value.byteLength;
                if (bytes > MAXIMUM_BYTES) throw failure('RANKING_RESPONSE_TOO_LARGE');
                html += decoder.decode(chunk.value, { stream: true });
            }
            html += decoder.decode();
            if (!bytes || html.length > MAXIMUM_BYTES) throw failure('RANKING_INVALID_RESPONSE');
            return html;
        } catch (error) { try { await reader.cancel(error); } catch { /* Already cancelled. */ } throw error; }
        finally { signal.removeEventListener('abort', abort); try { reader.releaseLock(); } catch { /* Already released. */ } }
    }
    function parse(html, source) {
        const template = document.createElement('template');
        if (typeof globalThis.Sanitizer !== 'function' || typeof template.setHTML !== 'function') throw failure('RANKING_SANITIZER_UNAVAILABLE');
        if (!sanitizer) sanitizer = new globalThis.Sanitizer({
            // Canonical links remain inside the detached template only. No fetched
            // nodes are ever inserted into a live document or passed to DOMParser.
            removeElements: ['applet', 'audio', 'base', 'embed', 'frame', 'frameset', 'iframe', 'img', 'meta', 'noscript', 'object', 'picture', 'portal', 'script', 'source', 'style', 'track', 'video', 'svg', 'math'],
            removeAttributes: ['background', 'data', 'imagesizes', 'imagesrcset', 'manifest', 'ping', 'poster', 'src', 'srcset', 'style'], comments: false,
        });
        template.setHTML(html, { sanitizer });
        return snapshots.parseSnapshot(template.content, { date: source.date, sourceUrl: source.href, fetchedAt: Date.now() });
    }
    function handleMessage(message, sender) {
        if (!['hltv-sp:fetch-ranking-snapshot', 'hltv-sp:cancel-ranking-snapshot'].includes(message?.type)) return undefined;
        if (!extensionSender(sender) || message.documentId !== ledger.documentId || !/^a\d{1,20}$/.test(message.attemptId || '')) return undefined;
        const binding = { documentId: ledger.documentId, requestId: message.requestId, attemptId: message.attemptId };
        const slot = ledger.slots.get(message.source?.date);
        if (message.type === 'hltv-sp:cancel-ranking-snapshot') {
            if (slot?.requestId === message.requestId && slot.attemptId === message.attemptId) slot.controller?.abort(failure('RANKING_CONTEXT_UNAVAILABLE'));
            return Promise.resolve({ ...binding, ok: true });
        }
        const unavailable = (code) => Promise.resolve({ ...binding, ok: false, attemptStarted: false, code });
        if (!slot || slot.requestId !== message.requestId || !slot.promise
            || slot.epoch !== owner?.epoch || JSON.stringify(slot.source) !== JSON.stringify(message.source)
            || !active(owner, slot.source) || !Number.isSafeInteger(message.deadline) || message.deadline <= Date.now()
            || message.deadline > Math.min(slot.source.timestamp, Date.now() + 12000)) return unavailable('RANKING_CONTEXT_UNAVAILABLE');
        if (slot.attempted) return unavailable(slot.error || 'RANKING_ALREADY_ATTEMPTED');
        if (ledger.attemptsStarted >= MAXIMUM_WEEKS) return unavailable('RANKING_BUDGET_EXHAUSTED');
        const currentOwner = owner;
        const controller = new AbortController(); slot.controller = controller; slot.attemptId = message.attemptId;
        const timer = globalThis.setTimeout(() => controller.abort(failure('RANKING_TIMEOUT')), Math.max(0, message.deadline - Date.now()));
        const aborted = new Promise((resolve, reject) => controller.signal.addEventListener('abort', () => reject(controller.signal.reason), { once: true }));
        const operation = (async () => {
            // This ledger belongs to the document, independent of prediction-source
            // attempts and of background restarts. Debit immediately before fetch.
            slot.attempted = true; ledger.attemptsStarted += 1;
            let response;
            try { response = await globalThis.fetch(slot.source.href, { method: 'GET', credentials: 'include', headers: { Accept: 'text/html' }, cache: 'no-store', redirect: 'error', signal: controller.signal }); }
            catch { throw controller.signal.aborted ? controller.signal.reason : failure('RANKING_NETWORK'); }
            if (controller.signal.aborted) { await cancelBody(response.body); throw controller.signal.reason; }
            if (!response.ok || response.redirected || response.url !== slot.source.href) {
                await cancelBody(response.body); throw failure(!response.ok ? `RANKING_HTTP_${response.status}` : 'RANKING_INVALID_RESPONSE');
            }
            const mime = String(response.headers.get('content-type') || '').split(';', 1)[0].trim().toLowerCase();
            if (mime && !['text/html', 'application/xhtml+xml'].includes(mime)) { await cancelBody(response.body); throw failure('RANKING_INVALID_RESPONSE'); }
            const html = await readHtml(response, controller.signal);
            if (!active(currentOwner, slot.source) || controller.signal.aborted || Date.now() >= message.deadline) throw failure('RANKING_CONTEXT_UNAVAILABLE');
            let snapshot;
            try { snapshot = parse(html, slot.source); } catch (error) { throw failure(error.code || 'RANKING_INVALID_SNAPSHOT'); }
            if (!active(currentOwner, slot.source)) throw failure('RANKING_CONTEXT_UNAVAILABLE');
            return { ...binding, ok: true, attemptStarted: true, snapshot };
        })();
        return Promise.race([operation, aborted]).catch((error) => ({ ...binding, ok: false, attemptStarted: true, code: error.code || 'RANKING_INVALID_RESPONSE' }))
            .finally(() => { globalThis.clearTimeout(timer); if (slot.attemptId === message.attemptId) slot.controller = null; });
    }
    function release(slot) {
        try { void browser.runtime.sendMessage({ type: 'hltv-sp:release-ranking-snapshot', documentId: ledger.documentId, requestId: slot.requestId, source: slot.source }).catch(() => {}); } catch { /* Context gone. */ }
    }
    function pause(currentOwner) {
        currentOwner.paused = true; currentOwner.epoch += 1;
        if (owner !== currentOwner) return;
        for (const slot of ledger.slots.values()) if (slot.promise) {
            release(slot); slot.controller?.abort(failure('RANKING_CONTEXT_UNAVAILABLE')); slot.reject?.(failure('RANKING_CONTEXT_UNAVAILABLE'));
        }
    }
    function loadDate(date, currentOwner) {
        let slot = ledger.slots.get(date);
        if (slot?.result) return Promise.resolve(slot.result);
        if (slot?.promise) return slot.promise;
        if (!slot && ledger.slots.size >= MAXIMUM_WEEKS) return Promise.reject(failure('RANKING_INVALID_REQUEST'));
        if (!slot) { slot = { source: { ...ledger.identity, date, href: snapshots.sourceUrl(date) }, attempted: false, result: null, promise: null }; ledger.slots.set(date, slot); }
        slot.requestId = `r${++ledger.sequence}`; slot.epoch = currentOwner.epoch;
        const epoch = currentOwner.epoch, requestId = slot.requestId;
        let timer;
        const cancelled = new Promise((resolve, reject) => { slot.reject = reject; });
        const operation = Promise.resolve().then(() => {
            if (!active(currentOwner, slot.source) || currentOwner.epoch !== epoch) throw failure('RANKING_CONTEXT_UNAVAILABLE');
            return browser.runtime.sendMessage({ type: 'hltv-sp:get-ranking-snapshot', documentId: ledger.documentId, requestId, source: slot.source });
        }).then((response) => {
            if (!active(currentOwner, slot.source) || currentOwner.epoch !== epoch) throw failure('RANKING_CONTEXT_UNAVAILABLE');
            if (!response?.ok) throw failure(response?.code || 'RANKING_INVALID_RESPONSE');
            if (!snapshots.validateSnapshot(response.snapshot) || response.snapshot.date !== date
                || response.snapshot.fetchedAt >= slot.source.timestamp || response.snapshot.fetchedAt > Date.now() + 60000) throw failure('RANKING_INVALID_RESPONSE');
            slot.result = { snapshot: response.snapshot, storageError: response.storageError, fromCache: response.fromCache === true };
            return slot.result;
        });
        timer = globalThis.setTimeout(() => { release(slot); slot.controller?.abort(failure('RANKING_TIMEOUT')); slot.reject?.(failure('RANKING_TIMEOUT')); }, Math.max(0, Math.min(14000, slot.source.timestamp - Date.now())));
        slot.promise = Promise.race([operation, cancelled]).catch((error) => { slot.error = error.code || 'RANKING_INVALID_RESPONSE'; throw error; })
            .finally(() => { globalThis.clearTimeout(timer); if (slot.requestId === requestId) { slot.promise = null; slot.reject = null; } });
        return slot.promise;
    }
    function calendarDay(value) {
        if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) throw failure('RANKING_INVALID_REQUEST');
        const timestamp = Date.parse(`${value}T00:00:00.000Z`);
        if (!Number.isFinite(timestamp) || new Date(timestamp).toISOString().slice(0, 10) !== value) throw failure('RANKING_INVALID_REQUEST');
        return timestamp;
    }
    function planDates({ currentDate, historicalDates = [] }) {
        const currentDay = calendarDay(currentDate);
        const observation = calendarDay(observationDay);
        const latestDay = calendarDay(new Date(Math.min(Date.now(), ledger.identity?.timestamp || Infinity)).toISOString().slice(0, 10));
        if (!Array.isArray(historicalDates) || currentDay > latestDay || currentDay < observation - 90 * DAY_MS) throw failure('RANKING_INVALID_REQUEST');
        const currentWeek = snapshots.weekBefore(currentDate);
        snapshots.sourceUrl(currentWeek);
        const earliestDay = observation - 90 * DAY_MS;
        const weeks = historicalDates.filter((date) => {
            const day = calendarDay(date);
            return day >= earliestDay && day <= currentDay;
        }).map((date) => snapshots.weekBefore(date)).filter((date) => date < currentWeek).sort().reverse();
        return [...new Set([currentWeek, ...weeks])];
    }
    function create({ getIdentity, onProgress = () => {} }) {
        if (typeof getIdentity !== 'function') throw new TypeError('Ranking identity reader is required.');
        if (!listenerInstalled && typeof browser?.runtime?.onMessage?.addListener === 'function') {
            browser.runtime.onMessage.addListener(handleMessage);
            listenerInstalled = true;
        }
        if (owner && !owner.destroyed) pause(owner);
        const currentOwner = { getIdentity, onProgress, epoch: 0, paused: false, destroyed: false, queue: Promise.resolve() }; owner = currentOwner;
        const snapshot = () => ({ documentId: ledger.documentId, used: ledger.attemptsStarted, remaining: MAXIMUM_WEEKS - ledger.attemptsStarted });
        async function load({ currentDate, historicalDates = [] }) {
            const result = { snapshots: [], missingWeeks: [], attemptsStarted: ledger.attemptsStarted, errors: [] };
            if (!snapshots) return result;
            if (!ledger.identity) ledger.identity = identityValue(getIdentity());
            let dates;
            try {
                dates = planDates({ currentDate, historicalDates });
            } catch { result.errors.push({ code: 'RANKING_INVALID_REQUEST' }); return result; }
            if (!active(currentOwner)) { result.missingWeeks = dates; result.errors.push({ code: 'RANKING_CONTEXT_UNAVAILABLE' }); return result; }
            const epoch = currentOwner.epoch;
            const found = new Map();
            const notify = () => {
                result.snapshots = dates.filter((date) => found.has(date)).map((date) => found.get(date));
                result.missingWeeks = dates.filter((date) => !found.has(date)); result.attemptsStarted = ledger.attemptsStarted;
                try { onProgress({ ...result, snapshots: [...result.snapshots], missingWeeks: [...result.missingWeeks], errors: [...result.errors] }); } catch { /* Optional UI callback. */ }
            };
            currentOwner.report = { dates, result, found, notify };
            for (const date of dates) {
                if (!active(currentOwner) || currentOwner.epoch !== epoch) break;
                try {
                    const entry = await loadDate(date, currentOwner);
                    if (!active(currentOwner) || currentOwner.epoch !== epoch) break;
                    found.set(date, entry.snapshot); if (entry.storageError) result.storageError = entry.storageError;
                } catch (error) { result.errors.push({ date, code: error.code || 'RANKING_INVALID_RESPONSE' }); }
                notify();
            }
            notify();
            return result;
        }
        return Object.freeze({
            load(options) { const task = currentOwner.queue.then(() => load(options)); currentOwner.queue = task.catch(() => {}); return task; },
            snapshot,
            suspend() { pause(currentOwner); }, cancel() { pause(currentOwner); },
            resume() { if (owner === currentOwner && !currentOwner.destroyed) currentOwner.paused = false; },
            destroy() { pause(currentOwner); currentOwner.destroyed = true; },
        });
    }
    browser.storage?.onChanged?.addListener((changes, area) => {
        if (area !== 'local') return;
        if (changes.extensionDisabled?.newValue === true && owner) { pause(owner); return; }
        if (!active(owner) || !owner.report) return;
        const report = owner.report;
        let changed = false;
        for (const date of report.dates) {
            const entry = changes[`hltvRankingSnapshot:v1:${date}`];
            if (!entry) continue;
            const slot = ledger.slots.get(date);
            if (!slot) continue;
            if (!entry.newValue) { slot.result = null; report.found.delete(date); changed = true; continue; }
            const value = entry.newValue;
            if (!snapshots.validateSnapshot(value) || value.date !== date
                || value.fetchedAt >= ledger.identity.timestamp || value.fetchedAt > Date.now() + 60000) continue;
            slot.result = { snapshot: value, fromCache: true };
            report.found.set(date, value);
            report.result.errors = report.result.errors.filter((error) => error.date !== date);
            changed = true;
        }
        if (changed) report.notify();
    });
    Object.defineProperty(globalThis, 'HLTV_RANKING_TRANSPORT', { value: Object.freeze({ create, planDates }), configurable: true });
})();
