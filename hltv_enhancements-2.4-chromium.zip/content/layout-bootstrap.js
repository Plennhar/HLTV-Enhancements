// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Plennhar

(async () => {
    'use strict';

    if (globalThis.HLTV_EXTENSION_GATE
        && !await globalThis.HLTV_EXTENSION_GATE.ready) return;

    const STYLE_ID = 'hltv-sp-layout-bootstrap-style';
    const LAYOUT_WIDTH_PRESETS = Object.freeze({
        default: Object.freeze({ contentExtraPx: 0, sidebarExtraPx: 0 }),
        wide: Object.freeze({ contentExtraPx: 120, sidebarExtraPx: 80 }),
        extra: Object.freeze({ contentExtraPx: 240, sidebarExtraPx: 140 }),
    });
    const DEFAULT_LAYOUT_WIDTH_PRESET = 'extra';
    const DEFAULT_LARGE_SIDEBAR_TEXT = true;
    const state = {
        layoutWidthPreset: DEFAULT_LAYOUT_WIDTH_PRESET,
        largeSidebarText: DEFAULT_LARGE_SIDEBAR_TEXT,
        settingsReady: false,
        released: false,
        applyTimer: 0,
        retryTimer: 0,
        retryGeneration: 0,
        observer: null,
        resizeHandler: null,
        storageChangeApi: null,
        storageChangeHandler: null,
        styleElement: null,
    };

    function normaliseLayoutWidthPreset(value) {
        return Object.prototype.hasOwnProperty.call(LAYOUT_WIDTH_PRESETS, value)
            ? value
            : DEFAULT_LAYOUT_WIDTH_PRESET;
    }

    function normaliseLargeSidebarText(value) {
        return typeof value === 'boolean' ? value : DEFAULT_LARGE_SIDEBAR_TEXT;
    }

    function installStyle() {
        if (state.released) return;
        if (document.getElementById(STYLE_ID)) return;
        const style = document.createElement('style');
        style.id = STYLE_ID;
        style.textContent = `
            @media (min-width: 975px) {
                body.hltv-sp-expanded-layout .bgPadding {
                    max-width: var(--hltv-sp-layout-background-width) !important;
                    width: var(--hltv-sp-layout-background-width) !important;
                }

                body.hltv-sp-expanded-layout .bgPadding > .widthControl {
                    max-width: var(--hltv-sp-layout-shell-width) !important;
                    width: var(--hltv-sp-layout-shell-width) !important;
                }

                body.hltv-sp-expanded-layout.cols1111 .bgPadding > .widthControl > .colCon,
                body.hltv-sp-expanded-layout.colsCustom1111 .bgPadding > .widthControl > .colCon {
                    grid-template-columns: 160px minmax(0, 1fr) 145px var(--hltv-sp-layout-sidebar-width) !important;
                }

                body.hltv-sp-expanded-layout.cols1101 .bgPadding > .widthControl > .colCon,
                body.hltv-sp-expanded-layout.colsCustom1101 .bgPadding > .widthControl > .colCon {
                    grid-template-columns: 160px minmax(0, 1fr) var(--hltv-sp-layout-sidebar-width) !important;
                }

                body.hltv-sp-expanded-layout.cols0101 .bgPadding > .widthControl > .colCon,
                body.hltv-sp-expanded-layout.colsCustom0101 .bgPadding > .widthControl > .colCon {
                    grid-template-columns: minmax(0, 1fr) var(--hltv-sp-layout-sidebar-width) !important;
                }
            }

            body.hltv-sp-large-sidebar-text .hltv-sp-sidebar-list > a.activity {
                min-height: 22px;
            }

            body.hltv-sp-large-sidebar-text .hltv-sp-sidebar-list > a.activity > .topic {
                font-size: 12px !important;
                line-height: 1.35 !important;
            }
        `;
        (document.head || document.documentElement)?.appendChild(style);
        state.styleElement = style;
    }

    function clearLayoutWidthOverrides() {
        if (!document.body) return;
        document.body.classList.remove('hltv-sp-expanded-layout');
        document.body.style.removeProperty('--hltv-sp-layout-background-width');
        document.body.style.removeProperty('--hltv-sp-layout-shell-width');
        document.body.style.removeProperty('--hltv-sp-layout-sidebar-width');
    }

    function captureLayoutWidthOverrides() {
        if (!document.body) return null;
        return {
            expanded: document.body.classList.contains('hltv-sp-expanded-layout'),
            backgroundWidth: document.body.style.getPropertyValue(
                '--hltv-sp-layout-background-width',
            ),
            shellWidth: document.body.style.getPropertyValue(
                '--hltv-sp-layout-shell-width',
            ),
            sidebarWidth: document.body.style.getPropertyValue(
                '--hltv-sp-layout-sidebar-width',
            ),
        };
    }

    function restoreLayoutWidthOverrides(snapshot) {
        if (!document.body || !snapshot) return;
        clearLayoutWidthOverrides();
        if (snapshot.backgroundWidth) {
            document.body.style.setProperty(
                '--hltv-sp-layout-background-width',
                snapshot.backgroundWidth,
            );
        }
        if (snapshot.shellWidth) {
            document.body.style.setProperty(
                '--hltv-sp-layout-shell-width',
                snapshot.shellWidth,
            );
        }
        if (snapshot.sidebarWidth) {
            document.body.style.setProperty(
                '--hltv-sp-layout-sidebar-width',
                snapshot.sidebarWidth,
            );
        }
        document.body.classList.toggle('hltv-sp-expanded-layout', snapshot.expanded);
    }

    function horizontalBoxExtras(element) {
        if (!(element instanceof Element)) return 0;
        const style = getComputedStyle(element);
        return [
            style.paddingLeft,
            style.paddingRight,
            style.borderLeftWidth,
            style.borderRightWidth,
        ].reduce((total, value) => total + (Number.parseFloat(value) || 0), 0);
    }

    function measuredElementWidth(element) {
        if (!(element instanceof Element)) return 0;
        const rectWidth = Number(element.getBoundingClientRect?.().width);
        if (Number.isFinite(rectWidth) && rectWidth > 0) return rectWidth;
        const computedWidth = Number.parseFloat(getComputedStyle(element).width);
        if (Number.isFinite(computedWidth) && computedWidth > 0) {
            return computedWidth + horizontalBoxExtras(element);
        }
        const offsetWidth = Number(element.offsetWidth);
        return Number.isFinite(offsetWidth) && offsetWidth > 0 ? offsetWidth : 0;
    }

    function getDesktopSidebarList() {
        return document.querySelector(
            '.bgPadding > .widthControl > .colCon > .right2Col .recent-activity .activitylist',
        );
    }

    function applyLayout(settleNoRoom = false) {
        if (state.released || !state.settingsReady || !document.body) return false;
        document.body.classList.toggle(
            'hltv-sp-large-sidebar-text',
            state.largeSidebarText,
        );

        const list = getDesktopSidebarList();
        list?.classList.add('hltv-sp-sidebar-list');
        const preset = LAYOUT_WIDTH_PRESETS[state.layoutWidthPreset];
        if (!preset) return false;
        if (!preset.contentExtraPx && !preset.sidebarExtraPx) {
            clearLayoutWidthOverrides();
            return Boolean(list);
        }
        if (!list) return false;

        const sidebarColumn = list.closest('.right2Col');
        const columns = sidebarColumn?.parentElement;
        const shell = columns?.closest('.widthControl');
        const background = shell?.parentElement;
        const viewportWidth = Math.max(
            Number(document.documentElement?.clientWidth) || 0,
            Number(window.innerWidth) || 0,
        );
        if (!sidebarColumn
            || !columns?.matches('.colCon')
            || !background?.classList.contains('bgPadding')) return false;
        if (viewportWidth <= 0) return false;
        if (viewportWidth < 975) {
            clearLayoutWidthOverrides();
            return true;
        }
        if (getComputedStyle(sidebarColumn).display === 'none') return false;

        const previousOverrides = captureLayoutWidthOverrides();
        clearLayoutWidthOverrides();
        const baseBackgroundWidth = measuredElementWidth(background);
        const baseShellWidth = measuredElementWidth(shell);
        const baseSidebarWidth = measuredElementWidth(sidebarColumn);
        if (!baseBackgroundWidth || !baseShellWidth || !baseSidebarWidth) {
            restoreLayoutWidthOverrides(previousOverrides);
            return false;
        }

        const requestedContentExtra = preset.contentExtraPx;
        const requestedSidebarExtra = preset.sidebarExtraPx;
        const requestedTotal = requestedContentExtra + requestedSidebarExtra;
        const availableExtra = Math.max(0, viewportWidth - 32 - baseBackgroundWidth);
        const scale = requestedTotal ? Math.min(1, availableExtra / requestedTotal) : 0;
        const contentExtra = Math.round(requestedContentExtra * scale);
        const sidebarExtra = Math.round(requestedSidebarExtra * scale);
        const appliedTotal = contentExtra + sidebarExtra;
        const backgroundExtras = horizontalBoxExtras(background);
        const shellExtras = horizontalBoxExtras(shell);
        if (appliedTotal < 40) {
            if (settleNoRoom) return true;
            restoreLayoutWidthOverrides(previousOverrides);
            return false;
        }

        document.body.style.setProperty(
            '--hltv-sp-layout-background-width',
            `${Math.round(baseBackgroundWidth - backgroundExtras + appliedTotal)}px`,
        );
        document.body.style.setProperty(
            '--hltv-sp-layout-shell-width',
            `${Math.round(baseShellWidth - shellExtras + appliedTotal)}px`,
        );
        document.body.style.setProperty(
            '--hltv-sp-layout-sidebar-width',
            `${Math.round(baseSidebarWidth + sidebarExtra)}px`,
        );
        document.body.classList.add('hltv-sp-expanded-layout');
        return true;
    }

    function scheduleApply(delayMs = 0) {
        if (state.released) return;
        globalThis.clearTimeout(state.applyTimer);
        state.applyTimer = globalThis.setTimeout(() => {
            state.applyTimer = 0;
            if (state.released) return;
            if (applyLayout()) {
                settleDomDiscovery();
            }
        }, delayMs);
    }

    function settleDomDiscovery() {
        state.retryGeneration += 1;
        globalThis.clearTimeout(state.applyTimer);
        globalThis.clearTimeout(state.retryTimer);
        state.applyTimer = 0;
        state.retryTimer = 0;
        state.observer?.disconnect();
        state.observer = null;
    }

    function scheduleStartupRetries() {
        if (state.released) return;
        globalThis.clearTimeout(state.applyTimer);
        state.applyTimer = 0;
        globalThis.clearTimeout(state.retryTimer);
        const generation = ++state.retryGeneration;
        const retryDelays = [0, 100, 400, 1200, 2500];
        let retryIndex = 0;
        const retry = () => {
            if (state.released || generation !== state.retryGeneration) return;
            state.retryTimer = 0;
            const settleNoRoom = retryIndex >= retryDelays.length;
            if (applyLayout(settleNoRoom)) {
                settleDomDiscovery();
                return;
            }
            if (settleNoRoom) {
                settleDomDiscovery();
                return;
            }
            state.retryTimer = globalThis.setTimeout(
                retry,
                retryDelays[retryIndex],
            );
            retryIndex += 1;
        };
        retry();
    }

    function installDomObserver() {
        if (state.released || state.observer || !document.documentElement) return;
        state.observer = new MutationObserver(() => {
            if (state.released) return;
            scheduleApply(0);
        });
        state.observer.observe(document.documentElement, {
            childList: true,
            subtree: true,
        });
    }

    function applyStoredValues(stored) {
        if (state.released) return;
        state.layoutWidthPreset = normaliseLayoutWidthPreset(
            stored?.layoutWidthPreset,
        );
        state.largeSidebarText = normaliseLargeSidebarText(
            stored?.largeSidebarText,
        );
        state.settingsReady = true;
        installDomObserver();
        scheduleStartupRetries();
    }

    function installStorageListener(storageApi) {
        if (state.released
            || state.storageChangeHandler
            || typeof storageApi?.onChanged?.addListener !== 'function') return;
        const onChanged = (changes, areaName) => {
            if (state.released
                || areaName !== 'local'
                || !changes
                || typeof changes !== 'object') return;
            let changed = false;
            if (Object.prototype.hasOwnProperty.call(changes, 'layoutWidthPreset')) {
                state.layoutWidthPreset = normaliseLayoutWidthPreset(
                    changes.layoutWidthPreset?.newValue,
                );
                changed = true;
            }
            if (Object.prototype.hasOwnProperty.call(changes, 'largeSidebarText')) {
                state.largeSidebarText = normaliseLargeSidebarText(
                    changes.largeSidebarText?.newValue,
                );
                changed = true;
            }
            if (changed) {
                state.settingsReady = true;
                installDomObserver();
                scheduleStartupRetries();
            }
        };
        try {
            storageApi.onChanged.addListener(onChanged);
            state.storageChangeApi = storageApi.onChanged;
            state.storageChangeHandler = onChanged;
        } catch {
            // Storage changes are an optional enhancement to this early hint.
        }
    }

    function release() {
        if (state.released) return false;
        state.released = true;
        state.retryGeneration += 1;
        globalThis.clearTimeout(state.applyTimer);
        globalThis.clearTimeout(state.retryTimer);
        state.applyTimer = 0;
        state.retryTimer = 0;
        state.observer?.disconnect();
        state.observer = null;
        if (state.resizeHandler) {
            window.removeEventListener('resize', state.resizeHandler);
            state.resizeHandler = null;
        }
        if (state.storageChangeApi
            && state.storageChangeHandler
            && typeof state.storageChangeApi.removeListener === 'function') {
            try {
                state.storageChangeApi.removeListener(state.storageChangeHandler);
            } catch {
                // Cleanup is best-effort; release still disables every callback.
            }
        }
        state.storageChangeApi = null;
        state.storageChangeHandler = null;
        state.styleElement?.remove();
        state.styleElement = null;
        return true;
    }

    const handoffApi = Object.freeze({ release });
    Object.defineProperty(globalThis, 'HLTV_SP_LAYOUT_BOOTSTRAP', {
        value: handoffApi,
        configurable: false,
        enumerable: false,
        writable: false,
    });

    try {
        installStyle();
        applyLayout();
        state.resizeHandler = () => scheduleApply(80);
        window.addEventListener('resize', state.resizeHandler, { passive: true });

        const storageApi = globalThis.browser?.storage;
        installStorageListener(storageApi);
        if (typeof storageApi?.local?.get === 'function') {
            try {
                Promise.resolve(storageApi.local.get([
                    'layoutWidthPreset',
                    'largeSidebarText',
                ]))
                    .then((stored) => applyStoredValues(stored))
                    .catch(() => applyStoredValues(null));
            } catch {
                applyStoredValues(null);
            }
        } else {
            applyStoredValues(null);
        }
    } catch {
        // A failed early hint must not block the page or the full content script.
    }
})();
