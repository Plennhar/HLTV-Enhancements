// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Plennhar

(async () => {
    'use strict';

    if (globalThis.HLTV_EXTENSION_GATE
        && !await globalThis.HLTV_EXTENSION_GATE.ready) return;

    const runtime = globalThis.browser?.runtime;
    if (typeof runtime?.sendMessage !== 'function') return;
    const privateUi = globalThis.HLTV_SP_PRIVATE_UI;
    const sendRuntimeMessage = runtime.sendMessage.bind(runtime);
    const screenshotDataUrls = new Map();
    const SCREENSHOT_STYLE_ID = 'hltv-sp-private-screenshot-styles';
    const MAX_DISCOVERY_ATTEMPTS = 8;
    const DISCOVERY_RETRY_MS = 40;
    let discoveryGeneration = 0;
    let discoveryTimer = 0;
    const SCREENSHOT_STYLES = `
        .hltv-sp-setting-screenshots {
            display: grid;
            gap: 8px;
            margin-top: 8px;
        }
        .hltv-sp-setting-screenshot-link {
            background: #1b1f23;
            border: 1px solid #435467;
            border-radius: 2px;
            box-sizing: border-box;
            display: block;
            max-width: 100%;
            overflow: hidden;
            padding: 3px;
        }
        .hltv-sp-setting-screenshot-link:hover,
        .hltv-sp-setting-screenshot-link:focus-visible {
            border-color: #87a3bf;
            outline: none;
        }
        .hltv-sp-setting-screenshot {
            display: block;
            height: auto;
            max-height: 360px;
            max-width: 100%;
            object-fit: contain;
            width: auto;
        }
        .hltv-sp-setting-screenshot-status {
            color: #929a9e;
            font-size: 10px;
        }
        @media (max-width: 700px) {
            .hltv-sp-setting-screenshot {
                max-height: 260px;
            }
        }
    `;

    const SCREENSHOTS = Object.freeze({
        'hltv-sp-green-upvotes-help': [
            {
                file: 'change-upvoted-comments-to-green.png',
                alt: 'An active HLTV upvote button displayed in green.',
                width: 223,
                height: 94,
            },
        ],
        'hltv-sp-thread-previews-help': [
            {
                file: 'thread-preview.png',
                alt: 'A thread preview opened from a recent-activity title.',
                width: 500,
                height: 724,
            },
        ],
        'hltv-sp-read-status-help': [
            {
                file: 'thread-read-status.png',
                alt: 'Recent-activity rows with read and unread indicators.',
                width: 268,
                height: 410,
            },
        ],
        'hltv-sp-relative-ages-help': [
            {
                file: 'show_relative_post_ages_in_threads_and_previews.png',
                alt: 'A compact relative age displayed beside a forum post timestamp.',
                width: 144,
                height: 39,
            },
        ],
        'hltv-sp-move-post-new-topic-help': [
            {
                file: 'move_post_new_topic_to_the_top_of_the_sidebar.png',
                alt: 'The Post new topic control above the recent-activity sidebar rows.',
                width: 327,
                height: 876,
            },
        ],
        'hltv-sp-extended-match-filter-help': [
            {
                file: 'add_more_teams_to_the_match_filter.png',
                alt: 'An expanded HLTV match filter containing more than five selected teams.',
                width: 362,
                height: 614,
            },
        ],
        'hltv-sp-reply-composer-after-op-help': [
            {
                file: 'reply-composer-below-original-post.png',
                alt: 'The reply composer placed directly below the original post.',
                width: 895,
                height: 412,
            },
        ],
        'hltv-sp-local-user-scores-help': [
            {
                file: 'local-user-reaction-counter.png',
                alt: 'A local reaction counter displayed beside an HLTV username.',
                width: 167,
                height: 29,
            },
        ],
        'hltv-sp-local-downvotes-help': [
            {
                file: 'local-downvote-button.png',
                alt: 'A local minus button displayed beside the HLTV upvote button.',
                width: 223,
                height: 94,
            },
        ],
        'hltv-sp-user-tags-help': [
            {
                file: 'enable_local_user_tags.png',
                alt: 'A private local tag displayed after an HLTV username.',
                width: 887,
                height: 94,
            },
        ],
        'hltv-sp-username-blocking-help': [
            {
                file: 'enable_right-lcikc_username_actions.png',
                alt: 'A right-click username menu with profile and block actions.',
                width: 324,
                height: 132,
            },
        ],
        'hltv-sp-sticky-match-header-help': [
            {
                file: 'show_a_sticky_match_header_while_scrolling.png',
                alt: 'A compact live match header remaining visible while the match page is scrolled.',
                width: 986,
                height: 678,
            },
        ],
        'hltv-sp-match-player-form-overlays-help': [
            {
                file: 'show_recent-form_statistics_on_match_lineups.png',
                alt: 'Recent Rating and KPR statistics overlaid on match-lineup player cards.',
                width: 889,
                height: 237,
            },
        ],
        'hltv-sp-match-prediction-help': [
            {
                file: 'show_match_result_predictions.png',
                alt: 'A match prediction showing the predicted winner, win probability, and likely score.',
                width: 917,
                height: 450,
            },
        ],
        'hltv-sp-full-map-names-help': [
            {
                file: 'show_full_map_names_on_player_match_history_pages.png',
                alt: 'Full map names displayed in a player match-history table.',
                width: 65,
                height: 649,
            },
        ],
        'hltv-sp-stats-column-chooser-help': [
            {
                file: 'win-adjusted-ratings.png',
                alt: 'A player statistics table with the win-adjusted rating column.',
                width: 652,
                height: 567,
            },
            {
                file: 'kpr-ranking-table.png',
                alt: 'Estimated KPR ranges in a player ranking table.',
                width: 652,
                height: 626,
            },
            {
                file: 'kpr-match-history.png',
                alt: 'Actual KPR values in a player match-history table.',
                width: 835,
                height: 673,
            },
            {
                file: 'enable_stats-table_column_controls.png',
                alt: 'The stats-table Columns menu beside a configurable player match-history table.',
                width: 884,
                height: 495,
            },
        ],
        'hltv-sp-stats-multi-sort-help': [
            {
                file: 'enable_multi-column_sorting.png',
                alt: 'A player match-history table sorted by multiple numbered columns.',
                width: 896,
                height: 438,
            },
        ],
        'hltv-sp-player-match-sparklines-help': [
            {
                file: 'show_selectable_player_match-history_trends.png',
                alt: 'A selectable Rating trend chart above a player match-history table.',
                width: 891,
                height: 256,
            },
        ],
        'hltv-sp-stats-table-period-comparison-help': [
            {
                file: 'compare_stats-table_data_with_another_date_period.png',
                alt: 'A stats ranking table with baseline date controls and a rating-delta column.',
                width: 883,
                height: 813,
            },
        ],
        'hltv-sp-team-performance-difference-help': [
            {
                file: 'show_team_overperformance_score.png',
                alt: 'A team FTU table with a sortable Overperformance Score column.',
                width: 887,
                height: 706,
            },
        ],
        'hltv-sp-player-map-matrix-help': [
            {
                file: 'add_a_map-by-stat_matrix_to_player_pages.png',
                alt: 'A player Map matrix tab with map-by-stat performance values.',
                width: 890,
                height: 752,
            },
        ],
        'hltv-sp-player-comparison-enhancements-help': [
            {
                file: 'enhance_player_comparison_pages.png',
                alt: 'A player comparison page with configurable match-history trend lines.',
                width: 888,
                height: 411,
            },
            {
                file: 'bug_comparison_page_graph_color.png',
                alt: 'A two-player Rating history graph with a distinct color for each player.',
                width: 888,
                height: 411,
            },
        ],
        'hltv-sp-player-consistency-score-help': [
            {
                file: 'show_a_player_consistency_score.png',
                alt: 'A player consistency score and its explanatory hover popup.',
                width: 249,
                height: 366,
            },
        ],
        'hltv-sp-player-page-period-comparison-help': [
            {
                file: 'compare_player-page_statistics_with_another_date_period.png',
                alt: 'A player statistics page with baseline date comparison controls and deltas.',
                width: 897,
                height: 452,
            },
        ],
    });

    function createScreenshot(item, dataUrl) {
        const link = document.createElement('a');
        link.className = 'hltv-sp-setting-screenshot-link';
        link.href = dataUrl;
        link.target = '_blank';
        link.rel = 'noopener noreferrer';
        link.title = 'Open full-size screenshot in a new tab';
        link.addEventListener('click', (event) => event.stopPropagation());

        const image = document.createElement('img');
        image.className = 'hltv-sp-setting-screenshot';
        image.src = dataUrl;
        image.alt = item.alt;
        image.width = item.width;
        image.height = item.height;
        image.loading = 'lazy';
        image.decoding = 'async';
        link.appendChild(image);
        return link;
    }

    function loadScreenshotDataUrl(item) {
        const path = `assets/screenshots/${item.file}`;
        if (screenshotDataUrls.has(path)) return screenshotDataUrls.get(path);
        const pending = (async () => {
            const response = await sendRuntimeMessage({
                type: 'hltv-sp:get-screenshot',
                file: item.file,
            });
            const dataUrl = typeof response?.dataUrl === 'string' ? response.dataUrl : '';
            if (!response?.ok
                || !/^data:image\/png;base64,[A-Za-z0-9+/]+={0,2}$/.test(dataUrl)
                || dataUrl.length > (3 * 1024 * 1024)) {
                throw new Error('Screenshot loader returned invalid data.');
            }
            return dataUrl;
        })();
        screenshotDataUrls.set(path, pending);
        pending.catch(() => screenshotDataUrls.delete(path));
        return pending;
    }

    async function populateScreenshotGallery(gallery, screenshots) {
        if (gallery.dataset.hltvSpLoaded === 'true'
            || gallery.dataset.hltvSpLoading === 'true') return;
        gallery.dataset.hltvSpLoading = 'true';
        const loading = document.createElement('span');
        loading.className = 'hltv-sp-setting-screenshot-status';
        loading.textContent = 'Loading screenshot\u2026';
        gallery.replaceChildren(loading);
        try {
            const items = await Promise.all(screenshots.map(async (item) => ({
                item,
                dataUrl: await loadScreenshotDataUrl(item),
            })));
            gallery.replaceChildren(...items.map(({ item, dataUrl }) => (
                createScreenshot(item, dataUrl)
            )));
            gallery.dataset.hltvSpLoaded = 'true';
        } catch {
            loading.textContent = 'Screenshot could not be loaded.';
            gallery.replaceChildren(loading);
        } finally {
            delete gallery.dataset.hltvSpLoading;
        }
    }

    function findPrivateSettingsRoot() {
        if (typeof privateUi?.getRoot !== 'function') return null;
        const hosts = document.querySelectorAll('.hltv-sp-settings-host');
        for (let index = hosts.length - 1; index >= 0; index -= 1) {
            const host = hosts[index];
            const root = privateUi.getRoot(host);
            if (root) return root;
        }
        return null;
    }

    function ensurePrivateScreenshotStyles(help) {
        const root = help?.getRootNode?.();
        if (!(root instanceof ShadowRoot) || root.querySelector(`#${SCREENSHOT_STYLE_ID}`)) return;
        const style = document.createElement('style');
        style.id = SCREENSHOT_STYLE_ID;
        style.textContent = SCREENSHOT_STYLES;
        root.appendChild(style);
    }

    function decorateSettingsScreenshots(root) {
        if (!(root instanceof ShadowRoot)) return Object.keys(SCREENSHOTS).length;
        let remaining = 0;
        for (const [helpId, screenshots] of Object.entries(SCREENSHOTS)) {
            const help = root.querySelector(`#${helpId}`);
            if (!help) {
                remaining += 1;
                continue;
            }
            ensurePrivateScreenshotStyles(help);
            if (help.querySelector(':scope > .hltv-sp-setting-screenshots')) continue;

            const gallery = document.createElement('div');
            gallery.className = 'hltv-sp-setting-screenshots';
            gallery.setAttribute('aria-label', 'Setting screenshots');
            help.appendChild(gallery);
            const info = help.parentElement?.querySelector(
                `button.hltv-sp-setting-info[aria-controls="${helpId}"]`,
            );
            if (info) {
                info.addEventListener('click', () => {
                    queueMicrotask(() => {
                        if (info.getAttribute('aria-expanded') === 'true') {
                            populateScreenshotGallery(gallery, screenshots);
                        }
                    });
                });
                if (info.getAttribute('aria-expanded') === 'true') {
                    populateScreenshotGallery(gallery, screenshots);
                }
            }
        }
        return remaining;
    }

    function stopSettingsDiscovery() {
        discoveryGeneration += 1;
        if (discoveryTimer) globalThis.clearTimeout(discoveryTimer);
        discoveryTimer = 0;
    }

    function discoverSettingsScreenshots(generation, attempt = 0) {
        if (generation !== discoveryGeneration) return;
        const root = findPrivateSettingsRoot();
        const remaining = root
            ? decorateSettingsScreenshots(root)
            : Object.keys(SCREENSHOTS).length;
        if (remaining === 0 || attempt + 1 >= MAX_DISCOVERY_ATTEMPTS) {
            discoveryTimer = 0;
            return;
        }
        discoveryTimer = globalThis.setTimeout(() => {
            discoveryTimer = 0;
            discoverSettingsScreenshots(generation, attempt + 1);
        }, DISCOVERY_RETRY_MS);
    }

    function beginSettingsDiscovery() {
        stopSettingsDiscovery();
        const generation = discoveryGeneration;
        discoverSettingsScreenshots(generation);
    }

    function decorateAfterSettingsOpen(event) {
        const target = event.target instanceof Element ? event.target : null;
        if (!target?.closest('#hltv-sp-cog')) return;
        beginSettingsDiscovery();
    }

    document.addEventListener('click', decorateAfterSettingsOpen);
    globalThis.addEventListener('pagehide', () => {
        stopSettingsDiscovery();
        document.removeEventListener('click', decorateAfterSettingsOpen);
    }, { once: true });
})();
