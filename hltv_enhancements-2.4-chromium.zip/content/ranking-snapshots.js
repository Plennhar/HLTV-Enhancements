// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Plennhar

(() => {
    'use strict';
    if (globalThis.HLTV_RANKING_SNAPSHOTS) return;
    const MONTHS = ['january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'];
    const ORIGIN = 'https://www.hltv.org';
    const ID = /^[1-9]\d{0,19}$/;
    function dateValue(value) {
        if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new TypeError('Invalid ranking date.');
        const date = new Date(`${value}T00:00:00.000Z`);
        if (!Number.isFinite(date.getTime()) || date.toISOString().slice(0, 10) !== value) throw new TypeError('Invalid ranking date.');
        return date;
    }
    function weekBefore(value) {
        const date = typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value) ? dateValue(value) : new Date(value);
        if (!Number.isFinite(date.getTime())) throw new TypeError('Invalid ranking reference date.');
        date.setUTCHours(0, 0, 0, 0);
        date.setUTCDate(date.getUTCDate() - ((date.getUTCDay() + 6) % 7 || 7));
        return date.toISOString().slice(0, 10);
    }
    function sourceUrl(value) {
        const date = dateValue(value);
        if (date.getUTCDay() !== 1) throw new TypeError('Ranking date must be a Monday.');
        return `${ORIGIN}/ranking/teams/${date.getUTCFullYear()}/${MONTHS[date.getUTCMonth()]}/${date.getUTCDate()}`;
    }
    function name(value) { return typeof value === 'string' ? value.normalize('NFKC').replace(/\s+/g, ' ').trim() : ''; }
    // Synchronous SHA-256 keeps the shared parser deterministic in background and
    // content contexts, without depending on async WebCrypto availability.
    function sha256(value) {
        const bytes = [];
        for (const char of value) {
            const point = char.codePointAt(0);
            if (point < 128) bytes.push(point);
            else if (point < 2048) bytes.push(192 | point >> 6, 128 | point & 63);
            else if (point < 65536) bytes.push(224 | point >> 12, 128 | point >> 6 & 63, 128 | point & 63);
            else bytes.push(240 | point >> 18, 128 | point >> 12 & 63, 128 | point >> 6 & 63, 128 | point & 63);
        }
        const length = bytes.length * 8;
        bytes.push(128);
        while (bytes.length % 64 !== 56) bytes.push(0);
        for (let index = 7; index >= 0; index -= 1) bytes.push(Math.floor(length / 2 ** (index * 8)) & 255);
        const constants = [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
        const hash = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
        const rotate = (number, shift) => number >>> shift | number << (32 - shift);
        for (let offset = 0; offset < bytes.length; offset += 64) {
            const words = new Array(64);
            for (let index = 0; index < 16; index += 1) words[index] = (bytes[offset + index * 4] << 24 | bytes[offset + index * 4 + 1] << 16 | bytes[offset + index * 4 + 2] << 8 | bytes[offset + index * 4 + 3]) >>> 0;
            for (let index = 16; index < 64; index += 1) {
                const a = words[index - 15], b = words[index - 2];
                words[index] = (words[index - 16] + (rotate(a, 7) ^ rotate(a, 18) ^ a >>> 3) + words[index - 7] + (rotate(b, 17) ^ rotate(b, 19) ^ b >>> 10)) >>> 0;
            }
            let [a,b,c,d,e,f,g,h] = hash;
            for (let index = 0; index < 64; index += 1) {
                const first = (h + (rotate(e, 6) ^ rotate(e, 11) ^ rotate(e, 25)) + ((e & f) ^ (~e & g)) + constants[index] + words[index]) >>> 0;
                const second = ((rotate(a, 2) ^ rotate(a, 13) ^ rotate(a, 22)) + ((a & b) ^ (a & c) ^ (b & c))) >>> 0;
                h = g; g = f; f = e; e = (d + first) >>> 0; d = c; c = b; b = a; a = (first + second) >>> 0;
            }
            [a,b,c,d,e,f,g,h].forEach((item, index) => { hash[index] = (hash[index] + item) >>> 0; });
        }
        return hash.map((part) => part.toString(16).padStart(8, '0')).join('');
    }
    function checksum(snapshot) {
        return sha256(JSON.stringify([1, snapshot.date, snapshot.sourceUrl, Object.values(snapshot.teamsById)
            .sort((a, b) => a.rank - b.rank).map(({ id, name: teamName, rank, points }) => [id, teamName, rank, points])]));
    }
    function validateSnapshot(snapshot) {
        try {
            if (!snapshot || snapshot.schemaVersion !== 1 || snapshot.sourceUrl !== sourceUrl(snapshot.date)
                || !Number.isSafeInteger(snapshot.fetchedAt) || snapshot.fetchedAt < dateValue(snapshot.date).getTime()
                || !snapshot.teamsById || typeof snapshot.teamsById !== 'object' || Array.isArray(snapshot.teamsById)) return false;
            const rows = Object.entries(snapshot.teamsById).sort((a, b) => a[1]?.rank - b[1]?.rank);
            if (!rows.length || rows.length > 10000) return false;
            if (rows.some(([id, team], index) => !ID.test(id) || team?.id !== id || !name(team.name)
                || team.name !== name(team.name) || team.name.length > 100 || team.rank !== index + 1
                || !Number.isSafeInteger(team.points) || team.points < 0 || team.points > 1000
                || (index > 0 && team.points > rows[index - 1][1].points))) return false;
            return typeof snapshot.checksum === 'string' && /^[a-f0-9]{64}$/.test(snapshot.checksum) && snapshot.checksum === checksum(snapshot);
        } catch { return false; }
    }
    function parseSnapshot(document, { date, sourceUrl: requestedUrl, fetchedAt }) {
        const expectedUrl = sourceUrl(date);
        const invalid = () => { throw new Error('Invalid complete world ranking snapshot.'); };
        if (requestedUrl !== expectedUrl || !document?.querySelectorAll) return invalid();
        const canonicals = [...document.querySelectorAll('link[rel="canonical"]')];
        if (canonicals.length !== 1 || canonicals[0].getAttribute('href') !== expectedUrl) return invalid();
        const reference = dateValue(date);
        const day = reference.getUTCDate();
        const headingPattern = new RegExp(`^Counter-Strike(?: 2|: Global Offensive)? World ranking on ${MONTHS[reference.getUTCMonth()]} ${day}(?:st|nd|rd|th)?,? ${reference.getUTCFullYear()}$`, 'i');
        const headings = [...document.querySelectorAll('.regional-ranking-header-text, h1')];
        if (!headings.some((heading) => headingPattern.test(name(heading.textContent)))) return invalid();
        const active = [...document.querySelectorAll('.navItem.active')].filter((node) => /ranking\/teams\//.test(node.getAttribute('href') || ''));
        if (active.length && (active.length !== 1 || new URL(active[0].getAttribute('href'), ORIGIN).href !== expectedUrl
            || !/^World(?: ranking)?$/i.test(name(active[0].textContent)))) return invalid();
        if (/\b(?:just a moment|access denied|captcha|log[ -]?in|error)\b/i.test(document.title || document.querySelector('title')?.textContent || '')
            || document.querySelector('#challenge-running, #challenge-stage, .cf-challenge, form[action*="challenge"]')) return invalid();
        // Native next navigation advances to another complete weekly ranking;
        // it does not paginate teams within this snapshot. Accept only exact
        // canonical world-ranking URLs for a later Monday.
        for (const next of document.querySelectorAll('.pagination-next:not(.disabled), a[rel~="next"]:not(.disabled)')) {
            // The latest native week uses an inactive anchor without href.
            // A destination, even on an inactive anchor, must still validate.
            if (next.classList.contains('inactive') && !(next.getAttribute('href') || '').trim()) continue;
            let valid = false;
            try {
                const url = new URL(next.getAttribute('href'), ORIGIN);
                const match = /^\/ranking\/teams\/(\d{4})\/([a-z]+)\/([1-9]\d?)$/.exec(url.pathname);
                if (match) {
                    const nextDate = `${match[1]}-${String(MONTHS.indexOf(match[2]) + 1).padStart(2, '0')}-${match[3].padStart(2, '0')}`;
                    valid = nextDate > date && url.href === sourceUrl(nextDate);
                }
            } catch { /* Invalid or non-Monday ranking destination. */ }
            if (!valid) return invalid();
        }
        const rows = [...document.querySelectorAll('.ranked-team')];
        const list = rows[0]?.parentElement;
        const tail = list?.nextElementSibling;
        // Native current and historical pages close the full list with this
        // methodology block. Its presence rejects a truncated top-N response
        // without imposing a fixed historical team count.
        if (!rows.length || rows.some((row) => row.parentElement !== list)
            || !list.parentElement?.matches('.ranking') || list.lastElementChild !== rows.at(-1)
            || !tail?.matches('.description-box') || list.parentElement.lastElementChild !== tail
            || name(tail.querySelector('h1')?.textContent) !== "HLTV's world ranking of Counter-Strike Teams") return invalid();
        const teamsById = Object.create(null);
        for (const row of rows) {
            const rankText = name(row.querySelector('.position')?.textContent);
            const pointsText = name(row.querySelector('.points')?.textContent);
            if (!/^#[1-9]\d*$/.test(rankText) || !/^\(\d+ HLTV points?\)$/.test(pointsText)) return invalid();
            const ids = new Set();
            for (const anchor of row.querySelectorAll('a[href]')) {
                const url = new URL(anchor.getAttribute('href'), ORIGIN);
                const match = /^\/team\/([1-9]\d{0,19})(?:\/|$)/.exec(url.pathname)
                    || /^\/ranking\/teams\/\d{4}\/[a-z]+\/\d{1,2}\/details\/([1-9]\d{0,19})(?:\/|$)/.exec(url.pathname);
                if (match) {
                    if (url.origin !== ORIGIN || url.username || url.password || url.search || url.hash) return invalid();
                    if (url.pathname.includes('/details/') && url.pathname.split('/details/')[0] !== new URL(expectedUrl).pathname) return invalid();
                    ids.add(match[1]);
                }
            }
            if (ids.size !== 1) return invalid();
            const id = [...ids][0];
            if (teamsById[id]) return invalid();
            teamsById[id] = { id, name: name(row.querySelector('.name')?.textContent), rank: Number(rankText.slice(1)), points: Number(/^\((\d+)/.exec(pointsText)[1]) };
        }
        const snapshot = { schemaVersion: 1, date, sourceUrl: expectedUrl, fetchedAt, teamsById };
        snapshot.checksum = checksum(snapshot);
        if (!validateSnapshot(snapshot)) return invalid();
        return snapshot;
    }
    Object.defineProperty(globalThis, 'HLTV_RANKING_SNAPSHOTS', { value: Object.freeze({ weekBefore, sourceUrl, validateSnapshot, parseSnapshot }), configurable: true });
})();
