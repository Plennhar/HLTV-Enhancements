# Trademark and Affiliation Notice

HLTV Enhancements is an independent, unofficial project.  It is not
affiliated with, sponsored by, endorsed by, or approved by HLTV.org or its
owners.

HLTV and related names, logos, and marks belong to their respective owners.
Their names are used only to identify the website with which this extension
works.

The bundled extension icon incorporates the HLTV 2017 logo as a referential
element inside a distinct original composition depicting a magic wand applying
enhancements.  The mark is used only to identify compatibility with HLTV.org.
Its inclusion does not indicate that this extension is an official HLTV
product or that HLTV has sponsored, endorsed, approved, or reviewed it.

Copyright provenance for the incorporated logo artwork is recorded in
`THIRD_PARTY_NOTICES.md`.  A copyright classification does not grant trademark
permission.  All trademark rights remain with their respective owners.
