# Screenshot assets

Store visual setting examples here.

Packaged files are declared explicitly in the exact allowlists in
`background/screenshot-loader.js` and `content/screenshot-help.js`. Add any new
image to both allowlists before referencing it from setting help.

The content helper must resolve setting-help targets only through registered
private settings roots.  Do not add a light-DOM ID fallback: a page element
whose ID collides with a setting-help ID must be ignored, and a missing private
root must fail closed without attaching image data.

Crop screenshots to the feature being explained. Remove private account data,
credentials, tokens, email addresses, private messages, and other non-public
or sensitive material before packaging. Review visible usernames, labels,
forum text, likenesses, and other third-party material for context and
right-to-use concerns. PNG is retained for the supplied captures to avoid
lossy re-encoding.

The bundled set must contain only images present in both code allowlists.
Adding or restoring an image requires updating both allowlists, reviewing
every visible item, and confirming the right to distribute the result inside
the extension as well as on any public gallery.  Deleted captures must not
remain in a release archive.

## Filename-matched feature examples

The following supplied captures map directly to the named setting help. The
source filenames are retained so the association remains reviewable:

- `compare_player-page_statistics_with_another_date_period.png` — Compare
  player-page statistics with another date period.
- `show_a_player_consistency_score.png` — Show a player consistency score.
- `enhance_player_comparison_pages.png` and
  `bug_comparison_page_graph_color.png` — Enhance player comparison pages.
- `add_a_map-by-stat_matrix_to_player_pages.png` — Add a map-by-stat matrix to
  player pages.
- `show_team_overperformance_score.png` — Show team Overperformance Score.
- `compare_stats-table_data_with_another_date_period.png` — Compare stats-table
  data with another date period.
- `show_selectable_player_match-history_trends.png` — Show selectable player
  match-history trends.
- `enable_multi-column_sorting.png` — Enable multi-column sorting.
- `enable_stats-table_column_controls.png` — Enable stats-table column
  controls.
- `show_full_map_names_on_player_match_history_pages.png` — Show full map names
  on player match-history pages.
- `enable_right-lcikc_username_actions.png` — Enable right-click username
  actions (the supplied filename is retained verbatim).
- `enable_local_user_tags.png` — Enable local user tags.
- `show_relative_post_ages_in_threads_and_previews.png` — Show relative post
  ages in threads and previews.
- `show_match_result_predictions.png` — Show match result predictions.
- `show_recent-form_statistics_on_match_lineups.png` — Show recent-form
  statistics on match lineups.
- `show_a_sticky_match_header_while_scrolling.png` — Show a sticky match header
  while scrolling.
- `add_more_teams_to_the_match_filter.png` — Add more teams to the match
  filter.
- `move_post_new_topic_to_the_top_of_the_sidebar.png` — Move Post new topic to
  the top of the sidebar.
