# Chromium desktop edition

Build the current HLTV Enhancements 2.4 runtime for desktop browsers using
Chromium 148 or newer:

```sh
npm ci --ignore-scripts --no-audit --no-fund
npm run build:chromium
```

Requires Node.js 24.x, npm 11.x, and `unzip` on PATH. Output:

- `chromium-dist/hltv_enhancements-2.4-chromium.zip`
- `chromium-dist/hltv_enhancements-2.4-chromium.zip.sha256`
- `chromium-dist/hltv-enhancements/` (the same package, unpacked)

Extract the ZIP to a permanent folder. In the browser's extensions manager,
enable Developer mode, choose **Load unpacked**, and select the folder that
contains `manifest.json`. Chrome uses `chrome://extensions`, Edge uses
`edge://extensions`, and other Chromium browsers provide an equivalent page.
Keep the folder in place and reload existing HLTV tabs.

For updates, export local data first, replace files in the same folder, click
**Reload** on the existing extension, and reload HLTV tabs. Keeping the folder
and installed extension preserves its identity and settings. Unpacked copies
do not receive store updates. Browser or organization policy may restrict
unpacked extensions. No store submission or publication is part of this build.

## Shared source and native APIs

This package derives directly from the current Firefox source. It includes the
2.4 opponent adjustment, ranking history with the 15-fetch limit, prediction
modes (Market + stats, Stats only, Market-estimated), profile/comparison
features, and the master Disable setting. Global settings use the shared popup
and on-site cog implementation.

The build replaces Firefox background scripts with a native MV3 service worker
and adds `offscreen` to the existing `storage` permission. It retains the exact
HLTV content-script site scope and adds no host permissions. Chromium 148+
provides the native `browser` namespace and Promise messaging used by this
edition. There is no API polyfill or developer server.

The build derives the offscreen parser from the exact current Firefox parsing
and validation functions, including team-history date and identity checks.
The worker delegates only DOM parsing to that extension-owned document.
HTML uses the native Sanitizer API before DOM parsing; missing sanitizer support
fails closed. Network requests remain in the requesting HLTV tab with the
shared size, attempt, origin, cancellation, and scheduled-start limits.
The parser accepts calls only from this extension's service worker.

Four packaged files have guarded browser adaptations: the prediction fetcher
uses offscreen parsing, the core recognizes Chromium extension URLs, and the
core/diagnostics/popup redact Chromium extension URLs in diagnostics. Everything
else in the canonical runtime is copied byte for byte. Neither the canonical
Firefox directory nor existing Firefox release archives are modified.

## Verification

`npm run ci` runs syntax checks, Firefox lint, the complete shared test suite,
and the Chromium package/worker/offscreen regressions. Package checks validate
ZIP integrity, manifest and inventory, extracted byte parity, current-source
parity, and the absence of Mozilla settings or extra host permissions.

The worker and offscreen tests use Node VM/JSDOM with mocked extension APIs and
a sanitizer fixture. These verify integration logic, not native browser APIs.
A native browser smoke test of this 2.4 package has not yet been performed.
Individual Chrome, Edge, Brave, Opera/GX, Vivaldi, browser/OS combinations remain
unverified. Before claiming one verified, load this exact package and exercise
popup Save/Cancel/reopen, the on-site cog, all prediction modes, ranking cache,
Disable/re-enable across reloads, private replies, previews, screenshots, and
worker restart/offscreen reuse using synthetic data. Do not send posts or votes
for smoke testing.
