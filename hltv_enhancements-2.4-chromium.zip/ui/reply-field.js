// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Plennhar

(() => {
    'use strict';

    const TOKEN_PATTERN = /^[A-Za-z0-9_-]{43}$/;
    const token = String(location.hash || '').slice(1);
    const textarea = document.getElementById('reply');
    const suggestions = document.getElementById('suggestions');
    if (!TOKEN_PATTERN.test(token)
        || !(textarea instanceof HTMLTextAreaElement)
        || !(suggestions instanceof HTMLElement)
        || !browser?.runtime?.connect) {
        document.body.replaceChildren();
        return;
    }

    const RECONNECT_DELAYS_MS = Object.freeze([0, 50, 250, 1_000, 3_000]);
    let port = null;
    let reconnectTimer = 0;
    let reconnectAttempt = 0;
    let connectionGeneration = 0;
    let disposed = false;
    let ready = false;
    let hasDraft = false;
    let disabled = false;
    let prefixTimer = 0;
    let prefixSequence = 0;
    let activePrefixRequest = '';
    let activeIndex = -1;

    function send(message) {
        if (disposed || !port) return false;
        try {
            port.postMessage({ ...message, token });
            return true;
        } catch {
            return false;
        }
    }

    function stopReconnectTimer() {
        if (!reconnectTimer) return;
        clearTimeout(reconnectTimer);
        reconnectTimer = 0;
    }

    function scheduleReconnect() {
        if (disposed || reconnectTimer || reconnectAttempt >= RECONNECT_DELAYS_MS.length) {
            return;
        }
        const delay = RECONNECT_DELAYS_MS[reconnectAttempt];
        reconnectAttempt += 1;
        reconnectTimer = setTimeout(() => {
            reconnectTimer = 0;
            connect();
        }, delay);
    }

    function handleDisconnect(activePort, generation) {
        if (disposed || port !== activePort || generation !== connectionGeneration) return;
        port = null;
        ready = false;
        textarea.disabled = false;
        closeSuggestions();
        try {
            activePort.disconnect();
        } catch {
            // The failed Port may already be disconnected.
        }
        scheduleReconnect();
    }

    function handleMessage(message, activePort, generation) {
        if (disposed
            || port !== activePort
            || generation !== connectionGeneration
            || message?.token !== token) return;
        switch (message.type) {
            case 'ready':
                ready = true;
                reconnectAttempt = 0;
                textarea.disabled = disabled;
                if (!send({ type: 'state', hasDraft })) {
                    handleDisconnect(activePort, generation);
                }
                break;
            case 'parent-disconnected':
                ready = false;
                textarea.disabled = false;
                closeSuggestions();
                break;
            case 'closed':
                disposed = true;
                ready = false;
                stopReconnectTimer();
                textarea.disabled = false;
                closeSuggestions();
                try {
                    activePort.disconnect();
                } catch {
                    // The router may already have disconnected the Port.
                }
                break;
            case 'configure':
                if (typeof message.placeholder !== 'string'
                    || typeof message.label !== 'string') return;
                textarea.placeholder = message.placeholder;
                textarea.setAttribute('aria-label', message.label);
                break;
            case 'focus':
                textarea.focus();
                break;
            case 'set-disabled':
                if (typeof message.disabled === 'boolean') {
                    disabled = message.disabled;
                    textarea.disabled = disabled;
                }
                break;
            case 'clear':
                textarea.value = '';
                textarea.blur();
                closeSuggestions();
                publishDraftState();
                break;
            case 'request-text':
                if (typeof message.requestId !== 'string') return;
                send({
                    type: 'text-response',
                    requestId: message.requestId,
                    text: textarea.value,
                });
                break;
            case 'restore-text':
                if (typeof message.requestId !== 'string'
                    || typeof message.text !== 'string'
                    || message.text.length > 50_000) return;
                {
                    const restored = !textarea.value;
                    if (restored) {
                        textarea.value = message.text;
                        closeSuggestions();
                        publishDraftState();
                    }
                    send({
                        type: 'restore-response',
                        requestId: message.requestId,
                        restored,
                        reason: restored ? '' : 'not-empty',
                    });
                }
                break;
            case 'suggestions-response':
                if (message.requestId !== activePrefixRequest
                    || !Array.isArray(message.names)) return;
                if (findPrefix()) renderSuggestions(message.names);
                else closeSuggestions();
                break;
            default:
                break;
        }
    }

    function connect() {
        if (disposed || port) return;
        const generation = ++connectionGeneration;
        let nextPort;
        try {
            nextPort = browser.runtime.connect({ name: 'hltv-sp:reply-field' });
        } catch {
            scheduleReconnect();
            return;
        }
        port = nextPort;
        nextPort.onMessage.addListener((message) => {
            handleMessage(message, nextPort, generation);
        });
        nextPort.onDisconnect.addListener(() => {
            handleDisconnect(nextPort, generation);
        });
        if (!send({ type: 'register', role: 'child' })) {
            handleDisconnect(nextPort, generation);
        }
    }

    function publishDraftState() {
        const nextHasDraft = Boolean(textarea.value);
        if (nextHasDraft === hasDraft && ready) return;
        hasDraft = nextHasDraft;
        if (ready) send({ type: 'state', hasDraft });
    }

    function closeSuggestions() {
        activePrefixRequest = '';
        activeIndex = -1;
        suggestions.hidden = true;
        suggestions.replaceChildren();
    }

    function findPrefix() {
        const cursor = textarea.selectionStart;
        if (!Number.isInteger(cursor) || cursor !== textarea.selectionEnd) return null;
        const before = textarea.value.slice(0, cursor);
        const match = before.match(/(?:^|[\s(])@([A-Za-z0-9_.-]{1,100})$/);
        if (!match) return null;
        return {
            prefix: match[1],
            start: cursor - match[1].length - 1,
            end: cursor,
        };
    }

    function renderSelectedSuggestion() {
        [...suggestions.querySelectorAll('button')].forEach((button, index) => {
            button.setAttribute('aria-selected', index === activeIndex ? 'true' : 'false');
        });
    }

    function insertSuggestion(name) {
        const prefix = findPrefix();
        if (!prefix) return;
        textarea.setRangeText(`@${name}\u2063`, prefix.start, prefix.end, 'end');
        publishDraftState();
        closeSuggestions();
        textarea.focus();
    }

    function renderSuggestions(names) {
        suggestions.replaceChildren();
        for (const name of names) {
            const option = document.createElement('button');
            option.type = 'button';
            option.setAttribute('role', 'option');
            option.textContent = name;
            option.addEventListener('mousedown', (event) => event.preventDefault());
            option.addEventListener('mouseenter', () => {
                activeIndex = names.indexOf(name);
                renderSelectedSuggestion();
            });
            option.addEventListener('click', () => insertSuggestion(name));
            suggestions.appendChild(option);
        }
        activeIndex = names.length ? 0 : -1;
        renderSelectedSuggestion();
        suggestions.hidden = !names.length;
    }

    function schedulePrefixRequest() {
        clearTimeout(prefixTimer);
        const match = findPrefix();
        if (!match || !ready) {
            closeSuggestions();
            return;
        }
        const requestId = `p${++prefixSequence}`;
        activePrefixRequest = requestId;
        prefixTimer = setTimeout(() => {
            if (activePrefixRequest !== requestId
                || findPrefix()?.prefix !== match.prefix) return;
            send({
                type: 'prefix-request',
                requestId,
                prefix: match.prefix,
            });
        }, 180);
    }

    document.addEventListener('click', () => {
        if (ready) send({ type: 'click' });
    }, true);

    textarea.addEventListener('input', () => {
        publishDraftState();
        schedulePrefixRequest();
    });
    textarea.addEventListener('click', schedulePrefixRequest);
    textarea.addEventListener('keydown', (event) => {
        const options = [...suggestions.querySelectorAll('button')];
        if (event.key === 'Escape') {
            closeSuggestions();
        } else if (options.length && (event.key === 'ArrowDown' || event.key === 'ArrowUp')) {
            event.preventDefault();
            const direction = event.key === 'ArrowDown' ? 1 : -1;
            activeIndex = (activeIndex + direction + options.length) % options.length;
            renderSelectedSuggestion();
            options[activeIndex]?.scrollIntoView({ block: 'nearest' });
        } else if (options.length && event.key === 'Enter' && activeIndex >= 0) {
            event.preventDefault();
            insertSuggestion(options[activeIndex].textContent || '');
        }
    });
    textarea.addEventListener('blur', () => setTimeout(closeSuggestions, 120));

    globalThis.addEventListener('pagehide', () => {
        if (disposed) return;
        send({ type: 'close' });
        disposed = true;
        ready = false;
        stopReconnectTimer();
        try {
            port?.disconnect();
        } catch {
            // The router may already have disconnected the Port.
        }
        port = null;
    });
    connect();
})();
